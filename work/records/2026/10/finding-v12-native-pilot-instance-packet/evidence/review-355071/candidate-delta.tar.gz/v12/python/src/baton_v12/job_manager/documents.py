"""The versioned documents this control plane reads and answers with.

W71875. Two documents cross this leaf's boundary and they travel in opposite
directions: a SUBMISSION arrives from an operator or another program, and a
STATUS document leaves for one. Both carry an explicit schema name with its
version in it, because a control plane that accepts "whatever the last build
wrote" cannot tell an old operator from a wrong one.

WHAT IS OWNED HERE AND WHAT IS NOT. The submission is caller input and is
owned member by member: exact built-in data, a closed member set, closed
vocabularies, resolvable stage-scoped dependencies and no cycle. The status
document is this build's own answer and is assembled through closed
constructors, which fix its SHAPE and say nothing about its members' values --
the same split `worker_manager.boundaries` and `worker_manager.documents` make
one layer down, for the same reason.

THE SUBMISSION IS NOT A PLAN OF SHELL COMMANDS. It names Jobs, their immutable
input identities, the stages each Job owes, the runtime profile each stage
requests, the bounded test-change scope the Work was accepted with, and the
terminal policy. Everything else -- which worker runs it, where its workspace
is, what a reviewer decides, what an integrator imports -- belongs to the other
leaves of W71830 and is deliberately absent rather than stubbed.

THE DOCUMENT, WRITTEN OUT ONCE. Two independent Jobs from one baseline, one of
them with a review stage gated on its own implementation:

    {
      "schema": "baton.v12.job-submission/1",
      "submission_id": "sub-1",
      "jobs": [
        {
          "job_id": "job-a",
          "input_digest": "sha256:...",
          "policy_digest": "sha256:...",
          "test_scope": ["v12/python/tests/job_manager"],
          "terminal_policy": "report-and-hold",
          "stages": [
            {"kind": "implementation", "work_id": "0000000a-W1",
             "profile_name": "reference", "profile_digest": "sha256:...",
             "depends_on": []},
            {"kind": "review", "work_id": "0000000a-W2",
             "profile_name": "reviewer", "profile_digest": "sha256:...",
             "depends_on": [{"job_id": "job-a",
                             "kind": "implementation"}]}
          ]
        },
        {
          "job_id": "job-b",
          "input_digest": "sha256:...",
          "policy_digest": "sha256:...",
          "test_scope": [],
          "terminal_policy": "report-and-hold",
          "stages": [
            {"kind": "implementation", "work_id": "0000000a-W3",
             "profile_name": "reference", "profile_digest": "sha256:...",
             "depends_on": []}
          ]
        }
      ]
    }

Every member is required and no other member is admitted, so a document that
grows a field this build does not name is refused rather than half-read. A
stage is identified by its Job and its kind, which is why one Job carries at
most one stage of each kind and why a dependency names exactly that pair.
"""

from . import execution_limits
from ..contracts import (ContractRefusal, canonical_text,
                         check_relative_path, own)
from ..contracts.errors import name_value, sample_of
from ..worker_manager import boundaries

__all__ = ["ACTS", "CONTRACTS", "CORRECTION_ENDINGS", "DEPENDENCY_MEMBERS",
           "EPISODE_ENDINGS", "EXCLUSION_ENDINGS",
           "ABANDONED_RESTART_SCHEMA", "abandoned_restart",
           "EXCHANGE_ACTS", "stage_exchange",
           "JOB_MEMBERS",
           "MAX_JOBS", "MAX_STAGES", "REPLACEABLE_ENDINGS", "STAGE_KINDS",
           "STAGE_MEMBERS", "STAGE_STATES", "STATUS_SCHEMA",
           "SUBMISSION_LIMITS_SCHEMAS",
           "SUBMISSION_MEMBERS", "SUBMISSION_SCHEMA", "SUBMISSION_SCHEMAS",
           "TERMINAL_POLICIES",
           "TERMINAL_STAGE_STATES", "act", "correction", "dependency_gate",
           "job_status",
           "owned_submission", "read_submission", "receipt", "reconciliation",
           "stage_episode", "stage_id", "stage_launch", "stage_status",
           "status",
           "submission_recorded", "submission_signature", "sweep_report"]

# W156162 moved this to /2. A Job may now carry `execution_limits`, and a
# reader written against /1 would see a Job whose provider turn and verification
# commands have ceilings it does not know were configured. The version is in the
# name so that reader is told rather than left to find out.
#
# /1 IS STILL READ, AND THAT IS THE POINT. The owner's decision preserves every
# runner default for a Job that states nothing, and a /1 submission states
# nothing -- so it resolves to exactly the behaviour it had before this Work.
# Refusing /1 would have made a compatibility promise into a migration.
SUBMISSION_SCHEMA = "baton.v12.job-submission/2"
SUBMISSION_SCHEMAS = ("baton.v12.job-submission/1", SUBMISSION_SCHEMA)
# Which submitted members each version admits. `execution_limits` is optional
# even in /2: a Job that configures nothing is the ordinary case.
SUBMISSION_LIMITS_SCHEMAS = (SUBMISSION_SCHEMA,)
# W73629 moved this to /2. A stage now reports the EPISODES it has been through
# and its offer/attempt identities name the current one, so a reader written
# against /1 would see one stage's history as the stage itself. The version is
# in the name so that reader is told rather than left to find out.
# W81857 moved this to /3. A stage no longer reports `running` on the
# strength of an attached runtime identity: the vocabulary gains
# `starting`, `waiting` and `answering`, and every stage carries the
# canonical file-exchange projection beside its runtime. A reader written
# against /2 would see a started container it used to be told was working, and
# the version is in the name so that reader is told rather than left to find
# out.
# W71877 moved this to /4. A stage now reports its scheduler allocation
# history beside the Worker Manager's assignment and runtime identities.
# W156162 moved this to /5. A Job now reports its requested and EFFECTIVE
# execution limits with their units, scope and origins, and a reader written
# against /4 would not know a ceiling had been configured at all.
# W333486: AND /7 ADDS `attempt_diagnostics` TO EVERY STAGE. What an older
# reader would not know was recorded is WHICH COMPONENT OF THE WORKER MANAGER
# ORDERED THIS ATTEMPT'S RUNTIME STOPPED, under which operation identity, with
# what engine outcome, and whether cessation was established -- plus the token
# axis, the revocation and the completion the token journal holds. A /6 reader
# sees a stage with no diagnostic and reads it as "nobody looked", which is
# the honest thing for it to read: the member is OPTIONAL in the contract, so
# a document composed before it existed is still a valid one.
#
# AND IT IS A DIAGNOSTIC, NOT A STATE. Nothing in the projection branches on
# it and no stage state is derived from it; a diagnostic cause is not an
# acceptance and must not become a second route to `exceptional`.
STATUS_SCHEMA = "baton.v12.job-status/7"

# The three stages this milestone's vertical slice has. They are a CLOSED
# vocabulary rather than free text because the projection below maps each one
# onto the state an operator reads -- `reviewing` is what a claimed review
# stage is, and a kind nobody named could only be projected as a guess.
STAGE_KINDS = ("implementation", "review", "integration")

# W71830's first-slice ruling, as a vocabulary of exactly one member: a wedged
# or failed Job is REPORTED AND CONTAINED, and this leaf does not discard,
# accept or reassign its output. A second policy is a later decision with a
# later record; an enum of one says the decision was made rather than skipped.
TERMINAL_POLICIES = ("report-and-hold",)

# What a stage may be, in the vocabulary the acceptance bullet names. Every
# one of these is DERIVED at read time from persisted receipts plus canonical
# manager state -- none of them is a column this leaf advances on its own.
# W81857 added three, and the reason each one exists is that the state it
# replaced was a lie.
#
# `starting` is a claimed stage whose runtime is attached and which this
# control plane has NOT commanded, or cannot see a command for. It is what
# `running` used to say, and saying `running` there is the whole defect: the
# retained W71917 container was healthy, idle and projected as work in
# progress for as long as anybody cared to look.
#
# `waiting` is a stage whose command is published and whose worker has not
# accepted it yet. The manager has done everything it owes and the container
# has not answered -- which is a real, bounded, ordinary state and is not the
# same as either of its neighbours.
#
# `answering` is a stage whose worker published a valid terminal answer and
# whose output is not frozen yet. The turn is over and the ending is owed;
# calling that `completed` would report a result nobody has taken custody of,
# and calling it `running` would report a provider that has stopped.
STAGE_STATES = ("blocked", "queued", "offered", "claimed", "starting",
                "waiting", "running", "reviewing", "integrating", "answering",
                "changes-requested", "completed", "exceptional")

# Where a stage stops being something this control plane owes an act for.
# `changes-requested` is terminal FOR THIS LEAF and not for the pipeline: the
# same-line correction cycle is W71918's, and inventing a second offer here
# would be this leaf building the state machine it was told not to build.
TERMINAL_STAGE_STATES = ("changes-requested", "completed", "exceptional")

# Which canonical offer endings END THIS STAGE'S EXECUTION EPISODE.
#
# A TERMINAL OFFER IS NOT A TERMINAL STAGE, and review [P1, 2026-09-03] is what
# that sentence cost. `claimed` is terminal for the OFFER -- there is nothing
# further to do to it -- and it is the one ending that means the stage's
# execution is going WELL: the claim was taken, the attempt the offer froze is
# the one now running, and everything the projection reports about that stage
# from here comes from that same attempt. Ending the episode on it cleared the
# stage's current offer and attempt identities, stopped observing the running
# attempt, and reported a claimed stage as `exceptional` at its next restart --
# a stage that was working, broken by the machinery meant to recover the ones
# that were not.
#
# So this set is the offer endings that end an EXECUTION, and `claimed` is
# deliberately absent from it. The others all mean the same thing in different
# words: this offer will never produce a claim, so nothing is going to run on
# the attempt it froze.
EPISODE_ENDINGS = ("abandoned-after-restart", "claim-refused", "declined",
                   "expired", "settlement-expired")

# Which of those endings make the stage's episode REPLACEABLE, as a
# closed set with one member.
#
# W73629 reproduced and corrected exactly one: an offer a different manager
# incarnation abandoned because nothing durable proved its bearer was ever
# delivered. Nobody decided anything about that stage, so re-admitting it takes
# back nothing.
#
# `expired` and `declined` are DELIBERATELY ABSENT and are not oversights. An
# expired offer WAS delivered and its worker did not accept in time; a declined
# one was answered. Whether either should be re-offered, offered elsewhere, or
# reported is a scheduling policy decision that belongs to the pool leaf, and
# quietly re-offering here would be this leaf making it. Neither is hidden: an
# episode ending outside this set is recorded, stays in the status history, and
# projects the stage `exceptional`, so an operator sees a stage that stopped
# rather than one silently retrying.
# W128698: THE SECOND WAY AN EPISODE BECOMES REPLACEABLE, and it is NOT an
# offer ending.
#
# An operator declares an attempt abandoned; W128682 fences its generation,
# destroys the runtime and discharges the gate; W128692 restores the checkout
# to its retained checkpoint and excludes the old writer. What is left is a
# LIVE episode whose attempt can never answer, and nothing could end it -- so
# `manager._replace` never opened a successor and the Job stopped there. That
# is the defect W119114 measured.
#
# IT IS ITS OWN CLOSED SET, exactly as `CORRECTION_ENDINGS` is and for the same
# reason. `EPISODE_ENDINGS` is the Worker Manager's offer vocabulary minus
# `claimed` -- `manager.py` asserts that equality -- and nothing about an
# operator's declaration is something that happened to an OFFER: it was
# accepted, the claim was taken, a container ran. Putting this word in that set
# would break that assert at import and would file a claimed, executing round
# under a word for an offer nobody took.
EXCLUSION_ENDINGS = ("abandoned-after-exclusion",)

# Which of those endings make the stage's episode REPLACEABLE, as a closed set.
REPLACEABLE_ENDINGS = ("abandoned-after-restart", "abandoned-after-exclusion")

# Stated rather than assumed, and restated by W128698. A replaceable ending is
# an ending in ONE of the two vocabularies: the offer endings this control
# plane acts on, or the exclusion ending an operator's declaration reaches. It
# is deliberately not "an ending in EPISODE_ENDINGS" any more, because that set
# is the OFFER vocabulary and this ending is not an offer's.
assert frozenset(REPLACEABLE_ENDINGS) <= (
    frozenset(EPISODE_ENDINGS) | frozenset(EXCLUSION_ENDINGS))
assert not (frozenset(EXCLUSION_ENDINGS) & frozenset(EPISODE_ENDINGS))

# W103076: HOW AN EPISODE ENDS WHEN THE LINE ASKED FOR CHANGES, and it is a
# SEPARATE SET rather than a new member of `EPISODE_ENDINGS`.
#
# `EPISODE_ENDINGS` is exactly the Worker Manager's offer vocabulary minus
# `claimed` -- `manager.py` asserts that equality, and the assert is right.
# Every one of those endings is something that happened to an OFFER. A
# correction is not: the offer was accepted, the claim was taken, the worker
# answered and a reviewer read what it produced. What ends here is the
# episode, because the stage is going to be attempted again on the same
# development line, and calling that `declined` or `expired` would file a
# completed round of work under a word for an offer nobody took.
#
# IT IS DELIBERATELY NOT REPLACEABLE. `REPLACEABLE_ENDINGS` is what the sweep
# re-offers on its own authority; a correction opens both successors inside
# the SAME transaction that ends both predecessors, so by the time any sweep
# looks there is nothing owed. A correction ending that was also replaceable
# would be a second opener racing the first.
CORRECTION_ENDINGS = ("superseded-by-correction",)

assert not (frozenset(CORRECTION_ENDINGS) & frozenset(EPISODE_ENDINGS))
assert not (frozenset(CORRECTION_ENDINGS) & frozenset(REPLACEABLE_ENDINGS))
assert not (frozenset(CORRECTION_ENDINGS) & frozenset(EXCLUSION_ENDINGS))

# The two acts this leaf derives and delegates. Both are control-plane acts on
# the admission half of a stage; starting a runtime, freezing an output,
# deciding a review and importing a proposal are other leaves' operations and
# are absent here rather than represented by a placeholder.
ACTS = ("admit", "claim")

# W81857: THE TWO EXCHANGE ACTS, and they are deliberately not members of
# `ACTS`. `ACTS` is the closed set this leaf writes RECEIPTS for; these two
# write none, because the durable command file and each ending substep's own
# journalled operation are the records, and a second account of either here is
# the one this leaf could not keep true across the crash window it exists for.
EXCHANGE_ACTS = ("dispatch", "conclude")

# Bounds on one submission. A control plane that accepts an unbounded document
# accepts an unbounded amount of durable work from one call.
MAX_JOBS = 64
MAX_STAGES = len(STAGE_KINDS)

SUBMISSION_MEMBERS = ("schema", "submission_id", "jobs")
JOB_MEMBERS = ("job_id", "input_digest", "policy_digest", "test_scope",
               "terminal_policy", "stages")
# W156162: and the one OPTIONAL member, admitted only by the version that names
# it. A /1 document carrying it is refused as the unknown member it is there.
JOB_LIMIT_MEMBER = "execution_limits"
STAGE_MEMBERS = ("kind", "work_id", "profile_name", "profile_digest",
                 "depends_on")
DEPENDENCY_MEMBERS = ("job_id", "kind")


def _refuse(message):
    raise ContractRefusal("integrity", "schema", message)


def stage_id(job_id, kind):
    """The one spelling of a stage's identity, derived from what names it.

    A stage is one Job's one attempt at one kind, so its identity is those two
    facts and nothing else. Deriving it means a resubmission of the same
    intent addresses the same rows without an operator having to keep an id
    stable by hand -- which is what makes the submission idempotent from the
    caller's side rather than only from the store's.
    """
    return f"{job_id}/{kind}"


def read_submission(payload):
    """Decode submission TEXT and own it.

    The decode is where the trust domain is crossed, so the decode is where
    the owner lives -- `boundaries.adopted`'s rule, applied to a document that
    arrives on a file handle or a pipe instead of out of our own store.
    """
    return owned_submission(boundaries.adopted(payload, "a job submission"))


def owned_submission(document):
    """One submission, proved and returned in this build's own member order.

    THE ORDER IS THE POINT of returning a new document rather than the
    caller's. The submission's canonical text is its durable identity, and two
    spellings of one intent must not be two identities -- so the normalized
    document is what is signed, stored and compared, and a caller that spells
    its members in another order or pretty-prints its JSON resubmits the same
    submission rather than a conflicting one.
    """
    taken = boundaries.document(document, "a job submission",
                                required=SUBMISSION_MEMBERS)
    if taken["schema"] not in SUBMISSION_SCHEMAS:
        _refuse(f"a job submission is one of "
                f"{', '.join(name_value(one) for one in SUBMISSION_SCHEMAS)}; "
                f"this is {name_value(taken['schema'])}. The version is IN the "
                f"schema name because a control plane that reads an "
                f"unrecognised document as its own turns an old operator into "
                f"a wrong one")
    submission_id = boundaries.identity(taken["submission_id"],
                                        "a submission id")
    jobs = _sequence(taken["jobs"], "a job submission's jobs", MAX_JOBS)
    owned = [_job(entry, taken["schema"]) for entry in jobs]
    _unique([one["job_id"] for one in owned], "job id", "a job submission")
    _resolvable(owned)
    # THE DOCUMENT KEEPS ITS OWN VERSION. The normalized text is the durable
    # identity a resubmission is compared against, so rewriting a /1 caller's
    # document as /2 would give one intent two identities -- and would make an
    # old signed operation unreplayable after this build shipped.
    return {"schema": taken["schema"], "submission_id": submission_id,
            "jobs": owned}


def _sequence(value, what, limit):
    if type(value) is not list or value == []:
        _refuse(f"{what} is a non-empty list; this is {name_value(value)}")
    if len(value) > limit:
        _refuse(f"{what} carries {len(value)} entries and this build admits "
                f"{limit}; an unbounded submission is an unbounded amount of "
                f"durable work from one call")
    return value


def _unique(values, what, where):
    seen = set()
    repeated = set()
    for one in values:
        if one in seen:
            repeated.add(one)
        seen.add(one)
    if repeated:
        repeated = sorted(repeated)
        _refuse(f"{where} names {what} {sample_of(repeated)} more than once; "
                f"one identity naming two things is the conflict this control "
                f"plane refuses rather than resolves")


def _job(entry, schema=SUBMISSION_SCHEMA):
    optional = ((JOB_LIMIT_MEMBER,) if schema in SUBMISSION_LIMITS_SCHEMAS
                else ())
    taken = boundaries.document(entry, "a submitted Job", required=JOB_MEMBERS,
                                optional=optional)
    job_id = boundaries.identity(taken["job_id"], "a Job id")
    input_digest = boundaries.text(taken["input_digest"],
                                   "a Job's input digest")
    policy_digest = boundaries.text(taken["policy_digest"],
                                    "a Job's policy digest")
    if taken["terminal_policy"] not in TERMINAL_POLICIES:
        _refuse(f"a Job's terminal policy is one of "
                f"{', '.join(TERMINAL_POLICIES)}; this is "
                f"{name_value(taken['terminal_policy'])}")
    # THE BOUNDED TEST-CHANGE SCOPE TRAVELS WITH THE JOB. AGENTS.md makes an
    # accepted Work's explicit test scope the case-specific authority a later
    # reviewer and integrator check a proposal against, so a submission that
    # could not carry it would push that authority back into a message thread.
    # This leaf STORES it and enforces nothing with it: what a reviewer and an
    # integrator do with the scope is W71918's and W71878's.
    scope = _paths(taken["test_scope"], job_id)
    stages = _sequence(taken["stages"], f"Job {job_id}'s stages", MAX_STAGES)
    owned = [_stage(job_id, one) for one in stages]
    _unique([one["kind"] for one in owned], "stage kind", f"Job {job_id}")
    held = {"job_id": job_id, "input_digest": input_digest,
            "policy_digest": policy_digest, "test_scope": scope,
            "terminal_policy": taken["terminal_policy"], "stages": owned}
    # W156162: PRESENT ONLY WHEN THE JOB STATED IT. An absent member and an
    # empty object are different intents and both are admitted; what is not
    # admitted is this build inventing the member for a Job that never wrote
    # it, which would give every /1 Job a /2 identity.
    if JOB_LIMIT_MEMBER in taken:
        # AND A PRESENT NULL IS NOT AN OPTIONAL OBJECT. Review
        # 2026-09-13T01:13:49Z R2: `owned_execution_limits(None)` is an
        # INTERNAL convenience for a Job that stated nothing, and calling it for
        # a member the document really carries admitted `execution_limits: null`
        # and preserved that null as normalized intent. The contract is omit the
        # member or provide an object; the empty object stays admitted.
        if taken[JOB_LIMIT_MEMBER] is None:
            _refuse(f"a Job's {JOB_LIMIT_MEMBER} is an object of settings, "
                    f"omitted entirely when the Job configures nothing; this "
                    f"is {name_value(None)}, which is neither")
        held[JOB_LIMIT_MEMBER] = execution_limits.owned_execution_limits(
            taken[JOB_LIMIT_MEMBER])
    return held


def _paths(value, job_id):
    """The scope as a PATH SET, in one spelling each.

    Review [P1]: this owned each entry as text alone, and text alone accepted
    `../outside.py`, `/absolute.py` and `v12//dup.py` unchanged. That is not
    input tolerance here: the scope IS the bounded test-change authority a
    later reviewer and integrator check a proposal against, so an entry that
    climbs out of the repository or names one place twice is an authority
    nobody can evaluate against a changed-path list.

    `check_relative_path` is the contract that already says what a repository
    path is -- absolute, backslash, NUL, and empty, `.` or `..` segments are
    all refused there -- and reaching for it rather than restating it keeps one
    rule for every v12 path. Duplicates are refused on top of it, because two
    spellings of one authority set are two things a reviewer could be reading.
    """
    if type(value) is not list:
        _refuse(f"a Job's test scope is a list of repository-relative paths, "
                f"empty when the Work changes none; this is "
                f"{name_value(value)}")
    if len(value) > MAX_JOBS:
        _refuse(f"a Job's test scope names {len(value)} paths and this build "
                f"admits {MAX_JOBS}")
    scope = [check_relative_path(one, "a test-scope path") for one in value]
    _unique(scope, "test-scope path", f"Job {job_id}")
    return scope


def _stage(job_id, entry):
    taken = boundaries.document(entry, f"a stage of Job {job_id}",
                                required=STAGE_MEMBERS)
    if taken["kind"] not in STAGE_KINDS:
        _refuse(f"a stage kind is one of {', '.join(STAGE_KINDS)}; this is "
                f"{name_value(taken['kind'])}")
    kind = taken["kind"]
    work_id = boundaries.text(taken["work_id"], f"the Work {kind} stage names")
    profile_name = boundaries.text(taken["profile_name"],
                                   "a requested profile name")
    profile_digest = boundaries.text(taken["profile_digest"],
                                     "a requested profile digest")
    depends = _sequence_or_empty(taken["depends_on"],
                                 f"Job {job_id}'s {kind} dependencies")
    gates = [_dependency(job_id, kind, one) for one in depends]
    _unique([stage_id(one["job_id"], one["kind"]) for one in gates],
            "dependency", f"Job {job_id}'s {kind} stage")
    return {"kind": kind, "work_id": work_id, "profile_name": profile_name,
            "profile_digest": profile_digest, "depends_on": gates}


def _sequence_or_empty(value, what):
    # A stage with no predecessor is the ordinary case -- it is what lets two
    # Jobs fork from one baseline and run at once -- so an empty list is a
    # legitimate answer here and a missing member is still not.
    if type(value) is not list:
        _refuse(f"{what} is a list of stage-scoped dependencies, empty when "
                f"the stage has none; this is {name_value(value)}")
    if len(value) > MAX_JOBS * MAX_STAGES:
        _refuse(f"{what} names more dependencies than this build admits")
    return value


def _dependency(job_id, kind, entry):
    taken = boundaries.document(entry, f"a dependency of Job {job_id}'s "
                                       f"{kind} stage",
                                required=DEPENDENCY_MEMBERS)
    named = boundaries.identity(taken["job_id"], "a depended-on Job id")
    if taken["kind"] not in STAGE_KINDS:
        _refuse(f"a dependency names a stage kind out of "
                f"{', '.join(STAGE_KINDS)}; this is "
                f"{name_value(taken['kind'])}")
    if named == job_id and taken["kind"] == kind:
        _refuse(f"Job {name_value(job_id)}'s {kind} stage depends on itself; a "
                f"stage that gates on its own completion is never eligible")
    return {"job_id": named, "kind": taken["kind"]}


def _resolvable(jobs):
    """Every dependency names a stage this submission actually carries, and
    the graph has no cycle.

    BOTH, AND IN THIS ORDER. An unresolvable dependency is the likelier
    operator mistake and has the clearer diagnostic; a cycle is the one that
    would otherwise be discovered as "nothing is ever eligible", which reads
    as the scheduler being broken rather than as the submission being wrong.
    """
    present = {stage_id(job["job_id"], stage["kind"]): stage["depends_on"]
               for job in jobs for stage in job["stages"]}
    missing = sorted({stage_id(gate["job_id"], gate["kind"])
                      for gates in present.values() for gate in gates
                      if stage_id(gate["job_id"], gate["kind"])
                      not in present})
    if missing:
        _refuse(f"this submission gates on {sample_of(missing)}, which it does "
                f"not carry; a dependency on a stage outside the submission "
                f"is a gate nothing in it can ever open")
    _acyclic(present)


def _acyclic(present):
    # Kahn's ordering, over a graph whose size this document's own bounds have
    # already fixed. What survives with unmet gates is exactly the cycle.
    pending = {one: {stage_id(gate["job_id"], gate["kind"])
                     for gate in gates} for one, gates in present.items()}
    settled = set()
    moved = True
    while moved:
        moved = False
        for one in sorted(pending):
            if pending[one] <= settled:
                settled.add(one)
                del pending[one]
                moved = True
    if pending:
        _refuse(f"this submission's stage dependencies form a cycle through "
                f"{sample_of(sorted(pending))}; no stage in a cycle is ever "
                f"eligible, and refusing it at submission is the only moment "
                f"an operator can be told which stages are involved")


def submission_signature(owned):
    """The durable identity of one submitted intent.

    The canonical text of the NORMALIZED document, so an exact resubmission
    replays and a submission that changes any member of the intent collides
    rather than quietly rewriting durable rows.
    """
    return canonical_text(own(owned, what="a job submission"))


# -- the outbound half -------------------------------------------------------
#
# name -> (required, optional). One table, so "what does this control plane
# answer with" has a written answer rather than a survey of return statements.
# W128698: what ending one abandoned correction's episode answers. The two
# provider operation identities ride it because they are what authorized the
# act, and a consumer holding this document can re-read both of them.
ABANDONED_RESTART_SCHEMA = "baton.v12.abandoned-episode-restart/1"

CONTRACTS = {
    "stage.abandoned-restart": (("schema", "operation_id", "job_id",
                                 "stage_id", "episode", "attempt_id",
                                 "assignment", "line_id", "checkpoint_id",
                                 "preparation_operation_id",
                                 "discharge_operation_id", "ended_state"),
                                ()),
    "submission.recorded": (("submission_id", "signature", "jobs", "stages",
                             "recorded_at"), ()),
    "stage.act": (("stage_id", "job_id", "kind", "episode", "act",
                   "operation_id", "offer_id", "attempt_id", "work_id"), ()),
    "stage.receipt": (("stage_id", "episode", "act", "operation_id", "state",
                       "recorded_at", "detail"), ()),
    "stage.dependency-gate": (("stage_id", "state", "open"), ()),
    # One attempt at admitting one stage. `ended_state` is null while it is
    # live, and the three ending members travel together because an ending
    # nobody can order against the next assertion is not one.
    "stage.episode": (("stage_id", "episode", "offer_id", "attempt_id",
                       "opened_at", "incarnation", "ended_state",
                       "ended_revision", "ended_at"), ()),
    # `episode`, `offer_id` and `attempt_id` name the CURRENT episode and are
    # null between an ending and its replacement; `episodes` is the whole
    # append-only history, which is where an abandoned attempt stays visible.
    # W81857: `exchange` is the canonical file-exchange projection, beside
    # the runtime rather than folded into it. The two answer different
    # questions -- whether a container is up, and whether a turn is happening
    # inside it -- and the whole of this Work is that the first one was being
    # read as the second. `null` means this control plane holds no exchange
    # read at all, which is "nobody looked" and is deliberately distinguishable
    # from an exchange that has been looked at and carries no command.
    # W103076: ONE CORRECTION ROUND, which is one act about two stages. The
    # line, checkpoint and verdict identities are what AUTHORIZED the round and
    # are reported rather than stored; `ended` names the episode each stage
    # left, and the two episode documents are the ones it entered.
    "stage.correction": (("job_id", "work_id", "line_id", "checkpoint_id",
                          "verdict_id", "corrected_at", "ended",
                          "implementation", "review"), ()),
    "stage.status": (("stage_id", "job_id", "kind", "state", "work_id",
                      "profile_name", "profile_digest", "episode", "offer_id",
                      "attempt_id", "episodes", "corrections", "allocation",
                      "allocations", "gates", "receipts", "deferral",
                      "runtime", "exchange", "artifacts"),
                     ("attempt_diagnostics", "diagnostic_degradation",)),
    # W156162 added `execution_limits`, which is why STATUS_SCHEMA moved to /5.
    # W197661 added `deferral` to `stage.status`, which is why it is at /6: a
    # reader that must not mistake a re-enterable deferral for a state has to
    # be able to tell which shape it is holding.
    "job.status": (("job_id", "submission_id", "input_digest",
                    "policy_digest", "test_scope", "terminal_policy",
                    "execution_limits", "stages"), ()),
    "status": (("schema", "observed_at", "incarnation", "canonical",
                "jobs"), ()),
    "reconciliation": (("stage_id", "episode", "act", "outcome",
                        "operation_id"), ("detail",)),
    # W76207: ONE claimed stage's attempt at becoming a live worker. It is a
    # separate document from a reconciliation because it settles no receipt --
    # the acts it drives are journalled by the Worker Manager, and what this
    # leaf reports is which stage it asked for, and what came back.
    "stage.launch": (("stage_id", "episode", "attempt_id", "outcome"),
                     ("runtime_id", "detail")),
    # `recovered` is the manager's OWN restart report and is null on an
    # ordinary tick, so a reader can tell a resumed process from a running
    # one without keeping count of ticks. `observed` counts the canonical
    # state assertions this tick applied and `replaced` names the episodes it
    # opened because an earlier one ended -- a recovery that did something is
    # reported rather than inferred from the acts that followed it. `started`
    # names every claimed stage this tick asked the deployment to launch,
    # whatever came back.
    # W81857: `spoken` names every stage this tick published a command for
    # or drove through its ending, whatever came back. It is separate from
    # `started` for the reason `started` is separate from `acts`: they settle
    # no receipt, and what this leaf reports is which stage it asked for.
    # W85500: `refreshed` names every live attempt this tick asked the engine
    # about before it projected anything. It is separate from `observed` for
    # the reason `spoken` is separate from `started`: `observed` is canonical
    # state this manager drained, and this is the RUNTIME axis, which no
    # canonical assertion carries.
    "sweep": (("observed_at", "recovered", "observed", "replaced", "acts",
               "started", "spoken", "refreshed"), ()),
    # One live attempt's runtime refresh. `state` is what the reconciliation
    # recorded, or null when this tick could not ask. `detail` carries only
    # what this manager itself can name: a contained refusal's typed category
    # and code, or `uncertain / engine-unreachable` plus the type name of the
    # failure a deployment reported its engine with. Never a refusal's prose
    # and never an engine's message -- both are composed from bytes a worker
    # or a daemon wrote, and a sweep report is read by whoever watches the
    # service.
    "stage.refresh": (("stage_id", "episode", "attempt_id", "state"),
                      ("detail",)),
    # One claimed, started stage's attempt at being COMMANDED, or at being
    # ended after it answered. `act` is `dispatch` or `conclude`; `outcome` is
    # the same closed set a launch answers with, because the question is the
    # same one: did this tick perform it, defer it, or find it refused.
    "stage.exchange": (("stage_id", "episode", "attempt_id", "act",
                        "outcome"), ("detail",)),
}


def _emit(name, members):
    required, optional = CONTRACTS[name]
    missing = [member for member in required if member not in members]
    if missing:
        raise ContractRefusal(
            "integrity", "schema",
            f"this build assembled a {name} document without "
            f"{', '.join(missing)}; an answer that does not match its "
            f"contract is one no receiver can own")
    allowed = frozenset(required) | frozenset(optional)
    extra = sorted(member for member in members if member not in allowed)
    if extra:
        raise ContractRefusal(
            "integrity", "schema",
            f"this build assembled a {name} document carrying "
            f"{', '.join(extra)}, which its contract does not name")
    ordered = tuple(required) + tuple(member for member in optional
                                      if member in members)
    return {member: members[member] for member in ordered}


def submission_recorded(**members):
    return _emit("submission.recorded", members)


def act(**members):
    return _emit("stage.act", members)


def receipt(**members):
    return _emit("stage.receipt", members)


def dependency_gate(**members):
    return _emit("stage.dependency-gate", members)


def stage_episode(**members):
    return _emit("stage.episode", members)


def correction(**members):
    return _emit("stage.correction", members)


def abandoned_restart(**members):
    """W128698: the one episode an explicit abandonment recovery ended."""
    return _emit("stage.abandoned-restart", members)


def stage_status(**members):
    return _emit("stage.status", members)


def job_status(**members):
    return _emit("job.status", members)


def status(**members):
    return _emit("status", members)


def reconciliation(**members):
    return _emit("reconciliation", members)


def stage_launch(**members):
    return _emit("stage.launch", members)


def stage_exchange(**members):
    return _emit("stage.exchange", members)


def stage_refresh(**members):
    return _emit("stage.refresh", members)


def sweep_report(**members):
    return _emit("sweep", members)
