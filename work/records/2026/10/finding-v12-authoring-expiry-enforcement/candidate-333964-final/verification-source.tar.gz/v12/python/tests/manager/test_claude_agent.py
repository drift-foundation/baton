"""W39357 — the real Claude adapter, proved without a provider or a secret.

`work/records/2026/08/finding-v12-first-useful-dogfood-task/findings/
finding-real-claude-adapter-image/`.

WHY THERE IS NO LIVE PROVIDER HERE, and it is the acceptance's own decision
rather than a shortcut: the first live provider invocation needs the operator's
exact credential grant and an approved network posture, and it belongs to
W39364. What this file owns is everything a live run could not establish
deterministically anyway — the composed argv, the composed environment, the
credential boundary, the source copy, the write boundary, and the four ways a
turn fails to produce a candidate.

THE PROVIDER IS INJECTED, NOT MOCKED-OVER. `ClaudeAgent(run=...)` takes the
process-running capability, exactly as the manager's own components take theirs,
so what these cases drive is the real `work` path with one seam supplied.

NO SECRET EVER EXISTS IN THIS FILE. The credential is a file containing the
literal text `not-a-credential`, and one case asserts the adapter never opens
it.
"""

import json
import os
import pathlib
import shutil
import stat
import subprocess
import sys
import tempfile
import time
import unittest
from unittest import mock

WORKER = (pathlib.Path(__file__).resolve().parents[3] / "worker")
sys.path.insert(0, str(WORKER))
# W71917: AND THE PROFILE PACKAGE, UNDER THE NAME THE IMAGE GIVES IT.
# `Dockerfile.claude` copies `src/baton_v12/source_profiles` to
# `/opt/baton/source_profiles`, so inside the container it is a
# top-level package and `claude_agent` imports it as one. Putting its
# parent directory here reproduces that layout rather than relaxing the
# rule that this module can never spell `baton_v12`.
sys.path.insert(0, str(WORKER.parent / "python" / "src" / "baton_v12"))
shutil.rmtree(WORKER / "__pycache__", ignore_errors=True)

import claude_agent                                          # noqa: E402
from claude_agent import ClaudeAgent, TaskRefusal            # noqa: E402

DECLARED = [{"name": "proposal", "type": "directory-result",
             "path": "proposal", "required": True,
             "constraints": {"max_bytes": 1 << 20, "max_entries": 100,
                             "allowed_media_types": ["text/plain"],
                             "link_policy": "forbid",
                             "validator_digest": None}}]

# W71917 bumped this contract to `/2` and added the two members below. The
# generic profile is what this suite's staged trees are: an ordinary directory
# read in place, with no version-control fact declared about it -- which is
# also why `declared_base` is null here, since a generic profile carrying one
# is refused by the profile package itself.
TASK = {"schema": "baton.dogfood-task/2",
        "task_id": "w39364-ping-pong-coverage",
        "instructions": "Add focused unit coverage for _observed_readable.",
        "verification": ["python3", "harness.py"],
        "source_root": "source",
        "source_profile": "generic",
        "declared_base": None}


class TheContextEnvironmentRemainsPrivate(unittest.TestCase):
    def setUp(self):
        from tests.manager.test_claude_context import ServingContextCase
        self.case = ServingContextCase()
        self.addCleanup(self.case.doCleanups)
        self.case.setUp()

    def test_actual_child_environment_verifier_and_public_outputs_exclude_private_state(self):
        from baton_v12.worker_manager import intake_receipt_of
        captured = []
        original = ClaudeAgent._verify
        def verify(agent, task, candidate, environment, directories):
            captured.append(dict(environment))
            return original(agent, task, candidate, environment, directories)
        with mock.patch.object(ClaudeAgent, "_verify", verify):
            held = self.case.implemented()
        provider = self.case.actual_environments[0]
        self.assertEqual(set(provider), {"HOME", "PATH", "TMPDIR", "XDG_CACHE_HOME", "PYTHONPYCACHEPREFIX"})
        self.assertEqual(len(captured), 1)
        self.assertNotEqual(provider["HOME"], captured[0]["HOME"])
        self.assertFalse(captured[0]["HOME"].startswith(str(self.case.context_root)))
        for one in intake_receipt_of(held.control, held.attempt_id)["artifacts"]:
            root = pathlib.Path(one["custody_locator"][len("file://"):])
            for path in root.rglob("*"):
                if path.is_file():
                    self.assertNotIn(b"PRIVATE-CONTEXT-MARKER", path.read_bytes(), path.name)

    def test_injected_context_is_unknown_for_activity_even_on_initial_open(self):
        agent = ClaudeAgent()
        agent._seen = {"provider_context": {"mode": "open"}}
        agent._bound_activity("/tmp/unused-context-scratch")
        self.assertIsNone(agent.observed_activity())
        agent._seen["provider_context"]["mode"] = "restore"
        agent._bound_activity("/tmp/unused-context-scratch")
        self.assertIsNone(agent.observed_activity())


class AdapterCase(unittest.TestCase):
    """A staged `/input`, a writable `/output`, and no provider.

    THE ROOTS ARE PATCHED ON THE MODULE, like `test_worker_image` does with the
    worker's own: they are CONSTANTS of the workload contract, so there is no
    operand for a fixture to supply. A test may reach into the module; a caller
    may not reach into the contract.
    """

    def setUp(self):
        home = tempfile.mkdtemp(prefix="v12-w39357-")
        self.addCleanup(shutil.rmtree, home, True)
        self.home = home
        self.inputs = os.path.join(home, "input")
        self.outputs = os.path.join(home, "output")
        self.scratch = os.path.join(home, "scratch")
        self.credentials = os.path.join(home, "credentials")
        for place in (self.inputs, self.outputs, self.scratch,
                      self.credentials):
            os.makedirs(place)
        self.source = os.path.join(self.inputs, "source")
        os.makedirs(self.source)
        self.write(os.path.join(self.source, "harness.py"),
                   "print('the staged harness')\n")
        self.write(os.path.join(self.source, "preflight.py"),
                   "def _observed_readable():\n    return True\n")
        self.task(TASK)
        # THE CREDENTIAL IS A FILE THAT SAYS IT IS NOT ONE. Its content is
        # asserted never to be read, so a real bearer would prove nothing that
        # this does not and would put a secret in a repository.
        self.slot = os.path.join(self.credentials, "claude")
        self.write(self.slot, "not-a-credential\n")
        for module, name, value in (
                (claude_agent, "INPUT_ROOT", self.inputs),
                (claude_agent, "OUTPUT_ROOT", self.outputs),
                (claude_agent, "CREDENTIAL_ROOT", self.credentials)):
            held = getattr(module, name)
            setattr(module, name, value)
            self.addCleanup(setattr, module, name, held)

    @staticmethod
    def write(place, body):
        os.makedirs(os.path.dirname(place), exist_ok=True)
        with open(place, "w", encoding="utf-8") as handle:
            handle.write(body)

    def task(self, document):
        place = os.path.join(self.inputs, claude_agent.TASK_DOCUMENT)
        if document is None:
            if os.path.exists(place):
                os.unlink(place)
            return
        self.write(place, json.dumps(document))

    # -- the injected provider ----------------------------------------------

    def provider(self, *, edits=None, status=0, verify=0,
                 timeout=False, missing=False):
        """One recorded process-running capability.

        `edits` is what the "provider" writes into the candidate copy — which
        is the only way a real one changes anything, so a fake that wrote
        nowhere else is exactly as capable here.

        THERE IS NO `stderr=` OPERAND, and its removal is the fixture half of
        W39357 review 2026-08-30T04:01:29Z [P1]. The adapter hands both
        children `subprocess.DEVNULL`, so a fake cannot write to a stream at
        all — an operand that quietly wrote nowhere would leave every case
        using it looking like it proved something about a diagnostic. The
        cases that genuinely need a child to SAY something drive a real
        `subprocess.run`; see `NoChildStreamByteReachesTheProposal`.
        """
        self.calls = []

        def run(argv, **options):
            recorded = dict(options)
            recorded["resolved_env"] = dict(options.get("env", {}))
            for name, place in recorded["resolved_env"].items():
                if name != "PATH" and place.startswith("/proc/self/fd/"):
                    recorded["resolved_env"][name] = os.path.realpath(place)
            self.calls.append((list(argv), recorded))
            if argv[0] == claude_agent.PROVIDER_PROGRAM:
                if timeout:
                    raise subprocess.TimeoutExpired(argv, 1)
                if missing:
                    raise OSError("no such file")
                for name, body in (edits or {}).items():
                    self.write(os.path.join(options["cwd"], name), body)
                return subprocess.CompletedProcess(argv, status, None, None)
            return subprocess.CompletedProcess(argv, verify, None, None)

        return run

    # -- W321528: the launch document a Job stands behind --------------------

    # A SELECTED CEILING THAT IS NOT THE DEFAULT and is not either number the
    # two historic runs happened to use. Those runs are the EVIDENCE that the
    # publishers reported a constant; they are not the values under test, and
    # a fixture built on them would pass against a publisher that had simply
    # learned to spell 600.
    SELECTED_SECONDS = 137

    def launched(self, *, seconds=None, **members):
        """The launch document the manager delivers for a Job-backed turn.

        THE CONFIGURATION IS THE OWNER'S, RESOLVED BY THE OWNER. The whole
        claim the `seconds_bound` member makes is that a result reports what
        the operator actually configured, so this composes the execution
        limits through `execution_limits.resolved` -- the same function
        `launch._job_execution` re-resolves a delivery against -- rather than
        writing a configuration document by hand. A hand-built one would only
        ever prove the adapter agrees with this file.

        `seconds=None` IS A JOB THAT CONFIGURED NOTHING, which is a different
        document from no Job at all: it carries the boundary with the
        preserved runner default and the `compatibility` origin, and it is
        exactly the delivery whose number a reader must not mistake for an
        operator's choice.
        """
        from baton_v12.job_manager import execution_limits

        limits = execution_limits.resolved(
            {} if seconds is None else {"provider_turn_seconds": seconds})
        return dict({"contract": "the frozen task",
                     "job_execution": {"job_id": "job-w321528",
                                       "attempt_id": "attempt-w321528",
                                       "execution_limits": limits}},
                    **members)

    def worked(self, *, seen=None, **operands):
        agent = ClaudeAgent(run=self.provider(**operands),
                            home=self.scratch)
        return agent.work({"contract": "the frozen task"} if seen is None
                          else seen, list(DECLARED))

    def proposal(self, *parts):
        return os.path.join(self.outputs, "proposal", *parts)

    def result(self):
        with open(self.proposal("result.json"), encoding="utf-8") as handle:
            return json.load(handle)


class ThePositiveTurnWritesTheDeclaredProposal(AdapterCase):

    def test_a_changed_and_verified_candidate_is_completed(self):
        answered = self.worked(edits={"harness.py": "print('now covered')\n"})
        self.assertEqual(answered["disposition"], "completed")
        self.assertEqual(answered["outputs"],
                         [{"name": "proposal", "status": "present",
                           "result_metadata": {}}])
        self.assertEqual(self.result()["disposition"], "candidate")
        self.assertEqual(self.result()["changed_paths"], ["harness.py"])

    def test_the_four_declared_members_are_all_written(self):
        self.worked(edits={"harness.py": "print('now covered')\n"})
        for name in ("candidate", "change.patch", "result.json",
                     "verification.txt"):
            self.assertTrue(os.path.exists(self.proposal(name)), name)
        # THE CANDIDATE IS THE WHOLE TREE, not only what changed: the operator
        # diffs it against the recorded input manifest, which needs every file.
        self.assertEqual(sorted(os.listdir(self.proposal("candidate"))),
                         ["harness.py", "preflight.py"])

    def test_the_patch_is_a_unified_diff_of_the_changed_paths(self):
        self.worked(edits={"harness.py": "print('now covered')\n"})
        with open(self.proposal("change.patch"), encoding="utf-8") as handle:
            patch = handle.read()
        self.assertIn("--- a/harness.py", patch)
        self.assertIn("+++ b/harness.py", patch)
        self.assertIn("+print('now covered')", patch)

    def test_the_verification_transcript_carries_the_command_and_status(self):
        self.worked(edits={"harness.py": "print('now covered')\n"})
        with open(self.proposal("verification.txt"),
                  encoding="utf-8") as handle:
            transcript = handle.read()
        self.assertIn("python3 harness.py", transcript)
        self.assertIn("exit: 0", transcript)

    def test_the_written_tree_is_group_readable_for_collection(self):
        """A STATED COOPERATION, not custody.

        W36540 owns unconditional custody; until it lands, an owner-only tree
        is one the manager fails closed on. This adapter cooperates on purpose
        and the mode is asserted so a later change cannot quietly stop.
        """
        self.worked(edits={"harness.py": "print('now covered')\n"})
        self.assertEqual(os.stat(self.proposal()).st_mode & 0o777,
                         claude_agent.DIRECTORY_MODE & 0o777)
        self.assertEqual(os.stat(self.proposal("result.json")).st_mode & 0o777,
                         claude_agent.FILE_MODE)

    # -- W321528: the bound a result reports is the bound the turn ran under

    def test_the_reported_bound_is_this_workers_own_default_with_no_job(self):
        """No Job behind the launch is the ONE case the constant is correct
        for, and it is still reported as a resolution rather than asserted."""
        self.worked(edits={"harness.py": "print('now covered')\n"})
        self.assertEqual(self.result()["provider"]["seconds_bound"],
                         claude_agent.PROVIDER_SECONDS)
        self.assertEqual(self.result()["provider"]["seconds_bound_source"],
                         claude_agent.WORKER_DEFAULT_BOUND)

    def test_an_operator_selected_bound_is_what_the_result_publishes(self):
        """THE DEFECT, in the directory publisher. The turn ran under the
        Job's number and the record said 3600, so an operator reading a
        retained proposal could not tell what had actually bounded it."""
        self.worked(edits={"harness.py": "print('now covered')\n"},
                    seen=self.launched(seconds=self.SELECTED_SECONDS))
        self.assertNotEqual(self.SELECTED_SECONDS,
                            claude_agent.PROVIDER_SECONDS)
        self.assertEqual(self.result()["provider"]["seconds_bound"],
                         self.SELECTED_SECONDS)
        self.assertEqual(self.result()["provider"]["seconds_bound_source"],
                         claude_agent.JOB_SELECTED_BOUND)

    def test_a_job_that_configured_nothing_is_not_an_operator_choice(self):
        """The same NUMBER as the no-Job case and a different FACT: this
        delivery resolved the boundary's preserved default, and saying an
        operator selected it would be this adapter inventing a decision."""
        self.worked(edits={"harness.py": "print('now covered')\n"},
                    seen=self.launched())
        self.assertEqual(self.result()["provider"]["seconds_bound"],
                         claude_agent.PROVIDER_SECONDS)
        self.assertEqual(self.result()["provider"]["seconds_bound_source"],
                         claude_agent.JOB_DEFAULT_BOUND)

    def test_a_delivery_naming_no_origin_is_unstated_and_not_a_default(self):
        """An origin this module does not know is reported as unread rather
        than folded into either answer: a document that cannot be read is not
        evidence that nobody configured anything."""
        seen = self.launched(seconds=self.SELECTED_SECONDS)
        seen["job_execution"]["execution_limits"]["boundaries"][
            "provider_turn"].pop("origin")
        self.worked(edits={"harness.py": "print('now covered')\n"}, seen=seen)
        self.assertEqual(self.result()["provider"]["seconds_bound"],
                         self.SELECTED_SECONDS)
        self.assertEqual(self.result()["provider"]["seconds_bound_source"],
                         claude_agent.UNSTATED_BOUND_SOURCE)

    def test_the_origin_words_are_the_execution_limit_owners_own(self):
        """The image carries no `baton_v12`, so the two mirrored words are
        held against their owner here rather than imported across."""
        from baton_v12.job_manager import execution_limits

        self.assertEqual(
            sorted(claude_agent._ORIGIN_SELECTION),
            sorted((execution_limits.JOB, execution_limits.COMPATIBILITY)))
        # AND THE DEFAULT THIS MODULE KEEPS IS THE ONE THAT OWNER PRESERVES
        # FOR IT. Two copies of a number that disagreed would make the
        # no-Job answer and the Job-that-configured-nothing answer differ for
        # a reason neither document explains.
        self.assertEqual(
            execution_limits.boundary_default("provider_turn"),
            claude_agent.PROVIDER_SECONDS)

    def test_the_staged_source_is_never_written(self):
        """The read-only input is the evidence the result is measured against.

        Asserted by CONTENT rather than by mode: this fixture's `/input` is an
        ordinary directory, so a mode assertion would prove the fixture rather
        than the adapter.
        """
        def held():
            found = {}
            for name in sorted(os.listdir(self.source)):
                with open(os.path.join(self.source, name),
                          encoding="utf-8") as handle:
                    found[name] = handle.read()
            return found

        before = held()
        self.worked(edits={"harness.py": "print('now covered')\n"})
        self.assertEqual(held(), before)


class NeitherChildLeavesEphemeraInTheCandidate(AdapterCase):
    """W85497: the candidate is the proposal, so a cache in it is a change.

    THE MEASUREMENT THIS ANSWERS. The first ordinary self-hosted W71917 retry
    published a 10,779,527-byte patch for ten real paths, because
    `python3 -m compileall -q src tests tools` wrote 149 `cpython-311`
    entries into the tree this adapter diffs. Verification is not allowed to
    turn its own generated artefacts into proposed source changes.

    BOTH CHILDREN ARE ASKED, and the provider is the one an inspection would
    miss: it is PROMPTED to run the verification command itself, and `work`
    walks the tree after that turn -- so a provider that does as it is asked
    contaminates the proposal even when the adapter's own verification is
    perfectly clean.
    """

    def envs(self):
        """The two composed environments, by the program each belongs to."""
        self.worked(edits={"harness.py": "print('now covered')\n"})
        provider = next(options for argv, options in self.calls
                        if argv[0] == claude_agent.PROVIDER_PROGRAM)
        verifier = next(options for argv, options in self.calls
                        if argv[0] != claude_agent.PROVIDER_PROGRAM)
        return provider["resolved_env"], verifier["resolved_env"]

    def test_the_verifier_inherits_the_exact_held_directory_objects(self):
        """The provider-writable names are no longer launch authority."""
        self.worked(edits={"harness.py": "print('now covered')\n"})
        options = next(options for argv, options in self.calls
                       if argv[0] != claude_agent.PROVIDER_PROGRAM)
        passed = set(options["pass_fds"])
        for name in ("HOME", *(one for one, _leaf
                               in ClaudeAgent.EPHEMERA_ROOTS)):
            place = options["env"][name]
            self.assertRegex(place, r"\A/proc/self/fd/[0-9]+\Z")
            self.assertIn(int(place.rsplit("/", 1)[1]), passed)
            self.assertTrue(options["resolved_env"][name].startswith(
                self.scratch + os.sep), (name, options))

    def test_every_ephemeral_root_is_outside_the_candidate(self):
        provider, verifier = self.envs()
        candidate = os.path.join(self.scratch, claude_agent.CANDIDATE)
        for whose, env in (("provider", provider), ("verification", verifier)):
            for name in ("PYTHONPYCACHEPREFIX", "TMPDIR", "XDG_CACHE_HOME"):
                place = env[name]
                self.assertTrue(os.path.isabs(place), (whose, name, place))
                # NOT `startswith`: `candidate-other` starts with `candidate`
                # and is not inside it. The relative path is the question.
                self.assertTrue(
                    os.path.relpath(place, candidate).startswith(os.pardir),
                    f"the {whose}'s {name} is inside the candidate: {place}")
                self.assertTrue(
                    place.startswith(self.scratch + os.sep),
                    f"the {whose}'s {name} is outside the private scratch: "
                    f"{place}")

    def test_every_named_root_exists_before_either_child_starts(self):
        """W85497 review 2026-09-04T13-56-04Z [P1]: named is not created.

        Only the OUTER ephemera directory was made; the three children were
        pointed at and absent, and an absent directory is one the child
        silently ignores. A boundary that depends on a directory existing is
        declarative until the directory exists.
        """
        provider, verifier = self.envs()
        for whose, env in (("provider", provider), ("verification", verifier)):
            for name, _leaf in ClaudeAgent.EPHEMERA_ROOTS:
                place = env[name]
                self.assertTrue(os.path.isdir(place),
                                f"the {whose}'s {name} does not exist: "
                                f"{place}")
                self.assertEqual(stat.S_IMODE(os.stat(place).st_mode), 0o700)

    def test_a_child_given_this_environment_really_selects_those_roots(self):
        """THE PROOF THE STRING CHECK CANNOT GIVE.

        A reviewer's probe of the composed environment found Python presented
        with the old absent `TMPDIR` selecting `/tmp` instead. So this runs a
        REAL interpreter with the composed environment and asks it where it
        would put a temporary file and its bytecode.
        """
        import subprocess as sub

        _provider, verifier = self.envs()
        answered = sub.run(
            [sys.executable, "-c",
             "import os, tempfile; print(tempfile.gettempdir()); "
             "print(os.environ['PYTHONPYCACHEPREFIX']); "
             "print(tempfile.NamedTemporaryFile(delete=False).name)"],
            env=verifier, capture_output=True, text=True, timeout=120)
        self.assertEqual(answered.returncode, 0, answered.stderr)
        chose, prefix, made = answered.stdout.split()
        self.assertEqual(chose, verifier["TMPDIR"])
        self.assertEqual(prefix, verifier["PYTHONPYCACHEPREFIX"])
        self.assertTrue(made.startswith(verifier["TMPDIR"] + os.sep), made)
        candidate = os.path.join(self.scratch, claude_agent.CANDIDATE)
        self.assertTrue(
            os.path.relpath(made, candidate).startswith(os.pardir), made)

    def test_the_pycache_prefix_is_set_because_compileall_ignores_the_other(
            self):
        """`PYTHONDONTWRITEBYTECODE` cannot answer this and is not relied on.

        `compileall` writes bytecode as its PURPOSE and ignores that variable;
        a local 3.13 reproduction produced `__pycache__/probe.cpython-313.pyc`
        with it set. `PYTHONPYCACHEPREFIX` is the name that decides WHERE.
        """
        provider, verifier = self.envs()
        for env in (provider, verifier):
            self.assertIn("PYTHONPYCACHEPREFIX", env)
            self.assertNotIn("PYTHONDONTWRITEBYTECODE", env)

    def test_the_verification_home_is_not_the_candidate_and_holds_no_bearer(
            self):
        """It used to BE the candidate, so a command writing to its own home
        wrote into the proposal; and it is not the provider's home either,
        because that one holds the link to the mounted credential."""
        provider, verifier = self.envs()
        candidate = os.path.join(self.scratch, claude_agent.CANDIDATE)
        self.assertNotEqual(verifier["HOME"], candidate)
        self.assertTrue(
            os.path.relpath(verifier["HOME"], candidate).startswith(os.pardir),
            verifier["HOME"])
        self.assertNotEqual(verifier["HOME"], provider["HOME"])
        for base, _directories, files in os.walk(verifier["HOME"]):
            for name in files:
                self.assertNotIn(claude_agent.PROVIDER_CREDENTIAL, name)

    def test_the_providers_home_is_still_the_prepared_credential_home(self):
        """The correction moves ephemera, not the credential."""
        provider, _verifier = self.envs()
        self.assertTrue(os.path.lexists(
            os.path.join(provider["HOME"], claude_agent.PROVIDER_HOME_STATE,
                         claude_agent.PROVIDER_CREDENTIAL)))

    def test_provider_symlinks_cannot_replace_the_verifiers_owned_roots(self):
        """Review 2026-09-04T14:44:23Z: predictable is attacker-known.

        The provider runs as this uid and can name scratch siblings. Replacing
        either verifier root with a link must be a refusal before verification,
        never an `exist_ok` plus chmod that follows the link into candidate.
        """
        self.calls = []

        def run(argv, **options):
            self.calls.append((list(argv), dict(options)))
            if argv[0] == claude_agent.PROVIDER_PROGRAM:
                candidate = options["cwd"]
                self.write(os.path.join(candidate, "harness.py"),
                           "print('now covered')\n")
                for name in (claude_agent.VERIFICATION_HOME,
                             claude_agent.VERIFICATION_EPHEMERA):
                    place = os.path.join(self.scratch, name)
                    shutil.rmtree(place)
                    os.symlink(candidate, place)
                return subprocess.CompletedProcess(argv, 0, None, None)
            self.fail("verification followed a provider-controlled root")

        agent = ClaudeAgent(run=run, home=self.scratch)
        with self.assertRaises(TaskRefusal) as caught:
            agent.work({"contract": "t"}, list(DECLARED))
        self.assertIn("verifier root", str(caught.exception))
        candidate = os.path.join(self.scratch, claude_agent.CANDIDATE)
        for name in ("cache", "pycache", "tmp"):
            self.assertFalse(os.path.lexists(os.path.join(candidate, name)))
        self.assertEqual(len(self.calls), 1)

    def test_a_descendant_cannot_redirect_a_root_after_final_validation(self):
        """Review 2026-09-04T18-59-48Z: discriminate the TOCTOU.

        The replacement happens inside the injected process-launch seam,
        after `_verify` has performed its final held-object validation and
        before the real interpreter resolves its environment. The old
        pathname environment wrote bytecode through this link into candidate;
        the descriptor-bound environment keeps using the renamed object.
        """
        self.task(dict(TASK, verification=["python3", "-m", "compileall",
                                           "-q", "."]))
        held = os.path.join(self.scratch,
                            claude_agent.VERIFICATION_EPHEMERA,
                            "pycache-held")
        seen = {}

        def run(argv, **options):
            if argv[0] == claude_agent.PROVIDER_PROGRAM:
                self.write(os.path.join(options["cwd"], "harness.py"),
                           "print('now covered')\n")
                return subprocess.CompletedProcess(argv, 0, None, None)
            visible = os.path.join(self.scratch,
                                   claude_agent.VERIFICATION_EPHEMERA,
                                   "pycache")
            os.rename(visible, held)
            os.symlink(options["cwd"], visible)
            seen["resolved"] = os.path.realpath(
                options["env"]["PYTHONPYCACHEPREFIX"])
            return subprocess.run(argv, **options)

        answered = ClaudeAgent(run=run, home=self.scratch).work(
            {"contract": "t"}, list(DECLARED))
        self.assertEqual(answered["disposition"], "completed")
        candidate = os.path.join(self.scratch, claude_agent.CANDIDATE)
        self.assertEqual(self.caches(candidate), [])
        self.assertEqual(seen["resolved"], held)
        self.assertTrue(any(files for _base, _directories, files
                            in os.walk(held)),
                        "the verifier produced no bytecode in the held root")

    def test_a_real_compileall_leaves_the_candidate_cache_free(self):
        """THE DEFECT ITSELF, with a real interpreter rather than a double.

        The fake provider cannot write bytecode, so this drives the adapter's
        own verification with the actual command the retry ran and then asks
        the published proposal what it contains.
        """
        self.task(dict(TASK, verification=["python3", "-m", "compileall",
                                           "-q", "."]))
        agent = ClaudeAgent(run=self.compiling(), home=self.scratch)
        answered = agent.work({"contract": "t"}, list(DECLARED))
        self.assertEqual(answered["disposition"], "completed")
        candidate = os.path.join(self.scratch, claude_agent.CANDIDATE)
        self.assertEqual(self.caches(candidate), [],
                         "verification wrote its own bytecode into the tree "
                         "this adapter publishes")
        self.assertEqual(self.result()["changed_paths"], ["harness.py"])
        # AND THE BYTECODE REALLY WAS PRODUCED, somewhere. A case that proved
        # only "no caches in the candidate" would also pass if the command had
        # never compiled anything at all.
        made = [place for place in (
            os.path.join(self.scratch, claude_agent.VERIFICATION_EPHEMERA,
                         "pycache"),)
            for _b, _d, files in os.walk(place) if files]
        self.assertTrue(made, "nothing compiled, so nothing was proved")

    def compiling(self):
        """A provider double that edits, then a REAL `compileall` child."""
        import subprocess as sub

        self.calls = []

        def run(argv, **options):
            self.calls.append((list(argv), dict(options)))
            if argv[0] == claude_agent.PROVIDER_PROGRAM:
                self.write(os.path.join(options["cwd"], "harness.py"),
                           "print('now covered')\n")
                return sub.CompletedProcess(argv, 0, None, None)
            return sub.run(argv, **options)

        return run

    @staticmethod
    def caches(tree):
        found = []
        for base, directories, files in os.walk(tree):
            if os.path.basename(base) == "__pycache__":
                found.append(os.path.relpath(base, tree))
            found.extend(os.path.relpath(os.path.join(base, name), tree)
                         for name in files if name.endswith(".pyc"))
        return sorted(found)


class TheProviderCreatesPrivateDirectories(AdapterCase):
    """W239528, owner 2026-09-23T03:06:11Z.

    THE MANAGER'S CHECK IS NOT WEAKENED and is not exercised here;
    `context_delivery._private` still refuses a custody directory carrying
    group or other bits. What this covers is the other side of that rule: the
    provider child is spawned under a mask that cannot create one.

    A real turn created seven directories under its own HOME at `0o755` -- the
    ordinary umask default -- so the manager could not seal the generation, the
    context use was held `custody-invalid`, and a run that had produced a
    correct attributed proposal reported nothing until its bound.
    """

    def test_the_provider_child_is_spawned_under_the_private_mask(self):
        """The operand, at the boundary, on the provider and nowhere else."""
        import claude_agent

        self.worked(edits={"harness.py": "print('now covered')\n"})
        provider = [held for argv, held in self.calls
                    if argv[0] == claude_agent.PROVIDER_PROGRAM]
        self.assertEqual(len(provider), 1, self.calls)
        self.assertEqual(provider[0].get("umask"), claude_agent.PROVIDER_UMASK)
        self.assertEqual(claude_agent.PROVIDER_UMASK, 0o077)

    def test_no_other_child_has_its_creation_mask_narrowed(self):
        """A mask on this whole process would also narrow what the adapter
        writes into the shared private line, whose group access the deployment
        configures on purpose."""
        import claude_agent

        self.worked(edits={"harness.py": "print('now covered')\n"})
        for argv, held in self.calls:
            if argv[0] == claude_agent.PROVIDER_PROGRAM:
                continue
            with self.subTest(argv=argv[:2]):
                self.assertIn(held.get("umask", -1), (-1, None))

    def test_a_child_under_that_mask_cannot_create_a_readable_directory(self):
        """ESTABLISHED RATHER THAN ASSUMED, with a real child.

        `mkdir` applies `mode & ~umask`, so even an EXPLICIT `0o755` comes out
        private, and the mask is inherited by descendants. That is why a mask
        is the correction and a later `chmod` sweep is not.
        """
        import claude_agent
        import stat
        import subprocess
        import sys

        script = ("import os\n"
                  "os.makedirs('a/b')\n"
                  "os.mkdir('explicit', 0o755)\n"
                  "open('f', 'w').close()\n")
        subprocess.run([sys.executable, "-c", script], cwd=self.scratch,
                       umask=claude_agent.PROVIDER_UMASK, check=True)
        for name in ("a", "a/b", "explicit"):
            with self.subTest(entry=name):
                mode = stat.S_IMODE(
                    os.lstat(os.path.join(self.scratch, name)).st_mode)
                self.assertEqual(mode, 0o700, oct(mode))
        self.assertEqual(
            stat.S_IMODE(os.lstat(os.path.join(self.scratch, "f")).st_mode),
            0o600)


class TheProviderArgvAndEnvironmentAreClosed(AdapterCase):

    def spoken(self):
        self.worked(edits={"harness.py": "print('now covered')\n"})
        return next((argv, options) for argv, options in self.calls
                    if argv[0] == claude_agent.PROVIDER_PROGRAM)

    def test_the_argv_is_exactly_the_pinned_vector_plus_one_prompt(self):
        """GOLDEN. The one operand a golden test cannot establish is whether
        the flag is the right spelling for the pinned image — the live turn
        under W64268 owns that — so what this pins is that nothing else is
        composed and that the prompt is the last word."""
        argv, _options = self.spoken()
        self.assertEqual(argv[:-1], ["claude", "--print",
                                     "--dangerously-skip-permissions",
                                     "--output-format", "json"])
        self.assertEqual(len(argv), 6)

    def test_the_inner_permission_policy_is_bypassed_and_not_re_spelled(self):
        """W64268's negative half.

        The decision names ONE activation flag. The two nearby spellings are
        wrong in ways a positive vector alone would not catch:
        `--allow-dangerously-skip-permissions` merely permits bypass to be
        selected later and does not activate it, and any surviving
        `--permission-mode` operand keeps the inner command allowlist this
        Work removed. Occurring exactly once also forbids composing the flag
        twice while one is being removed.
        """
        argv, _options = self.spoken()
        self.assertNotIn("--permission-mode", argv)
        self.assertNotIn("acceptEdits", argv)
        self.assertNotIn("--allow-dangerously-skip-permissions", argv)
        self.assertEqual(argv.count("--dangerously-skip-permissions"), 1)

    def test_the_prompt_carries_the_task_and_names_nothing_protocol(self):
        argv, _options = self.spoken()
        prompt = argv[-1]
        self.assertIn(TASK["instructions"], prompt)
        self.assertIn("python3 harness.py", prompt)
        # THE PROVIDER IS NOT TOLD ABOUT THE PROTOCOL. A provider that could
        # see the output root, the session or the assignment could write into
        # them or name them in its answer.
        for forbidden in ("/output", "output.json", "session", "assignment",
                          "worker-entry", "/run/baton"):
            self.assertNotIn(forbidden, prompt)

    def test_the_environment_is_composed_and_never_inherited(self):
        """A credential variable in this process must not reach the child.

        This is the failure the provider's own resolution order makes silent:
        an `ANTHROPIC_API_KEY` present in the container outranks every other
        source, so a forwarded environment would decide which account the
        trial ran as.
        """
        os.environ["ANTHROPIC_API_KEY"] = "not-a-credential-either"
        self.addCleanup(os.environ.pop, "ANTHROPIC_API_KEY", None)
        _argv, options = self.spoken()
        # STILL A CLOSED SET, and W85497 adds three members to it rather than
        # opening it. The set is spelled out so a fourth arriving without a
        # decision fails here; what this case has always proved -- that
        # `os.environ` is not forwarded -- is the assertion below it.
        self.assertEqual(sorted(options["env"]),
                         ["HOME", "PATH", "PYTHONPYCACHEPREFIX", "TMPDIR",
                          "XDG_CACHE_HOME"])
        self.assertNotIn("ANTHROPIC_API_KEY", options["env"])

    def test_the_provider_runs_in_the_workspace_copy_and_not_the_source(self):
        """W71917 MOVED THE COPY, AND NOT THE RULE.

        The provider still edits a private copy and never the mounted source;
        what changed is where that copy lives. It used to be under the 64 MiB
        tmpfs, which is the ceiling this Work exists to remove, and it is now
        in the manager-created disk-backed workspace. The second assertion --
        never the source -- is the one that was always the point and it is
        unchanged.
        """
        _argv, options = self.spoken()
        self.assertTrue(options["cwd"].startswith(self.outputs), options)
        self.assertNotEqual(options["cwd"], self.source)
        # AND NOT ON THE TMPFS, stated rather than implied: a copy that drifted
        # back to scratch would still satisfy "not the source".
        self.assertFalse(options["cwd"].startswith(self.scratch), options)

    def test_the_turn_is_bounded(self):
        _argv, options = self.spoken()
        self.assertEqual(options["timeout"], claude_agent.PROVIDER_SECONDS)

    def test_the_provider_stderr_is_discarded_rather_than_captured(self):
        """W39357 review 2026-08-30T04:01:29Z [P1], and it is why the stderr
        half of that finding is UNCHANGED by W55360.

        Stderr was captured and interpolated into `result.json` and, through
        `recap`, into the worker's own `/output/output.json` — and the
        process writing it is the one holding this attempt's credential.
        That is the stream where a bearer actually appeared, and this
        adapter still has no descriptor onto it.

        SUPERSEDED IN ONE HALF ONLY. This case used to require BOTH provider
        streams on `DEVNULL`. W55360's approver ruling (event 55479) narrowly
        allows the adapter to read provider STDOUT when it has selected the
        CLI's structured JSON mode, so that half moved to
        `test_the_provider_stdout_is_a_bounded_anonymous_pipe` below. Stderr
        did not move, and neither did either verification stream.
        """
        _argv, options = self.spoken()
        self.assertIs(options["stderr"], subprocess.DEVNULL)

    def test_the_provider_stdout_is_a_bounded_anonymous_pipe(self):
        """W55360: read, but never through a name a child could reach.

        The first two W39357 review rounds were both about capture PLUMBING —
        a pathname a child could replace, then a descriptor read back too
        late — so the shape matters as much as the boundedness. What the
        child is handed is an anonymous pipe descriptor this process
        created: not `DEVNULL` any more, and not a file, a path, or
        anything under the output root either.
        """
        seen = {}
        handed = self.provider(edits={"harness.py": "print('now covered')\n"})

        def run(argv, **options):
            if argv[0] == claude_agent.PROVIDER_PROGRAM:
                # FSTAT'ED WHILE THE CHILD WOULD HOLD IT. The adapter closes
                # both ends when the run returns, which is the behaviour a
                # later case asserts, so the descriptor has to be examined
                # here rather than out of the recorded options.
                found = os.fstat(options["stdout"])
                seen.update(fifo=stat.S_ISFIFO(found.st_mode),
                            fd=options["stdout"])
            return handed(argv, **options)

        ClaudeAgent(run=run, home=self.scratch).work(
            {"contract": "t"}, list(DECLARED))
        self.assertIsInstance(seen["fd"], int)
        self.assertNotIn(seen["fd"], (subprocess.DEVNULL, subprocess.PIPE,
                                      subprocess.STDOUT))
        # AN ANONYMOUS PIPE AND NOT A FILE, asserted of the descriptor itself
        # rather than of how it was made.
        self.assertTrue(seen["fifo"], "the provider's stdout is not a pipe")

    def test_both_verification_streams_are_discarded_too(self):
        """The sharper of the two, because this child is provider-EDITED code
        running with the same credential mount readable."""
        self.worked(edits={"harness.py": "print('now covered')\n"})
        _argv, options = next(
            (argv, options) for argv, options in self.calls
            if argv[0] != claude_agent.PROVIDER_PROGRAM)
        self.assertIs(options["stdout"], subprocess.DEVNULL)
        self.assertIs(options["stderr"], subprocess.DEVNULL)


class NoChildStreamByteReachesTheProposal(AdapterCase):
    """W39357 review 2026-08-30T04:01:29Z [P1], as one property.

    SUPERSEDES `OutputIsBoundedBeforeItIsAllocated`, whose two ceiling cases
    and `_window` case are gone with their subject. Those asked how much of a
    child's stream reached the artifact and how safely it was read back; this
    review's finding is that the question was wrong. The provider holds the
    attempt's bearer and the verification command is provider-edited code with
    the same mount readable, so no window onto either stream is publishable at
    any size. `MAX_DIAGNOSTIC`, `MAX_VERIFICATION` and `_window` are deleted
    rather than tightened, and what replaces them is this: NOTHING a child
    wrote appears anywhere in the proposal or in the worker's answer.

    THESE CASES USE A REAL `subprocess.run`, deliberately and for the same
    reason the deleted ones did. A fake that "wrote" to a handle would prove
    the fixture, and `subprocess.DEVNULL` is the thing under test — only a real
    child can be given it.
    """

    def shouting(self, *, marker, words=1, status=0, verify=0):
        """A real child that writes a distinctive marker to BOTH streams."""
        program = (f"import sys;"
                   f"sys.stdout.write({marker!r} * {words});"
                   f"sys.stderr.write({marker!r} * {words});"
                   f"raise SystemExit(%d)")

        def run(argv, **options):
            if argv[0] == claude_agent.PROVIDER_PROGRAM:
                self.write(os.path.join(options["cwd"], "harness.py"),
                           "print('now covered')\n")
                argv = [sys.executable, "-c", program % status]
            else:
                argv = [sys.executable, "-c", program % verify]
            return subprocess.run(argv, **options)

        return run

    def published(self):
        """Every byte this turn made host-visible, as one blob."""
        found = []
        for base, _directories, files in os.walk(self.proposal()):
            for name in sorted(files):
                with open(os.path.join(base, name), "rb") as handle:
                    found.append(handle.read())
        return b"".join(found)

    def test_a_shouting_provider_puts_nothing_in_the_proposal_or_the_answer(
            self):
        agent = ClaudeAgent(run=self.shouting(marker="PROVIDER-SAID",
                                              words=8192, status=3),
                            home=self.scratch)
        answered = agent.work({"contract": "t"}, list(DECLARED))
        self.assertEqual(answered["disposition"], "unable")
        self.assertNotIn(b"PROVIDER-SAID", self.published())
        # AND THE ANSWER TOO. `recap` is composed from `why`, so the old
        # interpolation reached the worker's protocol document as well as
        # `result.json` — a sink the review did not have to name for it to be
        # real.
        self.assertNotIn("PROVIDER-SAID", answered["recap"])
        # WHAT SURVIVES IS THE STATUS, which this adapter got from `wait` and
        # not from a stream. Failure stays honest without being transcribed.
        self.assertIn("the provider exited 3", self.result()["why"])

    def test_a_shouting_verification_puts_nothing_in_the_transcript(self):
        agent = ClaudeAgent(run=self.shouting(marker="COMMAND-SAID",
                                              words=8192),
                            home=self.scratch)
        answered = agent.work({"contract": "t"}, list(DECLARED))
        self.assertEqual(answered["disposition"], "completed")
        self.assertNotIn(b"COMMAND-SAID", self.published())
        self.assertNotIn("COMMAND-SAID", answered["recap"])

    def test_the_transcript_still_carries_the_operator_authored_evidence(self):
        """Withholding is not emptying. What is left is the frozen command,
        which the OPERATOR wrote into `/input/task.json`, and the ending, which
        came from `wait` — neither of them a byte any child produced."""
        agent = ClaudeAgent(run=self.shouting(marker="COMMAND-SAID", verify=4),
                            home=self.scratch)
        agent.work({"contract": "t"}, list(DECLARED))
        with open(self.proposal("verification.txt"),
                  encoding="utf-8") as handle:
            transcript = handle.read()
        self.assertIn("$ python3 harness.py", transcript)
        self.assertIn("exit: 4", transcript)
        # AND IT SAYS THE OUTPUT IS WITHHELD, so absence does not read as a
        # command that said nothing.
        self.assertIn("deliberately not", transcript)

    def test_the_module_keeps_no_ceiling_on_bytes_it_never_reads(self):
        """The deletions asserted directly, so re-adding a capture ceiling is
        a deliberate act rather than drift back toward the finding."""
        for gone in ("MAX_DIAGNOSTIC", "MAX_VERIFICATION", "_window",
                     "_capture"):
            self.assertFalse(hasattr(claude_agent, gone), gone)


class TheStructuredRecordIsMappedAndNeverPublished(AdapterCase):
    """W55360, as one property: a WORD comes out and no BYTE does.

    THESE DRIVE A REAL CHILD, for the reason
    `NoChildStreamByteReachesTheProposal` gives and one more of its own. A
    fake handing back a prebuilt buffer would prove this file's arithmetic;
    what is under test is fd plumbing — an anonymous pipe, a drain running
    beside the child, a bounded retention and a close that lets the reader
    see EOF — and only a real process writing into a real descriptor
    exercises any of it.

    THE MARKER STANDS IN FOR THE BEARER. It is placed in every part of the
    document that is not the one matched value: other members, member NAMES,
    nested values, the terminal reason itself when unknown, and the bytes after
    the ceiling. None of them may appear in the proposal or the answer.
    """

    MARKER = "PROVIDER-BEARER-fbb1c0"

    def speaking(self, *, says, status, chunks=1, also_stderr=True, verify=0):
        """A real child that writes `says` to stdout in `chunks` pieces.

        Written in pieces on purpose: one `write` per chunk with a flush
        between, so the parent's drain performs several reads and a reader
        that only ever read once would be visible.
        """
        # THE BODY TRAVELS IN A FILE, not in argv. A single argument is capped
        # at 128 KiB on Linux, and the overflow cases here are deliberately
        # larger than that -- an argv-carried body would have made those cases
        # fail as "the provider could not be started", which is a different
        # ending than the one under test.
        carried = os.path.join(self.home, "provider-says.txt")
        with open(carried, "w", encoding="utf-8") as handle:
            handle.write(says)
        program = (
            "import sys, time\n"
            "body = open(sys.argv[1], encoding='utf-8').read()\n"
            "count = int(sys.argv[2])\n"
            "size = max(1, (len(body) + count - 1) // count)\n"
            "for at in range(0, len(body), size):\n"
            "    sys.stdout.write(body[at:at + size])\n"
            "    sys.stdout.flush()\n"
            "    time.sleep(0.001)\n"
            "if int(sys.argv[4]):\n"
            "    sys.stderr.write(body)\n"
            "raise SystemExit(int(sys.argv[3]))\n")

        def run(argv, **options):
            if argv[0] == claude_agent.PROVIDER_PROGRAM:
                self.write(os.path.join(options["cwd"], "harness.py"),
                           "print('now covered')\n")
                argv = [sys.executable, "-c", program, carried, str(chunks),
                        str(status), "1" if also_stderr else "0"]
            else:
                argv = [sys.executable, "-c", "raise SystemExit(%d)" % verify]
            return subprocess.run(argv, **options)

        return run

    LINGERS = 20.0

    def outliving(self, *, says, status, leader_sleeps=0.0):
        """A real child that leaves a DESCENDANT holding stdout, then exits.

        This is W55360 review (2026-09-01T03:35:56Z) [P1] as a fixture, and
        the shape matters: the leader writes its record and starts a
        `subprocess.Popen` it never waits for. The descendant INHERITS the
        write end of the adapter's pipe, so EOF cannot arrive while it lives —
        and it lives `LINGERS` seconds, an order longer than the adapter is
        allowed to wait for it.

        THE DESCENDANT WRITES THE MARKER, on purpose. Its bytes really are
        retained by the drain, which is what makes this more than a timing
        case: the record the adapter holds contains the marker, is PARTIAL,
        and must still publish nothing but one of this module's own words.
        """
        carried = os.path.join(self.home, "provider-says.txt")
        with open(carried, "w", encoding="utf-8") as handle:
            handle.write(says)
        descendant = os.path.join(self.home, "descendant.py")
        self.write(descendant,
                   "import sys, time\n"
                   "sys.stdout.write(sys.argv[1])\n"
                   "sys.stdout.flush()\n"
                   "time.sleep(float(sys.argv[2]))\n")
        program = (
            "import subprocess, sys, time\n"
            "sys.stdout.write(open(sys.argv[1], encoding='utf-8').read())\n"
            "sys.stdout.flush()\n"
            "subprocess.Popen([sys.executable, sys.argv[2], sys.argv[3],\n"
            "                  sys.argv[4]])\n"
            "time.sleep(float(sys.argv[5]))\n"
            "raise SystemExit(int(sys.argv[6]))\n")

        def run(argv, **options):
            if argv[0] == claude_agent.PROVIDER_PROGRAM:
                self.write(os.path.join(options["cwd"], "harness.py"),
                           "print('now covered')\n")
                argv = [sys.executable, "-c", program, carried, descendant,
                        f"{self.MARKER}-from-a-descendant", str(self.LINGERS),
                        str(leader_sleeps), str(status)]
            else:
                argv = [sys.executable, "-c", "raise SystemExit(0)"]
            return subprocess.run(argv, **options)

        return run

    def turned(self, **operands):
        agent = ClaudeAgent(run=self.speaking(**operands), home=self.scratch)
        return agent.work({"contract": "t"}, list(DECLARED))

    def published(self):
        """Every byte this turn made host-visible, as one blob."""
        found = []
        for base, _directories, files in os.walk(self.proposal()):
            for name in sorted(files):
                with open(os.path.join(base, name), "rb") as handle:
                    found.append(handle.read())
        return b"".join(found)

    def document(self, reason, **members):
        """The structured record, with the marker in every other part."""
        body = {"terminal_reason": reason,
                "is_error": True,
                "duration_api_ms": 0,
                "result": self.MARKER,
                f"{self.MARKER}-member": {"nested": self.MARKER}}
        body.update(members)
        return json.dumps(body)

    def clean(self, answered):
        """No marker anywhere host-visible or returned, ever."""
        self.assertNotIn(self.MARKER.encode("ascii"), self.published())
        self.assertNotIn(self.MARKER, answered["recap"])

    # -- the one value the evidence earned -----------------------------------

    def test_the_observed_api_error_becomes_the_adapter_word(self):
        """The whole point of the Work, end to end through a real child."""
        answered = self.turned(says=self.document("api_error"), status=1,
                               chunks=4)
        self.assertEqual(self.result()["provider"]["failure_reason"],
                         "api-error")
        self.assertEqual(self.result()["disposition"], "provider-failed")
        self.assertEqual(answered["disposition"], "unable")
        self.clean(answered)

    def test_the_providers_own_spelling_never_reaches_a_sink(self):
        """`api_error` earns `api-error`, and the underscore form is not what
        gets written down. A published raw spelling would be a one-value
        passthrough, which is the thing the closed map exists to not be."""
        answered = self.turned(says=self.document("api_error"), status=1)
        self.assertNotIn(b"api_error", self.published())
        self.assertNotIn("api_error", answered["recap"])
        self.assertIn("api-error", self.result()["why"])

    def test_the_mapped_word_reaches_the_recap_and_the_status_survives(self):
        answered = self.turned(says=self.document("api_error"), status=7)
        self.assertIn("api-error", answered["recap"])
        self.assertIn("the provider exited 7", self.result()["why"])
        self.assertEqual(self.result()["provider"]["status"], 7)

    # -- everything else is one word ----------------------------------------

    def test_every_unusable_record_is_unclassified_and_says_nothing_more(self):
        """One case per way the document can fail to earn a word.

        Each carries the marker, and each must publish the SAME word: telling
        these apart in the record would be publishing a parser's reading of
        untrusted bytes.
        """
        marker = self.MARKER
        cases = {
            "an unknown reason": self.document(f"{marker}-unknown"),
            "no reason at all": json.dumps({"result": marker}),
            "a non-string reason": self.document(None),
            "a reason that is a document": json.dumps(
                {"terminal_reason": {"kind": marker}}),
            "a non-object root": json.dumps([{"terminal_reason": "api_error"},
                                             marker]),
            "malformed json": '{"terminal_reason": "api_error", ' + marker,
            "trailing data": ('{"terminal_reason": "api_error"} '
                              '{"second": "%s"}' % marker),
            # BOTH ORDERS, and the second is the one that makes the guard
            # load-bearing: `json.loads` keeps the LAST of two equal keys, so
            # a document whose duplicate resolves to the earned value would
            # publish `api-error` if the check were dropped.
            "a duplicated reason, marker last":
                ('{"terminal_reason": "api_error", '
                 '"terminal_reason": "%s"}' % marker),
            "a duplicated reason, the earned value last":
                ('{"terminal_reason": "%s", '
                 '"terminal_reason": "api_error"}' % marker),
            "nothing at all": "",
            "not json at all": marker,
            # PYTHON'S EXTENSIONS ARE NOT THE GRAMMAR. `json.loads` accepts
            # `NaN` and the infinities; JSON does not, so neither does this.
            "a non-standard constant":
                '{"terminal_reason": "api_error", "%s": NaN}' % marker,
            # AND A DOCUMENT INSIDE THE CEILING THE PARSER STILL CANNOT
            # FINISH: bytes were bounded, recursion was not.
            "nesting the parser cannot finish":
                ('{"terminal_reason": "api_error", "%s": ' % marker
                 + "[" * 30000 + "]" * 30000 + "}"),
        }
        for why, says in cases.items():
            with self.subTest(record=why):
                self.setUp()
                answered = self.turned(says=says, status=1, chunks=3)
                self.assertEqual(
                    self.result()["provider"]["failure_reason"],
                    "unclassified", why)
                self.clean(answered)

    def test_invalid_utf8_is_unclassified_rather_than_replaced(self):
        """Decoded strictly, so an undecodable record cannot become a
        different record by substitution."""
        agent = ClaudeAgent(run=self.provider(status=1), home=self.scratch)
        self.assertEqual(
            claude_agent._failure_reason(
                b'{"terminal_reason": "api_error", "x": "\xff\xfe"}',
                partial=False),
            "unclassified")
        # AND THE VALID FORM OF THE SAME DOCUMENT STILL EARNS ITS WORD, so the
        # case above is about the bytes rather than about the members.
        self.assertEqual(
            claude_agent._failure_reason(
                b'{"terminal_reason": "api_error", "x": "ok"}',
                partial=False),
            "api-error")
        del agent

    def test_pythons_non_standard_constants_are_not_json(self):
        """W55360 review (2026-09-01T03:35:56Z) [P1]: the parser was strict
        about duplicates and permissive about the grammar.

        `NaN`, `Infinity` and `-Infinity` are Python extensions and are not
        JSON. A record carrying one used to earn `api-error` — the adapter
        called a document well-formed that the approved rule says is
        unusable, which makes the classification the provider's choice rather
        than this module's.
        """
        for literal in ("NaN", "Infinity", "-Infinity", "[NaN]",
                        '{"nested": Infinity}'):
            with self.subTest(constant=literal):
                record = ('{"terminal_reason": "api_error", "x": %s}'
                          % literal).encode("utf-8")
                self.assertEqual(
                    claude_agent._failure_reason(record, partial=False),
                    "unclassified")
        # AND THE SAME DOCUMENT WITH A REAL NUMBER STILL EARNS ITS WORD, so
        # the cases above are about the grammar rather than about the member.
        self.assertEqual(
            claude_agent._failure_reason(
                b'{"terminal_reason": "api_error", "x": 0}', partial=False),
            "api-error")

    def test_a_record_the_parser_cannot_finish_is_unclassified(self):
        """The same review's second half: `_failure_reason` was not TOTAL.

        A record well inside the 64 KiB ceiling can still exhaust the decoder's
        recursion, and `RecursionError` is not a `ValueError` — so a provider
        could fault the worker from inside the function whose whole contract is
        to answer one of two words. The bound on bytes was never a bound on
        parser depth, and this is the shape that shows the difference.
        """
        depth = 30000
        record = ('{"terminal_reason": "api_error", "x": '
                  + "[" * depth + "]" * depth + "}").encode("utf-8")
        self.assertLess(len(record), claude_agent.MAX_PROVIDER_RECORD)
        self.assertEqual(
            claude_agent._failure_reason(record, partial=False),
            "unclassified")

    # -- the boundedness, and that it is a bound on MEMORY not on the child --

    def test_a_flood_is_drained_to_the_end_and_retained_bounded(self):
        """The two properties together, against a real child.

        A provider writing far more than the ceiling must neither wedge on a
        full pipe nor make this process hold what it wrote. So the child emits
        several times `MAX_PROVIDER_RECORD`, the turn still completes, and the
        retained record is measured directly at the seam.
        """
        flood = self.MARKER * ((claude_agent.MAX_PROVIDER_RECORD * 3)
                               // len(self.MARKER))
        self.assertGreater(len(flood), claude_agent.MAX_PROVIDER_RECORD * 2)
        agent = ClaudeAgent(run=self.speaking(says=flood, status=1, chunks=16),
                            home=self.scratch)
        status, record, partial = agent._ran_provider(
            [claude_agent.PROVIDER_PROGRAM], cwd=self.scratch, seconds=60,
            env={"HOME": self.scratch, "PATH": "/usr/bin:/bin"})
        self.assertEqual(status, 1)
        self.assertTrue(partial, "the overflow was not noticed")
        self.assertLessEqual(len(record), claude_agent.MAX_PROVIDER_RECORD)
        self.assertEqual(_failure := claude_agent._failure_reason(
            record, partial=partial), "unclassified")
        del _failure

    def test_a_partial_record_is_unclassified_even_when_it_parses(self):
        """The guard on its own, with the parser deliberately unable to help.

        Every end-to-end flood case below also fails to PARSE, so none of them
        can tell whether the partial check is doing anything. This hands
        `_failure_reason` a perfectly good `api_error` document and the
        partial flag, which is the only shape that isolates it: the stream was
        not proved whole, so what survived is not known to be the whole
        record, and a prefix that happens to parse is not a document the
        provider sent.

        BOTH WAYS OF BEING PARTIAL ARRIVE HERE AS THIS ONE FLAG -- bytes
        dropped at the ceiling, and a stream whose EOF never came because a
        provider descendant still held the write end.
        """
        earned = json.dumps({"terminal_reason": "api_error"}).encode("utf-8")
        self.assertEqual(
            claude_agent._failure_reason(earned, partial=False),
            "api-error")
        self.assertEqual(
            claude_agent._failure_reason(earned, partial=True),
            "unclassified")

    def test_a_flood_beginning_with_a_good_record_is_unclassified(self):
        """Overflow is not a reason to trust the prefix.

        A provider that emitted a valid `api_error` document and then a
        megabyte of anything else has not sent one document, and reassembling
        the readable part would be this module deciding which bytes counted.
        """
        says = (self.document("api_error")
                + self.MARKER * claude_agent.MAX_PROVIDER_RECORD)
        answered = self.turned(says=says, status=1, chunks=32)
        self.assertEqual(self.result()["provider"]["failure_reason"],
                         "unclassified")
        self.clean(answered)

    def test_a_descendant_holding_stdout_cannot_outlive_the_bound(self):
        """W55360 review (2026-09-01T03:35:56Z) [P1], at the seam.

        EOF arrives when the LAST writer closes the descriptor, and the
        provider's own children are writers it never told this adapter about.
        The reader used to wait for that EOF with no deadline, so a leader
        that spawned something long-lived and exited wedged the worker AFTER
        `self._run` had returned — past the one bound, `PROVIDER_SECONDS`,
        that was supposed to cover this.

        So the assertion is a CLOCK as much as a word: the call returns while
        the descendant is still alive and still holding the pipe.
        """
        self.assertGreater(self.LINGERS,
                           claude_agent.PROVIDER_DRAIN_SECONDS + 5,
                           "the fixture must outlive the bound under test")
        agent = ClaudeAgent(
            run=self.outliving(says=self.document("api_error"), status=1),
            home=self.scratch)
        began = time.monotonic()
        status, record, partial = agent._ran_provider(
            [claude_agent.PROVIDER_PROGRAM], cwd=self.scratch, seconds=600,
            env={"HOME": self.scratch, "PATH": "/usr/bin:/bin"})
        elapsed = time.monotonic() - began
        self.assertEqual(status, 1)
        self.assertLess(elapsed, claude_agent.PROVIDER_DRAIN_SECONDS + 5,
                        "the reader waited on a descendant's descriptor")
        self.assertTrue(partial, "an unfinished stream was called whole")
        self.assertEqual(claude_agent._failure_reason(record, partial=partial),
                         "unclassified")

    def test_a_descendant_holding_stdout_publishes_only_the_fallback(self):
        """End to end, and the retained bytes really do carry the marker.

        The document the LEADER wrote parses and would have earned a word.
        It does not get one, because a stream that never proved it finished is
        a prefix of a record rather than a record — the same rule the ceiling
        is under, arrived at the other way.
        """
        agent = ClaudeAgent(
            run=self.outliving(says=self.document("api_error"), status=1),
            home=self.scratch)
        began = time.monotonic()
        answered = agent.work({"contract": "t"}, list(DECLARED))
        elapsed = time.monotonic() - began
        self.assertLess(elapsed, claude_agent.PROVIDER_DRAIN_SECONDS + 5)
        self.assertEqual(self.result()["provider"]["failure_reason"],
                         "unclassified")
        self.assertEqual(answered["disposition"], "unable")
        self.clean(answered)

    def test_a_timed_out_provider_with_a_descendant_still_ends(self):
        """The same hazard, reached from the timeout path.

        `subprocess.run` kills its DIRECT child and nothing else, so a
        provider that timed out can leave exactly the same inherited writer
        behind. The bound has to be in the `finally`, which is where the
        reader's clock is started, or the failing turn hangs instead.
        """
        agent = ClaudeAgent(
            run=self.outliving(says=self.document("api_error"), status=1,
                               leader_sleeps=self.LINGERS),
            home=self.scratch)
        began = time.monotonic()
        with self.assertRaises(subprocess.TimeoutExpired):
            agent._ran_provider([claude_agent.PROVIDER_PROGRAM],
                                cwd=self.scratch, seconds=1,
                                env={"HOME": self.scratch,
                                     "PATH": "/usr/bin:/bin"})
        elapsed = time.monotonic() - began
        self.assertLess(elapsed, claude_agent.PROVIDER_DRAIN_SECONDS + 6)

    # -- the streams that did not move --------------------------------------

    def test_a_success_publishes_no_reason_and_none_of_the_marker(self):
        """A clean turn writes its structured record too, and none of it is
        read into anything published -- the field is null rather than a word
        readers learn to ignore."""
        answered = self.turned(says=self.document("api_error"), status=0)
        self.assertEqual(answered["disposition"], "completed")
        self.assertIsNone(self.result()["provider"]["failure_reason"])
        self.clean(answered)

    def test_the_provider_stderr_is_still_never_read(self):
        """The child above writes the marker to BOTH streams. Stdout is read,
        bounded and discarded; stderr is not opened at all, and that half of
        W39357 is untouched by this Work."""
        answered = self.turned(says=self.document("api_error"), status=1,
                               also_stderr=True)
        self.clean(answered)
        self.assertEqual(self.result()["provider"]["failure_reason"],
                         "api-error")

    def test_the_verification_streams_are_still_devnull(self):
        """W55360 must not weaken the sharper half: verification is
        provider-EDITED code with the same credential mount readable."""
        agent = ClaudeAgent(run=self.speaking(says=self.document("api_error"),
                                              status=0),
                            home=self.scratch)
        calls = []
        held = agent._run

        def watched(argv, **options):
            calls.append((list(argv), dict(options)))
            return held(argv, **options)

        agent._run = watched
        agent.work({"contract": "t"}, list(DECLARED))
        _argv, options = next(
            (argv, options) for argv, options in calls
            if argv[0] != claude_agent.PROVIDER_PROGRAM)
        self.assertIs(options["stdout"], subprocess.DEVNULL)
        self.assertIs(options["stderr"], subprocess.DEVNULL)

    def test_the_map_is_closed_and_matched_by_equality(self):
        """No prefix, no substring, no pattern. A near miss is a miss."""
        self.assertEqual(claude_agent.PROVIDER_FAILURE_REASONS,
                         {"api_error": "api-error"})
        for near in ("api_error ", " api_error", "api_errors", "API_ERROR",
                     "an api_error occurred", "api-error"):
            with self.subTest(reason=near):
                self.assertEqual(
                    claude_agent._failure_reason(
                        json.dumps({"terminal_reason": near}).encode("utf-8"),
                        partial=False),
                    "unclassified")


class TheCredentialIsLinkedAndNeverRead(AdapterCase):

    def test_the_providers_credential_path_points_at_the_mounted_slot(self):
        self.worked(edits={"harness.py": "print('now covered')\n"})
        _argv, options = next((argv, options) for argv, options in self.calls
                              if argv[0] == claude_agent.PROVIDER_PROGRAM)
        link = os.path.join(options["env"]["HOME"], ".claude",
                            ".credentials.json")
        self.assertTrue(os.path.islink(link), link)
        self.assertEqual(os.readlink(link), self.slot)

    def test_the_bearer_bytes_are_never_opened(self):
        """THE PROPERTY, measured rather than asserted about intent.

        The slot is replaced by a directory, which makes any attempt to READ
        it fail — and the turn still completes, because this adapter only ever
        writes a path.
        """
        os.unlink(self.slot)
        os.makedirs(self.slot)
        answered = self.worked(edits={"harness.py": "print('covered')\n"})
        self.assertEqual(answered["disposition"], "completed")

    def test_an_absent_credential_refuses_rather_than_falling_back(self):
        """The finding forbids a home-directory or ambient default."""
        os.unlink(self.slot)
        with self.assertRaises(TaskRefusal) as refused:
            self.worked(edits={"harness.py": "print('covered')\n"})
        self.assertIn("no home-directory or ambient fallback",
                      str(refused.exception))

    def test_an_unreadable_credential_refuses_before_the_provider_runs(self):
        """W52800, and it is the case that would have saved three attempts.

        THE OLD GUARD WAS `os.path.exists`, which is a `stat` -- so a slot
        delivered at a mode this container's fixed uid cannot open passed it,
        was symlinked into the private home, and became a provider that
        printed `Not logged in` and exited 1. The manager's mode was the
        defect and is corrected there; this is the half that makes the same
        failure SAY WHAT IT IS instead of arriving three layers away from its
        cause.

        MISSING AND UNREADABLE ARE DIFFERENT REFUSALS, because they are
        different operator actions: one is a delivery that did not happen, the
        other is a delivery whose permissions do not admit this runtime.

        THAT THE CHECK ITSELF READS NOTHING is already the property
        `test_the_bearer_bytes_are_never_opened` measures, by replacing the
        slot with a directory and requiring the turn to complete: `os.access`
        answers for the effective identity without a descriptor, so that case
        still passes with this guard in place.
        """
        os.chmod(self.slot, 0o000)
        self.addCleanup(os.chmod, self.slot, 0o600)

        with self.assertRaises(TaskRefusal) as refused:
            self.worked(edits={"harness.py": "print('covered')\n"})

        self.assertIn("cannot READ its credential", str(refused.exception))
        self.assertNotIn("no home-directory or ambient fallback",
                         str(refused.exception))
        # AND NO PROVIDER RAN. The refusal is before the launch, which is the
        # whole point: an unreadable delivery must not become a provider
        # failure whose diagnostic may not be published.
        self.assertEqual(
            [argv for argv, _options in self.calls
             if argv and argv[0] == claude_agent.PROVIDER_PROGRAM], [],
            "the provider was launched with a credential it cannot read")

    def test_no_bearer_reaches_the_argv_or_the_result(self):
        self.worked(edits={"harness.py": "print('now covered')\n"})
        rendered = json.dumps(self.result()) + json.dumps(
            [argv for argv, _options in self.calls])
        self.assertNotIn("not-a-credential", rendered)

    def test_a_provider_created_link_cannot_copy_the_bearer_to_the_proposal(
            self):
        """The provider controls the candidate after the trusted source-copy
        check. Its tree must be revalidated before diffing or publication, or
        a link can turn the fixed credential mount into an output source."""
        def run(argv, **options):
            if argv[0] == claude_agent.PROVIDER_PROGRAM:
                os.symlink(self.slot,
                           os.path.join(options["cwd"], "credential-copy"))
                return subprocess.CompletedProcess(argv, 0, b"", b"")
            return subprocess.CompletedProcess(argv, 0, b"ok\n", b"")

        agent = ClaudeAgent(run=run, home=self.scratch)
        try:
            agent.work({"contract": "the frozen task"}, list(DECLARED))
        except TaskRefusal:
            return
        copied = self.proposal("candidate", "credential-copy")
        self.assertFalse(os.path.exists(copied), copied)
        for name in ("change.patch", "result.json", "verification.txt"):
            with open(self.proposal(name), encoding="utf-8") as handle:
                self.assertNotIn("not-a-credential", handle.read(), name)

    def test_verification_cannot_swap_a_checked_parent_for_the_credential_root(
            self):
        """Validation must remain true through the final candidate read.

        Verification executes code from the provider-edited candidate after
        `_checked_tree` and `_diff`, but before `_publish`.  `O_NOFOLLOW` on
        the final file does not protect an intermediate directory component,
        so replacing that directory with a link can redirect the later open
        into the mounted credential root.
        """
        def run(argv, **options):
            nested = os.path.join(options["cwd"], "nested")
            if argv[0] == claude_agent.PROVIDER_PROGRAM:
                self.write(os.path.join(nested, "claude"), "ordinary\n")
            else:
                shutil.rmtree(nested)
                os.symlink(self.credentials, nested)
            return subprocess.CompletedProcess(argv, 0, b"", b"")

        agent = ClaudeAgent(run=run, home=self.scratch)
        with self.assertRaises(TaskRefusal):
            agent.work({"contract": "the frozen task"}, list(DECLARED))
        copied = self.proposal("candidate", "nested", "claude")
        if os.path.exists(copied):
            with open(copied, encoding="utf-8") as handle:
                self.assertNotIn("not-a-credential", handle.read())

    def test_verification_cannot_replace_checked_file_bytes_with_the_credential(
            self):
        """Revalidation must hold CONTENT, not only path shape.

        The verification program runs after `_diff` measures the candidate and
        before `_publish` reads it.  Replacing an already-checked regular
        file's bytes therefore needs no link at all: a path-only revalidation
        accepts the file and publishes bytes that neither `change.patch` nor
        `changed_paths` measured.  The mounted credential makes that evidence
        mismatch a disclosure boundary as well as an integrity failure.
        """
        def run(argv, **options):
            nested = os.path.join(options["cwd"], "nested")
            target = os.path.join(nested, "claude")
            if argv[0] == claude_agent.PROVIDER_PROGRAM:
                self.write(target, "ordinary\n")
                self.write(os.path.join(options["cwd"], "harness.py"),
                           "print('now covered')\n")
            else:
                shutil.copyfile(self.slot, target)
            return subprocess.CompletedProcess(argv, 0, b"", b"")

        agent = ClaudeAgent(run=run, home=self.scratch)
        with self.assertRaises(TaskRefusal):
            agent.work({"contract": "the frozen task"}, list(DECLARED))
        self.assertFalse(os.path.exists(self.proposal()), self.proposal())

    def test_verification_cannot_replace_its_capture_with_the_credential(self):
        """Capture state must not be reachable by the verification command.

        The reviewer's regression (2026-08-29T22:18:55Z [P1]) ran the attack
        against the `capture-*/stdout` pathname the first round created inside
        the candidate: unlink it once its descriptor is open, put a link to
        the credential there, and the bounded reader — which reopened the NAME
        — transcribed the bearer.

        The adapter now captures NOTHING at all, so the case asserts the
        strongest form of what it started as: the child sees no capture
        pathname anywhere it can reach, and the swap it can still attempt
        against any pathname it does find cannot reach the transcript. The
        credential assertion is the reviewer's, unchanged through three
        rounds of remedy.
        """
        visible = []

        def run(argv, **options):
            if argv[0] == claude_agent.PROVIDER_PROGRAM:
                self.write(os.path.join(options["cwd"], "harness.py"),
                           "print('now covered')\n")
                return subprocess.CompletedProcess(argv, 0, b"", b"")
            # NOTHING NAMED IS LEFT FOR IT, in its own working directory or in
            # the adapter's private scratch — which the same-uid child could
            # have reached just as easily as its own cwd.
            for base in (options["cwd"], self.scratch):
                for where, directories, files in os.walk(base):
                    visible.extend(
                        os.path.join(where, name)
                        for name in directories + files
                        if name.startswith("capture-")
                        or name in ("stdout", "stderr"))
            # ...and the historical attack, against whatever it did find.
            for place in visible:
                os.unlink(place)
                os.symlink(self.slot, place)
            return subprocess.CompletedProcess(argv, 0, b"", b"")

        agent = ClaudeAgent(run=run, home=self.scratch)
        agent.work({"contract": "the frozen task"}, list(DECLARED))
        self.assertEqual(visible, [])
        with open(self.proposal("verification.txt"),
                  encoding="utf-8") as handle:
            transcript = handle.read()
        self.assertNotIn("not-a-credential", transcript)
        # THE TRANSCRIPT IS STILL A TRANSCRIPT. This asserted `"ok"` — the
        # child's own stdout — which is precisely what the 2026-08-30T04:01:29Z
        # finding says may not be there. What proves the file is not merely
        # empty is the evidence no child wrote.
        self.assertIn("$ python3 harness.py", transcript)
        self.assertIn("exit: 0", transcript)

    def test_verification_cannot_print_the_mounted_credential(self):
        """The transcript cannot trust provider-edited verification output.

        The frozen command runs code from the candidate the provider just
        edited, and that process can read the same fixed credential mount as
        the provider.  It therefore needs no pathname race to disclose the
        bearer: writing it to either captured stream is enough unless the
        verification boundary makes the mount unavailable or withholds the
        untrusted bytes from the proposal.

        THE REVIEWER'S CASE, RUN AGAINST A REAL CHILD. Its original form wrote
        the bearer to `options["stdout"]`, which was a file object while the
        adapter still captured. The remedy is that both streams are
        `subprocess.DEVNULL` — an operand only a real `subprocess.run` can
        honour — so the disclosure it models is performed by an actual process
        writing the actual bytes to its actual fd 1 and 2. The assertion is
        the reviewer's, unchanged and now stronger.
        """
        def run(argv, **options):
            if argv[0] == claude_agent.PROVIDER_PROGRAM:
                self.write(os.path.join(options["cwd"], "harness.py"),
                           "print('now covered')\n")
                return subprocess.CompletedProcess(argv, 0, b"", b"")
            return subprocess.run(
                [sys.executable, "-c",
                 f"import sys;"
                 f"bearer = open({self.slot!r}, 'rb').read();"
                 f"sys.stdout.buffer.write(bearer);"
                 f"sys.stderr.buffer.write(bearer)"], **options)

        agent = ClaudeAgent(run=run, home=self.scratch)
        agent.work({"contract": "the frozen task"}, list(DECLARED))
        with open(self.proposal("verification.txt"), "rb") as handle:
            transcript = handle.read()
        self.assertNotIn(b"not-a-credential", transcript)

    def test_provider_stderr_cannot_print_the_mounted_credential(self):
        """A bounded provider diagnostic is still an untrusted secret sink.

        THE REVIEWER'S CASE, RUN AGAINST A REAL CHILD for the reason the case
        above gives, and EXTENDED TO THE SINK IT DID NOT NAME: `why` is what
        `recap` is composed from, so the interpolated diagnostic reached the
        worker's own `/output/output.json` as well as `result.json`.
        """
        def run(argv, **options):
            self.assertEqual(argv[0], claude_agent.PROVIDER_PROGRAM)
            return subprocess.run(
                [sys.executable, "-c",
                 f"import sys;"
                 f"sys.stderr.buffer.write("
                 f"open({self.slot!r}, 'rb').read());"
                 f"raise SystemExit(3)"], **options)

        agent = ClaudeAgent(run=run, home=self.scratch)
        answered = agent.work({"contract": "the frozen task"}, list(DECLARED))
        with open(self.proposal("result.json"), "rb") as handle:
            result = handle.read()
        self.assertNotIn(b"not-a-credential", result)
        self.assertNotIn("not-a-credential", answered["recap"])


class TheCheckedTreeIsProvedAtEveryComponent(AdapterCase):
    """W39357 review 2026-08-29T22:18:55Z [P1], as properties of the reader.

    The reviewer's own regressions drive the attack through `work`. These hold
    the two invariants that make it impossible, so a later change that keeps
    the attack out by accident still fails here.
    """

    def rooted(self):
        root = os.path.join(self.home, "rooted")
        self.write(os.path.join(root, "nested", "claude"), "ordinary\n")
        return root

    def test_an_intermediate_link_is_refused_rather_than_followed(self):
        root = self.rooted()
        self.assertEqual(claude_agent._read_under(root, "nested/claude", "t"),
                         b"ordinary\n")
        shutil.rmtree(os.path.join(root, "nested"))
        os.symlink(self.credentials, os.path.join(root, "nested"))
        with self.assertRaises(TaskRefusal) as refused:
            claude_agent._read_under(root, "nested/claude", "t")
        self.assertIn("without following a link", str(refused.exception))

    def test_a_final_link_is_refused_rather_than_followed(self):
        root = self.rooted()
        os.unlink(os.path.join(root, "nested", "claude"))
        os.symlink(self.slot, os.path.join(root, "nested", "claude"))
        with self.assertRaises(TaskRefusal):
            claude_agent._read_under(root, "nested/claude", "t")

    def test_a_swapped_tree_refuses_before_one_output_byte_is_written(self):
        """`_open_under` makes each read safe on its own; the revalidation
        after the payload's own command is what keeps a refusal from landing
        part-way through a published proposal."""
        def run(argv, **options):
            nested = os.path.join(options["cwd"], "nested")
            if argv[0] == claude_agent.PROVIDER_PROGRAM:
                self.write(os.path.join(nested, "claude"), "ordinary\n")
            else:
                shutil.rmtree(nested)
                os.symlink(self.credentials, nested)
            return subprocess.CompletedProcess(argv, 0, b"", b"")

        agent = ClaudeAgent(run=run, home=self.scratch)
        with self.assertRaises(TaskRefusal):
            agent.work({"contract": "the frozen task"}, list(DECLARED))
        self.assertFalse(os.path.exists(self.proposal()), self.proposal())


class TheMeasuredBytesAreWhatGetPublished(AdapterCase):
    """W39357 review 2026-08-29T22:51:53Z [P1], as properties.

    The reviewer's regression drives the mutation through `work`. These hold
    the rule around it: what verification may do, what it may not, and what
    the ceilings still cover once untrusted code has run.
    """

    def verifying(self, act):
        """A provider that edits, then a verification command that does
        `act` in the candidate."""
        def run(argv, **options):
            if argv[0] == claude_agent.PROVIDER_PROGRAM:
                self.write(os.path.join(options["cwd"], "harness.py"),
                           "print('now covered')\n")
            else:
                act(options["cwd"])
            return subprocess.CompletedProcess(argv, 0, b"", b"")
        return ClaudeAgent(run=run, home=self.scratch)

    def test_a_verification_that_grows_a_checked_file_is_refused(self):
        """Appending needs no link and no new inode, and it makes the patch an
        account of bytes the proposal does not carry."""
        def grow(cwd):
            with open(os.path.join(cwd, "harness.py"), "a") as handle:
                handle.write("# and one more line\n")

        with self.assertRaises(TaskRefusal) as refused:
            self.verifying(grow).work({"contract": "t"}, list(DECLARED))
        self.assertIn("changed at harness.py", str(refused.exception))
        self.assertFalse(os.path.exists(self.proposal()))

    def test_a_verification_that_deletes_a_checked_file_is_refused(self):
        with self.assertRaises(TaskRefusal):
            self.verifying(
                lambda cwd: os.unlink(os.path.join(cwd, "preflight.py"))
            ).work({"contract": "t"}, list(DECLARED))
        self.assertFalse(os.path.exists(self.proposal()))

    def test_a_verification_that_only_adds_is_not_a_fault(self):
        """A command that leaves a cache behind has invalidated nobody's
        evidence: what it added was never measured and is never published."""
        answered = self.verifying(
            lambda cwd: self.write(os.path.join(cwd, "__pycache__", "x.pyc"),
                                   "bytecode\n")
        ).work({"contract": "t"}, list(DECLARED))
        self.assertEqual(answered["disposition"], "completed")
        self.assertEqual(sorted(os.listdir(self.proposal("candidate"))),
                         ["harness.py", "preflight.py"])

    def test_what_verification_adds_is_counted_against_the_ceiling(self):
        """A fixed list could not see what ran AFTER it, so the bound the
        module advertises stopped applying at exactly the moment untrusted
        code did."""
        held = claude_agent.MAX_SOURCE_ENTRIES
        claude_agent.MAX_SOURCE_ENTRIES = 2
        self.addCleanup(setattr, claude_agent, "MAX_SOURCE_ENTRIES", held)
        with self.assertRaises(TaskRefusal) as refused:
            self.verifying(
                lambda cwd: os.mkdir(os.path.join(cwd, "one-more-entry"))
            ).work({"contract": "t"}, list(DECLARED))
        self.assertIn("exceeds this adapter's bound", str(refused.exception))

    def test_a_link_verification_leaves_behind_is_refused_by_the_fresh_walk(
            self):
        with self.assertRaises(TaskRefusal):
            self.verifying(
                lambda cwd: os.symlink(self.slot,
                                       os.path.join(cwd, "late-link"))
            ).work({"contract": "t"}, list(DECLARED))
        self.assertFalse(os.path.exists(self.proposal()))

    def test_the_published_bytes_are_the_bytes_the_patch_describes(self):
        """The positive half, so the rule is not only proved by refusals."""
        self.worked(edits={"harness.py": "print('now covered')\n"})
        with open(self.proposal("candidate", "harness.py"),
                  encoding="utf-8") as handle:
            published = handle.read()
        with open(self.proposal("change.patch"), encoding="utf-8") as handle:
            patch = handle.read()
        self.assertEqual(published, "print('now covered')\n")
        self.assertIn("+print('now covered')", patch)


class FailureIsHonest(AdapterCase):
    """Four ways a turn does not produce a useful result, and none of them may
    be reported as one."""

    def ended(self, **operands):
        answered = self.worked(**operands)
        return answered["disposition"], self.result()["disposition"]

    def test_a_provider_that_exits_nonzero_is_not_completed(self):
        self.assertEqual(self.ended(status=3),
                         ("unable", "provider-failed"))
        # THE STATUS, WHICH CAME FROM `wait`. This asserted that the
        # provider's own stderr appeared in `why` — which was the disclosure
        # W39357 review 2026-08-30T04:01:29Z [P1] found, so the assertion had
        # to go with it. What replaces it is that the failure is still named
        # exactly, and `NoChildStreamByteReachesTheProposal` holds the other
        # half: a real shouting provider reaches neither `why` nor `recap`.
        self.assertIn("the provider exited 3", self.result()["why"])

    def test_a_provider_that_never_started_is_not_completed(self):
        self.assertEqual(self.ended(missing=True),
                         ("unable", "provider-failed"))

    def test_a_provider_that_did_not_finish_is_not_completed(self):
        self.assertEqual(self.ended(timeout=True),
                         ("unable", "provider-failed"))

    def test_a_clean_turn_that_changed_nothing_is_not_completed(self):
        self.assertEqual(self.ended(), ("unable", "no-candidate"))

    def test_a_candidate_whose_verification_failed_is_not_completed(self):
        self.assertEqual(
            self.ended(edits={"harness.py": "raise SystemExit(1)\n"},
                       verify=1),
            ("unable", "verification-failed"))

    def test_a_failed_turn_still_publishes_the_required_output(self):
        """The declaration says the proposal is required, and the worker
        refuses an answer that reports a required output absent. So a failure
        writes the tree and says what happened in it."""
        self.worked(status=3)
        self.assertTrue(os.path.isdir(self.proposal()))
        self.assertTrue(os.path.exists(self.proposal("result.json")))

    # -- W321528: a failure reports the bound it actually failed under ------

    def test_a_timed_out_turn_names_one_bound_in_its_sentence_and_record(self):
        """What the two historic sealed results got wrong, reproduced in the
        shape that produced them: the `why` named the effective bound, the
        `seconds_bound` member named the constant, and the two were in the
        same document. They are one resolution now."""
        self.worked(timeout=True,
                    seen=self.launched(seconds=self.SELECTED_SECONDS))
        held = self.result()
        self.assertEqual(held["disposition"], "provider-failed")
        self.assertEqual(held["provider"]["failure_reason"],
                         claude_agent.PROVIDER_TIMED_OUT)
        self.assertEqual(held["provider"]["seconds_bound"],
                         self.SELECTED_SECONDS)
        self.assertEqual(held["provider"]["seconds_bound_source"],
                         claude_agent.JOB_SELECTED_BOUND)
        self.assertIn(f"within {self.SELECTED_SECONDS}s", held["why"])
        self.assertNotIn(str(claude_agent.PROVIDER_SECONDS),
                         json.dumps(held))

    def test_a_provider_that_never_started_still_reports_its_bound(self):
        """A turn with no child at all still ran under a ceiling, and the
        record says which -- an absent member here would be the one shape a
        reader cannot tell from a publisher that forgot."""
        self.worked(missing=True,
                    seen=self.launched(seconds=self.SELECTED_SECONDS))
        self.assertEqual(self.result()["provider"]["failure_reason"],
                         claude_agent.PROVIDER_START_ERROR)
        self.assertEqual(self.result()["provider"]["seconds_bound"],
                         self.SELECTED_SECONDS)
        self.assertEqual(self.result()["provider"]["seconds_bound_source"],
                         claude_agent.JOB_SELECTED_BOUND)

    def test_a_failed_verification_reports_the_bound_and_stays_unable(self):
        """A candidate WAS produced and the turn still failed. Reporting the
        real ceiling beside it changes neither fact."""
        answered = self.worked(edits={"harness.py": "raise SystemExit(1)\n"},
                               verify=1,
                               seen=self.launched(
                                   seconds=self.SELECTED_SECONDS))
        self.assertEqual(answered["disposition"], "unable")
        self.assertEqual(self.result()["disposition"], "verification-failed")
        self.assertEqual(self.result()["provider"]["seconds_bound"],
                         self.SELECTED_SECONDS)
        self.assertEqual(self.result()["provider"]["seconds_bound_source"],
                         claude_agent.JOB_SELECTED_BOUND)

    def test_the_verification_is_not_run_when_there_is_no_candidate(self):
        """A verification against an unchanged tree would pass and mean
        nothing; running it would manufacture evidence."""
        self.worked()
        self.assertEqual([argv for argv, _o in self.calls
                          if argv[0] != claude_agent.PROVIDER_PROGRAM], [])


class TheFrozenTaskIsAClosedDocument(AdapterCase):

    def refuses(self, document, expected):
        self.task(document)
        with self.assertRaises(TaskRefusal) as refused:
            self.worked()
        self.assertIn(expected, str(refused.exception))

    def test_an_absent_task_refuses(self):
        self.refuses(None, "no readable")

    def test_a_task_from_another_generation_refuses(self):
        # THE NEIGHBOURING GENERATION, whichever way it lies. This named `/2`
        # while the contract was `/1`; W71917 moved the contract to `/2`, so
        # the document from another generation is now `/1` -- the same test,
        # against a version this reader must still refuse rather than
        # downgrade to.
        self.refuses(dict(TASK, schema="baton.dogfood-task/1"),
                     "another generation")

    def test_an_extra_member_refuses(self):
        self.refuses(dict(TASK, alias="a second identity"), "unexpected alias")

    def test_a_missing_member_refuses(self):
        short = {name: value for name, value in TASK.items()
                 if name != "verification"}
        self.refuses(short, "missing verification")

    def test_a_task_identity_is_text_before_it_is_matched(self):
        """`str(7)` matches the identity regex, but a JSON number is not the
        versioned task's text identity and the sender already refuses it."""
        self.refuses(dict(TASK, task_id=7), "usable task identity")

    def test_a_verification_that_is_a_string_refuses(self):
        """There is no shell in this image, so a command this adapter would
        have to split is a command it cannot run."""
        self.refuses(dict(TASK, verification="python3 harness.py"),
                     "non-empty list of words")

    def test_a_source_root_other_than_the_fixed_one_refuses(self):
        """Review [P2]: containment was the wrong rule.

        `SOURCE_ROOT` was defined and never read, so the effective source was
        selected by the task payload while the module and the dossier both
        said the path is a constant. Any OTHER value is refused now, not only
        an escaping one — a sibling inside `/input` is exactly as much a
        payload-selected source as `../elsewhere` is.
        """
        for wrong in ("../elsewhere", "/etc", "a/../..", "..", "elsewhere",
                      "source/nested", ""):
            with self.subTest(source_root=wrong):
                self.refuses(dict(TASK, source_root=wrong),
                             "stages exactly 'source'"
                             if wrong else "bounded non-empty text")


class TheSourceCopyIsBoundedAndFollowsNoLink(AdapterCase):

    def test_a_link_in_the_staged_tree_refuses(self):
        os.symlink("/etc", os.path.join(self.source, "escape"))
        with self.assertRaises(TaskRefusal) as refused:
            self.worked()
        self.assertIn("link", str(refused.exception))

    def test_an_absent_source_tree_refuses(self):
        shutil.rmtree(self.source)
        with self.assertRaises(TaskRefusal) as refused:
            self.worked()
        self.assertIn("stages no source tree", str(refused.exception))

    def test_an_empty_source_tree_refuses(self):
        for name in os.listdir(self.source):
            os.unlink(os.path.join(self.source, name))
        with self.assertRaises(TaskRefusal) as refused:
            self.worked()
        self.assertIn("is empty", str(refused.exception))

    def test_a_tree_past_the_entry_bound_refuses(self):
        held = claude_agent.MAX_SOURCE_ENTRIES
        claude_agent.MAX_SOURCE_ENTRIES = 1
        self.addCleanup(setattr, claude_agent, "MAX_SOURCE_ENTRIES", held)
        with self.assertRaises(TaskRefusal) as refused:
            self.worked()
        self.assertIn("exceeds this adapter's bound", str(refused.exception))

    def test_staged_directories_count_against_the_entry_bound(self):
        """Review [P2], the other walk. A second party that counts differently
        from the walk it is checking is not proving the same thing."""
        os.mkdir(os.path.join(self.source, "one-more-entry"))
        held = claude_agent.MAX_SOURCE_ENTRIES
        claude_agent.MAX_SOURCE_ENTRIES = 2
        self.addCleanup(setattr, claude_agent, "MAX_SOURCE_ENTRIES", held)
        with self.assertRaises(TaskRefusal) as refused:
            self.worked()
        self.assertIn("exceeds this adapter's bound", str(refused.exception))

    def test_provider_created_directories_count_against_the_entry_bound(self):
        """The candidate bound covers directories as well as regular files."""
        held = claude_agent.MAX_SOURCE_ENTRIES
        claude_agent.MAX_SOURCE_ENTRIES = 2
        self.addCleanup(setattr, claude_agent, "MAX_SOURCE_ENTRIES", held)

        def run(argv, **options):
            if argv[0] == claude_agent.PROVIDER_PROGRAM:
                os.mkdir(os.path.join(options["cwd"], "one-more-entry"))
                self.write(os.path.join(options["cwd"], "harness.py"),
                           "print('now covered')\n")
            return subprocess.CompletedProcess(argv, 0, b"", b"")

        agent = ClaudeAgent(run=run, home=self.scratch)
        with self.assertRaises(TaskRefusal) as refused:
            agent.work({"contract": "the frozen task"}, list(DECLARED))
        self.assertIn("exceeds this adapter's bound", str(refused.exception))


class TheAgentContractIsWholeAndTheWorkerOwnsTheRest(AdapterCase):

    def test_exactly_one_declared_output_is_honoured(self):
        agent = ClaudeAgent(run=self.provider(), home=self.scratch)
        for declared in ([], list(DECLARED) * 2, "not a list"):
            with self.subTest(declared=declared):
                with self.assertRaises(TaskRefusal):
                    agent.work({}, declared)

    def test_consider_declines_rather_than_inventing_a_decision(self):
        """This runtime is not entitled to be asked; the object still answers
        the whole contract rather than the reachable half."""
        answered = ClaudeAgent().consider({"contract": "anything"}, {})
        self.assertEqual(answered["decision"], "decline")
        self.assertEqual(sorted(answered),
                         ["contract_digest", "decision", "reason"])

    def test_the_adapter_publishes_no_completion_manifest(self):
        """`/output/output.json` is the WORKER's document, published after
        this returns. An adapter that wrote one would be publishing protocol
        identity from the least trusted thing in the container."""
        self.worked(edits={"harness.py": "print('now covered')\n"})
        self.assertFalse(os.path.exists(
            os.path.join(self.outputs, "output.json")))

    def test_this_module_imports_nothing_from_the_manager(self):
        """The image's whole isolation rule, held as a property of the source
        rather than as a comment."""
        import ast
        tree = ast.parse((WORKER / "claude_agent.py").read_text("utf-8"))
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for one in node.names:
                    self.assertFalse(one.name.startswith("baton_v12"))
            elif isinstance(node, ast.ImportFrom):
                self.assertFalse((node.module or "").startswith("baton_v12"))


class TheRecipeIsInspectableWithoutADaemon(unittest.TestCase):
    """What the image says about itself, read off the recipe."""

    def setUp(self):
        self.lines = [one.strip() for one
                      in (WORKER / "Dockerfile.claude").read_text(
                          "utf-8").splitlines()
                      if one.strip() and not one.strip().startswith("#")]

    def test_the_provider_version_is_pinned(self):
        self.assertIn("ARG CLAUDE_VERSION=2.1.247", self.lines)

    def test_the_entrypoint_is_the_reference_worker_with_the_agent_injected(
            self):
        self.assertIn('ENTRYPOINT ["python3", "/opt/baton/dogfood_entry.py"]',
                      self.lines)
        entry = (WORKER / "dogfood_entry.py").read_text("utf-8")
        self.assertIn("from baton_worker import main", entry)
        self.assertIn("main(agent=ClaudeAgent())", entry)

    def test_the_reviewed_worker_and_its_frozen_contract_travel(self):
        """W71917 widened the build context to `v12`, so every source path in
        the recipe is spelled from there. What travels is unchanged."""
        for copied in ("COPY worker/baton_worker.py /opt/baton/baton_worker.py",
                       "COPY worker/claude_agent.py /opt/baton/claude_agent.py",
                       "COPY worker/worker-control-1.0.schema.json \\"):
            self.assertIn(copied, self.lines)

    def test_the_program_the_git_profile_names_is_installed(self):
        """W71917: an image carrying the plan and not the program composes a
        vector it cannot run.

        Measured before it was written: the image built without this and
        `command -v git` answered nothing, so the Git profile's clone, detach
        and rev-parse steps would each have failed at the first one. The
        manager stays Git-agnostic and runs none of them, which is exactly why
        the program has to be HERE.
        """
        installs = [one for one in self.lines if "apt-get install" in one]
        self.assertEqual(len(installs), 1, self.lines)
        self.assertIn(" git ", installs[0])

    def test_the_profile_package_travels_under_its_own_name(self):
        """W71917: the worker's half of the source boundary has to be IN the
        image, and it arrives without creating a `baton_v12` namespace there.

        `claude_agent` imports it as a top-level package, which is the same
        name this line lands it under; an image that copied it to
        `/opt/baton/baton_v12/source_profiles` would be one `mkdir` away from
        the namespace the case below refuses.
        """
        self.assertIn(
            "COPY python/src/baton_v12/source_profiles /opt/baton/"
            "source_profiles", self.lines)

    def test_the_fixed_non_root_identity_matches_the_adapters_restriction(
            self):
        self.assertIn("USER 65532:65532", self.lines)

    def test_no_provider_credential_is_named_in_the_image(self):
        """ASSERTED OVER THE INSTRUCTIONS, not the file.

        `self.lines` is comment-stripped, and the first cut of this case was
        not: it read the whole recipe and failed on the paragraph that explains
        why `ENV ANTHROPIC_*` is absent. A case that a comment can fail is a
        case that says nothing about the image.
        """
        for line in self.lines:
            self.assertFalse(line.startswith("ENV ANTHROPIC"), line)
            self.assertNotIn("ANTHROPIC_API_KEY=", line)
            self.assertNotIn("ANTHROPIC_AUTH_TOKEN=", line)

    def test_the_retired_environment_transport_is_absent(self):
        for line in self.lines:
            self.assertNotIn("BATON_WORKER_", line)

    def copies(self):
        """Every COPY in the recipe as (sources, destination).

        CONTINUATIONS ARE JOINED FIRST. W71917 second review [P2]: the recipe
        carries one COPY split across two physical lines, and reading the
        lines separately made its last token a backslash -- so its destination
        was never asserted and its continuation was not a COPY at all and was
        skipped. A recipe check that a line break can silently switch off is
        not a check.
        """
        joined = []
        for line in self.lines:
            if joined and joined[-1].endswith("\\"):
                joined[-1] = joined[-1][:-1].rstrip() + " " + line
                continue
            joined.append(line)
        found = []
        for line in joined:
            if not line.startswith("COPY "):
                continue
            words = [one for one in line.split()[1:]
                     if not one.startswith("--")]
            self.assertGreaterEqual(len(words), 2, line)
            found.append((words[:-1], words[-1]))
        self.assertTrue(found)
        return found

    def test_what_the_image_takes_from_the_distribution_IMPORTS_NO_MANAGER(self):
        """The property the allowlist is a proxy for, held directly.

        W198667: a second permitted path is only safe because of what is IN it.
        A worker that can import the manager is a worker one bug away from
        holding the manager's capabilities, so the admitted module is checked
        for what it imports rather than for what it is called.
        """
        import ast

        place = (pathlib.Path("/home/sl/src/baton/v12/python/src/baton_v12")
                 / "attempt_log_format.py")
        tree = ast.parse(place.read_text())
        imported = set()
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                imported.update(one.name for one in node.names)
            elif isinstance(node, ast.ImportFrom):
                imported.add(node.module or "")
        self.assertEqual(sorted(imported), ["itertools", "json", "os", "stat"])

    def test_nothing_from_the_manager_is_copied_in(self):
        """The rule is about the MANAGER, and W71917 made that distinction
        load-bearing rather than incidental.

        This used to refuse the string `baton_v12` anywhere in a COPY, which
        was exact while nothing from that tree travelled at all. The profile
        package now does, and it is not the manager: it imports nothing from
        `baton_v12` and `baton_v12.worker_manager` imports nothing from it,
        which `tests/manager/test_source_boundary` holds in both directions.

        AN ALLOWLIST, NOT AN APPROXIMATION OF ONE. W71917 second review [P2]:
        the first correction named three manager directories, which is a
        denylist that a COPY of `attempts.py`, `offers.py` or any other module
        would have walked straight through while still violating the property
        this case states. So the permitted paths are NAMED and everything else
        under `baton_v12` is refused whatever it is called.

        W198667 ADDS THE SECOND NAME, and it is admitted on exactly the rule
        that admitted the first. `attempt_log_format` is the capture
        declaration format, which a worker WRITES and a manager READS -- two
        implementations of one format is how they drift -- and it imports
        `itertools`, `json`, `os` and `stat` and nothing from `baton_v12`. The
        case below holds that property directly rather than trusting the name,
        because a name is what the allowlist checks and the IMPORT GRAPH is
        what the rule is actually about.
        """
        allowed = ("python/src/baton_v12/source_profiles",
                   "python/src/baton_v12/attempt_log_format.py")
        for sources, destination in self.copies():
            for source in sources:
                if "baton_v12" not in source:
                    continue
                self.assertIn(source, allowed,
                                 "the image copies material out of the "
                                 "manager's distribution that is not the "
                                 "profile package")
            # NOTHING LANDS UNDER THAT NAME. The source path may name the
            # distribution's layout; the destination may not create it, or the
            # worker could `import baton_v12` and hold the manager's
            # capabilities.
            self.assertNotIn("baton_v12", destination)

    def test_every_copy_lands_where_the_image_keeps_its_own_material(self):
        """The destination half, asked of EVERY COPY including the split one.

        This is the case the continuation defect hid: the worker-control
        schema's COPY is the one whose destination went unasserted, and a
        destination nobody checks is a path the recipe can move without a test
        noticing.
        """
        for _sources, destination in self.copies():
            self.assertTrue(destination.startswith("/opt/baton/"), destination)
        self.assertIn(
            (["worker/worker-control-1.0.schema.json"],
             "/opt/baton/worker-control-1.0.schema.json"),
            [(sources, destination) for sources, destination in self.copies()],
            "the split COPY was not joined, so its destination is unasserted")


# -- W105575: the prepared private line ---------------------------------------
#
# `work/records/2026/09/finding-v12-concrete-worker-proposal-head/`.
#
# EVERY CASE BELOW DRIVES REAL `git`, and that is the point rather than a
# convenience. What this Work delivers is a commit the MANAGER'S OWN checkpoint
# profile will freeze, an object bundle a stranger can resolve, and one private
# history that survives a correction round -- and not one of those is provable
# against a fake that answers whatever the adapter asked for. The provider stays
# injected exactly as it is above; only the version-control half is real.
#
# THE ENVIRONMENT IS COMPOSED, NEVER INHERITED, for the reason the container's
# is: the runtime has no Git configuration at all, and a developer's global
# `core.hooksPath`, `commit.gpgsign` or `user.name` would make these cases pass
# or fail for a reason the image does not have.

import baton_worker                                          # noqa: E402


LINE_TASK = {"schema": "baton.dogfood-task/2",
             "task_id": "w105575-private-line",
             "instructions": "Add focused coverage for _observed_readable.",
             "verification": ["python3", "harness.py"],
             "source_root": "source",
             "source_profile": "git-line",
             "declared_base": None}


class LineCase(AdapterCase):
    """One materialized private line, mounted where the workspace is."""

    def setUp(self):
        super().setUp()
        from baton_v12.checkpoint_profiles import GitCheckpointProfile
        self.git_calls = []
        self.git_home = os.path.join(self.home, "git-home")
        os.makedirs(self.git_home)
        self.origin = os.path.join(self.home, "origin")
        os.makedirs(self.origin)
        self.git("init", "-q", "-b", "main", at=self.origin)
        self.populate_origin()
        self.git("add", "--all", at=self.origin)
        self.git("commit", "-q", "--message", "base", at=self.origin)
        self.base = self.git("rev-parse", "HEAD", at=self.origin).strip()
        # THE MANAGER MATERIALIZES THE LINE, and this fixture uses the accepted
        # profile to do it rather than a hand-rolled clone: what the worker is
        # handed has to be what that component actually produces.
        self.git("clone", "-q", "--no-hardlinks", "--no-local", self.origin,
                 self.outputs, at=None)
        self.profile = GitCheckpointProfile(self.git_runner)
        self.profile.materialize(self.origin, self.outputs, self.base)
        self.task(dict(LINE_TASK, declared_base=self.base))

    def populate_origin(self):
        """What the baseline repository contains, as a HOOK (W202663 D10).

        The two files are the historical fixture unchanged; a case about the
        real repository's shape overrides this to commit what the real one
        commits -- symlinks included -- without duplicating the setup."""
        self.write(os.path.join(self.origin, "harness.py"),
                   "print('the staged harness')\n")
        self.write(os.path.join(self.origin, "preflight.py"),
                   "def _observed_readable():\n    return True\n")

    # -- real version control, composed environment -------------------------

    def environment(self):
        """What the adapter's own vectors run under: NO identity at all.

        The container has no Git configuration, so a commit that worked here
        only because the environment named an author would be a commit that
        cannot happen in the image. The adapter composes its identity onto the
        command line, and this is what makes that the only source of one.
        """
        return {"PATH": os.environ.get("PATH", "/usr/bin:/bin"),
                "HOME": self.git_home,
                "GIT_CONFIG_GLOBAL": os.devnull,
                "GIT_CONFIG_SYSTEM": os.devnull,
                "GIT_TERMINAL_PROMPT": "0"}

    def fixture_environment(self):
        """The FIXTURE's own identity, for the commits this test authors.

        Deliberately not the adapter's environment: these are the manager's
        and the provider's commits in the story being set up, and lending the
        adapter an identity through the environment would erase the case above.
        """
        return dict(self.environment(),
                    GIT_AUTHOR_NAME="Baton Test",
                    GIT_AUTHOR_EMAIL="test@baton.invalid",
                    GIT_COMMITTER_NAME="Baton Test",
                    GIT_COMMITTER_EMAIL="test@baton.invalid")

    def git(self, *arguments, at="LINE"):
        place = self.outputs if at == "LINE" else at
        argv = ["git"] + (["-C", place] if place is not None else []) \
            + list(arguments)
        answer = subprocess.run(argv, capture_output=True, text=True,
                                env=self.fixture_environment(), timeout=300)
        self.assertEqual(answer.returncode, 0,
                         f"{argv} failed: {answer.stderr}")
        return answer.stdout

    def git_runner(self, argv):
        answer = subprocess.run(list(argv), capture_output=True, text=True,
                                env=self.environment(), timeout=300)
        return {"returncode": answer.returncode, "stdout": answer.stdout,
                "stderr": answer.stderr}

    def runner(self, **operands):
        """The adapter's one process seam: real version control, and every
        other child injected exactly as the cases above inject it."""
        fake = self.provider(**operands)

        def run(argv, **options):
            if argv[0] == "git":
                self.git_calls.append(list(argv))
                return subprocess.run(list(argv), env=self.environment(),
                                      **options)
            return fake(argv, **options)

        return run

    def turn_scratch(self):
        """A fresh private root per turn, because a turn is a fresh container.

        The adapter creates its predictable child roots EXCLUSIVELY and refuses
        to repair one that already exists. Reusing a scratch across two turns
        would be the fixture asking it to, and the correction rounds below are
        about the LINE surviving, not the tmpfs.
        """
        place = tempfile.mkdtemp(prefix="v12-w105575-", dir=self.home)
        self.addCleanup(shutil.rmtree, place, True)
        return place

    def worked(self, *, seen=None, **operands):
        agent = ClaudeAgent(run=self.runner(**operands),
                            home=self.turn_scratch())
        return agent.work({"contract": "the frozen task"} if seen is None
                          else seen, list(DECLARED))

    # -- the worker's complete ending ---------------------------------------

    def completed(self, answered):
        """`baton_worker`'s OWN completion envelope, published where it will be.

        This is not decoration. The envelope is written AFTER the agent returns
        and it lands in the workspace, which under this profile is the line --
        so a proof that stopped at `work` would be proving a freeze that cannot
        happen in production.
        """
        held = baton_worker.OUTPUT_ROOT
        baton_worker.OUTPUT_ROOT = self.outputs
        try:
            return baton_worker.publish_completion(
                {"work_ref": {"authority_uuid": "0" * 32,
                              "work_id": "01234567-W1"},
                 "participant": "baton.impl", "generation": 1},
                answered["disposition"],
                [{"name": one["name"], "type": "directory-result",
                  "path": "proposal", "status": one["status"],
                  "content_manifest": None,
                  "result_metadata": one["result_metadata"]}
                 for one in answered["outputs"]])
        finally:
            baton_worker.OUTPUT_ROOT = held

    def frozen(self, revision):
        return self.profile.freeze(self.outputs, line_id="line-w105575",
                                   revision=revision, declared_base=self.base)

    def claim(self, answered):
        return answered["outputs"][0]["result_metadata"][
            claude_agent.CLAIM_NAMESPACE]


class ThePreparedLineTurnCommitsAndDeclaresItsObjects(LineCase):

    def test_one_worker_commit_continues_the_admitted_entry_head(self):
        answered = self.worked(edits={"harness.py": "print('now covered')\n"})
        self.assertEqual(answered["disposition"], "completed")
        claim = self.claim(answered)
        self.assertEqual(sorted(claim), sorted(claude_agent.CLAIM_MEMBERS))
        # THE BASE IS THE IMMUTABLE ONE and the head is this turn's commit.
        self.assertEqual(claim["base"], self.base)
        self.assertEqual(claim["head"], self.git("rev-parse", "HEAD").strip())
        self.assertNotEqual(claim["head"], self.base)
        # EXACTLY ONE COMMIT, and its parent is where the turn was admitted.
        self.assertEqual(self.git("rev-parse", "HEAD^").strip(), self.base)
        self.assertEqual(
            self.git("rev-list", "--count", f"{self.base}..HEAD").strip(), "1")

    def test_the_declared_output_carries_objects_and_no_candidate_tree(self):
        self.worked(edits={"harness.py": "print('now covered')\n"})
        self.assertEqual(sorted(os.listdir(self.proposal())),
                         ["change.patch", "objects.bundle", "result.json",
                          "verification.txt"])
        # THE CANDIDATE IS A COMMIT NOW. A copy of its files beside it would be
        # a second account of the same bytes for somebody to reconcile.
        self.assertFalse(os.path.exists(self.proposal("candidate")))
        self.assertEqual(self.result()["schema"],
                         claude_agent.LINE_RESULT_SCHEMA)
        self.assertEqual(self.result()["changed_paths"], ["harness.py"])
        self.assertEqual(self.result()["base"], self.base)

    def test_the_complete_worker_ending_leaves_a_freezable_line(self):
        """The whole point, and the step a `work`-only proof would miss."""
        answered = self.worked(edits={"harness.py": "print('now covered')\n"})
        envelope = self.completed(answered)
        self.assertTrue(os.path.exists(
            os.path.join(self.outputs, "output.json")))
        self.assertEqual(envelope["outputs"][0]["result_metadata"],
                         answered["outputs"][0]["result_metadata"])
        evidence = self.frozen(1)
        self.assertEqual(evidence["head"], self.claim(answered)["head"])
        self.assertEqual(evidence["base"], self.base)
        self.assertEqual(evidence["paths"], ["harness.py"])
        self.assertEqual(self.git("rev-parse", evidence["reference"]).strip(),
                         evidence["head"])

    # -- W321528: the bound the Git-line publisher reports -------------------

    def test_the_line_result_reports_this_workers_default_with_no_job(self):
        self.worked(edits={"harness.py": "print('now covered')\n"})
        self.assertEqual(self.result()["provider"]["seconds_bound"],
                         claude_agent.PROVIDER_SECONDS)
        self.assertEqual(self.result()["provider"]["seconds_bound_source"],
                         claude_agent.WORKER_DEFAULT_BOUND)

    def test_the_line_result_reports_the_operator_selected_bound(self):
        """THE DEFECT, in the Git-line publisher -- the one the two historic
        runs were sealed by. A proposal retained on a private line carried
        `seconds_bound: 3600` beside a turn the Job had bounded far lower."""
        self.worked(edits={"harness.py": "print('now covered')\n"},
                    seen=self.launched(seconds=self.SELECTED_SECONDS))
        self.assertNotEqual(self.SELECTED_SECONDS,
                            claude_agent.PROVIDER_SECONDS)
        self.assertEqual(self.result()["provider"]["seconds_bound"],
                         self.SELECTED_SECONDS)
        self.assertEqual(self.result()["provider"]["seconds_bound_source"],
                         claude_agent.JOB_SELECTED_BOUND)

    def test_the_line_result_separates_a_job_default_from_no_job_at_all(self):
        self.worked(edits={"harness.py": "print('now covered')\n"},
                    seen=self.launched())
        self.assertEqual(self.result()["provider"]["seconds_bound"],
                         claude_agent.PROVIDER_SECONDS)
        self.assertEqual(self.result()["provider"]["seconds_bound_source"],
                         claude_agent.JOB_DEFAULT_BOUND)

    def test_a_timed_out_line_turn_reports_one_bound_in_both_places(self):
        """The sentence and the member come from the same resolution now.

        W319114's sealed evidence is the two disagreeing: a `why` naming the
        real bound beside a `seconds_bound` naming the constant. A turn that
        timed out also published no commit, which this asserts stays true --
        the bound repair does not soften a failure."""
        answered = self.worked(timeout=True,
                               seen=self.launched(
                                   seconds=self.SELECTED_SECONDS))
        self.assertEqual(answered["disposition"], "unable")
        self.assertEqual(self.result()["disposition"], "provider-failed")
        self.assertEqual(self.result()["provider"]["seconds_bound"],
                         self.SELECTED_SECONDS)
        self.assertEqual(self.result()["provider"]["failure_reason"],
                         claude_agent.PROVIDER_TIMED_OUT)
        self.assertIn(f"within {self.SELECTED_SECONDS}s",
                      self.result()["why"])
        self.assertNotIn(str(claude_agent.PROVIDER_SECONDS),
                         json.dumps(self.result()))

    def test_the_reserved_names_are_this_workers_and_never_the_candidates(self):
        self.assertEqual(claude_agent.COMPLETION_MANIFEST,
                         baton_worker.OUTPUT_MANIFEST)
        self.assertEqual(claude_agent.COMPLETION_STAGING,
                         baton_worker.OUTPUT_MANIFEST + ".publishing")
        self.worked(edits={"harness.py": "print('now covered')\n"})
        self.completed(self.worked(edits={"harness.py": "print('again')\n"}))
        with open(os.path.join(self.outputs, ".git", "info", "exclude"),
                  encoding="utf-8") as handle:
            written = handle.read().splitlines()
        self.assertEqual(sorted(written),
                         ["/output.json", "/output.json.publishing",
                          "/proposal", "/result-*"])
        # NOTHING RESERVED IS IN THE HISTORY, however many turns have run.
        self.assertEqual(
            self.git("ls-files", "--", "output.json", "proposal",
                     "result-*").strip(), "")

    def test_a_manager_created_result_root_never_enters_the_candidate(self):
        os.makedirs(os.path.join(self.outputs, "result-attempt-1"))
        answered = self.worked(edits={"harness.py": "print('now covered')\n"})
        self.completed(answered)
        self.assertEqual(self.result()["changed_paths"], ["harness.py"])
        self.frozen(1)

    def test_the_commit_runs_no_hook_at_all(self):
        """`--no-verify` would leave `prepare-commit-msg` running, so the
        guarantee is the hook PATH rather than the flag."""
        hooks = os.path.join(self.outputs, ".git", "hooks")
        os.makedirs(hooks, exist_ok=True)
        marker = os.path.join(self.home, "hook-ran")
        self.write(os.path.join(hooks, "prepare-commit-msg"),
                   f"#!/bin/sh\ntouch {marker}\n")
        os.chmod(os.path.join(hooks, "prepare-commit-msg"), 0o755)
        self.worked(edits={"harness.py": "print('now covered')\n"})
        self.assertFalse(os.path.exists(marker),
                         "a repository hook ran during the worker's commit")
        commits = [argv for argv in self.git_calls if "commit" in argv]
        self.assertEqual(len(commits), 1)
        self.assertIn(f"core.hooksPath={claude_agent.NO_HOOKS}", commits[0])
        self.assertIn("--no-gpg-sign", commits[0])

    def test_every_worker_vector_carries_its_ownership_override(self):
        """The runtime is uid 65532 and the line is the manager's."""
        self.worked(edits={"harness.py": "print('now covered')\n"})
        self.assertTrue(self.git_calls)
        for argv in self.git_calls:
            self.assertIn(f"safe.directory={self.outputs}", argv)

    def test_no_index_write_reaches_a_hook_either(self):
        """`post-index-change` runs on an INDEX WRITE, so a commit-only
        override leaves staging and even a status refresh uncovered."""
        hooks = os.path.join(self.outputs, ".git", "hooks")
        os.makedirs(hooks, exist_ok=True)
        marker = os.path.join(self.home, "index-hook-ran")
        self.write(os.path.join(hooks, "post-index-change"),
                   f"#!/bin/sh\ntouch {marker}\n")
        os.chmod(os.path.join(hooks, "post-index-change"), 0o755)
        self.worked(edits={"harness.py": "print('now covered')\n"})
        self.assertFalse(os.path.exists(marker),
                         "a repository hook ran during an index write")
        # ONE COMPOSED PREFIX rather than a policy applied per call site: a
        # per-site rule has a gap in it the moment somebody adds a site.
        self.assertTrue(self.git_calls)
        for argv in self.git_calls:
            self.assertIn(f"core.hooksPath={claude_agent.NO_HOOKS}", argv)


class TheCommittedChangeIsTheMeasuredChange(LineCase):

    def test_a_deletion_is_proved_by_absence_and_not_by_a_blob(self):
        def run(argv, **options):
            if argv[0] == claude_agent.PROVIDER_PROGRAM:
                os.unlink(os.path.join(options["cwd"], "preflight.py"))
                self.write(os.path.join(options["cwd"], "harness.py"),
                           "print('now covered')\n")
                return subprocess.CompletedProcess(argv, 0, None, None)
            if argv[0] == "git":
                self.git_calls.append(list(argv))
                return subprocess.run(list(argv), env=self.environment(),
                                      **options)
            return subprocess.CompletedProcess(argv, 0, None, None)

        answered = ClaudeAgent(run=run, home=self.scratch).work(
            {"contract": "the frozen task"}, list(DECLARED))
        self.completed(answered)
        self.assertEqual(self.result()["changed_paths"],
                         ["harness.py", "preflight.py"])
        self.assertEqual(
            self.git("cat-file", "-t",
                     f"{self.claim(answered)['head']}^{{tree}}").strip(),
            "tree")
        self.assertFalse(os.path.exists(
            os.path.join(self.outputs, "preflight.py")))
        self.frozen(1)

    def test_a_transforming_filter_refuses_before_anything_is_published(self):
        """A clean filter makes the committed blob differ from the bytes this
        adapter verified, and no later comparison can tell them apart."""
        self.git("config", "filter.shout.clean", "tr a-z A-Z")
        self.write(os.path.join(self.outputs, ".gitattributes"),
                   "harness.py filter=shout\n")
        self.git("add", "--all")
        self.git("commit", "-q", "--message", "attributes")
        self.base = self.git("rev-parse", "HEAD").strip()
        self.task(dict(LINE_TASK, declared_base=self.base))
        with self.assertRaises(TaskRefusal) as caught:
            self.worked(edits={"harness.py": "print('now covered')\n"})
        self.assertIn("filter", str(caught.exception))

    def test_the_bytes_committed_are_the_bytes_that_were_measured(self):
        answered = self.worked(edits={"harness.py": "print('now covered')\n"})
        head = self.claim(answered)["head"]
        self.assertEqual(self.git("cat-file", "blob", f"{head}:harness.py"),
                         "print('now covered')\n")

    def test_an_ignored_dependency_publishes_and_is_disclosed(self):
        """Owner 2026-09-21T12:47:17Z superseded the veto this case held.

        The turn verifies BECAUSE the ignored file is on disk, and the
        published head cannot carry it. The old regime refused outright;
        the owner is the integrator now, so the turn PUBLISHES the changes
        it can deliver and DISCLOSES what the collection excluded -- whether
        the verification relied on it is the integrator's question, put in
        the record rather than adjudicated by the adapter."""
        answered = self.worked(edits={
            ".gitignore": "ignored-data.txt\n",
            "ignored-data.txt": "needed\n",
            "harness.py": "print('reads the data')\n"})
        self.assertEqual(answered["disposition"], "completed")
        record = self.result()
        self.assertEqual(record["collection"]["excluded_ignored"],
                         ["ignored-data.txt"])
        self.assertIn("verification ran", record["collection"]["note"])
        head = self.claim(answered)["head"]
        delivered = self.git("diff", "--name-only",
                             f"{self.base}..{head}").split()
        self.assertNotIn("ignored-data.txt", delivered)
        self.assertIn("harness.py", delivered)
        self.assertIn(".gitignore", delivered)

    def test_an_edit_status_cannot_see_is_still_held_to_its_bytes(self):
        """Equal path sets still permit different bytes.

        `assume-unchanged` is an index flag, not a history mutation: the entry
        is clean, the edit is invisible to status and to every diff, and the
        path is in BOTH accounts. So a comparison over the reported change set
        never reaches it, the committed blob stays the original, and the
        verification that passed read the new bytes. The comparison that
        catches it asks Git only for what it stored.
        """
        self.git("update-index", "--assume-unchanged", "preflight.py")
        answered = self.worked(edits={"preflight.py": "verified payload\n",
                                      "harness.py": "print('reads preflight')\n"})
        # OWNER 2026-09-21T12:47:17Z RETIRED the whole-tree guarantee this
        # case once asserted, by name: the collection is status-based, so an
        # index-hidden edit is neither measured nor delivered. What survives
        # -- and is asserted -- is the narrow integrity the ruling keeps:
        # every DELIVERED change carries exactly the verified bytes, and the
        # hidden edit is provably absent from the published head rather than
        # smuggled into it.
        self.assertEqual(answered["disposition"], "completed")
        head = self.claim(answered)["head"]
        delivered = self.git("diff", "--name-only",
                             f"{self.base}..{head}").split()
        self.assertEqual(delivered, ["harness.py"])
        self.assertEqual(
            self.git("show", f"{head}:preflight.py"),
            "def _observed_readable():\n    return True\n")

    def test_every_measured_path_is_compared_and_not_only_the_changed_ones(
            self):
        """The unchanged files are in the comparison too, which is what makes
        it independent of what Git reported."""
        answered = self.worked(edits={"harness.py": "print('now covered')\n"})
        head = self.claim(answered)["head"]
        self.assertEqual(self.result()["changed_paths"], ["harness.py"])
        # `preflight.py` never appears in the change set and its bytes were
        # still held against the commit.
        self.assertEqual(
            self.git("cat-file", "blob", f"{head}:preflight.py"),
            "def _observed_readable():\n    return True\n")
        self.assertEqual(
            [argv for argv in self.git_calls if "--batch" in argv][0][-3:],
            ["cat-file", "--batch", "-Z"])

    def test_the_committed_tree_is_the_measured_tree_in_both_directions(self):
        answered = self.worked(edits={"harness.py": "print('now covered')\n",
                                      "added.py": "print('new')\n"})
        head = self.claim(answered)["head"]
        committed = sorted(
            one for one in
            self.git("ls-tree", "-r", "--name-only", head).splitlines() if one)
        self.assertEqual(committed, ["added.py", "harness.py",
                                     "preflight.py"])
        # THE RESERVED NAMES ARE IN NEITHER ACCOUNT, whoever wrote them.
        self.completed(answered)
        self.assertNotIn("output.json", committed)
        self.assertNotIn("proposal", committed)


class TheSamePrivateHistorySurvivesACorrectionRound(LineCase):

    def test_two_turns_advance_one_line_against_an_unchanged_base(self):
        first = self.worked(edits={"harness.py": "print('round one')\n"})
        self.completed(first)
        one = self.frozen(1)
        second = self.worked(edits={"harness.py": "print('round two')\n"})
        self.completed(second)
        two = self.frozen(2)
        # THE ENTRY HEAD MOVED AND THE BASE DID NOT, which is the whole reason
        # the two are separate facts.
        self.assertEqual(self.claim(first)["base"], self.base)
        self.assertEqual(self.claim(second)["base"], self.base)
        self.assertNotEqual(one["head"], two["head"])
        self.assertEqual(self.git("rev-parse", f"{two['head']}^").strip(),
                         one["head"])
        self.assertEqual(two["base"], self.base)
        # AND REVISION ONE IS STILL RESOLVABLE after the line advanced.
        self.assertEqual(self.git("rev-parse", one["reference"]).strip(),
                         one["head"])

    def test_the_second_rounds_proposal_is_still_offered_against_the_base(self):
        self.completed(self.worked(edits={"harness.py": "print('one')\n"}))
        self.frozen(1)
        self.completed(self.worked(edits={"extra.py": "print('two')\n"}))
        # CUMULATIVE, because a proposal is taken against the canonical target
        # rather than against the previous correction round.
        self.assertEqual(self.result()["changed_paths"],
                         ["extra.py", "harness.py"])


class TheDeclaredObjectsResolveForAStrangerHoldingOnlyTheBase(LineCase):

    def recipient(self, name):
        place = os.path.join(self.home, name)
        self.git("clone", "-q", "--no-hardlinks", "--no-local", self.origin,
                 place, at=None)
        return place

    def test_the_bundle_resolves_the_head_without_the_producers_objects(self):
        answered = self.worked(edits={"harness.py": "print('now covered')\n"})
        self.completed(answered)
        head = self.claim(answered)["head"]
        bundle = self.proposal(self.claim(answered)["transport"])
        place = self.recipient("recipient")
        # IT HOLDS THE BASE AND NOTHING OF THIS TURN'S.
        self.git("cat-file", "-e", self.base, at=place)
        missing = subprocess.run(["git", "-C", place, "cat-file", "-e", head],
                                 capture_output=True, env=self.environment())
        self.assertNotEqual(missing.returncode, 0)
        self.git("bundle", "verify", bundle, at=place)
        self.git("fetch", "-q", bundle, "HEAD:refs/heads/incoming", at=place)
        self.assertEqual(self.git("rev-parse", "incoming", at=place).strip(),
                         head)
        self.assertEqual(
            self.git("cat-file", "blob", f"{head}:harness.py", at=place),
            "print('now covered')\n")

    def test_the_second_rounds_bundle_carries_the_cumulative_range(self):
        self.completed(self.worked(edits={"harness.py": "print('one')\n"}))
        self.frozen(1)
        second = self.worked(edits={"extra.py": "print('two')\n"})
        self.completed(second)
        head = self.claim(second)["head"]
        place = self.recipient("late-recipient")
        self.git("bundle", "verify",
                 self.proposal(self.claim(second)["transport"]), at=place)
        self.git("fetch", "-q", self.proposal(self.claim(second)["transport"]),
                 "HEAD:refs/heads/incoming", at=place)
        self.assertEqual(self.git("rev-parse", "incoming", at=place).strip(),
                         head)
        # BOTH ROUNDS' OBJECTS, from a recipient that never saw round one.
        self.assertEqual(
            self.git("cat-file", "blob", f"{head}:harness.py", at=place),
            "print('one')\n")


class ThePreparedLineRefusesWhatItCannotAccountFor(LineCase):

    def test_a_line_that_does_not_descend_from_the_base_refuses(self):
        self.task(dict(LINE_TASK, declared_base="d" * 40))
        with self.assertRaises(TaskRefusal) as caught:
            self.worked(edits={"harness.py": "print('now covered')\n"})
        self.assertIn("development line", str(caught.exception))

    def test_a_dirty_line_refuses_before_the_provider_runs(self):
        self.write(os.path.join(self.outputs, "harness.py"), "left behind\n")
        with self.assertRaises(TaskRefusal) as caught:
            self.worked(edits={"harness.py": "print('now covered')\n"})
        self.assertIn("uncommitted", str(caught.exception))
        self.assertEqual(self.calls, [])

    def test_a_provider_that_committed_refuses_rather_than_being_adopted(self):
        def run(argv, **options):
            if argv[0] == claude_agent.PROVIDER_PROGRAM:
                self.write(os.path.join(options["cwd"], "harness.py"),
                           "print('now covered')\n")
                self.git("add", "--all")
                self.git("commit", "-q", "--message", "the provider's own")
                return subprocess.CompletedProcess(argv, 0, None, None)
            if argv[0] == "git":
                self.git_calls.append(list(argv))
                return subprocess.run(list(argv), env=self.environment(),
                                      **options)
            return subprocess.CompletedProcess(argv, 0, None, None)

        with self.assertRaises(TaskRefusal) as caught:
            ClaudeAgent(run=run, home=self.scratch).work(
                {"contract": "the frozen task"}, list(DECLARED))
        self.assertIn("HEAD moved", str(caught.exception))

    def test_a_tracked_reserved_name_refuses_rather_than_being_ignored(self):
        """An ignore rule cannot remove tracked content from a candidate."""
        self.write(os.path.join(self.outputs, "output.json"), "{}\n")
        self.git("add", "--all")
        self.git("commit", "-q", "--message", "a tracked reserved name")
        self.base = self.git("rev-parse", "HEAD").strip()
        self.task(dict(LINE_TASK, declared_base=self.base))
        with self.assertRaises(TaskRefusal) as caught:
            self.worked(edits={"harness.py": "print('now covered')\n"})
        self.assertIn("already tracks", str(caught.exception))

    def test_a_declared_path_that_is_a_pattern_refuses_before_reserving(self):
        """A declared path is a path; an ignore entry is a pattern."""
        declared = [dict(DECLARED[0], path="propos*l")]
        agent = ClaudeAgent(run=self.runner(edits={}), home=self.scratch)
        with self.assertRaises(TaskRefusal) as caught:
            agent.work({"contract": "the frozen task"}, declared)
        self.assertIn("not an ignore pattern", str(caught.exception))

    def test_a_no_op_correction_publishes_no_earlier_turns_objects(self):
        """The declared output SURVIVES on a persistent line, so a member's
        absence has to be made rather than assumed.

        The first turn's bundle carries objects for a head the second turn
        does not claim, and the manager collects whatever is in the declared
        output -- so leaving it there seals another turn's proposal as this
        one's.
        """
        first = self.worked(edits={"harness.py": "print('first')\n"})
        self.completed(first)
        self.frozen(1)
        self.assertTrue(os.path.exists(self.proposal("objects.bundle")))
        second = self.worked(edits={})
        self.assertEqual(second["disposition"], "unable")
        self.assertEqual(second["outputs"][0]["result_metadata"], {})
        self.assertIsNone(self.result()["head"])
        self.assertFalse(os.path.exists(self.proposal("objects.bundle")))
        self.assertEqual(sorted(os.listdir(self.proposal())),
                         ["change.patch", "result.json", "verification.txt"])
        # THE LINE AND ITS RETAINED CHECKPOINT ARE UNTOUCHED. The worker owns
        # its own declared members and nothing else.
        self.assertEqual(self.git("rev-parse", "HEAD").strip(),
                         self.claim(first)["head"])
        self.completed(second)
        self.assertEqual(self.frozen(2)["head"], self.claim(first)["head"])

    def test_a_later_turns_bundle_replaces_the_earlier_one(self):
        first = self.worked(edits={"harness.py": "print('first')\n"})
        self.completed(first)
        self.frozen(1)
        with open(self.proposal("objects.bundle"), "rb") as handle:
            earlier = handle.read()
        second = self.worked(edits={"extra.py": "print('second')\n"})
        with open(self.proposal("objects.bundle"), "rb") as handle:
            self.assertNotEqual(handle.read(), earlier)
        self.assertEqual(self.result()["head"], self.claim(second)["head"])

    def test_an_unchanged_line_commits_nothing_and_claims_nothing(self):
        answered = self.worked(edits={})
        self.assertEqual(answered["disposition"], "unable")
        self.assertEqual(answered["outputs"][0]["result_metadata"], {})
        self.assertEqual(self.git("rev-parse", "HEAD").strip(), self.base)
        self.assertEqual(self.result()["changed_paths"], [])
        self.assertIsNone(self.result()["head"])
        self.assertFalse(os.path.exists(self.proposal("objects.bundle")))
        self.completed(answered)
        self.frozen(1)

    def test_a_workspace_that_is_not_a_repository_is_never_rebuilt(self):
        shutil.rmtree(os.path.join(self.outputs, ".git"))
        with self.assertRaises(TaskRefusal) as caught:
            self.worked(edits={"harness.py": "print('now covered')\n"})
        self.assertIn("never cloned", str(caught.exception))
        self.assertFalse(os.path.exists(
            os.path.join(self.outputs, ".git")))

    def test_a_linked_repository_directory_is_never_written_through(self):
        """The provider owns this workspace for part of the turn, and a `.git`
        replaced by a link is how a write lands somewhere nobody authorized."""
        elsewhere = os.path.join(self.home, "elsewhere")
        os.makedirs(os.path.join(elsewhere, "info"))
        shutil.rmtree(os.path.join(self.outputs, ".git"))
        os.symlink(elsewhere, os.path.join(self.outputs, ".git"))
        with self.assertRaises(TaskRefusal) as caught:
            self.worked(edits={"harness.py": "print('now covered')\n"})
        self.assertIn("its own directory", str(caught.exception))
        self.assertFalse(os.path.exists(
            os.path.join(elsewhere, "info", "exclude")))

    def test_the_commit_identity_comes_from_the_argv_and_nowhere_else(self):
        """The container has no Git configuration and this environment has no
        identity, so a commit that happened at all proves where it came from."""
        answered = self.worked(edits={"harness.py": "print('now covered')\n"})
        head = self.claim(answered)["head"]
        self.assertEqual(
            self.git("show", "-s", "--format=%an <%ae>", head).strip(),
            f"{claude_agent.COMMIT_NAME} <{claude_agent.COMMIT_EMAIL}>")
        self.assertEqual(
            self.git("show", "-s", "--format=%s", head).strip(),
            f"baton candidate: {LINE_TASK['task_id']}")


if __name__ == "__main__":
    unittest.main()


# -- W110772: the review turn -------------------------------------------------

REVIEW_DECLARED = [
    {"name": "findings", "type": "directory-result", "path": "findings",
     "required": False,
     "constraints": {"max_bytes": 1 << 20, "max_entries": 100,
                     "allowed_media_types": ["text/plain"],
                     "link_policy": "forbid", "validator_digest": None}},
    {"name": "logs", "type": "directory-result", "path": "logs",
     "required": False,
     "constraints": {"max_bytes": 1 << 20, "max_entries": 100,
                     "allowed_media_types": ["text/plain"],
                     "link_policy": "forbid", "validator_digest": None}}]

# The shared Job's declaration set: the union both stages are launched under,
# because every stage of one Job matches that Job's ONE input digest.
SHARED_DECLARED = [
    {"name": "proposal", "type": "git-change-proposal", "path": "proposal",
     "required": False,
     "constraints": {"max_bytes": 1 << 20, "max_entries": 100,
                     "allowed_media_types": ["text/plain"],
                     "link_policy": "forbid", "validator_digest": None}}
] + REVIEW_DECLARED


class ReviewCase(AdapterCase):
    """One frozen line mounted READ-ONLY at `/input/source`, and a review turn.

    THE ARRANGEMENT IS THE MANAGER'S, and it is the mirror image of `LineCase`.
    An implementation turn gets the line as its writable workspace; a reviewer
    gets it as its read-only input and a separate writable output. So the
    repository is staged where the source mount is and `/output` holds only the
    two directories this turn authors.
    """

    def setUp(self):
        super().setUp()
        self.git_home = os.path.join(self.home, "git-home")
        os.makedirs(self.git_home)
        self.git("init", "-q", "-b", "main")
        self.git("add", "--all")
        self.git("commit", "-q", "--message", "base")
        self.base = self.git("rev-parse", "HEAD").strip()
        self.write(os.path.join(self.source, "harness.py"),
                   "print('the reviewed harness')\n")
        self.git("add", "--all")
        self.git("commit", "-q", "--message", "the change under review")
        self.head = self.git("rev-parse", "HEAD").strip()
        self.tree = self.git("rev-parse", "HEAD^{tree}").strip()
        self.task(dict(LINE_TASK, declared_base=self.base))

    def environment(self):
        return {"PATH": os.environ.get("PATH", "/usr/bin:/bin"),
                "HOME": self.git_home,
                "GIT_CONFIG_GLOBAL": os.devnull,
                "GIT_CONFIG_SYSTEM": os.devnull,
                "GIT_TERMINAL_PROMPT": "0",
                "GIT_AUTHOR_NAME": "Baton Test",
                "GIT_AUTHOR_EMAIL": "test@baton.invalid",
                "GIT_COMMITTER_NAME": "Baton Test",
                "GIT_COMMITTER_EMAIL": "test@baton.invalid"}

    def git(self, *arguments):
        answer = subprocess.run(["git", "-C", self.source] + list(arguments),
                                capture_output=True, text=True,
                                env=self.environment(), timeout=300)
        self.assertEqual(answer.returncode, 0,
                         f"git {arguments} failed: {answer.stderr}")
        return answer.stdout

    def report(self, verdict="accepted", findings="the change is coherent",
               body=...):
        """What the "provider" writes: its report, and nothing else."""
        if body is ...:
            body = json.dumps({"schema": claude_agent.REVIEW_REPORT_SCHEMA,
                               "verdict": verdict, "findings": findings})
        return body

    def runner(self, *, report=..., status=0, timeout=False, missing=False,
               after=None):
        """Real version control for the observation, an injected provider."""
        self.calls = []

        def run(argv, **options):
            if argv[0] == "git":
                return subprocess.run(list(argv), env=self.environment(),
                                      **options)
            self.calls.append((list(argv), dict(options)))
            if timeout:
                raise subprocess.TimeoutExpired(argv, 1)
            if missing:
                raise OSError("no such file")
            if report is not None:
                self.write(os.path.join(options["cwd"],
                                        claude_agent.REVIEW_REPORT),
                           self.report() if report is ... else report)
            if after is not None:
                after()
            return subprocess.CompletedProcess(argv, status, None, None)

        return run

    def reviewed(self, declared=None, *, seen=None, **operands):
        agent = ClaudeAgent(run=self.runner(**operands),
                            home=tempfile.mkdtemp(prefix="v12-w110772-",
                                                  dir=self.home))
        return agent.work(dict({"contract": "the frozen task"}
                               if seen is None else seen,
                               role=claude_agent.REVIEW_ROLE),
                          list(REVIEW_DECLARED if declared is None
                               else declared))

    def findings(self, *parts):
        return os.path.join(self.outputs, "findings", *parts)

    def logs(self, *parts):
        return os.path.join(self.outputs, "logs", *parts)

    def read(self, place):
        with open(place, encoding="utf-8") as handle:
            return handle.read()

    def claim(self, answered):
        held = {one["name"]: one for one in answered["outputs"]}
        return held["findings"]["result_metadata"].get(
            claude_agent.REVIEW_CLAIM_NAMESPACE)


class TheReviewTurnAuthorsAVerdictItDidNotDecide(ReviewCase):
    """The positive turn: a validated report becomes a claim and two outputs."""

    def test_a_valid_report_produces_findings_logs_and_one_claim(self):
        answered = self.reviewed()
        self.assertEqual(answered["disposition"], "completed")
        self.assertEqual(
            {one["name"]: one["status"] for one in answered["outputs"]},
            {"findings": "present", "logs": "present"})
        self.assertEqual(self.claim(answered),
                         {"verdict": "accepted", "base": self.base,
                          "head": self.head, "tree": self.tree})

    def test_the_findings_output_carries_the_document_and_its_prose(self):
        self.reviewed(report=self.report(verdict="changes-requested",
                                         findings="the tests do not cover x"))
        held = json.loads(self.read(self.findings(
            claude_agent.REVIEW_RESULT)))
        self.assertEqual(held, {"schema": claude_agent.REVIEW_REPORT_SCHEMA,
                                "verdict": "changes-requested",
                                "findings": "the tests do not cover x"})
        self.assertEqual(self.read(self.findings(
            claude_agent.REVIEW_FINDINGS)), "the tests do not cover x\n")

    def test_every_verdict_word_the_manager_records_is_carried(self):
        for verdict in claude_agent.REVIEW_VERDICTS:
            with self.subTest(verdict=verdict):
                self.setUp()
                answered = self.reviewed(report=self.report(verdict=verdict))
                self.assertEqual(self.claim(answered)["verdict"], verdict)

    def test_the_claim_is_closed_and_carries_no_manager_identity(self):
        answered = self.reviewed()
        self.assertEqual(sorted(self.claim(answered)),
                         sorted(claude_agent.REVIEW_CLAIM_MEMBERS))

    def test_the_logs_are_adapter_authored_and_name_no_child_stream(self):
        self.reviewed()
        held = json.loads(self.read(self.logs(claude_agent.REVIEW_LOG)))
        self.assertEqual(held["schema"], claude_agent.REVIEW_LOG_SCHEMA)
        self.assertEqual(held["reviewed"], {"base": self.base,
                                            "head": self.head,
                                            "tree": self.tree})
        self.assertEqual(held["provider"]["status"], 0)
        self.assertEqual(sorted(held),
                         ["provider", "report_bytes", "reviewed", "schema",
                          "task_id", "verdict", "verification"])

    # -- W321528: the bound the review log reports ---------------------------

    def test_the_review_log_reports_this_workers_default_with_no_job(self):
        self.reviewed()
        held = json.loads(self.read(self.logs(claude_agent.REVIEW_LOG)))
        self.assertEqual(held["provider"]["seconds_bound"],
                         claude_agent.PROVIDER_SECONDS)
        self.assertEqual(held["provider"]["seconds_bound_source"],
                         claude_agent.WORKER_DEFAULT_BOUND)

    def test_the_review_log_reports_the_operator_selected_bound(self):
        """THE DEFECT, in the review publisher. A review turn runs under the
        same Job ceiling an implementation turn does, and its log named the
        constant -- so the one record an operator reads about a reviewer
        container described a bound nobody had configured."""
        self.reviewed(seen=self.launched(seconds=self.SELECTED_SECONDS))
        held = json.loads(self.read(self.logs(claude_agent.REVIEW_LOG)))
        self.assertNotEqual(self.SELECTED_SECONDS,
                            claude_agent.PROVIDER_SECONDS)
        self.assertEqual(held["provider"]["seconds_bound"],
                         self.SELECTED_SECONDS)
        self.assertEqual(held["provider"]["seconds_bound_source"],
                         claude_agent.JOB_SELECTED_BOUND)
        # AND THE VERDICT IS STILL THE REPORT'S. Reporting the real bound
        # neither makes nor unmakes a decision.
        self.assertEqual(self.claim(self.reviewed())["verdict"], "accepted")

    def test_the_review_log_separates_a_job_default_from_no_job_at_all(self):
        self.reviewed(seen=self.launched())
        held = json.loads(self.read(self.logs(claude_agent.REVIEW_LOG)))
        self.assertEqual(held["provider"]["seconds_bound"],
                         claude_agent.PROVIDER_SECONDS)
        self.assertEqual(held["provider"]["seconds_bound_source"],
                         claude_agent.JOB_DEFAULT_BOUND)

    def test_the_reviewed_source_is_never_written_to(self):
        """The manager mounts it read-only; this proves the adapter does not
        try, which is the half a fixture can actually observe."""
        before = self.git("status", "--porcelain")
        self.reviewed()
        self.assertEqual(self.git("status", "--porcelain"), before)
        self.assertEqual(self.git("rev-parse", "HEAD").strip(), self.head)
        self.assertFalse(os.path.exists(
            os.path.join(self.source, claude_agent.REVIEW_REPORT)))

    def test_the_provider_runs_outside_the_output_and_the_source(self):
        self.reviewed()
        [(argv, options)] = self.calls
        self.assertEqual(argv[0], claude_agent.PROVIDER_PROGRAM)
        self.assertFalse(options["cwd"].startswith(self.outputs))
        self.assertFalse(options["cwd"].startswith(self.source))

    def test_the_prompt_asks_for_an_assessment_and_names_no_protocol(self):
        self.reviewed()
        [(argv, _options)] = self.calls
        prompt = argv[-1]
        self.assertIn(self.source, prompt)
        self.assertIn(claude_agent.REVIEW_REPORT, prompt)
        for verdict in claude_agent.REVIEW_VERDICTS:
            self.assertIn(verdict, prompt)
        # THE VERIFICATION COMMAND IS NAMED AS A CLAIM RATHER THAN AS EVIDENCE.
        self.assertIn("not evidence that it passed", prompt)
        # AND THE PROTOCOL IS STILL NOT DESCRIBED TO THE PROVIDER.
        self.assertNotIn(self.outputs, prompt)
        self.assertNotIn("output.json", prompt)


class NoUsableReportIsNoVerdictAtAll(ReviewCase):
    """The whole reason this channel exists: silence is not a decision."""

    def unable(self, **operands):
        answered = self.reviewed(**operands)
        self.assertEqual(answered["disposition"], "unable")
        self.assertIsNone(self.claim(answered))
        self.assertEqual(
            {one["name"]: one["status"] for one in answered["outputs"]},
            {"findings": "missing-optional", "logs": "present"})
        self.assertFalse(os.path.exists(self.findings()))
        return answered

    def test_a_provider_that_wrote_nothing_decided_nothing(self):
        self.unable(report=None)

    def test_a_failed_provider_earns_no_verdict_even_with_a_report(self):
        """A turn that failed is a turn whose account is incomplete, and an
        exit status is not a decision this adapter maps into one."""
        self.unable(status=1)

    def test_a_timed_out_provider_decides_nothing(self):
        answered = self.unable(timeout=True)
        self.assertIn(claude_agent.PROVIDER_TIMED_OUT, answered["recap"])

    def test_a_provider_that_could_not_start_decides_nothing(self):
        answered = self.unable(missing=True)
        self.assertIn(claude_agent.PROVIDER_START_ERROR, answered["recap"])

    # -- W321528: a turn that decided nothing still says what bounded it -----

    def test_a_timed_out_review_names_its_effective_bound_and_no_verdict(self):
        """The log is the only account an unanswered review leaves, so the
        bound in it is the one the turn actually ran under. The absence of a
        verdict is unchanged: a bound reported honestly is not a decision."""
        answered = self.unable(timeout=True,
                               seen=self.launched(
                                   seconds=self.SELECTED_SECONDS))
        held = json.loads(self.read(self.logs(claude_agent.REVIEW_LOG)))
        self.assertIsNone(held["verdict"])
        self.assertEqual(held["provider"]["seconds_bound"],
                         self.SELECTED_SECONDS)
        self.assertEqual(held["provider"]["seconds_bound_source"],
                         claude_agent.JOB_SELECTED_BOUND)
        self.assertEqual(held["provider"]["failure_reason"],
                         claude_agent.PROVIDER_TIMED_OUT)
        self.assertNotIn(str(claude_agent.PROVIDER_SECONDS),
                         json.dumps(held))
        self.assertIn(claude_agent.PROVIDER_TIMED_OUT, answered["recap"])

    def test_a_review_that_wrote_nothing_still_reports_the_default_bound(self):
        self.unable(report=None)
        held = json.loads(self.read(self.logs(claude_agent.REVIEW_LOG)))
        self.assertIsNone(held["verdict"])
        self.assertEqual(held["provider"]["seconds_bound"],
                         claude_agent.PROVIDER_SECONDS)
        self.assertEqual(held["provider"]["seconds_bound_source"],
                         claude_agent.WORKER_DEFAULT_BOUND)

    def test_a_report_that_is_not_a_readable_document_decides_nothing(self):
        self.unable(report="{not json at all")

    def test_a_report_from_another_generation_decides_nothing(self):
        self.unable(report=json.dumps({"schema": "baton.review-report/2",
                                       "verdict": "accepted",
                                       "findings": "fine"}))

    def test_a_report_with_an_unknown_verdict_decides_nothing(self):
        self.unable(report=json.dumps(
            {"schema": claude_agent.REVIEW_REPORT_SCHEMA,
             "verdict": "looks-fine", "findings": "fine"}))

    def test_a_report_with_an_extra_member_decides_nothing(self):
        self.unable(report=json.dumps(
            {"schema": claude_agent.REVIEW_REPORT_SCHEMA,
             "verdict": "accepted", "findings": "fine", "score": 9}))

    def test_a_report_answering_one_name_twice_decides_nothing(self):
        self.unable(report='{"schema": "%s", "verdict": "accepted", '
                           '"verdict": "rejected", "findings": "fine"}'
                           % claude_agent.REVIEW_REPORT_SCHEMA)

    def test_a_report_with_empty_findings_decides_nothing(self):
        self.unable(report=json.dumps(
            {"schema": claude_agent.REVIEW_REPORT_SCHEMA,
             "verdict": "accepted", "findings": "   \n"}))

    def test_a_report_wider_than_the_ceiling_decides_nothing(self):
        self.unable(report=json.dumps(
            {"schema": claude_agent.REVIEW_REPORT_SCHEMA,
             "verdict": "accepted",
             "findings": "x" * (claude_agent.MAX_REPORT_BYTES + 16)}))

    def test_a_report_that_is_a_fifo_decides_nothing_and_does_not_hang(self):
        """REVIEW 2026-09-07T15-19-16Z [P1]: the report was opened blocking
        before anything proved it a regular file, so a provider that created
        this name as a FIFO and exited successfully left the adapter waiting
        for a writer that never arrives -- outside its own bounded invocation,
        so the provider deadline bounded nothing about it.

        THE CASE IS ITS OWN PROOF OF NOT HANGING: it runs in this process with
        no writer anywhere, so a blocking open never returns and the suite
        stops. Returning at all is the assertion."""
        def after():
            place = os.path.join(self.calls[-1][1]["cwd"],
                                 claude_agent.REVIEW_REPORT)
            os.unlink(place)
            os.mkfifo(place)

        self.unable(after=after)

    def test_a_report_naming_a_link_decides_nothing(self):
        def after():
            place = os.path.join(self.calls[-1][1]["cwd"],
                                 claude_agent.REVIEW_REPORT)
            os.unlink(place)
            os.symlink(os.path.join(self.source, "harness.py"), place)

        self.unable(after=after)

    def test_findings_no_encoder_will_accept_decide_nothing(self):
        """REVIEW [P1]: `json` decodes an escaped lone surrogate into a `str`
        no UTF-8 encoder accepts, so the report passed every check and then
        raised `UnicodeEncodeError` from the findings writer -- after the logs
        output was published and while findings was half written. Adopting
        text is adopting the obligation to publish it."""
        self.unable(report='{"schema": "%s", "verdict": "accepted", '
                           '"findings": "bad \\ud800 surrogate"}'
                           % claude_agent.REVIEW_REPORT_SCHEMA)

    def test_a_report_that_is_a_directory_decides_nothing(self):
        def after():
            place = os.path.join(self.calls[-1][1]["cwd"],
                                 claude_agent.REVIEW_REPORT)
            os.unlink(place)
            os.mkdir(place)

        self.unable(after=after)


class TheReviewedObjectsAreObservedAndNotAsserted(ReviewCase):

    def refusal(self, **operands):
        with self.assertRaises(claude_agent.TaskRefusal) as caught:
            self.reviewed(**operands)
        return caught.exception

    def test_a_line_that_moved_under_the_review_is_refused(self):
        def after():
            self.write(os.path.join(self.source, "late.py"), "late\n")
            self.git("add", "--all")
            self.git("commit", "-q", "--message", "moved under the reviewer")

        caught = self.refusal(after=after)
        self.assertIn("moved while it was being reviewed", str(caught))

    def test_a_declared_base_this_line_does_not_carry_is_refused(self):
        self.task(dict(LINE_TASK, declared_base="f" * 40))
        self.refusal()

    def test_a_task_with_no_declared_base_is_refused(self):
        self.task(dict(LINE_TASK, declared_base=None))
        caught = self.refusal()
        self.assertIn("declares no base", str(caught))

    def test_another_source_profile_is_refused_rather_than_attempted(self):
        self.task(dict(TASK, source_profile="generic", declared_base=None))
        caught = self.refusal()
        self.assertIn("git-line", str(caught))


class TheSharedJobDeclaresBothStagesOutputs(ReviewCase):
    """Every stage of one Job matches one input digest, so the declaration set
    is the union and each role produces its own half."""

    def test_a_review_turn_answers_the_proposal_absent(self):
        answered = self.reviewed(declared=SHARED_DECLARED)
        self.assertEqual(
            {one["name"]: one["status"] for one in answered["outputs"]},
            {"proposal": "missing-optional", "findings": "present",
             "logs": "present"})
        self.assertEqual(
            {one["name"] for one in answered["outputs"]},
            {one["name"] for one in SHARED_DECLARED})

    def test_a_declaration_this_workload_does_not_know_is_refused(self):
        with self.assertRaises(claude_agent.TaskRefusal) as caught:
            self.reviewed(declared=REVIEW_DECLARED + [
                dict(REVIEW_DECLARED[0], name="transcript",
                     path="transcript")])
        self.assertIn("transcript", str(caught.exception))

    def test_a_review_turn_needs_both_of_its_own_outputs(self):
        with self.assertRaises(claude_agent.TaskRefusal) as caught:
            self.reviewed(declared=[REVIEW_DECLARED[0]])
        self.assertIn("logs", str(caught.exception))

    def test_the_other_stages_output_may_not_be_declared_required(self):
        required = [dict(one, required=one["name"] == "proposal")
                    for one in SHARED_DECLARED]
        with self.assertRaises(claude_agent.TaskRefusal) as caught:
            self.reviewed(declared=required)
        self.assertIn("required", str(caught.exception))


class TheTwoEndsAgreeOnTheReviewVocabulary(unittest.TestCase):
    """The image carries no `baton_v12`, so the words are spelled twice and
    held against each other here rather than imported across the boundary."""

    def test_the_verdict_words_are_the_managers_own_dispositions(self):
        from baton_v12.worker_manager import review_cycles
        self.assertEqual(sorted(claude_agent.REVIEW_VERDICTS),
                         sorted(review_cycles.DISPOSITIONS))

    def test_the_claim_namespace_and_members_are_the_readers_own(self):
        from baton_v12.job_manager import review_driver
        self.assertEqual(claude_agent.REVIEW_CLAIM_NAMESPACE,
                         review_driver.REVIEW_CLAIM_NAMESPACE)
        self.assertEqual(sorted(claude_agent.REVIEW_CLAIM_MEMBERS),
                         sorted(review_driver.REVIEW_CLAIM_MEMBERS))

    def test_the_two_output_names_are_the_ones_a_verdict_requires(self):
        from baton_v12.job_manager import review_driver
        self.assertEqual(sorted(claude_agent.REVIEW_OUTPUTS),
                         sorted((review_driver.FINDINGS_OUTPUT,
                                 review_driver.LOGS_OUTPUT)))


class TheOrdinaryTestObservationIsTheActualOne(LineCase):
    """W112029: the worker already ran the required command; nothing new does.

    `work/records/2026/09/finding-v12-ordinary-test-admission/`. What was
    missing is a way for integration admission to resolve that same fact from
    the frozen result, so this asserts the observation is the adapter's own
    read of the child it already started -- never a flag a provider set.

    THE COMMAND REALLY RUNS HERE. Review 2026-09-07T17-47-09Z [P1]: the first
    version of these cases inherited a runner that returned a
    `CompletedProcess` for every non-Git argv, so the status in the metadata
    was one the fixture injected and the case proved only that the member was
    carried. `really()` below executes the task's own verification argv for
    real, so a status of zero is a command that actually exited zero.
    """

    def really(self, **operands):
        """The adapter's process seam with the VERIFICATION COMMAND REAL.

        Git is real, as `LineCase` already makes it; the provider stays
        injected, because a model turn is what a deterministic case cannot
        have. The task's own command is executed with `subprocess.run` in the
        candidate, which is the one thing the accepted contract asks this
        observation to be about.
        """
        fake = self.provider(**operands)

        def run(argv, **options):
            if argv[0] == "git":
                self.git_calls.append(list(argv))
                return subprocess.run(list(argv), env=self.environment(),
                                      **options)
            if list(argv) == list(LINE_TASK["verification"]):
                return subprocess.run(list(argv), **options)
            return fake(argv, **options)

        return run

    def ran(self, **operands):
        agent = ClaudeAgent(run=self.really(**operands),
                            home=self.turn_scratch())
        return agent.work({"contract": "the frozen task"}, list(DECLARED))

    def observation(self, answered):
        return answered["outputs"][0]["result_metadata"].get(
            claude_agent.ORDINARY_TESTS_NAMESPACE)

    def test_an_actual_passing_command_is_reported_with_its_real_status(self):
        """The candidate's own `harness.py` is executed; nothing injects a
        status, and a zero here is a process that exited zero."""
        answered = self.ran(edits={"harness.py": "print('edited')\n"})
        held = self.observation(answered)
        self.assertEqual(held["status"], 0)
        self.assertEqual(held["argv"], list(LINE_TASK["verification"]))

    def test_an_actual_failing_command_is_reported_with_its_real_status(self):
        """The command is made to fail by what the provider WROTE, so the
        non-zero status comes from a real process rather than an operand."""
        answered = self.ran(
            edits={"harness.py": "raise SystemExit(3)\n"})
        self.assertEqual(self.observation(answered)["status"], 3)

    def test_a_passing_command_is_reported_with_its_actual_status(self):
        answered = self.worked(edits={"harness.py": "print('edited')\n"})
        held = self.observation(answered)
        self.assertEqual(sorted(held),
                         sorted(claude_agent.ORDINARY_TESTS_MEMBERS))
        self.assertEqual(held["status"], 0)
        self.assertEqual(held["task_id"], LINE_TASK["task_id"])
        self.assertEqual(held["argv"], list(LINE_TASK["verification"]))
        self.assertEqual(held["base"], self.base)
        self.assertEqual(held["head"],
                         self.claim(answered)["head"])

    def test_a_failing_command_keeps_its_nonzero_status(self):
        """Failed stays failed: this adapter reports what `wait` answered and
        decides nothing about it.

        The status here is the fixture's, which is what makes this a check of
        the CARRIAGE rather than of the execution; the two cases above run the
        command for real.
        """
        answered = self.worked(edits={"harness.py": "print('edited')\n"},
                               verify=1)
        self.assertEqual(self.observation(answered)["status"], 1)

    def test_the_digest_names_the_exact_task_bytes_this_turn_read(self):
        import hashlib
        answered = self.worked(edits={"harness.py": "print('edited')\n"})
        with open(os.path.join(self.inputs, claude_agent.TASK_DOCUMENT),
                  "rb") as handle:
            raw = handle.read()
        self.assertEqual(self.observation(answered)["task_digest"],
                         "sha256:" + hashlib.sha256(raw).hexdigest())

    def test_the_observation_carries_no_boolean_and_no_verdict(self):
        """There is no `passed` in it. A status is what a child exited with;
        deciding whether that satisfies a requirement belongs to the consumer
        that holds the requirement."""
        answered = self.worked(edits={"harness.py": "print('edited')\n"})
        held = self.observation(answered)
        for absent in ("passed", "verified", "ok", "result"):
            self.assertNotIn(absent, held)
        # ASKED BY TYPE, because `0 == False` in Python and a status of zero is
        # exactly the value this observation is most often carrying.
        for name, value in held.items():
            with self.subTest(member=name):
                self.assertIsNot(value, True)
                self.assertIsNot(value, False)

    def test_the_proposal_claim_beside_it_is_unchanged(self):
        """The existing four-field namespace keeps exactly its members: this
        adds a second observation rather than widening the first."""
        answered = self.worked(edits={"harness.py": "print('edited')\n"})
        self.assertEqual(sorted(self.claim(answered)),
                         sorted(claude_agent.CLAIM_MEMBERS))

    def test_a_turn_that_published_nothing_carries_neither(self):
        """No candidate, so nothing for either document to be about."""
        answered = self.worked()
        self.assertEqual(answered["outputs"][0]["result_metadata"], {})


def _diagnostic_record(**changes):
    document = {"type": "result", "subtype": "success", "is_error": True,
                "terminal_reason": "api_error", "api_error_status": None,
                "result": claude_agent.PROVIDER_OAUTH_EXPLANATION}
    document.update(changes)
    return json.dumps(document).encode()


class SupportedProviderDetail(AdapterCase):
    """W71879: real anonymous-pipe input, exact constant output, no provider run."""
    MARKER = "PROVIDER-DETAIL-SECRET-148870"
    speaking = TheStructuredRecordIsMappedAndNeverPublished.speaking
    turned = TheStructuredRecordIsMappedAndNeverPublished.turned
    published = TheStructuredRecordIsMappedAndNeverPublished.published

    def test_fixed_explanation_survives_real_pipe_and_untrusted_siblings_do_not(self):
        body = _diagnostic_record(request_id=self.MARKER,
                                  hidden={self.MARKER: self.MARKER})
        answer = self.turned(says=body.decode(), status=1, chunks=4)
        provider = self.result()["provider"]
        self.assertEqual("api-error", provider["failure_reason"])
        self.assertEqual("provider-failed", self.result()["disposition"])
        self.assertEqual("unable", answer["disposition"])
        self.assertEqual("authentication_failed", provider["diagnostic"]["classification"])
        self.assertEqual(claude_agent.PROVIDER_OAUTH_EXPLANATION,
                         provider["diagnostic"]["explanation"])
        self.assertIsNone(provider["diagnostic"]["request_id"])
        self.assertNotIn(self.MARKER.encode(), self.published())
        self.assertNotIn(self.MARKER, answer["recap"])

    def test_arbitrary_error_prose_is_withheld_but_http_status_survives(self):
        body = _diagnostic_record(result=self.MARKER, api_error_status=401,
                                  request_id=self.MARKER)
        answer = self.turned(says=body.decode(), status=1, chunks=3)
        detail = self.result()["provider"]["diagnostic"]
        self.assertEqual(401, detail["http_status"])
        self.assertEqual("unknown", detail["classification"])
        self.assertEqual("withheld", detail["explanation_status"])
        self.assertIsNone(detail["explanation"])
        self.assertNotIn(self.MARKER.encode(), self.published())
        self.assertNotIn(self.MARKER, answer["recap"])

    def test_zero_exit_does_not_publish_even_recognized_error_record(self):
        self.turned(says=_diagnostic_record().decode(), status=0)
        self.assertNotIn("diagnostic", self.result()["provider"])
        self.assertIsNone(self.result()["provider"]["failure_reason"])

    def test_partial_and_oversized_records_have_no_detail(self):
        for body, partial in [(_diagnostic_record(), True),
                              (_diagnostic_record()+b" "*65536, False)]:
            detail = claude_agent._provider_diagnostic(body, partial=partial)
            self.assertIsNone(detail["explanation"])
            self.assertIsNone(detail["http_status"])
            self.assertEqual("unavailable", detail["explanation_status"])

    def test_supported_record_and_full_constant_are_required(self):
        for changes in ({"type": "assistant"}, {"subtype": "error_during_execution"},
                        {"is_error": 1}, {"is_error": False},
                        {"terminal_reason": self.MARKER},
                        {"result": claude_agent.PROVIDER_OAUTH_EXPLANATION+self.MARKER},
                        {"result": {"text": claude_agent.PROVIDER_OAUTH_EXPLANATION}},
                        {"result": self.MARKER}):
            with self.subTest(changes=changes):
                detail = claude_agent._provider_diagnostic(_diagnostic_record(**changes), partial=False)
                self.assertEqual("unknown", detail["classification"])
                self.assertIsNone(detail["explanation"])
                self.assertNotIn(self.MARKER, json.dumps(detail))

    def test_http_status_is_typed_bounded_and_never_an_authentication_cause(self):
        for code in (400,401,403,429,500,599,True,False,399,600,-1,401.0,self.MARKER,None):
            detail = claude_agent._provider_diagnostic(_diagnostic_record(result="",api_error_status=code),partial=False)
            self.assertEqual(code if type(code) is int and 400<=code<=599 else None, detail["http_status"])
            self.assertEqual("unknown", detail["classification"])
            self.assertNotIn(self.MARKER,json.dumps(detail))

    def test_strict_parser_failures_cannot_leak_or_classify(self):
        good = _diagnostic_record().decode()
        for raw in (b"{",good.encode()+b" {}",b'[]',b'"x"',b'\xff',
                    (good[:-1]+',"is_error":true}').encode(),
                    (good[:-1]+',"other":NaN}').encode(),
                    (good[:-1]+',"other":'+"["*30000+"0"+"]"*30000+'}').encode()):
            detail = claude_agent._provider_diagnostic(raw,partial=False)
            self.assertEqual("unavailable",detail["explanation_status"])
            self.assertIsNone(detail["explanation"])
            self.assertIsNone(detail["http_status"])


class SupportedLineProviderDetail(LineCase):
    def test_line_proposal_retains_supported_detail_without_candidate(self):
        with mock.patch.object(ClaudeAgent,"_ran_provider",return_value=(1,_diagnostic_record(),False)):
            answer=self.worked()
        result=self.result()
        self.assertEqual("baton.dogfood-proposal/2",result["schema"])
        self.assertEqual("provider-failed",result["disposition"])
        self.assertEqual("unable",answer["disposition"])
        self.assertEqual(claude_agent.PROVIDER_OAUTH_EXPLANATION,result["provider"]["diagnostic"]["explanation"])
        self.assertEqual({},answer["outputs"][0]["result_metadata"])


class SupportedReviewProviderDetail(ReviewCase):
    def test_review_log_retains_detail_without_a_verdict(self):
        marker="PROVIDER-REVIEW-SECRET-148870"
        with mock.patch.object(ClaudeAgent,"_ran_provider",return_value=(1,_diagnostic_record(request_id=marker),False)):
            answer=self.reviewed(report=None)
        raw=self.read(self.logs(claude_agent.REVIEW_LOG));result=json.loads(raw)
        self.assertEqual("baton.review-log/1",result["schema"])
        self.assertIsNone(result["verdict"])
        self.assertEqual("unable",answer["disposition"])
        self.assertEqual(claude_agent.PROVIDER_OAUTH_EXPLANATION,result["provider"]["diagnostic"]["explanation"])
        self.assertNotIn(marker,raw)
        self.assertNotIn(marker,answer["recap"])
        self.assertIsNone(self.claim(answer))


class TheNativeSessionActivityObservation(AdapterCase):
    """W61599, approver ruling M61707: how much, never what.

    THE SOURCE IS THE ADAPTER'S OWN PRIVATE HOME. `_prepared_home` builds
    `$HOME/.claude` under this turn's scratch and puts exactly one entry in it
    -- the credential SYMLINK -- so native files appearing beneath it during a
    turn were written by this container's own provider invocation. No vendor
    directory layout is hardcoded and nothing is opened: what is observed is
    file metadata, and a LENGTH is content-free by construction, which is the
    only reason any of this may cross a container boundary at all.
    """

    def agent(self, *, home=None):
        return ClaudeAgent(run=self.provider(), home=home)

    def native(self, root, name, body):
        self.write(os.path.join(root, name), body)
        return os.path.join(root, name)

    def bound(self, scratch=None, *, home=None):
        """One agent with its baseline bound over a private `.claude`."""
        agent = self.agent(home=home)
        place = scratch if scratch is not None else os.path.join(self.home,
                                                                 "turn")
        os.makedirs(os.path.join(place, "home",
                                 claude_agent.PROVIDER_HOME_STATE),
                    exist_ok=True)
        agent._bound_activity(place)
        return agent, os.path.join(place, "home",
                                   claude_agent.PROVIDER_HOME_STATE)

    # -- the baseline --------------------------------------------------------

    def test_the_launch_path_performs_no_scan_and_no_stat(self):
        """THE BASELINE IS ADMITTED, NOT MEASURED. An earlier revision of this
        design scanned or stat-ed at launch; a bounded walk is still work the
        provider waits behind, and on a slow filesystem it is a turn delayed
        for a diagnostic."""
        agent = self.agent()
        refusing = mock.Mock(side_effect=AssertionError("the launch path "
                                                        "touched the disk"))
        with mock.patch.object(os, "scandir", refusing), \
                mock.patch.object(os, "listdir", refusing), \
                mock.patch.object(os, "stat", refusing), \
                mock.patch.object(os, "lstat", refusing):
            agent._bound_activity(os.path.join(self.home, "turn"))

    def test_a_scratch_this_process_made_counts_from_the_first_byte(self):
        """PROVED BY CONSTRUCTION. `tempfile.mkdtemp` answers a directory this
        process just created, so its `.claude` is provably empty of native
        files at that instant -- a true pre-launch zero with no scan."""
        agent, state = self.bound()
        self.native(state, "session.jsonl", "x" * 120)
        self.assertEqual(agent.observed_activity(), 120)

    def test_an_injected_or_reused_home_is_unknown_for_the_whole_operation(self):
        """AN UNPROVED HOME IS NEVER ESTIMATED. No scan reconstructs a baseline
        and no restored history is subtracted; the honest answer is unknown."""
        agent, state = self.bound(home=self.scratch)
        self.native(state, "session.jsonl", "x" * 120)
        self.assertIsNone(agent.observed_activity())

    def test_restored_history_under_an_unproved_home_fabricates_nothing(self):
        place = os.path.join(self.home, "restored")
        state = os.path.join(place, "home", claude_agent.PROVIDER_HOME_STATE)
        os.makedirs(state)
        self.native(state, "old.jsonl", "y" * 5000)
        agent = self.agent(home=place)
        agent._bound_activity(place)
        self.assertIsNone(agent.observed_activity())

    def test_an_agent_that_never_launched_a_provider_observes_nothing(self):
        self.assertIsNone(self.agent().observed_activity())

    # -- the accounting ------------------------------------------------------

    def test_the_total_is_monotonic_across_growth(self):
        agent, state = self.bound()
        place = self.native(state, "session.jsonl", "a" * 100)
        self.assertEqual(agent.observed_activity(), 100)
        with open(place, "a", encoding="utf-8") as writing:
            writing.write("b" * 50)
        self.assertEqual(agent.observed_activity(), 150)

    def test_a_second_file_contributes_its_whole_size_once(self):
        agent, state = self.bound()
        self.native(state, "one.jsonl", "a" * 100)
        self.assertEqual(agent.observed_activity(), 100)
        self.native(state, "projects/slug/two.jsonl", "b" * 40)
        self.assertEqual(agent.observed_activity(), 140)
        self.assertEqual(agent.observed_activity(), 140)

    def test_a_replaced_smaller_file_freezes_rather_than_going_backwards(self):
        """THE FORMULA THAT WOULD HAVE LIED. `sum(max(0, size - baseline))`
        drops from 100 to 80 when a grown file is replaced by a smaller one,
        and a count that can FALL is exactly what this projection must never
        say. Ambiguity freezes the total instead."""
        agent, state = self.bound()
        place = self.native(state, "session.jsonl", "a" * 100)
        self.assertEqual(agent.observed_activity(), 100)
        os.unlink(place)
        self.native(state, "session.jsonl", "b" * 80)
        self.assertEqual(agent.observed_activity(), 100)
        # AND IT DOES NOT RESUME. The source stayed ambiguous.
        with open(place, "a", encoding="utf-8") as writing:
            writing.write("c" * 1000)
        self.assertEqual(agent.observed_activity(), 100)

    def test_truncation_freezes_the_total(self):
        """FROZEN, NOT MERELY UNREDUCED. A file truncated IN PLACE keeps its
        identity, so the count could have carried on from the new size -- and
        the bytes it then counted would be a second accounting of bytes it had
        already reported. The growth after the truncation is what tells the
        two apart, so it is asserted rather than the instant value alone."""
        agent, state = self.bound()
        place = self.native(state, "session.jsonl", "a" * 100)
        self.assertEqual(agent.observed_activity(), 100)
        with open(place, "w", encoding="utf-8") as writing:
            writing.write("a" * 10)
        self.assertEqual(agent.observed_activity(), 100)
        with open(place, "a", encoding="utf-8") as writing:
            writing.write("b" * 1000)
        self.assertEqual(agent.observed_activity(), 100,
                         "the total resumed after an ambiguous source")

    def test_a_disappearing_file_freezes_the_total(self):
        agent, state = self.bound()
        place = self.native(state, "session.jsonl", "a" * 100)
        self.assertEqual(agent.observed_activity(), 100)
        os.unlink(place)
        self.assertEqual(agent.observed_activity(), 100)

    def test_a_home_that_does_not_exist_yet_is_unknown_and_not_a_zero(self):
        agent, state = self.bound()
        shutil.rmtree(state)
        self.assertIsNone(agent.observed_activity())

    # -- what is never counted ----------------------------------------------

    def test_the_credential_symlink_is_never_counted(self):
        """EXCLUDED TWICE OVER: it is a symlink, which the regular-file test
        refuses before any name is considered, and it is not a native file
        name either."""
        agent, state = self.bound()
        os.symlink(self.slot,
                   os.path.join(state, claude_agent.PROVIDER_CREDENTIAL))
        self.assertIsNone(agent.observed_activity())
        self.native(state, "session.jsonl", "a" * 10)
        self.assertEqual(agent.observed_activity(), 10)

    def test_a_link_pointing_at_a_large_file_is_not_followed(self):
        agent, state = self.bound()
        outside = os.path.join(self.home, "huge.jsonl")
        self.write(outside, "z" * 9000)
        os.symlink(outside, os.path.join(state, "pointer.jsonl"))
        self.assertIsNone(agent.observed_activity())

    def test_a_replaced_root_link_never_counts_foreign_activity(self):
        agent, state = self.bound()
        foreign = os.path.join(self.home, "foreign")
        self.native(foreign, "foreign.jsonl", "x" * 9000)
        os.rename(state, state + "-original")
        os.symlink(foreign, state)
        self.assertIsNone(agent.observed_activity())

    def test_a_directory_replaced_before_scanning_cannot_redirect_the_scan(self):
        agent, state = self.bound()
        child = os.path.join(state, "child")
        self.native(child, "own.jsonl", "x" * 7)
        foreign = os.path.join(self.home, "foreign")
        self.native(foreign, "foreign.jsonl", "x" * 9000)
        original = os.scandir
        calls = []

        def replaced(place):
            calls.append(place)
            if len(calls) == 2:
                os.rename(child, child + "-original")
                os.symlink(foreign, child)
            return original(place)

        with mock.patch.object(os, "scandir", replaced):
            total = agent.observed_activity()
        self.assertEqual(len(calls), 2, "replacement seam was not reached")
        self.assertIn(total, (None, 7), "foreign activity was attributed")

    def test_directory_acquisition_rejects_replacement_and_closes_descriptors(self):
        # Replace between no-follow entry stat and open, rather than after an
        # already-held descriptor. Both links and different ordinary objects
        # must fail toward unknown and release every descriptor we acquired.
        for link in (True, False):
            with self.subTest(link=link):
                scratch = os.path.join(self.home, "race-" + str(link))
                agent, state = self.bound(scratch)
                child = os.path.join(state, "child")
                self.native(child, "own.jsonl", "x" * 7)
                foreign = os.path.join(self.home, "foreign-" + str(link))
                self.native(foreign, "foreign.jsonl", "x" * 9000)
                opened, closed, replaced = [], [], []
                real_open, real_close = os.open, os.close

                def opening(path, flags, *args, **kwargs):
                    if path == "child" and not replaced:
                        replaced.append(True)
                        os.rename(child, child + "-original")
                        if link:
                            os.symlink(foreign, child)
                        else:
                            os.rename(foreign, child)
                    fd = real_open(path, flags, *args, **kwargs)
                    opened.append(fd)
                    return fd

                def closing(fd):
                    closed.append(fd)
                    real_close(fd)

                with mock.patch.object(os, "open", opening), \
                        mock.patch.object(os, "close", closing):
                    self.assertIsNone(agent.observed_activity())
                self.assertEqual(replaced, [True])
                self.assertCountEqual(opened, closed)

    def test_other_home_growth_is_not_activity(self):
        agent, state = self.bound()
        self.native(state, "settings.json", "{}" * 500)
        self.native(os.path.dirname(state), "history", "x" * 9000)
        self.assertIsNone(agent.observed_activity())

    # -- the bounds, all of which fail toward unknown ------------------------

    def test_exceeding_the_depth_yields_unknown_rather_than_a_sample(self):
        agent, state = self.bound()
        self.native(state, "session.jsonl", "a" * 100)
        self.assertEqual(agent.observed_activity(), 100)
        deep = os.path.join(state, *["down"] * (claude_agent.ACTIVITY_DEPTH
                                                + 1))
        self.native(deep, "deeper.jsonl", "b" * 10)
        # FROZEN AT THE LAST GOOD TOTAL, never a smaller or a sampled one.
        self.assertEqual(agent.observed_activity(), 100)
        self.assertEqual(agent.observed_activity(), 100)

    def test_exceeding_the_entry_bound_yields_unknown(self):
        """A SCAN THAT OVERRAN ITS BOUND REPORTS UNKNOWN RATHER THAN WHAT IT
        HAPPENED TO REACH. The native file is there and would be counted by an
        unbounded walk, so the answer distinguishes the bound from an empty
        result."""
        agent, state = self.bound()
        self.native(state, "session.jsonl", "a" * 90)
        for index in range(claude_agent.ACTIVITY_ENTRIES + 1):
            self.native(state, f"entry-{index}.txt", "x")
        self.assertIsNone(agent.observed_activity())

    def test_exceeding_the_tracked_file_bound_yields_unknown(self):
        agent, state = self.bound()
        for index in range(claude_agent.ACTIVITY_FILES + 1):
            self.native(state, f"session-{index}.jsonl", "x")
        self.assertIsNone(agent.observed_activity())

    def test_a_total_past_the_ceiling_is_unknown_rather_than_reported(self):
        """THE COUNT THIS READER COULD NOT COMPARE. A total outside the range
        the manager's parser carries is refused there, so reporting one here
        would be publishing a document nobody may read."""
        agent, _state = self.bound()
        with mock.patch.object(ClaudeAgent, "_activity_scan",
                               staticmethod(lambda _root: {
                                   (1, 1): claude_agent.MAX_ACTIVITY_BYTES
                                   + 2})):
            self.assertIsNone(agent.observed_activity())
            # AND IT STAYS UNKNOWN rather than answering again on the next
            # tick with a number the manager would refuse.
            self.assertIsNone(agent.observed_activity())

    # -- the whole turn ------------------------------------------------------

    def test_a_real_turn_observes_growth_before_it_completes(self):
        """THE NORMAL ADAPTER BOUNDARY, with a deterministic provider standing
        in for the real one. LABELLED SIMULATED-PROVIDER COVERAGE: it is not
        live-provider evidence and nothing here claims to be."""
        private = os.path.join(self.home, "private")
        os.makedirs(private)
        seen = []
        held = {}

        def run(argv, **options):
            if argv[0] == claude_agent.PROVIDER_PROGRAM:
                # THE PROVIDER'S OWN HOME, as the adapter composed it.
                state = os.path.join(options["env"]["HOME"],
                                     claude_agent.PROVIDER_HOME_STATE)
                self.write(os.path.join(state, "projects", "slug",
                                        "session.jsonl"), "x" * 700)
                # OBSERVED WHILE THE TURN IS STILL RUNNING.
                seen.append(held["agent"].observed_activity())
                self.write(os.path.join(options["cwd"], "preflight.py"),
                           "def _observed_readable():\n    return False\n")
            return subprocess.CompletedProcess(argv, 0, None, None)

        with mock.patch.object(claude_agent, "PRIVATE_ROOT", private):
            held["agent"] = ClaudeAgent(run=run)
            answer = held["agent"].work({"contract": "the frozen task"},
                                        list(DECLARED))

        self.assertEqual(answer["disposition"], "completed")
        self.assertEqual(seen, [700])
        self.assertEqual(held["agent"].observed_activity(), 700)


class LineDeltaCase(LineCase):
    """W202663 D10 — the delta inventory's own harness.

    `act` is the provider doing something `edits=` cannot express — linking,
    deleting, chmodding, mkfifo -- and `verify_act` is the VERIFICATION
    child doing it, which is the window `_line_revalidated` exists for.
    Both run inside the same fake-provider seam every other case uses.
    """

    def provider(self, *, act=None, verify_act=None, **operands):
        base = super().provider(**operands)

        def run(argv, **options):
            if argv[0] == claude_agent.PROVIDER_PROGRAM and act is not None:
                act(options["cwd"])
            if argv[0] != claude_agent.PROVIDER_PROGRAM \
                    and verify_act is not None:
                verify_act(options["cwd"])
            return base(argv, **options)

        return run

    def populate_origin(self):
        super().populate_origin()
        os.symlink("harness.py",
                   os.path.join(self.origin, "committed-file-link"))
        os.makedirs(os.path.join(self.origin, "records"))
        self.write(os.path.join(self.origin, "records", "kept.txt"),
                   "baseline record\n")
        os.symlink("records",
                   os.path.join(self.origin, "committed-dir-link"))


class TheLineDeltaKeepsEveryProviderRule(LineDeltaCase):
    """The negative half of D10: what the whole-tree walk refused, the
    delta still refuses -- about the CHANGES, where the rules belong."""

    def test_an_untouched_linked_baseline_is_no_candidate_not_a_fault(self):
        """The exact D10 defect, inverted: committed links and all, a turn
        that changed nothing publishes an honest no-candidate."""
        answered = self.worked()
        # "unable" is the WORK answer's word; the proposal's own record
        # carries the fine-grained one, exactly as every clean turn does.
        self.assertEqual(answered["disposition"], "unable")
        self.assertEqual(self.result()["disposition"], "no-candidate")

    def test_the_reviewers_unrelated_ignored_cache_probe_publishes(self):
        """Review230027's own R1 reproduction, kept as the positive it must
        be: an unrelated ignored cache beside a constant-print harness
        edit. The old regime refused solely for the cache's omission; the
        selected behavior publishes the edit and disclosures the cache."""
        answered = self.worked(edits={
            ".gitignore": "unrelated-cache.txt\n",
            "unrelated-cache.txt": "scratch nobody reads\n",
            "harness.py": "print('a constant, no cache involved')\n"})
        self.assertEqual(answered["disposition"], "completed")
        record = self.result()
        self.assertEqual(record["collection"]["excluded_ignored"],
                         ["unrelated-cache.txt"])
        head = self.claim(answered)["head"]
        delivered = self.git("diff", "--name-only",
                             f"{self.base}..{head}").split()
        self.assertEqual(sorted(delivered), [".gitignore", "harness.py"])

    def test_a_provider_authored_link_still_refuses(self):
        with self.assertRaises(TaskRefusal) as caught:
            self.worked(act=lambda cwd: os.symlink(
                "/run/baton/credentials/claude",
                os.path.join(cwd, "exfil-link")))
        self.assertIn("neither authors nor alters links",
                      str(caught.exception))
        self.assertFalse(os.path.exists(self.proposal("objects.bundle")))

    def test_a_retargeted_baseline_link_still_refuses(self):
        def retarget(cwd):
            place = os.path.join(cwd, "committed-file-link")
            os.unlink(place)
            os.symlink("preflight.py", place)

        with self.assertRaises(TaskRefusal) as caught:
            self.worked(act=retarget)
        self.assertIn("link at committed-file-link among its changes",
                      str(caught.exception))

    def test_a_link_replaced_by_a_file_still_refuses(self):
        """A type change is refused rather than interpreted -- the
        pre-existing `_identical` rule, which is where a link-to-file
        replacement now lands: the worktree entry is an ordinary file, so
        collection measures it, and the committed change then carries 'T',
        which is not an added, modified or deleted regular path."""
        def replace(cwd):
            place = os.path.join(cwd, "committed-file-link")
            os.unlink(place)
            self.write(place, "now a file\n")

        with self.assertRaises(TaskRefusal) as caught:
            self.worked(act=replace)
        self.assertIn("'T' change at committed-file-link",
                      str(caught.exception))

    def test_a_special_file_is_no_veto_and_is_never_delivered(self):
        """Owner 12:47:17Z: an unrelated special file is not a collection
        veto. Git's own status does not surface a fifo at all, so the turn
        publishes without it -- nothing reads the pipe (a read would
        block), nothing delivers it, and the change set is exactly the
        edit."""
        answered = self.worked(
            edits={"harness.py": "print('beside a pipe')\n"},
            act=lambda cwd: os.mkfifo(os.path.join(cwd, "pipe")))
        self.assertEqual(answered["disposition"], "completed")
        head = self.claim(answered)["head"]
        self.assertEqual(
            self.git("diff", "--name-only", f"{self.base}..{head}").split(),
            ["harness.py"])

    def test_a_mode_only_change_is_measured_and_published(self):
        """The executable bit is a change Git commits, so it is candidate
        material even with every byte identical."""
        answered = self.worked(act=lambda cwd: os.chmod(
            os.path.join(cwd, "harness.py"), 0o755))
        self.assertEqual(answered["disposition"], "completed")
        claim = self.claim(answered)
        self.assertEqual(
            self.git("ls-tree", "--format=%(objectmode)", claim["head"],
                     "harness.py").strip(), "100755")

    def test_a_baseline_deletion_is_published_as_a_deletion(self):
        answered = self.worked(edits={"harness.py": "print('kept')\n"},
                               act=lambda cwd: os.remove(
                                   os.path.join(cwd, "records", "kept.txt")))
        self.assertEqual(answered["disposition"], "completed")
        head = self.claim(answered)["head"]
        status = self.git("diff", "--name-status", f"{self.base}..{head}")
        self.assertIn("D\trecords/kept.txt", status)

    def test_a_verification_time_edit_still_refuses(self):
        def tamper(cwd):
            self.write(os.path.join(cwd, "harness.py"),
                       "print('swapped after measurement')\n")

        with self.assertRaises(TaskRefusal) as caught:
            self.worked(edits={"harness.py": "print('measured')\n"},
                        verify_act=tamper)
        self.assertIn("after its own verification command ran",
                      str(caught.exception))

    def test_a_verification_time_deletion_still_refuses(self):
        with self.assertRaises(TaskRefusal) as caught:
            self.worked(edits={"harness.py": "print('measured')\n"},
                        verify_act=lambda cwd: os.remove(
                            os.path.join(cwd, "records", "kept.txt")))
        self.assertIn("disagree about the removal", str(caught.exception))


class TheLineDeltaAdmitsTheRealRepositoryShape(LineDeltaCase):
    """The positive half of D10, at the measured scale.

    The live refusal was reproduced against 19,553 entries / 652 MB / 102
    committed links; this baseline is the same SHAPE past the same payload
    bounds -- more entries than MAX_SOURCE_ENTRIES, more bytes than
    MAX_SOURCE_BYTES, file and directory symlinks committed -- driven
    through the REAL work(): provider, measurement, verification,
    commit, representability and publication.
    """

    BULK_FILES = 2100
    BIG_BYTES = 66 * 1024 * 1024

    def populate_origin(self):
        super().populate_origin()
        for index in range(self.BULK_FILES):
            sub = os.path.join(self.origin, "bulk", f"d{index % 30:02d}")
            os.makedirs(sub, exist_ok=True)
            with open(os.path.join(sub, f"f{index:04d}.txt"), "w",
                      encoding="utf-8") as out:
                out.write(f"baseline {index}\n")
        with open(os.path.join(self.origin, "assets.bin"), "wb") as out:
            out.write(b"\x00" * self.BIG_BYTES)

    def test_the_shape_is_actually_past_the_payload_bounds(self):
        """The fixture proves it is the D10 shape, not a smaller stand-in."""
        self.assertGreater(self.BULK_FILES, claude_agent.MAX_SOURCE_ENTRIES)
        self.assertGreater(self.BIG_BYTES, claude_agent.MAX_SOURCE_BYTES)
        self.assertTrue(os.path.islink(
            os.path.join(self.outputs, "committed-file-link")))
        self.assertTrue(os.path.islink(
            os.path.join(self.outputs, "committed-dir-link")))

    def test_a_small_patch_publishes_through_verification(self):
        answered = self.worked(edits={
            "v12/tools/pool.py": "print('the candidate')\n",
            "v12/tests/test_pool.py": "print('its tests')\n"})
        self.assertEqual(answered["disposition"], "completed")
        claim = self.claim(answered)
        self.assertEqual(claim["base"], self.base)
        head = claim["head"]
        status = self.git("diff", "--name-only", f"{self.base}..{head}")
        self.assertEqual(sorted(status.split()),
                         ["v12/tests/test_pool.py", "v12/tools/pool.py"])
        # THE LINKS SURVIVED PUBLICATION UNTOUCHED, which is the whole point:
        # baseline material is the repository's own business.
        self.assertEqual(
            self.git("ls-tree", "--format=%(objectmode)", head,
                     "committed-file-link").strip(), "120000")
        self.assertTrue(os.path.exists(self.proposal("objects.bundle")))
        # AND THE VERIFICATION REALLY RAN: the second child in the calls.
        self.assertEqual(len([argv for argv, _options in self.calls
                              if argv[0] != claude_agent.PROVIDER_PROGRAM]),
                         1)

    def test_a_baseline_edit_is_measured_by_bytes_not_by_git(self):
        answered = self.worked(edits={
            "bulk/d00/f0000.txt": "edited baseline member\n"})
        self.assertEqual(answered["disposition"], "completed")
        head = self.claim(answered)["head"]
        self.assertEqual(
            self.git("diff", "--name-only",
                     f"{self.base}..{head}").split(),
            ["bulk/d00/f0000.txt"])

    def test_the_payload_bound_still_binds_what_the_turn_authors(self):
        with self.assertRaises(TaskRefusal) as caught:
            self.worked(act=lambda cwd: self.write(
                os.path.join(cwd, "oversized.bin"),
                "x" * (claude_agent.MAX_SOURCE_BYTES + 1)))
        self.assertIn("exceeds this adapter's bound", str(caught.exception))

    def test_the_collection_bound_binds_the_change_list(self):
        def flood(cwd):
            for index in range(12):
                self.write(os.path.join(cwd, f"new-{index}.txt"), "x\n")

        with mock.patch.object(claude_agent, "MAX_LINE_STATUS_ENTRIES", 10):
            with self.assertRaises(TaskRefusal) as caught:
                self.worked(act=flood)
        self.assertIn("bound", str(caught.exception))
