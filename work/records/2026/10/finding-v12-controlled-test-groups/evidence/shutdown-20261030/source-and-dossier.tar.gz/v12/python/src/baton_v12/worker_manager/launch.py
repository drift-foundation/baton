"""THE WORKER'S LAUNCH DOCUMENT: one versioned file, mounted read-only.

W26291, `work/records/2026/08/finding-v12-oci-worker-launch-environment/`. The
mechanism is not chosen here. The dossier's two supersessions and its pinned
contract of 2026-08-28 decide it, and this module implements that pin rather
than re-deciding it.

WHAT THIS REPLACED, and why the replacement is not an equivalent transport.
The first implementation of this Work delivered four `BATON_WORKER_*` values as
`--env` arguments. That is a vocabulary rather than a contract: every new fact
the worker needs is another variable, every variable is another thing a caller
could set, and the set has no version, so a manager and a worker from two
generations disagree silently rather than refusing. One VERSIONED DOCUMENT at a
FIXED path fails closed on exactly that disagreement, and it extends by adding
a member to a schema both ends are held to instead of by widening an
environment channel.

THERE IS NO FALLBACK, and that is the ruling rather than an omission. The
reference worker does not read `BATON_WORKER_POSTURE`, `BATON_WORKER_SESSION`,
`BATON_WORKER_CONTRACT` or `BATON_WORKER_ROLE`, and a container started with
only those refuses. A compatibility path would be the second live contract the
supersession exists to end.

WHAT THE DOCUMENT CARRIES: `schema`, `session`, `contract`, `role`. Four
members, closed. There is no `posture`: the consent-posture supersession
removed the axis, and a member carrying a constant would be transporting a fact
that no longer exists.

WHAT IT NEVER CARRIES: credentials or bearer material, source contents,
arbitrary environment, a Baton authority locator, or a host path. Credentials
are the separate transient read-only provider under `/run/baton/credentials`;
assignment input and worker output are on their own governed mounts. §13 walks
the authored document before it is written, so a live bearer cannot ride this
channel any more than it can ride the start vector.

WHERE THE FILE IS ALLOWED TO BE: one manager-owned regular file, mode 0444,
under a 0555 attempt-private root this module creates and owns outright. The
mode is the manager's own statement that the document is finished and that
anybody may read it; the READ-ONLY BIND is what makes it unwritable from inside
the container, and the worker proves that for itself rather than trusting
either. `READ_ONLY_FILE` says why world-readable is the correct mode here and
why it is only safe because §13 keeps this document non-secret.

AND THE MODE IS ESTABLISHED, NOT REQUESTED. Review [P0]: a creation mode is
filtered by the process umask, so a manager running under the ordinary service
umask 077 authored a 0400 document the container's fixed uid could not read —
the positive launch regressing to the unrunnable worker this Work exists to
fix, silently, on somebody else's machine. `materialize` now sets the exact
mode on the descriptor it wrote, and creates at 0000 first so no partial
document is readable at any instant.
"""

import json
import os
import stat

from ..contracts import ContractRefusal, check_no_durable_secret
from ..contracts.errors import name_value
from . import attempt_logs
from . import boundaries
from . import exchange

__all__ = ["EXCHANGE_MEMBERS", "EXCHANGE_SCHEMA", "JOB_EXECUTION_MEMBERS",
           "JOB_MEMBERS", "JOB_SCHEMA", "LAUNCH_MEMBERS",
           "LAUNCH_SCHEMA", "LAUNCH_TARGET",
           "MAX_LAUNCH_BYTES", "MAX_LAUNCH_VALUE", "MAX_SESSION",
           "PAYLOAD_SCHEMAS",
           "READ_ONLY_DIR", "READ_ONLY_FILE", "SCHEMAS", "TRANSPORTS",
           "WIRE_PROFILE", "WRAPPER_MEMBERS", "WRAPPER_SCHEMA",
           "LaunchDelivery",
           "adopt", "launch_document", "materialize", "members_for",
           "payload_of", "selected_transport"]

# THE FIXED CONTAINER PATH, a constant of the contract at BOTH ends. A path a
# caller could vary is a path a runtime can be pointed at wrongly, so there is
# no locator environment variable and no caller-selected target -- the worker
# is told where to look by this contract, and the adapter composes exactly this
# target and refuses to compose another.
LAUNCH_TARGET = "/run/baton/launch.json"

# THE VERSION IS IN THE NAME, exactly as `baton.worker-entry/1` carries the
# channel's. A document from another generation is then refused by an equality
# test rather than by parsing a separate version member and deciding what to do
# about it -- and "what to do about it" is where a compatibility path grows.
LAUNCH_SCHEMA = "baton.worker-launch/1"

# EXACTLY FOUR, and the set is closed at both ends. The worker derives nothing
# from this tuple -- it cannot import this package, and a second copy is what
# `test_oci` holds against this one by reading the worker's own literal.
LAUNCH_MEMBERS = ("schema", "session", "contract", "role")

# W81857: THE SECOND VERSION, AND IT EXISTS TO SELECT A TRANSPORT.
#
# The present image always enters the stdin framing loop, because that is the
# only thing `baton.worker-launch/1` can describe -- it says what the container
# IS and nothing about how it is spoken to. The file exchange cannot be
# smuggled in through path discovery or an environment flag: a worker that
# looked for a mounted command directory and used it if present would be a
# worker with two live contracts and no version, which is the exact shape the
# environment transport was retired for.
#
# So `/2` is a NEW CONTRACT with one added member, refused by the equality test
# rather than read as a compatible `/1`. `transport` names the production
# channel explicitly, and the closed vocabulary below is the whole of what it
# may say.
#
# `/1` IS NOT A FALLBACK AND IS NOT DEPRECATED. It remains the explicitly
# allowed diagnostic and test transport `worker_entry.converse` speaks to, and
# a production deployment that wants the exchange says so in its own launch
# document rather than being upgraded into it.
EXCHANGE_SCHEMA = "baton.worker-launch/2"
EXCHANGE_MEMBERS = LAUNCH_MEMBERS + ("transport",)

# W156162: /3 CARRIES THE JOB'S OWN EXECUTION CONTEXT.
#
# A Job may configure the seconds one provider turn and one verification
# command may take, and the container is where those ceilings are actually
# handed to a command -- so the delivery that tells a worker what it is has to
# carry them. `/1` and `/2` are UNCHANGED and still read: a deployment that
# configures nothing keeps the exact delivery it had.
#
# THE TRANSPORT IS EXPLICIT HERE, including when it is absent. `/1` says "no
# transport" by having no member and `/2` says "this transport" by having one;
# a version that carries a Job context must be able to say either, and a reader
# that had to infer absence from a missing member would be guessing at the one
# fact that decides which channel is authoritative.
JOB_SCHEMA = "baton.worker-launch/3"
JOB_MEMBERS = LAUNCH_MEMBERS + ("transport", "job_execution")
CONTEXT_SCHEMA = "baton.worker-launch/4"
CONTEXT_MEMBERS = JOB_MEMBERS + ("provider_context",)

# W376586: /5 IS THE ONE CURRENT FILE-EXCHANGE WRAPPER, and it is a different
# KIND of version from the four above.
#
# `/1`-`/4` each describe a container. `/5` describes the WIRE the container
# and this manager speak, and carries one of those four as its payload --
# `{schema, wire_profile, payload}` and nothing else. `AMENDMENT-376531.md`
# selects exactly this: "one current worker-launch/5 wrapper ... Payload
# preserves current ordinary/context/role launch semantics in the existing
# mode-specific /2-/4 payload shapes; these are internal payload variants, not
# support for executing historical unwrapped file launches."
#
# WHY A WRAPPER AND NOT A FIFTH MEMBER. The typed adapter exchange is a
# property of the CHANNEL, not of the container: the same `/3` payload is the
# same container whether it is spoken to over the typed file exchange or not.
# Putting the profile inside the payload would make every payload generation
# carry a member about the wire, and a reader would have to parse a version to
# find out which wire it was on -- which is the shape this campaign retired.
#
# AND THE FRAMED TRANSPORT IS OUTSIDE IT. `/1` and a `/3`/`/4` validly naming
# no transport are NOT wrapped: the amendment says the framed transport is
# outside this feature, and wrapping a launch that selects no file exchange
# would be a wrapper describing a wire nobody is on.
WRAPPER_SCHEMA = "baton.worker-launch/5"
WRAPPER_MEMBERS = ("schema", "wire_profile", "payload")

# THE ONE PROFILE, by equality. There is no negotiation, no list and no
# default: a profile this build cannot name is a wire it cannot speak, and the
# amendment forbids "no nested wrapper or arbitrary profile".
WIRE_PROFILE = "typed-adapter-file-exchange/1"

# WHAT THE JOB CONTEXT NAMES, closed. The Job and the attempt it is running,
# the identities the JOB was submitted with, the identities this RUNTIME was
# actually given, and the effective configuration with its own canonical digest.
#
# JOB INPUTS AND RUNTIME INPUTS ARE DIFFERENT FACTS and are both carried rather
# than compared: a review or a derived judgment legitimately consumes a frozen
# input that is not the Job's original one, so requiring them equal would refuse
# the ordinary case. What is required is that each is stated.
JOB_EXECUTION_MEMBERS = ("job_id", "attempt_id", "job_input_digest",
                         "job_policy_digest", "runtime_input_digest",
                         "runtime_policy_digest", "execution_limits",
                         "execution_limits_digest")

# schema -> the closed member set that schema carries. Both ends read this
# relationship the same way: the version decides the shape, and there is no
# document that is valid under two of them.
TRANSPORTS = {LAUNCH_SCHEMA: None,
              EXCHANGE_SCHEMA: exchange.EXCHANGE_TRANSPORT}

# EVERY LAUNCH SCHEMA THIS BUILD AUTHORS, which is a different question from
# `TRANSPORTS` and is why it is a second name. `TRANSPORTS` says which transport
# a schema FIXES, and `/3` fixes none -- it carries the transport as a member,
# so a reader asking "is this one of ours" cannot ask it there. W156162: it was
# asked there, and the composed integration bundle refused the `/3` its own port
# had just authored.
SCHEMAS = (LAUNCH_SCHEMA, EXCHANGE_SCHEMA, JOB_SCHEMA, CONTEXT_SCHEMA,
           WRAPPER_SCHEMA)

# THE PAYLOAD GENERATIONS, which is a THIRD question again: `SCHEMAS` says
# which documents this build authors, and this says which of them may sit
# INSIDE the wrapper. The wrapper is deliberately absent, so a nested wrapper
# is refused by a membership test rather than by a depth count.
PAYLOAD_SCHEMAS = (LAUNCH_SCHEMA, EXCHANGE_SCHEMA, JOB_SCHEMA, CONTEXT_SCHEMA)


def selected_transport(document):
    """The transport ONE document selects, wrapper or not.

    W376586. `/5` moves `transport` one level down, and every reader that asked
    `document.get("transport")` would have silently answered "none" for a
    wrapped exchange launch. `_exchange_materialized` records what that costs:
    "THE TRANSPORT DECIDES THIS, NOT THE VERSION ... a /3 exchange delivery
    composed NO namespaces, the worker had no delivery to read, and every such
    stage projected `unreadable` and then `exceptional`... Measured, not
    reasoned about: 54 cases in the one-worker pipeline failed exactly this
    way." The same proxy failing a second time one level up is the same defect,
    so the question is asked in ONE place and every reader asks it here.
    """
    if type(document) is not dict:
        return None
    if document.get("schema") == WRAPPER_SCHEMA:
        payload = document.get("payload")
        return payload.get("transport") if type(payload) is dict else None
    return document.get("transport")


def payload_of(document):
    """The CONTAINER document inside one launch delivery, wrapper or not.

    W376586, and the companion of `selected_transport` for the same reason:
    `/5` moves every container member one level down, so a reader asking the
    top level for `provider_context`, `role` or `job_execution` would answer
    "absent" for a wrapped exchange launch. `oci.OciAdapter` asked exactly
    that and refused a valid context delivery with "context launch and mount
    must both be present" -- a reader looking in the wrong place, reported as
    a missing mount.

    SO THERE ARE TWO SHARED QUESTIONS AND NO `get` AT A CALL SITE: which
    transport a delivery selects, and which container document it carries.
    """
    if type(document) is not dict:
        return {}
    if document.get("schema") == WRAPPER_SCHEMA:
        payload = document.get("payload")
        return payload if type(payload) is dict else {}
    return document


def members_for(document):
    """The closed member set the schema in this document names.

    THE SCHEMA DECIDES THE SHAPE, which is what makes the two versions two
    contracts rather than one contract with an optional member. A reader that
    accepted the union would accept a `/1` document carrying a transport and a
    `/2` document carrying none, and each of those is a manager and a worker
    disagreeing silently about which channel is authoritative.
    """
    schema = document.get("schema") if type(document) is dict else None
    if schema == WRAPPER_SCHEMA:
        return WRAPPER_MEMBERS
    if schema == CONTEXT_SCHEMA:
        return CONTEXT_MEMBERS
    if schema == JOB_SCHEMA:
        return JOB_MEMBERS
    if schema == EXCHANGE_SCHEMA:
        return EXCHANGE_MEMBERS
    return LAUNCH_MEMBERS

# The identity ceiling is the WORKER'S, deliberately. `session` is the value
# every frame on the worker-entry channel is bound to, and the worker refuses
# one wider than this -- so a value the worker would refuse is not one this
# manager may write. Writing it and letting the container fail would move a
# manager mistake inside a container, where the manager can no longer say why.
MAX_SESSION = 256

# A contract line and a role are operator PROSE, not identifiers, and a human
# contract legitimately carries newlines. The retired environment transport
# refused those because one `--env NAME=VALUE` argument cannot survive one;
# that ban is not carried forward, because it was a fact about the transport
# rather than about the value.
MAX_LAUNCH_VALUE = 4096

# The whole document, bounded so the worker's read is bounded. Comfortably
# above four members at their own ceilings and far below anything that would
# matter to a container.
MAX_LAUNCH_BYTES = 65536                       # 64 KiB

# READ-ONLY, AND READABLE BY ANYBODY. Both halves are deliberate and the
# second one is the interesting one.
#
# The container runs as the fixed non-root uid 65532 (the adapter's `--user`
# restriction and the recipe agree on it), and a bind mount carries the host
# file's ownership and mode through unchanged. So an owner-only mode would
# make delivery depend on the manager process happening to run as that uid --
# it does not, and it cannot chown its way there without privileges it must not
# have. A document the worker cannot read is a container that does not start,
# for a reason nothing in the mount table would show.
#
# That is only acceptable because of what this document IS: non-secret control
# metadata, and §13 is what keeps it that way rather than this comment --
# `launch_document` walks the authored document before any of it is written, so
# a bearer cannot arrive in a world-readable file by way of a `contract` line.
# Credentials are the opposite case and the narrow one: 0640 in the
# deployment's configured workspace group, under a 0700 manager-only root, in
# `credentials.py`, which is where secret material lives. W52800 ruled those
# group bits; `other` stays empty there, which is the whole difference from
# this document.
#
# WRITABLE BY NOBODY, including this manager after the write. The document is
# finished when it is written and nothing writes it again; the mode says so on
# disk rather than in a comment, and the READ-ONLY BIND is the separate
# statement the worker proves for itself.
READ_ONLY_FILE = 0o444
READ_ONLY_DIR = 0o555


def _refuse(message, code="schema"):
    raise ContractRefusal("integrity", code, message)


def _denied(message):
    raise ContractRefusal("policy", "denied", message)


def _value(given, name, ceiling):
    """One of the three values, owned under ONE LITERAL LABEL.

    The label is a constant and the member's name is in the prose after it,
    which is the rule this package's shared owners follow -- the inventory
    attributes an owned entry by the label written at the site, so a helper
    that owned under its caller's word would be a boundary nothing could place.
    """
    value = boundaries.text(given, "a launch document value")
    if len(value) > ceiling:
        _denied(f"the launch document's {name} is wider than {ceiling} "
                f"characters")
    # `U+0000` AND NOTHING ELSE. It is the one character that truncates a value
    # on the way into a path, an argument or a C string, and JSON will happily
    # carry it. Every other character survives this document, which is the
    # point of replacing an argv-shaped transport with one.
    if "\x00" in value:
        _refuse(f"the launch document's {name} carries a NUL; a value that "
                f"truncates where it is read is not one this manager writes")
    return value


def _same_attempt(attempt, job_execution):
    """The Job context names THE ATTEMPT THIS DELIVERY IS FOR.

    R5: `materialize(attempt_id="attempt-1", job_execution={"attempt_id":
    "attempt-other", ...})` succeeded, and `adopt` with the same contradictory
    operands succeeded too, so exact-byte replay faithfully preserved the
    contradiction. A launch root named for one attempt whose document describes
    another is the delivery mix-up this component is built to prevent, arriving
    inside the document instead of across it.

    Refused BEFORE anything is written, which is where every other launch
    refusal in this module lives.
    """
    if job_execution is None:
        return
    named = job_execution.get("attempt_id") \
        if type(job_execution) is dict else None
    if named != attempt:
        _refuse(f"a launch delivery for attempt {name_value(attempt)} carries "
                f"a job execution naming {name_value(named)}; one delivery is "
                f"one attempt's, and a document describing another is the "
                f"mix-up this root's naming exists to prevent")


def _job_execution(given):
    """One Job execution context, owned exactly as this build will write it.

    W156162. Every member is required: an absent one is a fact the worker would
    have to guess, and the whole reason this document exists is that guessing a
    ceiling is what the Work is removing.

    THE DIGEST IS OVER THE CONFIGURATION AND EXCLUDES ITSELF, which is the same
    rule every sealed document in this build follows -- a digest that covered
    its own member could never be recomputed by the reader checking it.
    """
    taken = boundaries.document(given, "a launch document's job execution",
                                required=JOB_EXECUTION_MEMBERS)
    held = {"job_id": boundaries.identity(taken["job_id"], "a Job id"),
            "attempt_id": boundaries.identity(taken["attempt_id"],
                                              "a runtime attempt id")}
    for name in ("job_input_digest", "job_policy_digest",
                 "runtime_input_digest", "runtime_policy_digest"):
        held[name] = boundaries.text(taken[name], f"a launch document's {name}")
    limits = _configuration(taken["execution_limits"])
    sealed = _digest(limits)
    declared = boundaries.text(taken["execution_limits_digest"],
                               "a launch document's execution limit digest")
    if declared != sealed:
        _refuse(f"a launch document declares execution limit digest "
                f"{name_value(declared)} and its configuration digests to "
                f"{name_value(sealed)}; a worker handed a ceiling whose seal "
                f"does not match has been handed a number nobody agreed to")
    held["execution_limits"] = limits
    held["execution_limits_digest"] = declared
    return held


def _configuration(given):
    """The effective configuration, held to the Job owner's OWN rules.

    Review 2026-09-13T01:36:01Z R5: this took any document at all and checked
    only that its digest matched, so a correctly sealed `{}` was accepted, and
    so was a sealed object stating `units: minutes`, `scope: cumulative`,
    generation 999 and a provider ceiling of -1. A MATCHING SEAL PROVES BYTE
    CORRESPONDENCE, NOT THAT ANYBODY AGREED TO THE CONTENT.

    THE RULE IS THE JOB MANAGER'S, IMPORTED RATHER THAN RESTATED, which is
    `schema.check_authority`'s own pattern in this build: a second, looser
    spelling of what a ceiling may be is exactly the drift that stays invisible
    until two components disagree about one number. The import is a RULE and not
    a capability -- it opens no store, holds no session and grants nothing --
    and it is late because the Job manager builds on this package.

    AND THE CHECK IS A RECOMPUTATION, NOT A CHECKLIST. What a Job is delivered
    is whatever that owner resolves from the Job's own requested settings under
    the generation it was admitted with, so this re-resolves exactly that and
    requires equality. Units, scope, origins, defaults, the supported range and
    the requested-versus-effective agreement are all caught by the one
    comparison, and a rule added over there is carried here without an edit.
    """
    from ..contracts import ContractRefusal as _Refusal
    from ..job_manager import execution_limits as rules

    held = boundaries.document(given, "a launch document's execution limits",
                               required=("units", "scope",
                                         "compatibility_generation",
                                         "requested", "boundaries"))
    try:
        expected = rules.resolved(
            rules.owned_execution_limits(held["requested"]),
            held["compatibility_generation"])
    except _Refusal as refused:
        _refuse(f"a launch document's execution limits are not ones the Job "
                f"owner accepts: {refused}")
    # COMPARED AS CANONICAL TEXT, NOT AS DICTS. Review 2026-09-13T01:44:11Z:
    # `True == 1` in Python, so a configuration whose effective provider seconds
    # were replaced by `true` -- and correctly resealed -- compared EQUAL to the
    # resolution of a Job requesting 1 second, and the carrier returned
    # `seconds: true`. The owner's own rules reject a bool precisely because it
    # is not a whole number of seconds; a comparison that cannot tell them apart
    # discards that. The canonical text a reader will actually parse is what is
    # compared, and a valid integer 1 stays accepted.
    if _canonical(held) != _canonical(expected):
        _refuse("a launch document's execution limits are not what the Job "
                "owner resolves from their own requested settings and "
                "generation; a worker handed a configuration nobody resolved "
                "has been handed numbers nobody agreed to")
    return held


def _canonical(document):
    """One document as the exact text a reader will parse.

    `json.dumps` writes `true` for a bool and `1` for an integer, so two values
    Python's `==` cannot separate are two different documents here -- which is
    what the comparison above needs and what dict equality could not give it.
    """
    return json.dumps(document, sort_keys=True, separators=(",", ":"),
                      ensure_ascii=False, allow_nan=False)


def _digest(document):
    """The canonical digest of one document, in this build's one spelling."""
    import hashlib

    return "sha256:" + hashlib.sha256(
        json.dumps(document, sort_keys=True, separators=(",", ":"),
                   ensure_ascii=False, allow_nan=False)
        .encode("utf-8")).hexdigest()


def launch_document(*, session, contract, role, transport=None,
                    job_execution=None, provider_context=None):
    """The complete document for the version this transport selects.

    AUTHORED HERE RATHER THAN ASSEMBLED BY A CALLER, and rebuilt over
    `LAUNCH_MEMBERS` rather than copied from a mapping, so how a caller
    happened to build its dict cannot reach the file. A caller supplies three
    values; it does not supply a document shape.

    §13 WALKS THE RESULT. Every function in this package that produces a
    durable document walks it before it returns, and this one is durable for
    the life of a container: a live bearer arriving as a `contract` line would
    otherwise sit in a file the worker reads, which is precisely the surface
    the rule names.
    """
    document = {"schema": LAUNCH_SCHEMA,
                "session": _value(session, "session", MAX_SESSION),
                "contract": _value(contract, "contract", MAX_LAUNCH_VALUE),
                "role": _value(role, "role", MAX_LAUNCH_VALUE)}
    if transport is not None:
        # W81857: THE VERSION MOVES WITH THE MEMBER, and the value is held to
        # the one transport this build knows. A `transport` this manager cannot
        # name is a channel it cannot compose mounts for, so writing it would
        # produce a container told to speak something nothing is listening to.
        if transport != exchange.EXCHANGE_TRANSPORT:
            _denied(f"a launch document selects "
                    f"{name_value(exchange.EXCHANGE_TRANSPORT)}; this is "
                    f"{name_value(transport)}")
        document["schema"] = EXCHANGE_SCHEMA
        document["transport"] = _value(transport, "transport",
                                       MAX_LAUNCH_VALUE)
    if job_execution is not None:
        # W156162: AND THE VERSION MOVES WITH THIS MEMBER TOO, for the same
        # reason. `/3` states the transport explicitly -- the value for an
        # exchange worker, `None` for the one-shot integration path -- so a
        # reader is told which channel is authoritative rather than inferring
        # it from a member that is missing.
        document["schema"] = JOB_SCHEMA
        document["transport"] = document.get("transport")
        document["job_execution"] = _job_execution(job_execution)
    if provider_context is not None:
        if job_execution is None or role != "implementation" or transport != exchange.EXCHANGE_TRANSPORT:
            _denied("provider context requires the implementation Job exchange")
        document["schema"] = CONTEXT_SCHEMA
        document["provider_context"] = _context_delivery(provider_context, document["job_execution"])
    # W376586: THE WRAPPER, APPLIED EXACTLY WHEN THE FILE EXCHANGE IS SELECTED.
    #
    # Composed here and nowhere else, because this function is the single
    # authoring point every writer and `adopt` both go through -- so the
    # delivery on disk, the bytes adoption re-derives and the document a bundle
    # carries cannot disagree about whether a launch is wrapped.
    #
    # THE CONDITION IS THE TRANSPORT, not the payload version. `/2` always
    # selects the exchange and `/3`/`/4` may; a `/3` naming no transport is the
    # one-shot integration launch and stays unwrapped, which is the framed
    # transport this feature does not reach.
    if document.get("transport") == exchange.EXCHANGE_TRANSPORT:
        document = {"schema": WRAPPER_SCHEMA, "wire_profile": WIRE_PROFILE,
                    "payload": document}
    # §13 WALKS THE WHOLE RESULT, wrapper included, so the payload is covered
    # by the same walk it was covered by before.
    check_no_durable_secret(document, what="a worker launch document")
    return document


def _bytes(document):
    """The exact bytes the worker will read, bounded before they are written.

    Sorted and separator-free for the same reason every other document this
    campaign writes is: two readers that canonicalize differently do not agree
    about what was delivered. The bound is checked on the ENCODED bytes rather
    than on the members, because the worker's ceiling is a byte ceiling and a
    four-byte character is four bytes to it.
    """
    payload = json.dumps(document, ensure_ascii=False, sort_keys=True,
                         separators=(",", ":")).encode("utf-8")
    if len(payload) > MAX_LAUNCH_BYTES:
        _denied(f"this launch document is {len(payload)} bytes and the worker "
                f"reads at most {MAX_LAUNCH_BYTES}; a document the worker "
                f"would refuse is not one this manager writes")
    return payload


def _write_whole(handle, payload):
    """Every byte, or a refusal. `os.write` is allowed to write fewer.

    The same rule `credentials._write_whole` states, for the same reason: a
    short write is ordinary rather than exotic, it is not an error the call
    reports, and a TRUNCATED launch document is one the worker refuses as
    malformed while this manager believes it delivered a whole one. No
    progress twice is a refusal rather than a spin.
    """
    written = 0
    while written < len(payload):
        step = os.write(handle, payload[written:])
        if type(step) is not int or step <= 0:
            _refuse(f"writing the launch document made no progress after "
                    f"{written} of {len(payload)} bytes; a partly written "
                    f"document is one the worker refuses and this manager "
                    f"believes it delivered")
        written += step
    return written


class LaunchDelivery:
    """The TYPED capability the adapter receives, and the only one.

    The adapter is handed this object rather than a path, a mapping or a mount
    plan. A path operand would be a caller-selected locator -- the thing the
    fixed target exists to take away -- and a mapping would be the environment
    channel this Work replaced, wearing a different name. What the adapter can
    do with this is ask for one mount, and the target of that mount is this
    contract's constant rather than anything it was told.
    """

    def __init__(self, *, attempt_id, root, place, document,
                 delivery=None, logs=None):
        self.attempt_id = attempt_id
        self.root = root
        self.place = place
        self.document = document
        # W198667: THE LOG ROOM RIDES WITH THE LAUNCH TOO, for the reason the
        # exchange does and stated one line further down: both are non-secret
        # material fixed before the container is created, and a composition
        # that could hold one without the other is one that starts a container
        # with a namespace nothing told it about.
        #
        # IT IS NOT UNDER THIS ROOT, deliberately. `discard` removes the launch
        # root and the required outcome is that partial evidence survives error,
        # abnormal termination and restart -- so the room is a SIBLING of the
        # attempt roots, under `<launch storage>/logs/<attempt>`, and a launch
        # teardown leaves it exactly where it is.
        #
        # `None` MEANS NO ROOM WAS MADE, which is the diagnostic `/1` case: the
        # deployment that has no workspace group to share the namespace with
        # has no way to give a container a writable room either.
        self.logs = logs
        # W81857: THE EXCHANGE RIDES WITH THE LAUNCH, and it is one object
        # rather than two capabilities the adapter has to relate. Both are
        # non-secret control material fixed before start, both belong to the
        # exact attempt and session, and both may be removed only after
        # positive runtime absence -- so a composition that could hold one
        # without the other is a composition that can mount a container's
        # command namespace without telling it the channel exists.
        #
        # `None` MEANS `/1`, and it is the ordinary case: the diagnostic and
        # test transport has no exchange, and a document that selected one
        # would be describing mounts nothing composed.
        self.exchange = delivery

    def mount(self):
        """The ONE read-only bind this delivery authorizes.

        A pair rather than a mount document: `readonly` is not a parameter
        here, and a delivery that could ask to be writable would be a launch
        document the worker could rewrite between reading and being asked
        about it.
        """
        return (self.place, LAUNCH_TARGET)


# W198667: THE LOG DELIVERY'S ROOT, beside the attempt launch roots rather than
# inside one. An attempt id is `attempt-<hex>`, so nothing can collide with this
# name, and being outside every attempt root is what lets `discard` tear a
# launch down without taking the evidence with it.
LOG_DIRECTORY = "logs"


def _log_root(home):
    return os.path.join(home, LOG_DIRECTORY)


def _logs_materialized(home, attempt, workspace_group):
    """This attempt's log room, made BEFORE the container is created.

    W198667. The mounts are fixed when the container is created, so a namespace
    that did not exist then is one nothing will ever hold -- the same sentence
    `exchange.materialize` is placed by.

    NO GROUP, NO ROOM, and that is honest rather than lenient. The container's
    fixed uid is not this manager's, so without the deployment's configured
    group a room this manager made would be one the worker cannot write; a
    delivery that promised a writable log and delivered an unwritable one is
    worse than saying there is none.
    """
    if workspace_group is None:
        return None
    root = _log_root(home)
    os.makedirs(root, mode=0o700, exist_ok=True)
    return attempt_logs.materialize(root, attempt_id=attempt,
                                    workspace_group=workspace_group)


def _logs_adopted(home, attempt, workspace_group):
    """The room a previous incarnation made, or a new one.

    A RESTART MUST NOT LOSE THE EVIDENCE and must not refuse for its absence
    either: the room survives `discard`, so a re-entry ordinarily finds one --
    and an attempt whose room was never made (an older incarnation, or one that
    failed before it got that far) is given one now rather than being refused
    for a namespace that is nobody's fault.
    """
    if workspace_group is None:
        return None
    root = _log_root(home)
    os.makedirs(root, mode=0o700, exist_ok=True)
    try:
        return attempt_logs.adopt(root, attempt_id=attempt,
                                  workspace_group=workspace_group)
    except FileNotFoundError:
        return attempt_logs.materialize(root, attempt_id=attempt,
                                        workspace_group=workspace_group)


def materialize(storage, *, attempt_id, session, contract, role,
                transport=None, job_execution=None, workspace_group=None, provider_context=None):
    """Author one launch document and put it on disk as this manager's own.

    `storage` is the manager's own launch storage, NOT an assignment root. The
    document is not assignment material: mounting it out of `inputs` would make
    it something the input digest describes, and mounting it out of `workspace`
    would put the worker's own launch contract inside the one tree the worker
    may WRITE -- so a worker could rewrite the document that says what it is.
    A separate manager-owned root is the same separation `credentials` draws
    for the same reason, and it is drawn here rather than argued.

    AN EXISTING ROOT IS A REFUSAL, not a place to write into. It is a live
    delivery or an orphan, and either way replacing bytes this manager cannot
    account for is how one attempt's container reads another attempt's launch
    contract.
    """
    attempt = boundaries.identity(attempt_id, "a launch attempt id")
    _same_attempt(attempt, job_execution)
    home = boundaries.text(storage, "the manager's launch storage")
    if not os.path.isabs(home):
        _refuse(f"the manager's launch storage is not an absolute path; a "
                f"root this build cannot name exactly is not a root",
                code="path")
    document = launch_document(session=session, contract=contract,
                               role=role, transport=transport,
                               job_execution=job_execution, provider_context=provider_context)
    payload = _bytes(document)
    root = os.path.join(os.path.realpath(home), attempt)
    if os.path.lexists(root):
        raise ContractRefusal(
            "refused", "precondition",
            f"a launch root already exists for attempt {name_value(attempt)}; "
            f"an existing root is a live delivery or an orphan, and writing "
            f"into either would replace bytes this manager cannot account for")
    place = os.path.join(root, os.path.basename(LAUNCH_TARGET))
    # 0700 WHILE IT IS BEING BUILT, and read-only-for-everybody only once the
    # document is whole. A half-written document nobody can see is a delivery
    # that failed; a half-written document a container could read is one it
    # would refuse in a way that looks like a manager bug.
    os.makedirs(root, mode=0o700, exist_ok=False)
    try:
        # EXCLUSIVE CREATION, NO-FOLLOW, AND CREATED UNREADABLE. `O_EXCL` so
        # nothing already at this name is written through, `O_NOFOLLOW` so a
        # link left there is refused rather than followed, and mode 0 so the
        # file is never WRITABLE and never readable while it is still partial.
        #
        # Review [P0]: this passed `READ_ONLY_FILE` as the creation mode and
        # stopped there. A creation mode is FILTERED BY THE UMASK, so a manager
        # under the ordinary service umask 077 authored 0400 — a document the
        # container's fixed uid 65532 cannot read, which is the unrunnable
        # worker this Work exists to fix, arriving silently and only on a host
        # with a restrictive umask. `os.chmod` on the ROOT was always exact and
        # was never affected; only the file was.
        #
        # `fchmod` ON THE DESCRIPTOR THIS FUNCTION WROTE, not a second `chmod`
        # by name: the name could be something else by then, and the descriptor
        # cannot be. It runs after the last byte, so the document becomes
        # readable exactly when it becomes complete, and there is still no
        # instant at which anything could open it for writing.
        handle = os.open(place,
                         os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW,
                         0o000)
        try:
            _write_whole(handle, payload)
            os.fchmod(handle, READ_ONLY_FILE)
        finally:
            os.close(handle)
        delivery = _exchange_materialized(root, attempt, document,
                                          workspace_group)
        logs = _logs_materialized(os.path.realpath(home), attempt,
                                  workspace_group)
        # THE ROOT IS CLOSED LAST, AFTER EVERY ENTRY IT WILL EVER HOLD EXISTS.
        # `READ_ONLY_DIR` is what stops the container renaming or replacing
        # `command` and `events` themselves -- those are permissions of this
        # parent, not of the namespaces -- so closing it before they were
        # created would have meant creating them somewhere the worker could
        # move. A parent can only be closed once nothing more needs to be made
        # in it, which is the same ordering `workspaces.assignment_workspace`
        # states for the assignment home.
        os.chmod(root, READ_ONLY_DIR)
    except BaseException:
        # A FAILED MATERIALIZATION TEARS ITSELF DOWN. Half a delivery is a root
        # holding a partial document that nothing is going to remove, and the
        # ending that would have removed it never starts, because the attempt
        # never launched.
        discard(root)
        raise
    return LaunchDelivery(attempt_id=attempt, root=root, place=place,
                          document=document, delivery=delivery, logs=logs)


def _exchange_materialized(root, attempt, document, workspace_group):
    """The exchange namespaces this document's transport selects, or nothing.

    THE DOCUMENT DECIDES, not the caller's intent. Whatever a caller asked for,
    what is on disk under this root has to agree with the launch document the
    worker will read -- a container told it speaks the file exchange and given
    no namespaces is a container that cannot answer, and namespaces created
    beside a `/1` document are host state nothing will ever mount.
    """
    # W156162: THE TRANSPORT DECIDES THIS, NOT THE VERSION.
    #
    # Comparing the schema was a proxy for "this document selects the exchange"
    # and it was exact while /2 was the only version that could. /3 carries a
    # Job context AND states its transport explicitly, so the proxy stopped
    # being exact the moment it existed: a /3 exchange delivery composed NO
    # namespaces, the worker had no delivery to read, and every such stage
    # projected `unreadable` and then `exceptional` -- a container running with
    # nothing to say to it. Measured, not reasoned about: 54 cases in the
    # one-worker pipeline failed exactly this way.
    # W376586: ASKED THROUGH `selected_transport`, so a `/5`-wrapped exchange
    # launch is not read as selecting nothing. See that function for why this
    # is one shared question rather than a `get` in each reader.
    if selected_transport(document) != exchange.EXCHANGE_TRANSPORT:
        return None
    if workspace_group is None:
        _denied(f"attempt {name_value(attempt)}'s launch document selects "
                f"{name_value(exchange.EXCHANGE_TRANSPORT)} and this "
                f"materialization names no workspace group; the container's "
                f"fixed uid is not this manager's, so without the "
                f"deployment's configured group the worker holds no share in "
                f"the namespace it must answer in")
    return exchange.materialize(root, attempt_id=attempt,
                                workspace_group=workspace_group)


def adopt(storage, *, attempt_id, session, contract, role,
          transport=None, job_execution=None, workspace_group=None, provider_context=None):
    """Recover the delivery THIS MANAGER already made, or FAIL CLOSED.

    W47225. `materialize` refuses an existing root and `discard` removes one,
    so a restarted process had no way to hold a delivery it had already made
    -- and W39358's narrow handoff retry, which runs in a FRESH process after
    the original exited, reconstructed its cleanup adapter with
    `launch_delivery=None`. `authorize_cleanup` could then remove the runtime
    while `_launch_ended` reported `not-delivered`, and the launch root the
    ordinary attempt materialized was left on disk with nothing that would
    ever come back for it.

    WHAT PROVES THE DELIVERY IS THE BYTES, and review 2026-08-30T15:05:35Z
    [P0] is why nothing weaker will do. Holding the document to its member
    NAMES and schema proves only that it is *a* launch document: a valid
    four-member document copied out of another attempt's root passed every
    one of those checks and came back as this attempt's delivery. Member
    values were not held either, so an integer `session` -- which
    `materialize` refuses before writing -- was adopted after the fact.

    So adoption AUTHORS what this component would have written, through the
    same `launch_document` and `_bytes` owners that wrote it, and requires the
    canonical bytes to match exactly. That one comparison closes identity and
    value drift together, and it reuses the authoring rules rather than
    copying them -- including the whole-document secret check, which a
    re-implementation here would have quietly dropped.

    AND THE ROOT IS HELD TO THE ONE ENTRY `materialize` CREATES. `discard`
    removes every name in the root it is given, so a sibling entry accepted
    here is a foreign file this component would later delete. [P0] again, and
    it is the difference between recovering a delivery and adopting a
    directory.

    EVERY PROOF IS DESCRIPTOR-RELATIVE AND NO-FOLLOW. [P1]: checking with
    `islink`/`isfile`, mode-checking with `lstat` and then reopening by name
    is three lookups of a path that can change between them, so the bytes
    could arrive through a link the earlier checks never inspected. The root
    is opened once with `O_NOFOLLOW|O_DIRECTORY`, the document is opened
    relative to THAT descriptor with `O_NOFOLLOW`, and the type, mode and
    bytes all come from the descriptor that is already open.

    ABSENT ADOPTS NOTHING, and that is an ordinary answer: an attempt may have
    had no launch delivery, and `None` is what lets a caller tell that apart
    from a delivery it failed to prove. A caller for whom absence is
    contradictory -- one whose attempt demonstrably started a runtime -- is
    the caller that must refuse, and this component does not decide that for
    it.
    """
    attempt = boundaries.identity(attempt_id, "a launch attempt id")
    _same_attempt(attempt, job_execution)
    home = boundaries.text(storage, "the manager's launch storage")
    if not os.path.isabs(home):
        _refuse(f"the manager's launch storage is not an absolute path; a "
                f"root this build cannot name exactly is not a root",
                code="path")
    # AUTHORED FIRST, through the owner that writes it. A document this
    # component would refuse to WRITE is one it must refuse to adopt, and
    # deriving the expectation before touching the disk is what makes the
    # comparison below a comparison rather than a second rule set.
    expected = _bytes(launch_document(session=session, contract=contract,
                                      role=role, transport=transport,
                                      job_execution=job_execution, provider_context=provider_context))
    root = os.path.join(os.path.realpath(home), attempt)
    if not os.path.lexists(root):
        return None
    name = os.path.basename(LAUNCH_TARGET)
    try:
        opened = os.open(root, os.O_RDONLY | os.O_NOFOLLOW | os.O_DIRECTORY)
    except OSError as failure:
        _denied(f"the launch root for attempt {name_value(attempt)} is not a "
                f"directory this manager made ({type(failure).__name__}); an "
                f"entry of another type is state this build cannot account "
                f"for")
    try:
        held = os.stat(opened)
        if stat.S_IMODE(held.st_mode) != READ_ONLY_DIR:
            _denied(f"attempt {name_value(attempt)}'s launch root is mode "
                    f"{oct(stat.S_IMODE(held.st_mode))} and this manager "
                    f"established {oct(READ_ONLY_DIR)}; a delivery whose "
                    f"modes have moved is not the one it wrote")
        # EXACTLY THE ENTRIES THIS TRANSPORT CREATES, because `discard`
        # deletes every name here. W81857 widened the set from one to three and
        # the rule did not change: the expectation is derived from the
        # transport being adopted, so a `/1` root carrying exchange namespaces
        # -- or a `/2` root missing them -- is refused rather than repaired.
        wanted = sorted(_root_entries(transport))
        entries = sorted(os.listdir(opened))
        if entries != wanted:
            _denied(f"attempt {name_value(attempt)}'s launch root holds "
                    f"{entries!r} and this manager creates exactly "
                    f"{wanted!r}; adopting a widened root would authorize "
                    f"deleting an entry this component never wrote")
        try:
            document = os.open(name, os.O_RDONLY | os.O_NOFOLLOW,
                               dir_fd=opened)
        except OSError as failure:
            _denied(f"attempt {name_value(attempt)}'s launch document could "
                    f"not be opened as this manager wrote it "
                    f"({type(failure).__name__})")
        try:
            found = os.stat(document)
            if not stat.S_ISREG(found.st_mode):
                _denied(f"attempt {name_value(attempt)}'s launch document is "
                        f"not a regular file")
            if stat.S_IMODE(found.st_mode) != READ_ONLY_FILE:
                _denied(f"attempt {name_value(attempt)}'s launch document is "
                        f"mode {oct(stat.S_IMODE(found.st_mode))} and this "
                        f"manager established {oct(READ_ONLY_FILE)}; a "
                        f"writable launch document is one the worker could "
                        f"rewrite between being given it and being asked "
                        f"about it")
            raw = os.read(document, MAX_LAUNCH_BYTES + 1)
        finally:
            os.close(document)
    finally:
        os.close(opened)
    # THE ONE COMPARISON, and it is exact. Canonical bytes, so a document that
    # merely MEANS the same thing in a different spelling is not this
    # delivery's document either -- `_bytes` is what wrote it and there is
    # only one serialization of a given launch document.
    if raw != expected:
        _denied(f"attempt {name_value(attempt)}'s launch document is not the "
                f"one this manager would have written for it; a document that "
                f"is merely well formed proves which KIND of thing it is and "
                f"not which delivery")
    place = os.path.join(root, name)
    delivery = None
    if transport is not None:
        # THE NAMESPACES ARE PROVED, NOT ASSUMED, and a `/2` root that has
        # lost one of them refuses rather than answering a delivery whose
        # mounts would fail at the engine. `exchange.adopt` answers `None`
        # only for a root that has neither, which cannot be reached here
        # because the entry set above already required both.
        delivery = exchange.adopt(root, attempt_id=attempt,
                                  workspace_group=workspace_group)
        if delivery is None:
            _denied(f"attempt {name_value(attempt)}'s launch document selects "
                    f"{name_value(transport)} and its exchange namespaces are "
                    f"absent; a replacement authored now would be mounted by "
                    f"nothing that exists")
    return LaunchDelivery(attempt_id=attempt, root=root, place=place,
                          document=launch_document(
                              session=session, contract=contract, role=role,
                              transport=transport,
                              job_execution=job_execution, provider_context=provider_context),
                          delivery=delivery,
                          logs=_logs_adopted(os.path.dirname(root), attempt,
                                             workspace_group))


def _root_entries(transport):
    """Every name this manager creates in a launch root for one transport."""
    name = os.path.basename(LAUNCH_TARGET)
    if transport is None:
        return (name,)
    return (name, exchange.COMMAND_DIRECTORY, exchange.EVENT_DIRECTORY)


def discard(root):
    """Remove one launch root WITHOUT reading anything in it.

    Answers whether it is gone. Removal is by name inside a directory this
    module created, never by walking something a worker could have replaced --
    the document is read-only and the root is the manager's, so there is
    nothing here to discover.

    W198667: AND IT LEAVES THE LOG ROOM ALONE, which is the required outcome
    rather than an oversight. The room is a sibling of this root, under
    `<launch storage>/logs/<attempt>`, precisely so that a teardown cannot take
    the evidence with it: partial output must survive error, abnormal
    termination and restart, and a directory emptied by the act of tearing its
    attempt down would lose exactly what it exists for. Retention is the
    retention policy's question, not a teardown's.
    """
    if not os.path.isdir(root):
        return not os.path.lexists(root)
    os.chmod(root, 0o700)
    # W81857: THE EXCHANGE FIRST, AND THROUGH ITS OWN WALK. This loop removes
    # names in a directory nothing else may write, which is exactly why it can
    # afford to be flat; the event namespace is writable by the container, so
    # the entries under it are DYNAMIC and none of them was authored here.
    # Widening this loop to recurse would have made a launch teardown follow
    # whatever a worker left behind.
    exchange.discard(root)
    for name in sorted(os.listdir(root)):
        try:
            os.remove(os.path.join(root, name))
        except OSError:
            pass
    try:
        os.rmdir(root)
    except OSError:
        pass
    return not os.path.lexists(root)


def _context_delivery(given, job):
    from . import provider_context as owner
    held = owner._document(given, owner.DELIVERY_MEMBERS)
    if held["schema"] != owner.DELIVERY_SCHEMA or held["attempt_id"] != job["attempt_id"]:
        _denied("context delivery names another schema or attempt")
    for key in ("context_id", "use_id", "invocation_id", "attempt_id", "cli_build", "model", "reported_model"):
        owner._text(held[key])
    for key in ("profile_digest", "delivery_digest", "invocation_binding_digest", "task_digest", "prompt_digest", "argv_digest", "argv_policy_digest", "environment_policy_digest"):
        owner._hash(held[key])
    owner._integer(held["generation"])
    owner._text(held["conversation_id"])
    try:
        canonical_uuid = str(__import__("uuid").UUID(held["conversation_id"]))
    except ValueError:
        _denied("context conversation is not a canonical UUID")
    if held["conversation_id"] != canonical_uuid:
        _denied("context conversation is not a canonical UUID")
    if held["mode"] != ("restore" if held["generation"] else "open") or (held["generation_digest"] is None) != (held["generation"] == 0):
        _denied("context generation and mode disagree")
    if held["generation_digest"] is not None:
        owner._hash(held["generation_digest"])
    if held["argv_policy_digest"] != owner.digest(owner.ARGV_POLICY) or held["environment_policy_digest"] != owner.digest(owner.ENVIRONMENT_POLICY):
        _denied("context serving policy disagrees")
    operands = {key: value for key, value in held.items() if key != "invocation_binding_digest"}
    if owner.digest(operands) != held["invocation_binding_digest"]:
        _denied("context invocation binding digest disagrees")
    return dict(held)
