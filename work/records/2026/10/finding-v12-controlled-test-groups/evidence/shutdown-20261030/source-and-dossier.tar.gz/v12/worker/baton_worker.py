"""`baton-worker`: the entry point inside the OCI reference image.

W6633 (`work/records/2026/08/finding-v12-oci-reference-worker-image`), the
third bounded child of W5.

THIS FILE IS THE WHOLE PROGRAM INSIDE THE IMAGE, and that is the design rather
than a convenience. It imports NOTHING from `baton_v12` -- no manager, no
contracts package, no authority client -- because a worker that could import
the manager is a worker one bug away from holding the manager's capabilities.
The image contains this file, the scripted agent beside it, and a Python
runtime. A case asserts the import graph, because "we did not import it" is a
property somebody will break by accident.

THE CHANNEL IS FRAMED AND BOUNDED. Every message is one length-prefixed JSON
document on stdin, answered on stdout:

    <decimal byte length>\\n<exactly that many bytes of UTF-8 JSON>

Length-prefixed rather than newline-delimited because a newline is a byte an
agent's own output legitimately contains, and a protocol whose framing a
payload can forge is a protocol with no framing. Both directions are bounded:
an oversized frame is refused before it is read into memory, not after.

EXCLUSIVE STDIO IS TRANSPORT ISOLATION, NOT MESSAGE IDENTITY -- the approved
`baton.worker-entry/1` ruling, 2026-08-25. Every request is one closed object
carrying `protocol`, `session`, `operation_id` and `operation`, plus only that
operation's own members. `session` is the manager-minted identity of THIS
exact container session and arrives in the launch document;
`operation_id` is consumed once within it. Wrong-session, replayed, missing,
unknown and extra members all refuse before the request reaches the agent.

`session` ARRIVES IN THE LAUNCH DOCUMENT (W26291), not in the environment.
Every container holds its own identity for its own lifetime, and no message
turns one container into another: a fresh container is what a continuation was
replaced by.

THERE IS EXACTLY ONE RESPONSE SHAPE AND IT IS CORRELATED. Every response
echoes the request's own `protocol`, `session` and `operation_id`; a success
adds `ok: true` and `answer`, a fault adds `ok: false`, `code` and a bounded
`message`. A frame this program cannot read an identity envelope out of is
answered with NO FRAME at all and a non-zero exit -- the ruling forbids
inventing an uncorrelated response shape, and the Worker Manager already owns
the launched session and settles that case from the engine.

THIS PROGRAM IS TOLD WHAT IT IS BY ONE VERSIONED DOCUMENT (W26291).
`/run/baton/launch.json` is a manager-authored, read-only, bind-mounted file
carrying exactly `schema`, `session`, `contract` and `role`. The path is a
CONSTANT of the contract, so there is no locator variable to point this program
somewhere else, and the read is bounded, no-follow and descriptor-proved for
the same reason every other worker-visible byte in this campaign is.

THERE IS NO ENVIRONMENT FALLBACK, and that is the ruling rather than an
omission. `BATON_WORKER_POSTURE`, `BATON_WORKER_SESSION`,
`BATON_WORKER_CONTRACT` and `BATON_WORKER_ROLE` are not read here at all: a
container started with only those does not start. A compatibility path would be
the second live contract the supersession exists to end.

AND THERE IS NO POSTURE. V12 launches one runtime, consent/execution is not a
runtime axis, and the ruling says there is no constant to transport -- so this
program does not ask what kind of container it is, and `OPERATIONS` is the one
runtime's set rather than a map keyed by an answer nothing supplies. `consider`
is KEPT as a known operation this runtime is not entitled to, which is what
makes refusing it mean something; deleting an operation from a ruled protocol
is a larger decision than the Work that removed the axis.

A BOOTSTRAP FAULT IS LATCHED, NOT RAISED -- the approved startup-correlation
ruling. A container whose launch document is present and
correlatable but not valid still has an operable framing loop, so it reads
exactly one bounded request identity envelope, returns the pending failure
through the ordinary correlated fault, and exits non-zero. A document that
cannot be read AT ALL is the other case: there is no session to answer under,
so nothing is written and the manager settles the start it already owns.

Reading that envelope grants no task, workspace, output, tool or agent
capability: a latched failure can never reach the agent.

STDOUT IS THE CHANNEL, so nothing else may write to it. Diagnostics go to
stderr. A `print` in an agent would otherwise corrupt a frame, which is the
kind of failure that looks like a protocol bug for a week.
"""

import hashlib
import json
import os
import re
import stat
import sys
import threading
import time

# W376586: THE SHARED TYPED DECLARATION REFUSAL, AND WHY ITS ABSENCE CANNOT
# SILENTLY DEFEAT THE CATCH.
#
# ONE MODULE SO ONE TYPE. The amendment requires the catch below to "exercise
# actual package imports so a duplicate type definition cannot defeat it": a
# second class defined here would make the `except` test identity against the
# wrong object, and the adapter's typed refusal would escape as a generic
# agent failure -- the exact outcome the four codes exist to replace.
#
# THE IMPORT IS GUARDED AND THAT IS NOT THE `attempt_log_format` COMPROMISE.
# An optional capture module degrades to no diagnostics, which is a cost; an
# optional exception class would ordinarily degrade to no catch, which would be
# the packaging defect review 2026-10-28T20-07-16Z found, moved here and made
# quiet. WHAT MAKES IT SAFE IS THAT THE PRODUCER CANNOT EXIST WITHOUT IT: every
# role adapter imports this module at its top level, so an image carrying an
# adapter and not this module cannot import the adapter at all -- it fails
# loudly, before this program starts, which is precisely the failure the review
# found. An image that carries NO adapter -- the reference and the preparation
# images, which ship no provider -- has nothing that can raise a typed refusal,
# so a dead clause there is the honest shape, and those two recipes keep the
# exhaustive layer contents their own gates assert.
#
# `test_worker_packaging` holds the pairing as a rule DERIVED from the recipes:
# a recipe must carry this module exactly when one of the programs it installs
# imports it unconditionally. The module is standard-library-only and imports
# nothing, including nothing from `baton_v12`.
try:
    import adapter_refusal
except ImportError:                                        # pragma: no cover
    class _NoTypedRefusal:
        """The inert stand-in for an image that ships no role adapter.

        NOT A SECOND DEFINITION OF THE SHARED CLASS. `AdapterDeclarationRefusal`
        here is a private exception type nothing in this distribution raises,
        constructs or exports -- so the `except` clause below is unreachable
        rather than wrong. A class that could be raised would be the duplicate
        definition the amendment forbids.
        """

        class AdapterDeclarationRefusal(Exception):
            pass

        COMPONENT = None
        CODES = ()
        ROLES = ()

    adapter_refusal = _NoTypedRefusal

PROTOCOL = "baton.worker-entry/1"

# The frame ceiling, both directions. Large enough for a human contract and a
# recap, small enough that a hostile or looping agent cannot exhaust the
# container's memory through the channel.
MAX_FRAME = 1 << 20

# The identity members are bounded on their own, well below the frame: an
# identity is a label the manager minted, not a payload.
MAX_IDENTITY = 256

# The bounded prose a fault carries. Bounded here rather than at the frame so
# the worker reports what went wrong instead of the channel reporting that the
# worker said too much.
MAX_MESSAGE = 2000

# W26291: THE FIXED LAUNCH DOCUMENT, and every constant of it.
#
# The path is the contract's, not an operand: a path this program could be told
# is a path a container can be pointed at wrongly, and the whole reason the
# retired environment transport was replaced is that its vocabulary had no
# version and no closed shape. `schema` carries the version IN THE NAME, so a
# document from another generation is refused by an equality test rather than
# by parsing a version member and deciding what to do about it.
LAUNCH_DOCUMENT = "/run/baton/launch.json"
LAUNCH_SCHEMA = "baton.worker-launch/1"
LAUNCH_MEMBERS = ("schema", "session", "contract", "role")

# W81857: THE SECOND LAUNCH VERSION, AND WHAT IT SELECTS.
#
# `/1` describes what this container IS and says nothing about how it is
# spoken to, so a worker reading only `/1` can only ever enter the stdin
# framing loop below. That loop is correct and stays -- it is the diagnostic
# and test transport -- but it makes the manager process that holds the pipe
# the only reader of a provider's answer, and a manager restart then destroys
# protocol state a healthy container is still producing.
#
# `/2` adds exactly one member, `transport`, and the value below is the only
# one this program knows. THE VERSION IS CHECKED BY EQUALITY and the member
# set is decided by the version: there is no document that is valid under both
# and no discovery path that turns a mounted directory into a contract. A
# container that finds `/run/baton/exchange/command` present and is launched
# under `/1` uses stdin, because a worker that picked its own transport from
# the filesystem would be a worker with two live contracts and no version --
# which is what the retired environment channel was.
EXCHANGE_LAUNCH_SCHEMA = "baton.worker-launch/2"
EXCHANGE_LAUNCH_MEMBERS = LAUNCH_MEMBERS + ("transport",)

# W156162: THE THIRD VERSION, AND WHAT IT ADDS.
#
# A Job may configure how many seconds one provider turn and one verification
# command get, and this container is where those ceilings are actually handed to
# a command -- so the delivery has to carry them. `/1` and `/2` are read exactly
# as before; a deployment that configures nothing is unaffected.
#
# `/3` STATES ITS TRANSPORT EXPLICITLY, including as null for the one-shot
# integration launch, because a version that carries a Job context must be able
# to say either and a reader inferring absence from a missing member would be
# guessing at the one fact that decides which channel is authoritative.
JOB_LAUNCH_SCHEMA = "baton.worker-launch/3"
JOB_LAUNCH_MEMBERS = EXCHANGE_LAUNCH_MEMBERS + ("job_execution",)
CONTEXT_LAUNCH_SCHEMA = "baton.worker-launch/4"
CONTEXT_LAUNCH_MEMBERS = JOB_LAUNCH_MEMBERS + ("provider_context",)

# W376586: /5 IS THE ONE CURRENT FILE-EXCHANGE WRAPPER, and it is a different
# KIND of version from the four above.
#
# `/1`-`/4` each describe this container. `/5` describes the WIRE it and the
# manager speak and carries one of those four as its payload --
# `{schema, wire_profile, payload}` and nothing else. `AMENDMENT-376531.md`
# selects exactly this wrapper and exactly one profile, and requires the typed
# worker to refuse an unsupported or UNWRAPPED file-exchange launch before the
# adapter is constructed, before the receipt is published and before any
# provider runs. `serve` reaches none of those if this validation raises, which
# is what makes "before" a property of the order rather than a claim.
#
# THE PROFILE IS CHECKED BY EQUALITY: no negotiation, no list, no default. A
# profile this program cannot name is a wire it cannot speak.
WRAPPER_LAUNCH_SCHEMA = "baton.worker-launch/5"
WRAPPER_LAUNCH_MEMBERS = ("schema", "wire_profile", "payload")
WIRE_PROFILE = "typed-adapter-file-exchange/1"

# EVERY LAUNCH GENERATION THIS FILE READS, in one place, ordered oldest first.
# W197661: the refusal for an unrecognised version spelled three of these by
# hand and omitted `/4`, so the one sentence an operator gets about a
# cross-generation launch was wrong about this worker's own range. A tuple
# cannot drift from the reader the way a hand-written list did.
SUPPORTED_LAUNCH_SCHEMAS = (LAUNCH_SCHEMA, EXCHANGE_LAUNCH_SCHEMA,
                            JOB_LAUNCH_SCHEMA, CONTEXT_LAUNCH_SCHEMA)

# THE ONE GENERATION THAT CANNOT BE AN EXCHANGE LAUNCH. `/1` has no transport
# member at all, so a document declaring it is unambiguously the framing-loop
# generation -- the diagnostic and test transport `worker_entry.converse`
# drives, where a manager really is writing frames.
#
# THIS IS A CONSERVATIVE REFUSAL-CHANNEL POLICY AND NOT A CLAIM ABOUT THE LATER
# VERSIONS. Review 2026-09-17T22-10-41Z finding 4: `/3` and `/4` carry the
# transport as a MEMBER and may legitimately set it to null, so "every later
# generation speaks the exchange" is false and the earlier comment here said
# it. What is true is the thing this decision actually rests on: when a launch
# document has been REFUSED, the member that would say which channel its
# manager intended is part of the document just refused, so it cannot be read
# -- and of the two ways to be wrong, waiting on a stdin nobody writes to is
# unbounded and reporting on stderr is not.
#
# W197661 USES THIS FOR EXACTLY ONE DECISION -- which channel a STARTUP FAILURE
# is reported on -- and never to select a transport, an execution or a peer. A
# VALIDATED document still selects its transport itself, including a `/3` or
# `/4` that validly names none. See `serve`.
ONE_SHOT_LAUNCH_SCHEMA = LAUNCH_SCHEMA

# The members of that context, closed, and the two that are NOT text: the
# configuration is a document and the transport may be null.
JOB_EXECUTION_MEMBERS = ("job_id", "attempt_id", "job_input_digest",
                         "job_policy_digest", "runtime_input_digest",
                         "runtime_policy_digest", "execution_limits",
                         "execution_limits_digest")

# The one range this container will hand to a command, the same one the Job
# owner admits. Stated here as well because this program is what a mis-composed
# delivery lands on, and a bound it cannot honour is refused rather than clamped.
MIN_LAUNCH_SECONDS = 1
MAX_LAUNCH_SECONDS = 86400

# EVERY BOUNDARY A COMPLETE CONFIGURATION NAMES, and the metadata it carries.
#
# W156162 review 2026-09-13T02:41:57Z [P1]: the first check accepted any nonempty
# boundary map and validated only what was present, so a delivery whose
# `provider_turn` had been DELETED and whose configuration was then resealed was
# accepted -- and the adapter fell back to 3600 for a Job that had asked for 60.
# A partial configuration is not a smaller configuration; it is a delivery that
# cannot say what this container was told to do.
LAUNCH_BOUNDARIES = ("provider_turn", "ordinary_verification",
                     "integration_verification", "host_verification")
LAUNCH_LIMIT_MEMBERS = ("units", "scope", "compatibility_generation",
                        "requested", "boundaries")
LAUNCH_UNITS = "seconds"
LAUNCH_SCOPE = "per-invocation"

# AND THE NESTED SHAPES, closed as well. Review 2026-09-13T02:51:29Z: a resealed
# `requested` carrying a Boolean or a setting nobody named was accepted, and so
# was a boundary missing its `origin` or carrying a member this program does not
# know. A seal proves the bytes were not changed after somebody wrote them; it
# says nothing about whether what they wrote is a configuration this container
# can act on, and every member below is one a reader here actually uses or
# reports.
LAUNCH_SETTINGS = ("provider_turn_seconds", "verification_command_seconds")

# WHICH SETTING EACH BOUNDARY IS, fixed. Review 2026-09-13T02:59:22Z: a resealed
# `provider_turn` naming `verification_command_seconds` was accepted, so the
# document could say a Job's verification setting had moved its provider turn --
# an association nothing checked. One explicit verification setting reaching all
# three verification boundaries is the owner's decision; WHICH setting a boundary
# answers to is not negotiable, and this container states it rather than reading
# whatever the file claims.
LAUNCH_BOUNDARY_SETTING = {
    "provider_turn": "provider_turn_seconds",
    "ordinary_verification": "verification_command_seconds",
    "integration_verification": "verification_command_seconds",
    "host_verification": "verification_command_seconds",
}
LAUNCH_BOUNDARY_MEMBERS = ("seconds", "origin", "setting", "default_seconds")
LAUNCH_ORIGINS = ("job", "compatibility")
EXCHANGE_TRANSPORT = "baton.worker-exchange/1"

# THE TWO FIXED EXCHANGE ROOTS, constants of the contract at both ends and
# never operands. The manager writes the command namespace and mounts it
# READ-ONLY here; this program writes the event namespace and the manager
# reads it as untrusted input. A path this program could be told is a path a
# container can be pointed at wrongly, which is the same rule the launch
# document's own fixed path states.
COMMAND_ROOT = "/run/baton/exchange/command"
EVENT_ROOT = "/run/baton/exchange/events"

COMMAND_SCHEMA = "baton.worker-exchange.command/1"
RECEIPT_SCHEMA = "baton.worker-exchange.receipt/1"
STATE_SCHEMA = "baton.worker-exchange.state/1"
# W376586: THE TERMINAL MOVES TO `/2`, and the version is in the name for the
# reason every other document here carries one -- a manager reading `/1` and a
# worker writing `/2` disagree about a MANDATORY member, and an equality test
# is how that is found at the boundary instead of inside a parser. The
# amendment selects one current closed release: there is no dual `/1` support
# at either end.
TERMINAL_SCHEMA = "baton.worker-exchange.terminal/2"

# WHAT `/2` ADDS, and it is MANDATORY rather than optional: the ten existing
# members plus `adapter_failure`, null on every ending that was not a typed
# pre-provider declaration refusal. Mandatory because an absent member and a
# null one are different claims only if both are spellable, and the manager
# must be able to tell "this worker says no typed failure happened" from "this
# worker does not know about typed failures".
ADAPTER_FAILURE_DOCUMENT = "adapter_failure"
ADAPTER_FAILURE_MEMBERS = ("component", "code", "role", "operation",
                           "operation_id")
# The ONE operation a typed declaration cause may name. A declaration is
# checked when the provider turn is composed, so `describe` -- which invokes
# no provider -- cannot produce one, and a typed refusal raised there keeps the
# safe generic agent failure.
ADAPTER_FAILURE_OPERATION = "work"
# The fault code the ending still carries. The typed object is ADDITIONAL
# evidence about an `agent` fault and never a new ending or a new code: the
# closed fault vocabulary is unchanged, so a manager that cannot read the added
# member still reads the same ending it always did.
ADAPTER_FAILURE_CODE = "agent"
# The added object's own ceiling, separate from the whole document's. Five
# bounded literals cannot approach it; a bound is here because this is the
# first member of this document composed from an OBJECT the adapter raised
# rather than from values this program authored.
MAX_ADAPTER_FAILURE_BYTES = 1024

COMMAND_MEMBERS = ("schema", "session", "attempt_id", "sequence_id",
                   "operations")
COMMAND_OPERATION_MEMBERS = ("operation", "operation_id")
RECEIPT_DOCUMENT = "receipt.json"
TERMINAL_DOCUMENT = "terminal.json"

# The worker's own closed ending vocabulary, the same three words the framed
# transport answers with. `lost` is accepted by the manager's reader and is
# deliberately NOT published by this program: a process that finds its own
# receipt with no terminal cannot know whether the provider it started is
# still running, and claiming loss would be exactly the observation it lacks.
# The manager derives loss by combining the durable receipt with its own exact
# runtime observation, which is evidence this side does not have.
EXCHANGE_ENDINGS = ("answered", "faulted", "lost")
EXCHANGE_STATES = ("dispatched", "answered", "faulted")

# The bytes any one exchange document may be. Bounded before it is read, for
# the reason the launch reader is: a reader with no bound is bounded by
# whoever writes the file.
MAX_EXCHANGE_BYTES = 65536                     # 64 KiB
MAX_EXCHANGE_VALUE = 4096

# How long this program waits between scans of the command namespace, and how
# many entries it will look at. The command is published AFTER the container
# starts -- that is what makes it a level-triggered manager act rather than a
# launch-time one -- so PID 1 waits for it here instead of on a pipe nobody
# may be holding.
SCAN_SECONDS = 2

# GROUP-READABLE, OWNER-WRITABLE-BY-NOBODY. The manager runs as another uid and
# reaches this namespace through the deployment's configured workspace group,
# which the container holds as a supplementary group; a document published at
# the process default 0600 would be one only this container could read. The
# document is finished when it is written and nothing writes it again, and the
# mode says so on disk.
EVENT_FILE = 0o440

# W61599: THE OPTIONAL ACTIVITY DOCUMENT, ITS SCHEMA AND ITS BOUNDS. The
# manager mirrors every one of these; the two copies are necessary for the
# reason the four lifecycle names are duplicated -- this program cannot import
# the manager.
ACTIVITY_DOCUMENT = "activity.json"
ACTIVITY_SCHEMA = "baton.worker-exchange.activity/1"

# THE ONE STAGING NAME, AND IT IS FIXED RATHER THAN UNIQUE. Everything else
# this program publishes stages under a unique name so a crash cannot wedge a
# later incarnation; this one must not, because the event namespace admits
# `MAX_EVENT_ENTRIES` entries in TOTAL and overrunning that budget does not
# degrade one document -- it makes the manager refuse to enumerate the
# namespace at all. One publisher, one slot and one fixed temporary is what
# keeps the accounting at six entries, and an existing entry at this name
# SUPPRESSES the write rather than being unlinked or written through.
ACTIVITY_STAGING = ".activity.json.tmp"

# AT MOST ONE WRITE A SECOND, which is the resolution of an operator reading
# "updated 4s ago" rather than the resolution of the stream; and a FINITE stop,
# after which the publisher is abandoned rather than joined. A diagnostic that
# could delay the provider's completion or this program's terminal would be a
# diagnostic that costs more than it reports.
ACTIVITY_DOCUMENT_OPERATION = "work"
ACTIVITY_SECONDS = 1.0
ACTIVITY_STOP_SECONDS = 2.0

# The manager writes these same four names, the same schema string and the same
# ceilings. THE TWO COPIES ARE NECESSARY -- this program cannot import the
# manager, which is the isolation rule the image is built on -- and a case in
# `test_oci` reads this literal and holds the manager's against it, because two
# copies of one contract agree until they don't.
MAX_LAUNCH_BYTES = 65536                       # 64 KiB
MAX_LAUNCH_VALUE = 4096

# WHAT THIS RUNTIME MAY BE ASKED. One tuple rather than a map keyed by posture:
# V12 launches one runtime, so there is no second set and nothing to key on.
# `consider` stays in the vocabulary below as an operation this runtime is NOT
# entitled to -- that refusal is the entitlement proof, and it needs `consider`
# to be a real operation rather than an unknown word.
OPERATIONS = ("describe", "work")

# The common envelope every request carries, and then EXACTLY the members each
# operation adds.
#
# Review [P1]: this used to be keyed by POSTURE, so an execution `describe`
# carrying `task` succeeded -- a member `describe` has no use for, accepted
# because some other operation of that posture does. Closure that is one level
# coarser than the contract is closure over the wrong thing.
COMMON_MEMBERS = ("protocol", "session", "operation_id", "operation")

REQUEST_MEMBERS = {
    "describe": COMMON_MEMBERS,
    "consider": COMMON_MEMBERS,
    # W14251, closed: A WORK REQUEST CARRIES NO TASK. The assignment is read
    # from `/input/input.json`, which is the manager-authored document at a
    # path that is a CONSTANT of the contract rather than an operand. An
    # inline task was the superseded shape and is not kept as an alias: two
    # live contracts for one operation is what a supersession exists to end.
    "work": COMMON_MEMBERS,
}

# What each answer is, exactly. Validated before it is framed, because an
# answer is what crosses the worker boundary and an agent is the least trusted
# thing inside this container -- a missing, unknown, extra or wrong-typed
# member must not become a frame the manager then has to interpret.
ANSWER_MEMBERS = {
    # W26291: `posture` and `environment` are GONE and `launch` replaced them.
    # `posture` reported an axis that no longer exists, and `environment`
    # reported the transport this Work retired; `launch` is the exact analogue
    # of what `environment` said -- the sorted member names of the document
    # this container was actually launched with.
    "describe": ("protocol", "operations", "launch"),
    "consider": ("contract_digest", "decision", "reason"),
    # `workspace` IS GONE ENTIRELY rather than renamed. A workspace path is a
    # HOST fact and the Worker Manager is artifact-neutral: what it needs from
    # a worker is which declared outputs were produced, and it learns where
    # they are from the declarations it wrote.
    "work": ("disposition", "outputs", "recap"),
}

# `ENVIRONMENT` IS GONE ENTIRELY rather than emptied (W26291). It named the
# four `BATON_WORKER_*` values a container was allowed to see, and the
# supersession retired that transport with no fallback -- so a set describing
# which of them are legal would be describing a channel this program no longer
# reads. What replaced it is `LAUNCH_MEMBERS` above: the closed set of one
# versioned document, checked as a closed set rather than as an allowlist over
# whatever the image happened to be started with.

# THE TWO FILESYSTEM ROLES, as constants of the contract. W14251 §7.0: a path
# a manifest could vary is a path a runtime can be pointed at wrongly, so the
# worker is told where to look by the contract rather than by a payload.
INPUT_ROOT = "/input"
OUTPUT_ROOT = "/output"
INPUT_MANIFEST = "input.json"
# W19784, approved 2026-08-26: THE SECOND MANAGER-AUTHORED INPUT DOCUMENT.
#
# The frozen `completionManifest` requires the exact full `assignment_ref` --
# Work reference, participant AND authority generation. `input.json` is minted
# before any claim exists and carries no generation, the `work` frame carries
# only the common worker-entry identity, and the execution environment
# deliberately carries no assignment value. So until this path existed there
# was NOWHERE inside the container to learn who this assignment is, and the
# only way to publish a valid envelope was to put `assignment_ref` into a
# document whose schema forbids it -- which is what this file used to do.
#
# The manager materializes this after the claim commits and before the input
# root is mounted. It is the ONE source of the identity below.
ASSIGNMENT_MANIFEST = "assignment.json"
OUTPUT_MANIFEST = "output.json"
COMPLETION_SCHEMA = "baton.worker-manifest/completion"

# THE FROZEN CONTRACT ITSELF, shipped beside this program as DATA.
#
# W19784 review [P0]: this worker read the two manager-authored documents by
# picking out the members it wanted. So a document with a false
# `manifest_digest`, or one carrying an extra top-level member -- a second
# identity alias, exactly what the ruling rejected -- passed straight through
# to agent dispatch. Shallow extraction is not validation.
#
# The fix could not be a hand-written member list. A list typed here is a
# SECOND COPY of the contract, and a second copy is a second thing to keep
# true; the campaign has been corrected for that before. So the schema travels
# with the image and the closed member sets are DERIVED from it at startup.
# `test_frozen` proves this copy is byte-identical to the other four, so there
# is one contract with five identical copies rather than five contracts.
#
# WHAT THIS DELIBERATELY IS NOT: a JSON Schema implementation. The image
# carries no validator library and must not grow one -- "no build toolchain, no
# package manager state" is a decision of the recipe, and a schema interpreter
# inside the worker would be a second validator to keep true anyway. What is
# proved here is the part a mis-composed or edited delivery breaks and that
# this program can prove ALONE: the document is the manager's closed document,
# it carries every member that definition requires, and its bytes are the ones
# its own digest describes. The manager proves the whole schema before it
# mounts the root (`workspaces.compose_input_root`, which calls the shipped
# `check_input_pair`), and `test_worker_image` pins that the two agree about
# what "closed" means.
CONTRACT_SCHEMA = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                               "worker-control-1.0.schema.json")

# How much of the manager's input manifest this worker will read. It is a
# document from outside the container and its size is not this program's
# decision, so the bound has to be.
MAX_INPUT_BYTES = 4 * 1024 * 1024

# W6633 eleventh review [P1]: the declared-output shape and the path grammar
# are DERIVED from the shipped contract, exactly as the manifest member sets
# are. A list typed here would be a paraphrase, and W19784's third review is
# the standing lesson about paraphrased rules: they agree with the original
# until they don't, and they stop agreeing where it costs most.
#
# `DECLARATION_MEMBERS` used to be four names with `constraints` missing, so
# the ceilings a declaration states were not merely unenforced -- they were not
# even required to be present.
DECLARATION_DEFINITION = "outputDescriptor"
CONSTRAINT_DEFINITION = "outputConstraints"
RELATIVE_PATH = "relativePath"

# What an `assignment_ref` is, exactly. The worker COPIES this value into the
# envelope rather than rebuilding it, so what it checks is that the delivered
# document carries the whole thing and nothing else -- an envelope carrying a
# reconstructed or widened identity would be this worker's invention.
ASSIGNMENT_REF_MEMBERS = ("work_ref", "participant", "generation")

# `ASSIGNMENT_MEMBERS` and the two manifest-schema constants are GONE with the
# W19784 review's correction rather than kept beside it. They were this
# program's own list of what a delivered document must carry and be, and the
# closed set is now derived from the frozen contract -- so keeping them would
# be exactly the second copy the derivation exists to avoid, differing from the
# real definition the first time either moves.

# What an agent says about ONE declared output. The bytes are deliberately not
# in it: the worker MEASURES them, because the agent is the least trusted thing
# in this container and a content manifest is a claim about a tree.
AGENT_OUTPUT_MEMBERS = ("name", "status", "result_metadata")
OUTPUT_STATUSES = ("present", "missing-optional")

# What a worker may say it did. The frozen `completionManifest`'s own set, and
# a worker's disposition is a CLAIM about its work rather than a settlement --
# the manager records it and settles the attempt itself.
DISPOSITIONS = ("completed", "unable", "plan-rejected", "cancelled")


class WorkerFault(Exception):
    """A refusal this program can report as a frame rather than a crash."""

    def __init__(self, code, message):
        super().__init__(message)
        self.code = code
        self.message = message[:MAX_MESSAGE]


class Uncorrelated(Exception):
    """A failure this program cannot answer, because it has no identity to
    answer under.

    Deliberately NOT a `WorkerFault`. The approved ruling forbids inventing an
    uncorrelated response shape, so a frame whose identity envelope cannot be
    read produces no frame at all -- the Worker Manager already owns the
    launched session and settles that case from the engine rather than from a
    worker message nobody can match to a request.
    """


def read_frame(stream):
    """One length-prefixed frame, or None at a clean end of input.

    The length is read BYTE BY BYTE up to the digits a ceiling can have, so a
    peer that sends no newline cannot make this read forever -- the bound is on
    the header as well as on the body, because a header is caller input too.
    """
    header = b""
    while True:
        piece = stream.read(1)
        if not piece:
            if not header:
                return None
            raise Uncorrelated("the frame header ended early")
        if piece == b"\n":
            break
        header += piece
        if len(header) > 12:
            raise Uncorrelated("the frame header is not a length")
    if not header.isdigit():
        raise Uncorrelated("the frame header is not a length")
    length = int(header)
    if length > MAX_FRAME:
        raise Uncorrelated(f"a frame of {length} bytes is larger than the "
                           f"{MAX_FRAME} this channel carries")
    body = stream.read(length)
    if len(body) != length:
        raise Uncorrelated("the frame body ended early")
    try:
        document = json.loads(body.decode("utf-8"))
    except (UnicodeDecodeError, ValueError):
        raise Uncorrelated("a frame is not UTF-8 JSON") from None
    if type(document) is not dict:
        raise Uncorrelated("a frame is one JSON object")
    return document


def write_frame(stream, document):
    body = json.dumps(document, sort_keys=True,
                      separators=(",", ":")).encode("utf-8")
    if len(body) > MAX_FRAME:
        # OUR OWN OUTPUT IS BOUNDED TOO, and the replacement KEEPS THE
        # IDENTITY. A bounds fault that dropped the correlation would be the
        # uncorrelated shape arriving by the back door.
        body = json.dumps(
            {"protocol": document.get("protocol"),
             "session": document.get("session"),
             "operation_id": document.get("operation_id"),
             "ok": False, "code": "bounds",
             "message": "the answer exceeded the frame ceiling"},
            sort_keys=True, separators=(",", ":")).encode("utf-8")
    stream.write(str(len(body)).encode("ascii") + b"\n" + body)
    stream.flush()


def _bounded(value, what):
    if type(value) is not str or not value or len(value) > MAX_IDENTITY:
        raise Uncorrelated(f"{what} is bounded non-empty text")
    return value


def identity_of(request):
    """The request's own identity envelope, or nothing this program can answer.

    Read BEFORE anything else and read the same way whatever the request turns
    out to be, because a response correlates to a REQUEST: the three members
    echoed back are the ones the sender put on the frame, so even a refusal is
    matchable to the frame that caused it.

    A request that does not carry a readable envelope is `Uncorrelated`. There
    is no fault frame for it, and that is the ruling rather than an omission.
    """
    if "protocol" not in request or "session" not in request \
            or "operation_id" not in request:
        raise Uncorrelated("a request carries protocol, session and "
                           "operation_id")
    return {"protocol": _bounded(request["protocol"], "a protocol"),
            "session": _bounded(request["session"], "a session"),
            "operation_id": _bounded(request["operation_id"],
                                     "an operation id")}


def success(identity, answer):
    return {**identity, "ok": True, "answer": answer}


def failure(identity, fault):
    return {**identity, "ok": False, "code": fault.code,
            "message": fault.message}


def read_launch(place=LAUNCH_DOCUMENT):
    """The manager's launch document, from a descriptor that proves what it is.

    W26291. THE FOUR PROPERTIES HERE ARE NOT DECORATION, and each is a way a
    container can be handed something other than the document it was promised:

      NO-FOLLOW, so a link at the fixed path is refused rather than resolved.
      A link is how a path this contract fixed becomes a path something else
      chose, which is the exact defect `_read_without_following` was added to
      the manager for.
      NON-BLOCKING, so a FIFO at that name cannot stop this program inside
      `open` before the descriptor check below can run. W26283's re-review is
      the standing lesson: a guard placed after an operation that may not
      return is a guard that never runs.
      REGULAR, PROVED ON THE DESCRIPTOR rather than on the path, because the
      descriptor is the one thing a racing replacement cannot have changed.
      BOUNDED, at one byte past the ceiling. The document is written by the
      manager, but this program is what a mis-composed delivery lands on, and a
      reader with no bound is bounded by whoever writes the file.

    AND READ-ONLY FOR THIS CONTAINER'S OWN VIEW. The manager mounts the file
    read-only; this proves it rather than trusting it, because a launch
    document this worker could rewrite is one it could change between reading
    it and being asked what it is. The proof is an attempted write-open, which
    is the only thing that actually answers the question -- the mode bits
    describe the host file and say nothing about how it was mounted.

    That proof depends on this process not being root, and it is not: the
    recipe fixes the image user at 65532 and the adapter's `--user` restriction
    names the same id, which is one decision written in two places with a case
    holding them together. Root would satisfy a write-open on a read-only MODE
    and still be refused by a read-only MOUNT, so the check is conservative in
    the direction that matters either way.

    Every failure here is `Uncorrelated`: without this document there is no
    session, nothing this program said could be matched to a request, and the
    ruling hands that case to the Worker Manager, which already owns the
    launched operation.
    """
    try:
        descriptor = os.open(place,
                             os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    except OSError:
        raise Uncorrelated(f"this container has no readable {place}; the "
                           f"launch document is how a worker is told what it "
                           f"is") from None
    try:
        if not stat.S_ISREG(os.fstat(descriptor).st_mode):
            raise Uncorrelated(f"{place} is not a regular file")
        raw = os.read(descriptor, MAX_LAUNCH_BYTES + 1)
    finally:
        os.close(descriptor)
    if len(raw) > MAX_LAUNCH_BYTES:
        raise Uncorrelated(f"{place} is wider than {MAX_LAUNCH_BYTES} bytes")
    try:
        writable = os.open(place, os.O_WRONLY | os.O_NOFOLLOW)
    except OSError:
        pass
    else:
        os.close(writable)
        raise Uncorrelated(f"{place} is writable from inside this container; "
                           f"a launch document this worker could rewrite is "
                           f"not one the manager can hold it to")
    try:
        document = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, ValueError):
        raise Uncorrelated(f"{place} is not UTF-8 JSON") from None
    if type(document) is not dict:
        raise Uncorrelated(f"{place} is one JSON object")
    return document


def container_of(document):
    """The CONTAINER document inside one launch delivery, wrapper or not.

    W376586 review 2026-10-28T22-29-20Z, P1. `/5` moved every container member
    one level down, and `serve` reads the session from the delivery BEFORE
    validating it -- so every valid current file-exchange delivery lost its
    session and the container exited 2 as uncorrelated before the new
    validator or the exchange ran. The manager composed a document this
    program could not start under, which is the worst direction: a correct
    delivery looking like a broken one.

    THE RULE IS NARROW ON PURPOSE. The review is explicit that this must not
    become "accept arbitrary nested identity": the ONLY thing admitted here is
    an outer document that DECLARES this wrapper and carries an object
    payload. Everything else about the wrapper -- its member set, its profile,
    a nested wrapper, the payload's own generation -- stays `launched`'s, which
    runs next and reports a CORRELATED fault. This function decides one thing:
    which document the session is read from.

    A NESTED WRAPPER HAS NO CONTAINER SESSION, and exits 2 rather than
    answering a fault. That is `session_of`'s own rule applied honestly: the
    inner document carries no session, so there is no identity to correlate an
    answer to, and the manager settles the start it already owns.
    """
    if type(document) is not dict:
        return document
    if document.get("schema") != WRAPPER_LAUNCH_SCHEMA:
        return document
    payload = document.get("payload")
    return payload if type(payload) is dict else {}


def session_of(document):
    """The identity the manager minted for THIS container session.

    Read BEFORE the rest of the document is validated, and deliberately: it is
    what every answer correlates to, so a document that carries a usable
    session and is wrong in some OTHER way can still be reported through the
    ordinary fault frame. Without it nothing this program says can be
    correlated to anything, so its absence is not a fault frame -- it is the
    case the ruling hands to the Worker Manager, which already owns the
    launched session and settles it as `worker_start_failed` from the
    container-engine result.
    """
    given = document.get("session")
    if type(given) is not str or not given or len(given) > MAX_IDENTITY:
        raise Uncorrelated("a worker session identity is bounded non-empty "
                           "text and arrives in the launch document")
    return given


def _job_execution(document, place):
    """`/3`'s Job context, held at the boundary the container reads it.

    W156162. THE WORKER IS THE UNTRUSTED SIDE and this is a manager-authored
    file it is handed; the manager proves the same things before it writes, and
    this proves them again because a container that trusts a delivery it cannot
    check is a container that will run a command for however long somebody put
    in a file.

    WHAT IS CHECKED HERE: the closed member set, the seal over the configuration
    -- recomputed, not compared to itself -- and that every effective ceiling is
    a whole number of seconds in a range this program will actually hand to a
    command. `True` is refused before the numeric tests, because it is an `int`
    in Python and would otherwise become a one-second bound nobody wrote.

    WHAT IS NOT RE-DERIVED HERE: which Job resolved to which numbers. That is
    the Job owner's answer and this program has no Job store; what it can do is
    refuse a document whose seal does not cover its own contents.
    """
    held = document.get("job_execution")
    if type(held) is not dict:
        raise WorkerFault(
            "launch", f"{place} carries a job execution that is not a document")
    missing = sorted(one for one in JOB_EXECUTION_MEMBERS if one not in held)
    extra = sorted(one for one in held if one not in JOB_EXECUTION_MEMBERS)
    if missing or extra:
        raise WorkerFault(
            "launch",
            f"{place}'s job execution is exactly "
            f"{', '.join(JOB_EXECUTION_MEMBERS)}"
            + (f"; missing {', '.join(missing)}" if missing else "")
            + (f"; unexpected {', '.join(extra)}" if extra else ""))
    limits = held["execution_limits"]
    if type(limits) is not dict:
        raise WorkerFault(
            "launch",
            f"{place}'s execution limits are not a document")
    sealed = "sha256:" + hashlib.sha256(
        json.dumps(limits, sort_keys=True, separators=(",", ":"),
                   ensure_ascii=False, allow_nan=False)
        .encode("utf-8")).hexdigest()
    if held["execution_limits_digest"] != sealed:
        raise WorkerFault(
            "launch",
            f"{place}'s execution limits do not match their own seal; a bound "
            f"this container cannot verify is a bound nobody agreed to")
    missing = sorted(one for one in LAUNCH_LIMIT_MEMBERS if one not in limits)
    extra = sorted(one for one in limits if one not in LAUNCH_LIMIT_MEMBERS)
    if missing or extra:
        raise WorkerFault(
            "launch",
            f"{place}'s execution limits are exactly "
            f"{', '.join(LAUNCH_LIMIT_MEMBERS)}"
            + (f"; missing {', '.join(missing)}" if missing else "")
            + (f"; unexpected {', '.join(extra)}" if extra else ""))
    # THE UNITS AND THE SCOPE ARE COMPARED, NOT CARRIED. [P2]: a resealed
    # document stating `minutes` was accepted, and a container that reads
    # somebody else's units hands a command sixty times the bound they wrote.
    if limits["units"] != LAUNCH_UNITS or limits["scope"] != LAUNCH_SCOPE:
        raise WorkerFault(
            "launch",
            f"{place}'s execution limits are {limits['units']!r} at "
            f"{limits['scope']!r} and this worker hands a command "
            f"{LAUNCH_UNITS!r} {LAUNCH_SCOPE!r}")
    generation = limits["compatibility_generation"]
    if type(generation) is not int or type(generation) is bool \
            or generation < 0:
        raise WorkerFault(
            "launch",
            f"{place} names compatibility generation {generation!r}, which is "
            f"not one")
    requested = limits["requested"]
    if type(requested) is not dict:
        raise WorkerFault(
            "launch", f"{place}'s requested settings are not a document")
    unknown = sorted(one for one in requested if one not in LAUNCH_SETTINGS)
    if unknown:
        raise WorkerFault(
            "launch",
            f"{place} requests {', '.join(unknown)}, which this worker does "
            f"not name; a setting nobody here reads is one nobody here honours")
    for name, value in sorted(requested.items()):
        if type(value) is not int or type(value) is bool \
                or value < MIN_LAUNCH_SECONDS or value > MAX_LAUNCH_SECONDS:
            raise WorkerFault(
                "launch",
                f"{place} requests {name} {value!r}; a requested setting is a "
                f"whole number of seconds between {MIN_LAUNCH_SECONDS} and "
                f"{MAX_LAUNCH_SECONDS}")
    boundaries = limits["boundaries"]
    if type(boundaries) is not dict:
        raise WorkerFault(
            "launch", f"{place}'s execution limits name no boundaries")
    # THE COMPLETE SET, [P1]. A missing boundary is not a boundary this
    # container may quietly give its own default to.
    missing = sorted(one for one in LAUNCH_BOUNDARIES
                     if one not in boundaries)
    extra = sorted(one for one in boundaries if one not in LAUNCH_BOUNDARIES)
    if missing or extra:
        raise WorkerFault(
            "launch",
            f"{place}'s execution limits name exactly "
            f"{', '.join(LAUNCH_BOUNDARIES)}"
            + (f"; missing {', '.join(missing)}" if missing else "")
            + (f"; unexpected {', '.join(extra)}" if extra else ""))
    for name in LAUNCH_BOUNDARIES:
        one = boundaries[name]
        if type(one) is not dict:
            raise WorkerFault(
                "launch", f"{place}'s {name} bound is not a document")
        missing = sorted(other for other in LAUNCH_BOUNDARY_MEMBERS
                         if other not in one)
        extra = sorted(other for other in one
                       if other not in LAUNCH_BOUNDARY_MEMBERS)
        if missing or extra:
            raise WorkerFault(
                "launch",
                f"{place}'s {name} bound is exactly "
                f"{', '.join(LAUNCH_BOUNDARY_MEMBERS)}"
                + (f"; missing {', '.join(missing)}" if missing else "")
                + (f"; unexpected {', '.join(extra)}" if extra else ""))
        for member in ("seconds", "default_seconds"):
            value = one[member]
            if type(value) is not int or type(value) is bool \
                    or value < MIN_LAUNCH_SECONDS \
                    or value > MAX_LAUNCH_SECONDS:
                raise WorkerFault(
                    "launch",
                    f"{place}'s {name} {member} is {value!r}; this worker "
                    f"hands a command a whole number of seconds between "
                    f"{MIN_LAUNCH_SECONDS} and {MAX_LAUNCH_SECONDS}")
        # THE ORIGIN AND THE SETTING ARE REPORTED, so they are held too: a
        # bound whose origin this program cannot name is one it cannot explain
        # to whoever reads a failure it caused.
        if one["origin"] not in LAUNCH_ORIGINS:
            raise WorkerFault(
                "launch",
                f"{place}'s {name} origin is {one['origin']!r} and this "
                f"worker names {', '.join(LAUNCH_ORIGINS)}")
        setting = LAUNCH_BOUNDARY_SETTING[name]
        if one["setting"] != setting:
            raise WorkerFault(
                "launch",
                f"{place}'s {name} names setting {one['setting']!r} and this "
                f"boundary answers to {setting!r}; which setting moves a "
                f"boundary is not something a delivery gets to say")
        # AND THE THREE ANSWERS MUST AGREE WITH EACH OTHER. A boundary whose
        # setting the Job REQUESTED is the Job's, at the requested number; one
        # it did not request is the preserved default, at the default number.
        # Anything else is a document contradicting itself -- `seconds: 30`
        # beside a requested 60, or `compatibility` beside an explicit request --
        # and this is checked from the document's OWN members rather than by
        # re-resolving anything, because this container has no Job store and the
        # current defaults are not the ones this Job was admitted under.
        if setting in requested:
            expected, origin = requested[setting], "job"
        else:
            expected, origin = one["default_seconds"], "compatibility"
        if one["seconds"] != expected or one["origin"] != origin:
            raise WorkerFault(
                "launch",
                f"{place}'s {name} reports {one['seconds']!r} from "
                f"{one['origin']!r} and its own requested settings make that "
                f"{expected!r} from {origin!r}; a configuration that "
                f"contradicts itself is not one this container can act on")
    # AND THE IDENTITIES ARE BOUNDED TEXT. [P2]: `job_id=False` was accepted,
    # and an identity that is not one names nothing.
    for name in ("job_id", "attempt_id", "job_input_digest",
                 "job_policy_digest", "runtime_input_digest",
                 "runtime_policy_digest", "execution_limits_digest"):
        value = held[name]
        if type(value) is not str or not value \
                or len(value) > MAX_LAUNCH_VALUE:
            raise WorkerFault(
                "launch",
                f"{place}'s job execution carries a {name} that is not "
                f"bounded non-empty text")
    return held


def _unwrapped(document, place):
    """One `/5` wrapper opened, or a refusal. ANSWERS THE PAYLOAD.

    W376586. THE WRAPPER IS VALIDATED BEFORE THE PAYLOAD IS LOOKED AT, in the
    order every other document here is under: the kind first, then the shape,
    then the contents. A reader that went for the payload first would be
    deciding what a document means before establishing what it is.

    NO NESTED WRAPPER AND NO ARBITRARY PROFILE, both by the amendment and both
    by equality: `wire_profile` must be the one profile this build speaks, and
    the payload must name one of the four CONTAINER generations -- `/5` is
    deliberately not among them, so a wrapper inside a wrapper is refused by a
    membership test rather than by counting depth.

    AND THE PAYLOAD MUST SELECT THE FILE EXCHANGE. The wrapper exists to say
    which wire a file-exchange container is on; wrapped around a framed or
    one-shot launch it would describe a wire nobody is on, which is the
    silent-downgrade direction in reverse.
    """
    missing = sorted(one for one in WRAPPER_LAUNCH_MEMBERS
                     if one not in document)
    extra = sorted(one for one in document
                   if one not in WRAPPER_LAUNCH_MEMBERS)
    if missing or extra:
        raise WorkerFault(
            "launch",
            f"{place} is exactly {', '.join(WRAPPER_LAUNCH_MEMBERS)}"
            + (f"; missing {', '.join(missing)}" if missing else "")
            + (f"; unexpected {', '.join(extra)}" if extra else ""))
    if document["wire_profile"] != WIRE_PROFILE:
        raise WorkerFault(
            "launch",
            f"{place} names wire profile {document['wire_profile']!r} and "
            f"this worker speaks {WIRE_PROFILE!r}; a profile this program "
            f"cannot name is a wire it cannot speak, and there is no "
            f"negotiation")
    payload = document["payload"]
    if type(payload) is not dict:
        raise WorkerFault(
            "launch", f"{place} carries a payload that is not one document")
    inside = payload.get("schema")
    if inside == WRAPPER_LAUNCH_SCHEMA:
        raise WorkerFault(
            "launch",
            f"{place} carries a {WRAPPER_LAUNCH_SCHEMA!r} inside a "
            f"{WRAPPER_LAUNCH_SCHEMA!r}; this wrapper takes one container "
            f"launch and never another wrapper")
    if inside not in SUPPORTED_LAUNCH_SCHEMAS:
        raise WorkerFault(
            "launch",
            f"{place} carries a payload saying it is {inside!r} and this "
            f"worker reads "
            f"{', '.join(repr(one) for one in SUPPORTED_LAUNCH_SCHEMAS)}")
    if payload.get("transport") != EXCHANGE_TRANSPORT:
        raise WorkerFault(
            "launch",
            f"{place} wraps a launch selecting transport "
            f"{payload.get('transport')!r}; the "
            f"{WIRE_PROFILE!r} wrapper carries a {EXCHANGE_TRANSPORT!r} "
            f"launch, and wrapping one that selects no file exchange would "
            f"describe a wire nothing is on")
    return payload


def launched(document, place=LAUNCH_DOCUMENT):
    """The launch document held to its own closed contract.

    A CLOSED SET, not an allowlist. Every required member present, NOTHING
    else, the pinned schema, and every value bounded non-empty text -- an extra
    top-level member is how a second contract alias would arrive, and this
    campaign has rejected those explicitly before.

    THE SCHEMA IS CHECKED BY EQUALITY. A version this program does not know is
    not a document to read the parts it recognises out of: a manager and a
    worker from two generations disagreeing silently is precisely what the
    versioned document replaced.

    Answers the VALIDATED DOCUMENT, all four members of it.

    Re-review [P1]: this stripped `schema` and answered three, on the argument
    that the version is this program's business. That is a plausible proposal
    and it is not the recorded decision: the pinned finding says `describe`'s
    `launch` is "the sorted member names of the validated launch document", and
    that document has exactly four. Reporting three made the implementation
    disagree with the ruling it was implementing, so the ruling wins — an
    operator reading `describe` now sees which generation the container was
    launched under, which is a fact worth having anyway.
    """
    # W81857: THE SCHEMA DECIDES THE MEMBER SET, which is what makes the two
    # versions two contracts rather than one contract with an optional member.
    # A reader that accepted the union would accept a `/1` document carrying a
    # transport and a `/2` document carrying none, and each of those is a
    # manager and a worker disagreeing silently about which channel is
    # authoritative.
    # W376586: THE WIRE IS OPENED FIRST, AND WHETHER IT WAS THERE IS REMEMBERED.
    # The payload is then held to exactly the rules it was held to before, so
    # every reader downstream of `launched` sees the same four-to-six member
    # container document it always saw.
    wrapped = document.get("schema") == WRAPPER_LAUNCH_SCHEMA \
        if type(document) is dict else False
    if wrapped:
        document = _unwrapped(document, place)
    given = document.get("schema")
    # W197661: AND THE VERSION IS DIAGNOSED FIRST, which is what the comment
    # here always claimed and the code never did. An unknown schema was held
    # to `/1`'s member set and the member comparison ran BEFORE this check, so
    # a `/3` document from a newer manager was refused by listing `/1`'s four
    # members and calling its own job execution and transport "unexpected" --
    # a sentence that reads like a corrupt file rather than a worker from
    # another generation. That is exactly the report this Work opened on.
    #
    # THE LIST IS EVERY VERSION THIS FILE READS. It named three while the
    # reader below accepts four, so the one sentence an operator gets for a
    # cross-generation launch was also incomplete about this worker's own
    # range.
    if given not in SUPPORTED_LAUNCH_SCHEMAS:
        raise WorkerFault(
            "launch",
            f"{place} says it is {given!r} and this worker reads "
            f"{', '.join(repr(one) for one in SUPPORTED_LAUNCH_SCHEMAS)}; a "
            f"launch document from another generation is not one to read the "
            f"recognised parts out of")
    members = (CONTEXT_LAUNCH_MEMBERS if given == CONTEXT_LAUNCH_SCHEMA else JOB_LAUNCH_MEMBERS if given in (JOB_LAUNCH_SCHEMA, CONTEXT_LAUNCH_SCHEMA)
               else EXCHANGE_LAUNCH_MEMBERS
               if given == EXCHANGE_LAUNCH_SCHEMA else LAUNCH_MEMBERS)
    missing = sorted(name for name in members if name not in document)
    extra = sorted(name for name in document if name not in members)
    if missing or extra:
        raise WorkerFault(
            "launch",
            f"{place} is exactly {', '.join(members)}"
            + (f"; missing {', '.join(missing)}" if missing else "")
            + (f"; unexpected {', '.join(extra)}" if extra else ""))
    # W156162 [P2]: `/3`'S TRANSPORT IS EXCHANGE OR NULL, AND NOTHING ELSE.
    # It was unchecked, so `transport='unknown/channel'` was accepted and
    # `main` then treated it as a one-shot launch -- a container told to speak
    # something nothing is listening to, deciding for itself that it had been
    # told nothing.
    if given in (JOB_LAUNCH_SCHEMA, CONTEXT_LAUNCH_SCHEMA) \
            and document.get("transport") not in (None, EXCHANGE_TRANSPORT):
        raise WorkerFault(
            "launch",
            f"{place} selects transport {document.get('transport')!r} and "
            f"this worker speaks {EXCHANGE_TRANSPORT!r} or none; a transport "
            f"this program cannot name is a channel nothing is listening to")
    if given == EXCHANGE_LAUNCH_SCHEMA \
            and document.get("transport") != EXCHANGE_TRANSPORT:
        raise WorkerFault(
            "launch",
            f"{place} selects transport {document.get('transport')!r} and "
            f"this worker speaks {EXCHANGE_TRANSPORT!r}; a transport this "
            f"program cannot name is a channel nothing is listening to")
    # W376586: AN UNWRAPPED FILE-EXCHANGE LAUNCH IS REFUSED, and this is the
    # half that makes the wrapper a release rather than an option. It is asked
    # once the transport has been validated above, so the answer is about a
    # transport this program has established rather than about a member it
    # happened to read -- and it is asked BEFORE `_job_execution`, the context
    # delivery, the adapter, the receipt and any provider.
    #
    # `/1` AND A NULL-TRANSPORT `/3`/`/4` ARE UNTOUCHED. The framed transport
    # is outside this feature, so a launch that selects no file exchange is
    # read exactly as it was.
    if not wrapped and document.get("transport") == EXCHANGE_TRANSPORT:
        raise WorkerFault(
            "launch",
            f"{place} selects {EXCHANGE_TRANSPORT!r} without the "
            f"{WRAPPER_LAUNCH_SCHEMA!r} wrapper; this release speaks the file "
            f"exchange through {WIRE_PROFILE!r} and an unwrapped file-exchange "
            f"launch is not one this worker executes")
    if given in (JOB_LAUNCH_SCHEMA, CONTEXT_LAUNCH_SCHEMA):
        _job_execution(document, place)
    if given == CONTEXT_LAUNCH_SCHEMA:
        context_delivery(document)
    for name in members:
        # THE TWO MEMBERS THAT ARE NOT BOUNDED TEXT. `/3`'s transport is
        # deliberately null for a one-shot launch and its job execution is a
        # document; both are proved above by their own rules, so holding them
        # to the text bound here would refuse the shapes this version exists
        # to carry.
        if given in (JOB_LAUNCH_SCHEMA, CONTEXT_LAUNCH_SCHEMA) and name in ("transport",
                                                   "job_execution", "provider_context"):
            continue
        value = document[name]
        if type(value) is not str or not value:
            raise WorkerFault(
                "launch",
                f"{place} carries a {name} that is not bounded non-empty text")
        if len(value) > MAX_LAUNCH_VALUE:
            raise WorkerFault(
                "launch",
                f"{place} carries a {name} wider than {MAX_LAUNCH_VALUE} "
                f"characters")
    return {name: document[name] for name in members}


def canonical(value):
    """RFC 8785-equivalent bytes for the documents this worker writes.

    Member names here are ASCII, so sorting them lexically is the UTF-16 order
    the frozen contract requires; `ensure_ascii=False` and no whitespace are
    the other two halves. A digest two readers compute differently is not an
    identity, and the manager recomputes this one.
    """
    return json.dumps(value, ensure_ascii=False, sort_keys=True,
                      separators=(",", ":")).encode("utf-8")


def digest(value):
    return "sha256:" + hashlib.sha256(canonical(value)).hexdigest()


def _frozen_contract():
    """The shipped `worker-control-1.0` document, read once per call.

    A schema this program cannot read is an operational fault rather than a
    reason to validate less: without it there is no closed set and no path
    grammar, and a worker that carried on would be back to the shallow
    extraction W19784's review replaced.
    """
    try:
        with open(CONTRACT_SCHEMA, "rb") as reading:
            return json.loads(reading.read().decode("utf-8"))
    except (OSError, UnicodeDecodeError, ValueError):
        raise WorkerFault(
            "input",
            f"this image carries no readable {CONTRACT_SCHEMA}; without the "
            f"frozen contract there is no closed member set to hold a "
            f"manager document to")


def _plain(frozen, named):
    """The closed member set and required set of a NON-composed definition.

    `outputDescriptor` and `outputConstraints` are plain objects with
    `additionalProperties: false` rather than the `allOf` composition the
    manifests use, so they are read directly.
    """
    definition = frozen["$defs"][named]
    return set(definition.get("properties", ())), set(
        definition.get("required", ()))


def _resolved(frozen, rule):
    """One property rule with its `$ref` followed, if it has one."""
    while "$ref" in rule:
        rule = frozen["$defs"][rule["$ref"].rsplit("/", 1)[-1]]
    return rule


def _held(frozen, rule, value, what):
    """One value, against the frozen rule that describes it.

    W6633 twelfth review [P1]: deriving the member NAMES and then checking two
    integers was mistaken for validation. `name` and `type` are used for
    lookup and for authoring the completion envelope, `required` decides
    control flow, and a ceiling above the frozen maximum weakens the resource
    bound the schema pins -- so every one of them was consumed unvalidated.

    THIS IS NOT A JSON SCHEMA ENGINE AND MUST NOT BECOME ONE. It is the closed,
    bounded keyword set that `outputDescriptor` and `outputConstraints`
    actually use, and nothing else: an unrecognised keyword is a FAULT rather
    than a value this function passes over, because silently skipping one is
    how a derived check becomes a paraphrase again. If a later version of those
    two definitions uses a keyword this does not implement, the worker refuses
    and says so instead of validating less than it claims.
    """
    rule = _resolved(frozen, rule)
    if "oneOf" in rule:
        for branch in rule["oneOf"]:
            try:
                return _held(frozen, branch, value, what)
            except WorkerFault:
                continue
        raise WorkerFault("input", f"{what} matches none of its frozen forms")
    for keyword, expected in rule.items():
        if keyword in ("description", "title"):
            continue
        if keyword == "const":
            if value != expected:
                raise WorkerFault(
                    "input", f"{what} is {value!r} and the contract pins "
                             f"{expected!r}")
        elif keyword == "type":
            if not _is_type(value, expected):
                raise WorkerFault(
                    "input", f"{what} is not the frozen {expected}")
        elif keyword == "pattern":
            if not re.match(expected, value):
                raise WorkerFault(
                    "input", f"{what} does not match its frozen grammar")
        elif keyword == "minLength":
            if len(value) < expected:
                raise WorkerFault("input", f"{what} is shorter than {expected}")
        elif keyword == "maxLength":
            if len(value) > expected:
                raise WorkerFault("input", f"{what} is longer than {expected}")
        elif keyword == "minimum":
            if value < expected:
                raise WorkerFault("input", f"{what} is below {expected}")
        elif keyword == "maximum":
            if value > expected:
                raise WorkerFault("input", f"{what} is above {expected}")
        elif keyword == "uniqueItems":
            if expected and len(set(map(repr, value))) != len(value):
                raise WorkerFault("input", f"{what} repeats an entry")
        elif keyword == "items":
            for entry in value:
                _held(frozen, expected, entry, f"an entry of {what}")
        else:
            raise WorkerFault(
                "input",
                f"the frozen rule for {what} uses {keyword!r}, which this "
                f"worker does not implement; it refuses rather than validate "
                f"less than it says it does")
    return value


def _is_type(value, expected):
    """JSON's own types, and BOOLEANS ARE NOT INTEGERS.

    `isinstance(True, int)` is true in Python and false in JSON, and a
    `required` flag arriving where a ceiling belongs would otherwise pass a
    `minimum: 0` check as the number one.
    """
    if expected == "string":
        return type(value) is str
    if expected == "integer":
        return type(value) is int
    if expected == "boolean":
        return type(value) is bool
    if expected == "array":
        return type(value) is list
    if expected == "object":
        return type(value) is dict
    if expected == "null":
        return value is None
    raise WorkerFault(
        "input", f"the frozen rule names the type {expected!r}, which this "
                 f"worker does not implement")


def _definition(named):
    """The closed member set and the required set of one frozen definition.

    DERIVED FROM THE SHIPPED SCHEMA, never typed here. A definition in this
    contract is `allOf: [manifestHeader, {...}]` with
    `unevaluatedProperties: false`, so its closed set is the union of the two
    property maps and nothing else may appear beside them.

    A schema this program cannot read is an operational fault rather than a
    reason to validate less: without it there is no closed set, and a worker
    that carried on would be back to the shallow extraction this replaced.
    """
    frozen = _frozen_contract()
    definition = frozen["$defs"][named]
    closed, required, names = set(), set(), None
    for part in definition["allOf"]:
        if "$ref" in part:
            part = frozen["$defs"][part["$ref"].rsplit("/", 1)[-1]]
        properties = part.get("properties", {})
        closed |= set(properties)
        required |= set(part.get("required", ()))
        # WHICH DOCUMENT THIS IS, taken from the contract rather than from a
        # constant. Without it the closed set alone would accept the two
        # `/input/` documents SWAPPED: they share the header, and a delivery
        # that put the assignment manifest at `input.json` would fail later,
        # somewhere less clear, or not at all.
        if "schema" in properties and "const" in properties["schema"]:
            names = properties["schema"]["const"]
    return closed, required, names


def _closed_manifest(place, document, named):
    """One manager-authored document, held to its own frozen definition.

    THREE QUESTIONS, and each is a different way a delivery is wrong:

      EVERY REQUIRED MEMBER IS PRESENT -- a document short a member is one
      this worker would have to guess the rest of;
      NOTHING ELSE IS -- `unevaluatedProperties: false` is the contract's own
      word, and an extra top-level member is how a second identity alias would
      arrive. W19784's ruling rejected compatibility aliases explicitly, so
      one appearing in a delivered document is refused rather than ignored;
      THE BYTES ARE THE ONES THE DIGEST DESCRIBES -- recomputed over this
      document's own canonical form with the digest member removed, which is
      how the frozen contract defines it. Comparing the two documents' digest
      STRINGS with each other, as this used to, proves they were minted
      together and says nothing about whether either still is what it was.
    """
    closed, required, names = _definition(named)
    missing = sorted(required - set(document))
    extra = sorted(set(document) - closed)
    if missing or extra:
        raise WorkerFault(
            "input",
            f"{place} is not a closed {named}"
            + (f"; missing {', '.join(missing)}" if missing else "")
            + (f"; unexpected {', '.join(extra)}" if extra else ""))
    if document["schema"] != names:
        raise WorkerFault(
            "input",
            f"{place} says it is {document['schema']} and this delivery reads "
            f"it as {names}; the two documents in this root are not "
            f"interchangeable")
    body = {name: value for name, value in document.items()
            if name != "manifest_digest"}
    if document["manifest_digest"] != digest(body):
        raise WorkerFault(
            "input",
            f"{place} does not identify itself; its manifest_digest describes "
            f"other bytes than the ones this worker read")
    return document


def _document(name, named):
    """One manager-authored document out of `/input/`, read once and bounded.

    W19784 review [P0]: this used to say the worker does not validate the
    manager's documents, and that was the defect. The manager DOES own the
    full boundary, and a worker that took a document on that basis had no way
    to tell a correctly delivered one from an edited or mis-composed one --
    which is precisely what a two-root delivery can get wrong.
    """
    place = os.path.join(INPUT_ROOT, name)
    try:
        with open(place, "rb") as reading:
            raw = reading.read(MAX_INPUT_BYTES + 1)
    except OSError:
        raise WorkerFault(
            "input",
            f"this assignment has no readable {place}; it is one of the two "
            f"documents a worker is told what it was asked for by")
    if len(raw) > MAX_INPUT_BYTES:
        raise WorkerFault(
            "input",
            f"{place} is wider than {MAX_INPUT_BYTES} bytes")
    try:
        document = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, ValueError):
        raise WorkerFault("input", f"{place} is not a readable document")
    if type(document) is not dict:
        raise WorkerFault("input", f"{place} is one JSON object")
    return place, _closed_manifest(place, document, named)


def input_manifest():
    """The manager's `/input/input.json`: what this assignment declared.

    IT NO LONGER NAMES THE ASSIGNMENT, and it never legitimately could.
    W19784: this used to read `assignment_ref` from here, which made the whole
    worker depend on a member the frozen `inputManifest` schema forbids -- the
    document is minted before any claim exists. The identity now comes from
    `assignment_manifest()` and the schema and this reader finally agree.
    """
    place, document = _document(INPUT_MANIFEST, "inputManifest")
    declared = document["outputs"]
    if type(declared) is not list or not declared:
        raise WorkerFault(
            "input", f"{place} declares at least one output")
    return document, _declarations(place, declared)


def _declarations(place, declared):
    """Every declared output, proved BEFORE an agent is dispatched.

    W6633 eleventh review [P1], and the order is the whole content. This used
    to check that four member names were present and then hand the
    declarations straight to the agent, which wrote under
    `os.path.join(OUTPUT_ROOT, path)`. A declaration spelling `../tmp/escaped`
    therefore had the agent writing OUTSIDE the output root -- into the
    writable private ephemeral space, where the read-only input mount does not
    contain it -- and this worker then measured that escaped tree, published a
    completion envelope describing it, and answered success.

    Everything below runs before `agent.work`, so a declaration this worker
    cannot honour never becomes bytes anywhere.

    THE RULES ARE THE CONTRACT'S OWN, not a paraphrase of them: the closed
    descriptor and constraint member sets and the `relativePath` grammar are
    read out of the shipped schema.
    """
    frozen = _frozen_contract()
    descriptor = frozen["$defs"][DECLARATION_DEFINITION]
    constraint = frozen["$defs"][CONSTRAINT_DEFINITION]
    closed, required = _plain(frozen, DECLARATION_DEFINITION)
    limits, limited = _plain(frozen, CONSTRAINT_DEFINITION)
    root = os.path.realpath(OUTPUT_ROOT)
    seen, taken = set(), []
    for one in declared:
        if type(one) is not dict or set(one) != closed | required:
            raise WorkerFault(
                "input",
                f"a declared output in {place} is exactly "
                f"{', '.join(sorted(closed | required))}")
        constraints = one["constraints"]
        if type(constraints) is not dict \
                or set(constraints) != limits | limited:
            raise WorkerFault(
                "input",
                f"a declared output in {place} declares constraints that are "
                f"exactly {', '.join(sorted(limits | limited))}")
        # EVERY VALUE, against the frozen rule that describes it. The member
        # set alone said only that the right NAMES were present -- W6633's
        # twelfth review, and the same shape of mistake as proving two
        # documents agree with each other and calling it authorization.
        for member, rule in descriptor["properties"].items():
            if member == "constraints":
                continue
            _held(frozen, rule, one[member],
                  f"a declared output's {member}")
        for member, rule in constraint["properties"].items():
            _held(frozen, rule, constraints[member],
                  f"output {one['name']!r}'s {member}")
        _limits(one["name"], constraints)
        path = one["path"]
        # AND THEN CONTAINMENT, resolved. The grammar refuses the spellings;
        # this refuses a path that resolves out of the root anyway, which is
        # what a symlinked component would do.
        landing = os.path.realpath(os.path.join(root, path))
        if landing != root and not landing.startswith(root + os.sep):
            raise WorkerFault(
                "input",
                f"output {one['name']!r} resolves outside {OUTPUT_ROOT}")
        if path == OUTPUT_MANIFEST or path.startswith(OUTPUT_MANIFEST + "/"):
            raise WorkerFault(
                "input",
                f"output {one['name']!r} is declared at "
                f"{OUTPUT_MANIFEST!r}, which is this root's protocol manifest")
        if one["name"] in seen:
            raise WorkerFault(
                "input", f"output {one['name']!r} is declared twice")
        seen.add(one["name"])
        for before in taken:
            if landing == before[1] \
                    or landing.startswith(before[1] + os.sep) \
                    or before[1].startswith(landing + os.sep):
                # §7.2: the same bytes under two names are two artifacts with
                # two identities, and retention would decide twice about
                # material that is once.
                raise WorkerFault(
                    "input",
                    f"outputs {before[0]!r} and {one['name']!r} name the same "
                    f"tree or one inside the other")
        taken.append((one["name"], landing))
    return declared


def _limits(name, constraints):
    """What the frozen VALUE rules cannot say, plus the account of each member.

    `_held` above proves every member against the contract -- types, patterns,
    lengths, the `link_policy` const and the schema's own maxima on both
    ceilings. What is left here is the one decision the schema does not make.

    ENFORCED WHILE MEASURING: `max_bytes` and `max_entries`.

    `link_policy` is `const: "forbid"` in 1.0 and is enforced BY CONSTRUCTION
    rather than by comparison -- `measured` admits regular files only, so a
    link is refused whatever the policy said. A comparison against a one-value
    const could never fail, and writing one would be a guard no removal can
    measure.

    `allowed_media_types` is CARRIED AND NOT ENFORCED HERE, deliberately. A
    frozen `contentManifest` entry is a path, a byte count and a digest -- this
    worker has no media type for anything it measures. The value is enforced
    where a media type exists, on the collected artifact in the manager's
    `output.py`. Saying so is the difference between a split boundary and a
    dropped rule.

    `validator_digest` REFUSES the assignment when it is not null, and that is
    fail-closed rather than unimplemented. §7.2 makes `type` opaque and says
    the manager never branches on it; a worker that ran a type-specific
    validator would be branching on exactly that. Nothing else in 1.0 runs it
    either, so accepting a declaration that states one would be publishing a
    result while ignoring a constraint the manager wrote down.
    """
    if constraints["validator_digest"] is not None:
        raise WorkerFault(
            "input",
            f"output {name!r} declares a type-specific validator digest and "
            f"this worker runs none; a result published while ignoring a "
            f"stated constraint would be a result nobody checked")


def assignment_manifest():
    """The manager's `/input/assignment.json`: WHO this assignment is.

    W19784, approved 2026-08-26. This is the only source of the participant and
    authority generation inside the container, and the value it returns is
    copied into the completion envelope unchanged. So what it refuses is a
    document that could not be copied from: an `assignment_ref` that is not
    exactly the frozen three members is either short of the generation the
    envelope requires or carrying something this worker would be inventing.
    """
    place, document = _document(ASSIGNMENT_MANIFEST, "assignmentManifest")
    assignment = document["assignment_ref"]
    if type(assignment) is not dict \
            or sorted(assignment) != sorted(ASSIGNMENT_REF_MEMBERS):
        raise WorkerFault(
            "input",
            f"{place} names an assignment by exactly "
            f"{', '.join(ASSIGNMENT_REF_MEMBERS)}; the completion envelope "
            f"carries this value unchanged")
    return document


def one_delivery(given, delivered):
    """The two `/input/` documents, held against each other before dispatch.

    §12 rule 16. Each document is separately readable and separately
    plausible, and that says nothing about whether they are ABOUT ONE THING. A
    container composed from one delivery's input and another's assignment
    would run the agent against the wrong material and then publish an
    envelope naming the wrong Work -- and every single-document check above
    would have passed.

    The manager performs the same comparison before it mounts the root. This is
    not redundancy: the worker is the party that COPIES the identity into a
    durable document, and a party that copies an identity proves the identity
    belongs to the material it is describing. It also runs before the agent, so
    a mis-composed container writes nothing at all.

    THE GENERATION IS NOT COMPARED and cannot be: `input.json` has none. That
    asymmetry is the whole reason this Work exists, and the assignment side is
    the sole source.
    """
    assignment = delivered["assignment_ref"]
    if assignment["work_ref"] != given.get("work_ref"):
        raise WorkerFault(
            "input",
            f"{INPUT_ROOT}/{ASSIGNMENT_MANIFEST} names another Work than "
            f"{INPUT_ROOT}/{INPUT_MANIFEST} declares")
    if delivered["input_manifest_digest"] != given.get("manifest_digest"):
        raise WorkerFault(
            "input",
            f"{INPUT_ROOT}/{ASSIGNMENT_MANIFEST} was minted against another "
            f"input manifest than the one beside it; the pair in one root is "
            f"one pair or it is two halves of two deliveries")
    for name in ("policy_digest", "runtime_profile_digest"):
        if delivered[name] != given.get(name):
            raise WorkerFault(
                "input",
                f"the two documents in {INPUT_ROOT}/ declare different "
                f"{name} values; one delivery carries one identity")
    return assignment


def measured(place, constraints):
    """One declared output tree, as the frozen `contentManifest`.

    THE WORKER MEASURES AND THE AGENT DOES NOT. A content manifest is a claim
    about bytes, and the agent is the least trusted thing inside this
    container -- so it says WHICH outputs it produced and this says what is in
    them. Sorted bytewise, aggregates computed rather than declared, and the
    tree digest over the canonical ordered entry array, which is §3.3's own
    rule and what makes two manifests over one tree the same manifest.
    """
    # W6633 eleventh review [P1]: THE CEILINGS ARE ENFORCED WHILE MEASURING,
    # not afterwards. A declaration's limits are the manager's statement about
    # what this assignment may produce, and a worker that measured a whole
    # oversized tree and then compared totals would already have read it all
    # into this process -- so the refusal arrives as the bound is crossed,
    # before the next file is accumulated and long before anything is
    # published.
    ceiling_entries = constraints["max_entries"]
    ceiling_bytes = constraints["max_bytes"]
    entries, total = [], 0
    for base, directories, files in os.walk(place):
        # EVERY ENTRY THE TRAVERSAL MEETS, not only the ones in `files`.
        #
        # W6633 twelfth review [P1]: this walked `files` alone, and
        # `os.walk(..., followlinks=False)` puts a symlink TO A DIRECTORY in
        # `directories` -- where it was then skipped in silence. So a declared
        # tree containing `linked-directory -> /output` measured as empty, the
        # worker answered success, and the completion manifest claimed a tree
        # with nothing in it while the link was still there.
        #
        # I had written that `link_policy: forbid` is enforced BY
        # CONSTRUCTION. That claim is only true when every entry the traversal
        # encounters takes part in the construction, and one whole list of
        # them did not. The claim is now true.
        for one in directories:
            full = os.path.join(base, one)
            if os.path.islink(full):
                raise WorkerFault(
                    "output",
                    f"{full} is a link; a declared output carries regular "
                    f"files in 1.0 and `link_policy` is `forbid`")
        for one in files:
            full = os.path.join(base, one)
            if not os.path.isfile(full) or os.path.islink(full):
                # REGULAR FILES ONLY, like the manager's own measurement. A
                # link is not material this worker can describe by content;
                # a socket, a device or a fifo is not either.
                raise WorkerFault(
                    "output",
                    f"{full} is not a regular file; a declared output carries "
                    f"regular files in 1.0")
            if len(entries) + 1 > ceiling_entries:
                raise WorkerFault(
                    "output",
                    f"this output declares at most {ceiling_entries} "
                    f"entries and carries more")
            size = os.path.getsize(full)
            if total + size > ceiling_bytes:
                raise WorkerFault(
                    "output",
                    f"this output declares at most {ceiling_bytes} bytes and "
                    f"carries more")
            with open(full, "rb") as reading:
                content = reading.read()
            total += len(content)
            entries.append({
                "path": os.path.relpath(full, place).replace(os.sep, "/"),
                "bytes": len(content),
                "content_digest": "sha256:" + hashlib.sha256(
                    content).hexdigest()})
    entries.sort(key=lambda entry: entry["path"].encode("utf-8"))
    return {"entries": entries, "entry_count": len(entries),
            "total_bytes": sum(one["bytes"] for one in entries),
            "tree_digest": digest(entries)}


def answered(declared, reported):
    """The agent's per-output answers, held against the declarations.

    The agent names outputs and says whether it produced them; everything else
    in the published answer comes from the DECLARATION or from this worker's
    own measurement. So an agent cannot rename an output, move it, invent one,
    or describe bytes it did not write.
    """
    if type(reported) is not list:
        raise WorkerFault("answer", "a work answer's outputs are a list")
    said = {}
    for one in reported:
        if type(one) is not dict \
                or sorted(one) != sorted(AGENT_OUTPUT_MEMBERS):
            raise WorkerFault(
                "answer",
                f"an output answer is exactly "
                f"{', '.join(AGENT_OUTPUT_MEMBERS)}")
        if one["status"] not in OUTPUT_STATUSES:
            raise WorkerFault(
                "answer",
                f"an output status is one of {', '.join(OUTPUT_STATUSES)}")
        if type(one["result_metadata"]) is not dict:
            raise WorkerFault("answer",
                              "an output's result metadata is one object")
        if one["name"] in said:
            raise WorkerFault(
                "answer", f"output {one['name']!r} is answered twice")
        said[one["name"]] = one
    names = sorted(one["name"] for one in declared)
    if sorted(said) != names:
        raise WorkerFault(
            "answer",
            f"a work answer answers exactly {', '.join(names)}")
    published = []
    for declaration in declared:
        one = said[declaration["name"]]
        place = os.path.join(OUTPUT_ROOT, declaration["path"])
        status = one["status"]
        if status == "present" and not os.path.isdir(place):
            raise WorkerFault(
                "answer",
                f"output {declaration['name']!r} is answered present and "
                f"{place} is not there")
        if declaration["required"] and status != "present":
            # WHETHER AN OUTPUT WAS REQUIRED IS THE MANAGER'S DECLARATION. An
            # agent that could answer a required output away would be settling
            # its own attempt, and the manager refuses this too -- refusing it
            # here as well is the worker declining to publish a document it
            # knows is wrong.
            raise WorkerFault(
                "answer",
                f"output {declaration['name']!r} is required and is answered "
                f"{status}")
        published.append({
            "name": declaration["name"], "type": declaration["type"],
            "path": declaration["path"], "status": status,
            "content_manifest": (measured(place, declaration["constraints"])
                                 if status == "present" else None),
            "result_metadata": one["result_metadata"]})
    return published


def publish_completion(assignment, disposition, outputs):
    """`/output/output.json`, published LAST and ATOMICALLY.

    LAST, because its presence under its final name is the completion signal:
    it exists only if everything it describes was already written, so no
    separate signal is needed and none is invented.

    ATOMICALLY, because writing bytes into the final name is not publication.
    A process stopped inside that write leaves the name existing and empty,
    and a manager cannot tell that from a settled answer -- so the bytes
    become visible under the final name only once they are complete.
    """
    body = {"version": {"major": 1, "minor": 0},
            "manifest_id": f"completion-{disposition}",
            "created_at": _instant(),
            "extensions": {},
            "schema": COMPLETION_SCHEMA,
            "assignment_ref": assignment,
            "disposition": disposition,
            "outputs": outputs}
    body["manifest_digest"] = digest(body)
    place = os.path.join(OUTPUT_ROOT, OUTPUT_MANIFEST)
    staged = place + ".publishing"
    with open(staged, "wb") as writing:
        writing.write(canonical(body))
        writing.flush()
        os.fsync(writing.fileno())
    os.replace(staged, place)
    return body


def _instant():
    """This worker's own clock, in the frozen grammar.

    The manager does not take its ordering from this -- it has its own clock
    and its own observation -- so what this needs to be is well formed rather
    than authoritative.
    """
    return time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime()) + ".000Z"


def check_answer(operation, answer):
    """The agent's answer, against the closed set the contract pins.

    THE LAST BOUNDARY BEFORE THE FRAME. The agent is the least trusted thing
    inside this container, and an answer is what crosses out of it -- so a
    missing, unknown, extra or wrong-typed member is refused here rather than
    handed to a manager that would then have to decide what it meant.
    """
    if type(answer) is not dict:
        raise WorkerFault("answer",
                          f"a {operation} answer is one JSON object")
    wanted = ANSWER_MEMBERS[operation]
    missing = sorted(name for name in wanted if name not in answer)
    extra = sorted(name for name in answer if name not in wanted)
    if missing or extra:
        raise WorkerFault(
            "answer",
            f"a {operation} answer is exactly {', '.join(wanted)}"
            + (f"; missing {', '.join(missing)}" if missing else "")
            + (f"; unexpected {', '.join(extra)}" if extra else ""))
    for name, value in answer.items():
        # ONE RULE, AND NO EXEMPTION. W6633 eleventh review [P1]: `outputs`
        # used to be skipped here, on the reasoning that `answered` had
        # already built it -- and that reasoning was about the wrong document.
        # `answered` builds the records the COMPLETION ENVELOPE carries, which
        # is where they belong; the framed answer is a different surface and
        # is pinned to the bounded names of the outputs produced. Skipping the
        # member meant the whole record set crossed the channel, and the rule
        # that was supposed to stop a shape the manager would have to
        # interpret was not applied to the one member most able to carry one.
        #
        # `MAX_FRAME` bounds the entries too. A list of unbounded strings is
        # unbounded text with extra steps.
        if type(value) is str and len(value) <= MAX_FRAME:
            continue
        if type(value) is list \
                and all(type(entry) is str and len(entry) <= MAX_FRAME
                        for entry in value):
            continue
        raise WorkerFault(
            "answer",
            f"a {operation} answer's {name} is bounded text or a list of it")
    return answer


def bind(identity, expected):
    """THE COMMON CONTRACT, and it holds on every path this program has.

    The order is the content. A frame that is not for this session is not a
    request to this container at all, so it is refused before any question
    about entitlement: answering "you are not asked to work" would be
    answering a question somebody else was asked.

    Re-review [P1]: this used to live inside `handle`, which the latched
    bootstrap path never reaches -- so a container with a pending launch fault
    echoed an arbitrary peer's session and disclosed its own failure to
    whoever asked. Startup correlation supplies an operation identity; it does
    not suspend the binding. Lifted out so the one caller that decides what to
    answer establishes the correlation FIRST, whatever it goes on to say.
    """
    if identity["protocol"] != PROTOCOL:
        raise WorkerFault(
            "protocol",
            f"this channel speaks {PROTOCOL}; the frame says "
            f"{identity['protocol']!r}")
    if identity["session"] != expected:
        raise WorkerFault(
            "session",
            "this frame names another container session; a worker answers "
            "only the session the manager minted for it, and no message turns "
            "one container into another")


def handle(request, identity, seen, agent, spent):
    """One operation, with ENTITLEMENT CHECKED EVERY TIME.

    The protocol and the session are `bind`'s and are established before this
    is reached; what remains here is entitlement, shape and the replay fence.

    W26291: the entitlement was a POSTURE check and the posture axis is gone.
    What it protected did not go with it -- this runtime answers `describe` and
    `work`, and an operation outside that set is refused on every message
    rather than once at start, because a check that ran once at start is a
    check a later message can walk past.
    """
    operation = request.get("operation")
    if type(operation) is not str or operation not in REQUEST_MEMBERS:
        raise WorkerFault("protocol", "a request names one known operation")
    if operation not in OPERATIONS:
        # NOT "unknown operation". The distinction is the whole point of
        # keeping `consider` in the vocabulary: it is a REAL operation that
        # this runtime is not entitled to, and saying so is what makes the
        # negative case mean something.
        raise WorkerFault(
            "entitlement",
            f"this worker is not asked to {operation!r}; it answers "
            f"{', '.join(OPERATIONS)}")
    wanted = REQUEST_MEMBERS[operation]
    missing = sorted(name for name in wanted if name not in request)
    extra = sorted(name for name in request if name not in wanted)
    if missing or extra:
        raise WorkerFault(
            "protocol",
            f"a {operation} request is exactly {', '.join(wanted)}"
            + (f"; missing {', '.join(missing)}" if missing else "")
            + (f"; unexpected {', '.join(extra)}" if extra else ""))
    # NO PER-OPERATION MEMBER CHECK REMAINS. `work` used to name an inline
    # task and this typed it; W14251 closed replaced that with
    # `/input/input.json`, so the closed member set above is the whole of what
    # a request carries and there is nothing left here to type.
    # ONE USE PER SESSION, CONSUMED BEFORE DISPATCH. An id that reached the
    # agent is spent whatever the outcome, because this program cannot know
    # whether the first attempt's side effects happened -- and "it failed, so
    # you may send it again" is exactly the reasoning a replay fence exists to
    # refuse.
    if identity["operation_id"] in spent:
        raise WorkerFault(
            "replay",
            f"operation {identity['operation_id']!r} was already used in this "
            f"session; an operation id is consumed once")
    spent.add(identity["operation_id"])
    if operation == "describe":
        return check_answer(operation,
                            {"protocol": PROTOCOL,
                             "operations": list(OPERATIONS),
                             "launch": sorted(seen)})
    if operation == "consider":
        return check_answer(operation, agent.consider(seen, request))
    # W14251, closed: THE WORK OF AN EXECUTION WORKER, IN ORDER.
    #
    #   read `/input/input.json`  -- the manager's declaration of what was
    #                                asked for, at a path this contract fixes;
    #   read `/input/assignment.json`
    #                             -- WHO this assignment is, at the other fixed
    #                                path (W19784);
    #   hold the pair             -- one Work, one input digest, one policy and
    #                                profile: two documents that are not one
    #                                delivery are refused BEFORE the agent runs
    #                                and therefore before anything is written;
    #   run the agent             -- which writes its material under the
    #                                declared output paths and says which of
    #                                them it produced;
    #   hold its answer           -- against those declarations, and measure
    #                                the bytes rather than believe them;
    #   publish `output.json`     -- LAST and atomically, which is what makes
    #                                its presence the completion signal.
    #
    # The manager then validates that envelope, holds it against the same
    # input manifest and its own assignment, and freezes. Nothing here decides
    # settlement: a worker reports what it produced and the manager settles.
    given, declared = input_manifest()
    delivered = assignment_manifest()
    assignment = one_delivery(given, delivered)
    contextual = seen.get("schema") == CONTEXT_LAUNCH_SCHEMA
    reserved_context = any(one["name"] == "provider-context-receipt" for one in declared)
    if contextual or "provider_context" in seen or reserved_context:
        context_declaration(seen, declared)
        if contextual and (seen["job_execution"]["attempt_id"] != delivered["runtime_attempt_id"] or seen["job_execution"]["runtime_input_digest"] != given["manifest_digest"] or seen["job_execution"]["runtime_policy_digest"] != given["policy_digest"]):
            raise WorkerFault("input", "context Job and assignment disagree")
    reported = agent.work(seen, declared)
    if type(reported) is not dict:
        raise WorkerFault("answer", "a work answer is one JSON object")
    published = answered(declared, reported.get("outputs"))
    if seen.get("role") == "integration" and reserved_context:
        receipt = next(one for one in published if one["name"] == "provider-context-receipt")
        if receipt["status"] != "missing-optional" or os.path.lexists(os.path.join(OUTPUT_ROOT, "provider-context-receipt")):
            raise WorkerFault("answer", "context-free integration must not produce a provider context receipt")
    disposition = reported.get("disposition")
    if disposition not in DISPOSITIONS:
        raise WorkerFault(
            "answer",
            f"a work disposition is one of {', '.join(DISPOSITIONS)}")
    publish_completion(assignment, disposition, published)
    # TWO SURFACES, AND THEY CARRY DIFFERENT THINGS. The completion envelope
    # above is the durable document and holds the whole record for each output
    # -- name, type, path, status, the measured content manifest and the
    # opaque metadata. The framed answer is the correlated reply on the
    # worker-entry channel and carries the bounded NAMES of what was produced.
    #
    # W6633 eleventh review [P1]: it used to carry the records themselves, so
    # the manager received one document twice by two routes, one of them the
    # transport it is supposed to be able to read without interpreting.
    return check_answer(operation, {
        "disposition": disposition,
        "outputs": [one["name"] for one in published
                    if one["status"] == "present"],
        "recap": reported.get("recap")})


# -- W81857: the durable file exchange ---------------------------------------
#
# THE SAME OPERATION HANDLER, THE OTHER TRANSPORT. Everything below composes
# requests and publishes documents; not one rule about what an operation IS
# lives here. `handle` still validates the closed request member set, checks
# entitlement on every message, consumes the operation id once, reads
# `/input/input.json` and `/input/assignment.json`, runs the agent, measures
# the declared outputs and publishes `/output/output.json` atomically. A second
# serve loop that reimplemented any of that would be a second worker-entry
# protocol nobody reviewed, which is the thing this file exists not to be.


def _publish(root, name, document):
    """One event document, published ATOMICALLY under a fixed name.

    FIVE STEPS AND ALL FIVE MATTER: exclusive no-follow staging so nothing
    already at the staging name is written through; the complete write; `fsync`
    on the file so the bytes survive the machine; `rename` WITHIN the directory
    so the final name never exists half written; and `fsync` on the directory
    so the rename itself survives. A manager scanning mid-publication sees the
    staging name, which is not one of the four names its contract describes and
    is therefore not protocol state.

    THE MODE IS ESTABLISHED, NOT REQUESTED, and it is the same correction the
    launch document's writer records. A creation mode is filtered by the
    umask, and the manager reaches this namespace as another uid through the
    deployment's configured group -- so a document left at the process default
    is one only this container can read, which is a lost turn on somebody
    else's machine and nothing in the mount table would show why.

    AND THE STAGING NAME IS UNIQUE PER PUBLICATION. W81857 review
    2026-09-04T03-43-45Z [P1]: a fixed `.publishing` name plus `O_EXCL` means a
    process that died between creation and rename left a file that made every
    later incarnation of this program fail `FileExistsError` forever -- a
    permanent wedge created by a crash, inside the transport whose entire
    purpose is surviving one. A unique name cannot collide with a stale one,
    and a stale one is invisible: the manager reads the four fixed names this
    contract describes and reports anything else as a foreign entry rather than
    reading it.

    THE FINAL NAME IS REPLACED RATHER THAN LINKED, and that is the difference
    from the manager's own publisher. A state event is published TWICE for one
    operation -- `dispatched` before the provider and then its outcome -- so
    the second publication must land on the first. The receipt and the terminal
    are each written once, behind the fence that reads them first.
    """
    payload = canonical(document)
    if len(payload) > MAX_EXCHANGE_BYTES:
        raise WorkerFault("answer",
                          f"a {name} of {len(payload)} bytes is wider than "
                          f"the {MAX_EXCHANGE_BYTES} this exchange carries")
    place = os.path.join(root, name)
    staged = os.path.join(root, f".{name}.{os.getpid()}."
                                f"{os.urandom(8).hex()}.publishing")
    handle = os.open(staged,
                     os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW,
                     0o000)
    # ONE CLEANUP BOUNDARY OVER EVERYTHING AFTER THE CREATE, the same shape the
    # manager's publisher was corrected to. W81857 review
    # 2026-09-04T04-17-15Z [P2] found the leak on the manager side and asked
    # for the same audit here: several small unwinds that each cover one step
    # are several places for a step to be added outside one, and a transient
    # write or sync failure leaving a staging file behind is a leak whether or
    # not unique names keep it from being a wedge.
    #
    # A SUCCESSFUL `replace` CONSUMES THE STAGED NAME, so the unlink below is
    # an ordinary no-op on the happy path rather than a second act with an
    # effect.
    try:
        try:
            written = 0
            while written < len(payload):
                step = os.write(handle, payload[written:])
                if type(step) is not int or step <= 0:
                    raise WorkerFault("answer",
                                      f"publishing {name} made no progress "
                                      f"after {written} of {len(payload)} "
                                      f"bytes")
                written += step
            os.fchmod(handle, EVENT_FILE)
            os.fsync(handle)
        finally:
            os.close(handle)
        os.replace(staged, place)
        opened = os.open(root, os.O_RDONLY | os.O_DIRECTORY)
        try:
            os.fsync(opened)
        finally:
            os.close(opened)
        return place
    finally:
        try:
            os.unlink(staged)
        except OSError:
            pass


def _publish_activity(root, document):
    """The optional count, staged EXCLUSIVELY and renamed OVER the published
    file. Answers whether this write happened.

    W61599, and every difference from `_publish` above is deliberate.

    THE PUBLISHED FILE IS NEVER RENAMED AWAY, never unlinked and never
    truncated in place. A reader concurrent with publication therefore sees the
    previous complete document or the next one -- never absence caused by the
    publisher, and never a partial file.

    THE STAGING NAME IS FIXED AND CREATED `O_CREAT|O_EXCL|O_NOFOLLOW`. An entry
    already at that name means an abandoned publisher may still hold it, or
    something put a link there; either way this SUPPRESSES the write and tries
    again at the next tick. It does not unlink, truncate or write through a
    file it did not create. At most one temporary can therefore exist, which is
    what keeps this namespace inside the manager's entry budget.

    IT NEVER RAISES OUT OF THE PUBLISHER. A diagnostic that could stop the
    thread it runs on would wedge the very turn it was added to observe, so
    every failure here is a write that did not happen.
    """
    payload = canonical(document)
    if len(payload) > MAX_EXCHANGE_BYTES:
        return False
    staged = os.path.join(root, ACTIVITY_STAGING)
    try:
        handle = os.open(staged,
                         os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW,
                         0o000)
    except OSError:
        return False
    try:
        try:
            written = 0
            while written < len(payload):
                step = os.write(handle, payload[written:])
                if type(step) is not int or step <= 0:
                    return False
                written += step
            os.fchmod(handle, EVENT_FILE)
            os.fsync(handle)
        finally:
            os.close(handle)
        os.replace(staged, os.path.join(root, ACTIVITY_DOCUMENT))
        opened = os.open(root, os.O_RDONLY | os.O_DIRECTORY)
        try:
            os.fsync(opened)
        finally:
            os.close(opened)
        return True
    except OSError:
        return False
    finally:
        # A SUCCESSFUL `replace` CONSUMED THE STAGED NAME, so this is an
        # ordinary no-op on the happy path. On any other path it is what keeps
        # the single-temporary budget true.
        try:
            os.unlink(staged)
        except OSError:
            pass


class _ActivityPublisher:
    """One `work`-only publisher, with ONE SLOT and a FINITE stop.

    W61599. WHAT IT OWNS is a single integer slot whose last value wins, a
    cadence, and a thread that writes at most one document a second. There is
    no queue, no per-tick publisher and no per-attempt thread accumulation: a
    count is a level rather than a stream of events, so the newest value is the
    only one worth writing.

    WHAT IT MAY NEVER DO is gate anything. Not the provider's completion, not a
    mandatory read, not the terminal document and not this program's exit. Its
    stop sets a flag and waits a finite bound; past that it is ABANDONED
    without joining, and what makes that safe is the binding every document
    carries -- a late write names a command that is over, and the manager
    discards a document bound to anything but the exchange it is observing.

    `describe` RUNS NONE. It invokes no provider, so there is no native stream
    for a count to be a count of.
    """

    def __init__(self, root, document, observe, *, seconds=ACTIVITY_SECONDS):
        self._root = root
        self._document = document
        self._observe = observe
        self._seconds = seconds
        self._stop = threading.Event()
        self._thread = None
        # THE SLOT. One integer, or `None` for "nothing observed yet", which is
        # not the same answer as zero and is deliberately never published as
        # one.
        self._slot = None

    def start(self):
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()
        return self

    def _run(self):
        while True:
            self._tick()
            if self._stop.wait(self._seconds):
                # ONE LAST OBSERVATION ON THE WAY OUT, so a count that landed
                # inside the quiet window is not lost. It is still a write that
                # may simply not happen.
                self._tick()
                return

    def _tick(self):
        try:
            total = self._observe()
        except BaseException:                              # noqa: BLE001
            # AN OBSERVER FAULT IS AN UNKNOWN COUNT, never this thread's death
            # and never the turn's. The projection stays at its last observed
            # value, which is exactly what absence has always meant here.
            return
        if type(total) is not int or type(total) is bool or total <= 0:
            # ONLY A POSITIVE TOTAL IS PUBLISHED. A stream that has produced
            # nothing leaves the projection ABSENT rather than asserting an
            # observed zero, because "observed, and empty" is a different claim
            # from "nothing observed yet".
            return
        if total == self._slot:
            return
        self._slot = total
        _publish_activity(self._root, {**self._document,
                                       "schema": ACTIVITY_SCHEMA,
                                       "bytes_observed": total})

    def stop(self, seconds=ACTIVITY_STOP_SECONDS):
        """Ask it to finish, and WAIT A FINITE BOUND. Answers whether it did."""
        self._stop.set()
        thread = self._thread
        if thread is None:
            return True
        thread.join(seconds)
        return not thread.is_alive()


def _exchange_read(root, name):
    """One named regular file's whole bytes, or absence. NO-FOLLOW, BOUNDED.

    The four properties are `read_launch`'s and each one is a way this program
    can be handed something other than a document: NO-FOLLOW so a link at a
    fixed name is refused rather than resolved, NON-BLOCKING so a FIFO cannot
    stop this program inside `open`, REGULAR proved on the DESCRIPTOR rather
    than on the path, and BOUNDED at one byte past the ceiling.
    """
    try:
        descriptor = os.open(os.path.join(root, name),
                             os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    except FileNotFoundError:
        return None
    except OSError:
        raise WorkerFault("exchange",
                          f"{name} could not be opened as an ordinary file; a "
                          f"link or a device at a name this contract fixes is "
                          f"not a document") from None
    try:
        if not stat.S_ISREG(os.fstat(descriptor).st_mode):
            raise WorkerFault("exchange", f"{name} is not a regular file")
        raw = os.read(descriptor, MAX_EXCHANGE_BYTES + 1)
    finally:
        os.close(descriptor)
    if len(raw) > MAX_EXCHANGE_BYTES:
        raise WorkerFault("exchange",
                          f"{name} is wider than {MAX_EXCHANGE_BYTES} bytes")
    return raw


def _commanded(root, session):
    """The one manager-authored command in this namespace, or absence.

    EXACTLY ONE, AND ITS NAME IS ITS OWN SEQUENCE IDENTITY. The manager derives
    the filename from the sequence rather than being given a path, so a
    namespace holding two commands is one this program did not receive from a
    manager it recognises -- choosing between them by directory order would be
    inventing which turn was asked for.

    STAGING NAMES ARE INVISIBLE, which is the other half of atomic
    publication: a scan that raced a rename sees a dot-prefixed name and must
    read nothing, because the document under it is not finished.

    AND THE NAMESPACE IS PROVED READ-ONLY. A command this worker could rewrite
    is one the manager cannot hold it to -- it could change what it was asked
    to do between reading the command and publishing the receipt that fences
    it. The proof is an attempted write-open, which is the only thing that
    answers the question: the mode bits describe the host file and say nothing
    about how it was mounted.
    """
    try:
        entries = sorted(os.listdir(root))
    except OSError:
        return None
    named = [one for one in entries
             if one.endswith(".json") and not one.startswith(".")]
    if not named:
        return None
    if len(named) > 1:
        raise WorkerFault("exchange",
                          f"this exchange carries {len(named)} commands and "
                          f"one attempt has one sequence")
    name = named[0]
    raw = _exchange_read(root, name)
    if raw is None:
        return None
    try:
        writable = os.open(os.path.join(root, name),
                           os.O_WRONLY | os.O_NOFOLLOW)
    except OSError:
        pass
    else:
        os.close(writable)
        raise WorkerFault("exchange",
                          f"{name} is writable from inside this container; a "
                          f"command this worker could rewrite is not one the "
                          f"manager can hold it to")
    try:
        document = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, ValueError):
        raise WorkerFault("exchange", f"{name} is not UTF-8 JSON") from None
    _closed(document, COMMAND_MEMBERS, name)
    if document["schema"] != COMMAND_SCHEMA:
        raise WorkerFault("exchange",
                          f"{name} says it is {document['schema']!r} and this "
                          f"worker reads {COMMAND_SCHEMA!r}")
    if document["session"] != session:
        # NOT THIS CONTAINER'S COMMAND. A frame that is not for this session is
        # not a request to this container at all, and the file transport
        # answers that question exactly as `bind` does for the framed one.
        raise WorkerFault("session",
                          f"{name} names another container session; a worker "
                          f"answers only the session the manager minted for "
                          f"it")
    if name != document["sequence_id"] + ".json":
        raise WorkerFault("exchange",
                          f"{name} carries sequence "
                          f"{document['sequence_id']!r}; the published name "
                          f"is derived from the sequence identity")
    ordered = document["operations"]
    if type(ordered) is not list or not ordered \
            or len(ordered) > len(OPERATIONS):
        raise WorkerFault("exchange",
                          f"{name} carries a bounded ordered operation list")
    for one in ordered:
        _closed(one, COMMAND_OPERATION_MEMBERS, name)
        if one["operation"] not in OPERATIONS:
            raise WorkerFault(
                "entitlement",
                f"this worker is not asked to {one['operation']!r}; it "
                f"answers {', '.join(OPERATIONS)}")
        _exchange_value(one["operation_id"], "an operation id", name)
    _exchange_value(document["attempt_id"], "an attempt id", name)
    return document, digest_of(raw)


def _closed(document, members, name):
    if type(document) is not dict:
        raise WorkerFault("exchange", f"{name} is JSON objects")
    missing = sorted(one for one in members if one not in document)
    extra = sorted(one for one in document if one not in members)
    if missing or extra:
        raise WorkerFault(
            "exchange",
            f"{name} is exactly {', '.join(members)}"
            + (f"; missing {', '.join(missing)}" if missing else "")
            + (f"; unexpected {', '.join(extra)}" if extra else ""))
    return document


def _exchange_value(value, what, name):
    if type(value) is not str or not value \
            or len(value) > MAX_EXCHANGE_VALUE:
        raise WorkerFault("exchange",
                          f"{name} carries {what} that is not bounded "
                          f"non-empty text")
    return value


def digest_of(payload):
    """The digest every event document is correlated by.

    Over the EXACT BYTES the manager published rather than over a
    recanonicalization of them: the manager holds its own bytes and this holds
    the file, so two readers that canonicalize differently cannot disagree
    about what was commanded.
    """
    return "sha256:" + hashlib.sha256(payload).hexdigest()


def _bound(command, digested, **members):
    """Every event document, bound to the exact command it answers.

    THE DIGEST IS THE BINDING and the identities are the readable half of it.
    A manager that found a document naming another sequence would have no way
    to tell a stale delivery from a foreign one, so all four travel on every
    document this program publishes.
    """
    return {"session": command["session"],
            "attempt_id": command["attempt_id"],
            "sequence_id": command["sequence_id"],
            "command_digest": digested, **members}


def _published_manifest_digest():
    """The completion envelope's own digest, read back from what was published.

    READ BACK RATHER THAN CARRIED. `publish_completion` is the atomic writer
    and its output is the durable record; naming its digest here from a value
    passed alongside would be a second account of a document that already
    exists. The manager validates that same file independently before it
    freezes anything, so this is a correlation label rather than evidence.
    """
    try:
        raw = _exchange_read(OUTPUT_ROOT, OUTPUT_MANIFEST)
    except WorkerFault:
        return None
    if raw is None:
        return None
    try:
        document = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, ValueError):
        return None
    found = document.get("manifest_digest") if type(document) is dict else None
    # THE SHAPE, NOT THE LENGTH. The manager holds this member to a canonical
    # sha256 grammar, so a value that would be refused there is not one this
    # program publishes -- a worker that wrote something the manager cannot
    # read would be moving its own mistake into a container the manager can no
    # longer ask about.
    if type(found) is not str or not re.match(r"\Asha256:[0-9a-f]{64}\Z",
                                              found):
        return None
    return found


def serve_exchange(agent, seen, expected, command_root, event_root,
                   sleep=None):
    """The durable transport. NOTHING HERE DEPENDS ON A LIVE MANAGER.

    THE ORDER IS THE WHOLE CONTRACT:

      1. wait for the one command, which the manager publishes AFTER this
         container is up -- so this program is running before there is
         anything to do, which is exactly the state the defect this Work
         corrects reported as `running`;
      2. publish the RECEIPT before the provider is dispatched. That receipt is
         the durable replay fence: rescanning this namespace, a manager
         restart during the turn, and a re-entry of this program after a crash
         all find it and none of them starts a second provider turn;
      3. publish one state event per operation actually reached, so an operator
         can tell "the turn is running" from "the turn is over" without
         interpreting silence; and
      4. publish ONE terminal document carrying only bounded protocol facts.

    A RECEIPT WITH NO TERMINAL IS NOT AN ENDING THIS PROGRAM MAY WRITE. Re-
    entering here after a receipt means a previous incarnation reached the
    provider and this one cannot know whether that provider is still running,
    already finished, or gone. Publishing `lost` would be claiming an
    observation this side does not have; the manager combines the durable
    receipt with its own exact runtime observation and decides.

    WHAT NEVER CROSSES: the provider's recap, its stdout or stderr, the prompt,
    a source excerpt, tool input or output, or any diagnostic prose. The
    terminal document carries the completed operation names, a bounded fault
    CODE from this program's own closed set, the worker disposition when there
    is one, and the digest of the completion envelope already published under
    the existing `/output` contract.
    """
    waiting = time.sleep if sleep is None else sleep
    try:
        found = _commanded(command_root, expected)
        while found is None:
            waiting(SCAN_SECONDS)
            found = _commanded(command_root, expected)
        command, digested = found
    except WorkerFault:
        # NOTHING CORRELATES A REFUSAL ABOUT THE COMMAND ITSELF. Without a
        # command there is no sequence, no digest and no session this program
        # may publish under -- writing an uncorrelated document into a
        # namespace the manager reads by identity would be inventing state
        # rather than reporting one. The manager already owns the launched
        # runtime and reads this exchange as `waiting`.
        return 2
    if _exchange_read(event_root, RECEIPT_DOCUMENT) is not None:
        # THE FENCE, AND IT IS READ BEFORE ANYTHING IS DISPATCHED. A receipt
        # under this command means a provider turn was already begun for it.
        # Whether it finished is not this program's question and not one it can
        # answer, so it reports the sequence as already accepted and stops.
        return 0 if _exchange_read(event_root,
                                   TERMINAL_DOCUMENT) is not None else 4
    _publish(event_root, RECEIPT_DOCUMENT,
             _bound(command, digested, schema=RECEIPT_SCHEMA,
                    accepted_at=_instant()))
    spent = set()
    answered = []
    disposition = None
    # BOUND BEFORE THE LOOP, because a command carries a BOUNDED ordered list
    # rather than necessarily the whole pair, and the terminal below needs
    # this value on every path. A sequence that never reached `work` has no
    # completion envelope to name and therefore no answer to publish.
    manifest = None
    for one in command["operations"]:
        operation = one["operation"]
        identity = {"protocol": PROTOCOL, "session": command["session"],
                    "operation_id": one["operation_id"]}
        request = {**identity, "operation": operation}
        _publish(event_root, f"state-{operation}.json",
                 _bound(command, digested, schema=STATE_SCHEMA,
                        operation=operation,
                        operation_id=one["operation_id"],
                        state="dispatched"))
        # W61599: THE OPTIONAL PUBLISHER, `work` ONLY, AROUND THE ONE CALL
        # THAT INVOKES A PROVIDER. It is started after `dispatched` is
        # published and stopped before anything else is, so it cannot race the
        # terminal causality this transport's whole meaning rests on -- and it
        # writes a SEPARATE document under a SEPARATE schema, so the four
        # lifecycle documents are byte-unchanged whether it runs or not.
        #
        # AN AGENT THAT OBSERVES NOTHING GETS NO PUBLISHER, which is the
        # ordinary case for the scripted agents and for any adapter that has no
        # native stream to measure.
        publisher = _activity_publisher(agent, event_root, command, digested,
                                        operation, one["operation_id"])
        try:
            answer = handle(request, identity, seen, agent, spent)
        except WorkerFault as fault:
            _stopped(publisher)
            return _faulted(event_root, command, digested, operation,
                            one["operation_id"], answered, fault.code)
        except adapter_refusal.AdapterDeclarationRefusal as refused:
            # W376586: THE TYPED PRE-PROVIDER DECLARATION CAUSE, CAUGHT BEFORE
            # THE GENERIC CLAUSE AND NOWHERE ELSE.
            #
            # It is ordered here and not earlier: `WorkerFault` is this
            # program's own vocabulary and keeps its existing ending, and a
            # typed adapter refusal is not one. It is ordered before
            # `Exception` because that is the clause it would otherwise fall
            # into -- which is the whole defect: a cause the adapter KNEW,
            # established before any provider was invoked, reported as an
            # anonymous agent failure an operator cannot act on.
            #
            # THE ENDING IS UNCHANGED. Same `faulted`, same `agent` code, same
            # one terminal document; what is added is the revalidated typed
            # object. `_adapter_failure` answers `None` for a wrong phase, a
            # mutated or overridden object, or anything else it cannot hold to
            # the closed literals, and that path is byte-identical to the
            # generic clause below.
            _stopped(publisher)
            return _faulted(event_root, command, digested, operation,
                            one["operation_id"], answered,
                            ADAPTER_FAILURE_CODE,
                            adapter_failure=_adapter_failure(
                                refused, operation, one["operation_id"],
                                # THE SELECTED LAUNCH ROLE, from the validated
                                # launch document this container was started
                                # under. `seen` is the manager's own
                                # composition; the adapter is not asked.
                                seen.get("role")))
        except Exception:                                  # noqa: BLE001
            # THE AGENT'S FAILURE IS NOT THIS PROGRAM'S CRASH, and it is not
            # this program's diagnostic either. The framed transport answers a
            # bounded description with no traceback; here even the exception's
            # type name stays out of the durable document, because a durable
            # file is a different surface from a frame the manager reads once.
            _stopped(publisher)
            return _faulted(event_root, command, digested, operation,
                            one["operation_id"], answered, "agent")
        # AN ANSWER NAMES THE ENVELOPE IT PUBLISHED, or it is not an answer.
        # W81857 review [P1] made this member load-bearing: the manager
        # compares it with the digest its own independent validation of
        # `/output/output.json` produced, and refuses the whole success ending
        # on a mismatch. So a `work` that ran and cannot read back its own
        # completion envelope is reported as a FAULT rather than as an answer
        # with a null digest -- publishing the latter would be asking the
        # manager to accept a correlation this program could not make.
        #
        # IT IS CHECKED BEFORE THE `answered` STATE IS PUBLISHED, and re-review
        # 2026-09-04T04-17-15Z [P1] is why the order matters now. The manager
        # holds a terminal against its own state evidence: an operation the
        # terminal does not answer must not be sitting there answered, and a
        # faulted ending must name the operation it stopped on. Publishing
        # `answered` for `work` and then faulting over the envelope would emit
        # exactly that contradiction, and the manager would refuse the whole
        # exchange rather than read the fault.
        # THE PUBLISHER IS STOPPED BEFORE THE OUTCOME IS PUBLISHED, on every
        # path out of the call above. A lost final count is acceptable and is
        # reported as last observed; a diagnostic still writing while the
        # terminal is composed is not.
        _stopped(publisher)
        if operation == "work":
            disposition = answer.get("disposition")
            manifest = _published_manifest_digest()
            if manifest is None:
                return _faulted(event_root, command, digested, operation,
                                one["operation_id"], answered, "output")
        _publish(event_root, f"state-{operation}.json",
                 _bound(command, digested, schema=STATE_SCHEMA,
                        operation=operation,
                        operation_id=one["operation_id"],
                        state="answered"))
        answered.append(operation)
    if manifest is None:
        # EVERY COMMANDED OPERATION SUCCEEDED AND NONE OF THEM WAS `work`, so
        # there is nothing this sequence could correlate an answer to. The
        # manager holds an answered terminal to a canonical completion digest,
        # so publishing one here would be publishing a document it refuses;
        # the honest report is that this exchange asked for no work.
        return _faulted(event_root, command, digested,
                        command["operations"][-1]["operation"],
                        command["operations"][-1]["operation_id"],
                        answered[:-1], "exchange")
    _publish(event_root, TERMINAL_DOCUMENT,
             _bound(command, digested, schema=TERMINAL_SCHEMA,
                    ending="answered", answered=answered,
                    disposition=disposition, fault_code=None,
                    manifest_digest=manifest,
                    # W376586: AN ANSWERED ENDING HAS NO TYPED CAUSE, and says
                    # so explicitly. The member is mandatory in `/2` precisely
                    # so that this is a statement rather than an absence.
                    adapter_failure=None))
    return 0


def _activity_publisher(agent, event_root, command, digested, operation,
                        operation_id):
    """The `work` publisher, if this agent can observe anything at all.

    W61599. THE ADAPTER OWNS THE OBSERVATION and this program owns the
    publication, which is the same separation the rest of this file draws: what
    a count MEANS -- which files, which baseline, when it becomes unknown -- is
    the adapter's, and an agent without `observed_activity` simply has none.
    A `describe` gets no publisher because it invokes no provider.
    """
    if operation != ACTIVITY_DOCUMENT_OPERATION:
        return None
    observe = getattr(agent, "observed_activity", None)
    if not callable(observe):
        return None
    return _ActivityPublisher(
        event_root,
        _bound(command, digested, operation=operation,
               operation_id=operation_id),
        observe).start()


def _stopped(publisher):
    """Stop one optional publisher, and NEVER let it stop the turn.

    An over-bound stop leaves the thread abandoned rather than joined. What
    makes that safe is the binding: whatever it eventually writes names a
    command that is over, and the manager discards a document bound to anything
    but the exchange it is observing.
    """
    if publisher is None:
        return True
    try:
        return publisher.stop()
    except BaseException:                                  # noqa: BLE001
        return False


def _adapter_failure(failed, operation, operation_id, selected):
    """The typed declaration cause, REVALIDATED HERE, or nothing at all.

    THE ROLE IS THE SELECTED LAUNCH ROLE, AND NOT THE EXCEPTION'S CLAIM.
    Review 2026-10-28T21-25-27Z reproduced the hole with the real worker and
    the real manager: this function held the role to the two allowed literals
    and NEVER compared it with the launch, so a container launched
    `implementation` published a typed cause saying `review` -- a valid
    vocabulary word standing in for an identity. "Vocabulary alone is not
    identity" is exactly right, and the amendment already required a wrong
    role to keep the generic failure.

    `selected` is the role out of the VALIDATED LAUNCH DOCUMENT, which the
    manager composes from the worker's configured launch role; it is the only
    party here entitled to say which lane this container is. A disagreement
    degrades, and so does a launch role outside the typed vocabulary -- the
    integration workload runs under `integration`, which no development
    declaration cause can name.

    THIS IS THE SERIALIZATION BOUNDARY and it trusts the exception for exactly
    one thing: being an instance of the shared class. Review
    2026-10-28T20-07-16Z: "this exception retains message/args and mutable
    code/role fields, so its `facts()` result is not inherently trusted
    forever." Both halves of that are true of any live object --
    `AdapterDeclarationRefusal` checks its code and role in `__init__` and
    nothing stops a later assignment, and a SUBCLASS may override `facts` with
    anything at all, including a method that returns host paths or raises.

    SO `facts()` IS NEVER CALLED. The three values are read as attributes,
    each one held to `type(...) is str` and to membership of this build's own
    closed tuple, and what is stored is THE MATCHING LITERAL FROM THAT TUPLE
    rather than the string the object handed over -- so even an equal-comparing
    `str` subclass carrying a payload cannot reach the document. A `property`
    that raises is a degradation, not a crash, which is why the reads are
    guarded.

    THE OPERATION AND ITS IDENTITY ARE THE COMMAND'S, and the ROLE IS THE
    LAUNCH'S. They are the manager's own minted values, taken from the sequence
    this program is answering and from the document it was started under, and
    the exception is not asked about any of them -- a worker-asserted operation
    identity is the one thing the manager's reader will not take, and a
    worker-asserted role is the one the reviewer caught it taking.

    DEGRADATION IS `None`, which the caller turns into the ordinary generic
    `agent` fault that this transport already published before any of this
    existed. Nothing about an unreadable, malicious or wrong-phase refusal
    produces a typed cause, and nothing about it loses the ending.
    """
    if operation != ADAPTER_FAILURE_OPERATION:
        return None
    if not isinstance(failed, adapter_refusal.AdapterDeclarationRefusal):
        return None
    if type(operation_id) is not str or not operation_id:
        return None
    # THE TRUSTED ROLE FIRST, because every other check about the role is
    # relative to it. A launch role this typed vocabulary does not contain is
    # not a mismatch to report -- it is a container that cannot produce a
    # development declaration cause at all.
    if type(selected) is not str or selected not in adapter_refusal.ROLES:
        return None
    held = {"operation": ADAPTER_FAILURE_OPERATION,
            "operation_id": operation_id,
            # THE LITERAL FROM THIS BUILD'S OWN TUPLE, resolved from the
            # LAUNCH's role rather than from anything the exception handed
            # over. The exception still has to agree, below; what is published
            # is the manager's selection.
            "role": adapter_refusal.ROLES[
                adapter_refusal.ROLES.index(selected)]}
    for name, allowed in (("component", (adapter_refusal.COMPONENT,)),
                          ("code", adapter_refusal.CODES),
                          ("role", (held["role"],))):
        try:
            value = getattr(failed, name)
        except BaseException:                              # noqa: BLE001
            return None
        if type(value) is not str or value not in allowed:
            return None
        held[name] = allowed[allowed.index(value)]
    # THE MEMBER SET IS CHECKED RATHER THAN ASSUMED, so a member added above
    # without a rule here cannot reach the document, and the bound is measured
    # on the canonical bytes that will actually be published.
    if sorted(held) != sorted(ADAPTER_FAILURE_MEMBERS):
        return None
    if len(canonical(held)) > MAX_ADAPTER_FAILURE_BYTES:
        return None
    return held


def _faulted(event_root, command, digested, operation, operation_id, answered,
             code, adapter_failure=None):
    """One refused operation, ended once and correlated.

    THE FAULT CODE AND NOTHING ELSE. This program's codes are a closed set of
    short literals it authored; a message is composed from values it read,
    including the assignment, the agent's answer and the container's own paths,
    and none of those is material the finding permits in a durable exchange
    document.

    W376586: `adapter_failure` IS PUBLISHED HERE AND IS NULL BY DEFAULT, so
    every existing fault path keeps the ending it had and gains the member
    saying no typed declaration cause was established. Only the typed catch in
    `serve_exchange` passes one, and only after `_adapter_failure` has
    revalidated it.
    """
    _publish(event_root, f"state-{operation}.json",
             _bound(command, digested, schema=STATE_SCHEMA,
                    operation=operation, operation_id=operation_id,
                    state="faulted"))
    _publish(event_root, TERMINAL_DOCUMENT,
             _bound(command, digested, schema=TERMINAL_SCHEMA,
                    ending="faulted", answered=answered, disposition=None,
                    fault_code=code, manifest_digest=None,
                    adapter_failure=adapter_failure))
    return 1


# HOW FAR A STARTUP DIAGNOSTIC TRAVELS ON STDERR. Bounded because the launch
# document is the least trusted input this program has and its values reach
# `MAX_LAUNCH_VALUE`; comfortably inside `worker_entry.MAX_STDERR`, which is
# what the manager actually carries back.
MAX_STARTUP_DIAGNOSTIC = 1024


def _startup_refusal(stream, fault):
    """Say why this container will not start, ONCE, on stderr, and go.

    W197661. THIS IS A DIAGNOSTIC SURFACE AND NOT A PROTOCOL EVENT. Nothing
    parses this sentence, and improvising a receipt, a state or a terminal
    document out of an invalid launch is exactly what the ruling forbids. What
    it replaces is SILENCE -- a container that waited forever on a stdin nobody
    would write to, with empty logs and empty events.

    WHO READS IT, stated exactly rather than generously. Review
    2026-09-17T22-10-41Z finding 4: `worker_entry.MAX_STDERR` is the FRAMED
    transport's own collection bound and is not evidence that the file-exchange
    path imports a container's stderr. On that path this is an operator-readable
    container diagnostic -- `docker logs`, and the engine's recorded ending --
    which is precisely what the reported incident had none of. No production
    collection of it is claimed here.

    ONE LINE OF PRINTABLE ASCII, BOUNDED. The text quotes a document this
    program has just refused to trust, so it is reduced to characters that
    cannot forge a frame header, cannot move an operator's cursor and cannot
    become an unbounded durable write.
    """
    # THE FAULT'S OWN WORDS, and its code. The messages already name the
    # document, so prefixing the path again would spend the bound repeating it.
    said = f"{fault.code}: {fault.message}"
    said = "".join(one if " " <= one <= "~" else " " for one in said)
    said = said[:MAX_STARTUP_DIAGNOSTIC]
    try:
        stream.write(f"baton-worker: {said}\n")
        stream.flush()
    except Exception:                                      # noqa: BLE001
        # A DIAGNOSTIC THAT CANNOT BE WRITTEN IS STILL A REFUSAL TO START.
        # Raising here would replace a bounded exit with a traceback carrying
        # image paths, and would put the failure of the message ahead of the
        # failure it was about.
        pass
    return STARTUP_REFUSED


# THE EXIT STATUSES THIS PROGRAM ENDS WITH, and each is a different fact:
#   0  a clean end with nothing latched, or an exchange sequence completed
#   1  a latched fault answered once, or an abnormal ending of the framing loop
#   2  nothing could be correlated, so nothing was said on any channel
#   3  W197661: the launch document was correlatable and REFUSED, and this
#      container's declared generation does not speak the stdin framing loop --
#      so the refusal went to stderr and this program stopped without reading
#      a channel nobody was going to write to
#   4  the exchange sequence is accepted and unfinished
# Nothing in the manager maps these to meanings: `worker_entry` compares a
# status to zero and `observe` does not read one at all. `3` is therefore an
# operator-visible distinction and not a contract change.
STARTUP_REFUSED = 3


def serve(stdin, stdout, agent, place=LAUNCH_DOCUMENT,
          command_root=COMMAND_ROOT, event_root=EVENT_ROOT, sleep=None, *,
          stderr=None):
    """The loop. Every answerable fault becomes a correlated frame; nothing
    becomes a traceback.

    A worker that died on a malformed frame would leave the manager waiting for
    a runtime that is gone, and reconciliation would have to infer what
    happened from engine state -- which is exactly what the manager is built
    not to do.

    W26291: THE LAUNCH DOCUMENT IS READ HERE, and the two failure kinds it has
    are the two this loop already had. A document that cannot be read at all,
    or that carries no usable session, is `Uncorrelated`: there is nothing to
    answer under, so nothing is written and the manager settles the start it
    already owns. A document that IS correlatable and is wrong in some other
    way -- an unknown member, another generation's schema, an over-long role --
    is refused before anything is dispatched. Nothing on either path reaches
    the agent.

    W197661 SPLIT THAT SECOND KIND BY THE CHANNEL THIS PROGRAM CAN STILL SHOW
    SOMEBODY IS ON. A `/1` document is LATCHED, answered once through the
    ordinary correlated fault and exits `1`, exactly as before: `/1` carries no
    transport member at all, so it is unambiguously the generation
    `worker_entry.converse` drives over this stdin. A refused document of any
    other declared version MIGHT be an exchange launch and might not -- `/3`
    and `/4` may validly name no transport -- and the member that would settle
    it is part of the document that was just refused. Those refusals therefore
    go to stderr and exit `3` rather than risking an unbounded wait. See the
    latch below.
    """
    try:
        document = read_launch(place)
        # W376586: THE SESSION IS THE CONTAINER'S, and `/5` carries the
        # container one level down. Asked through `container_of` so a valid
        # wrapped delivery is correlatable BEFORE it is validated, which is
        # the property this read exists for.
        expected = session_of(container_of(document))
    except Uncorrelated:
        # NOTHING THIS PROGRAM SAYS COULD BE MATCHED TO A REQUEST. The ruling
        # hands this to the manager, which already owns the launched session.
        return 2
    # THE BOOTSTRAP FAULT IS LATCHED, NOT RAISED. The framing loop is still
    # operable, so the failure is answered through the ordinary correlated
    # shape after exactly one identity envelope -- and it never reaches the
    # agent, because the dispatch below is not on this path at all.
    latched = None
    seen = {}
    try:
        seen = launched(document, place)
    except WorkerFault as fault:
        latched = fault
        # W197661: AND A CONTAINER NOBODY WILL WRITE TO DOES NOT WAIT TO BE
        # WRITTEN TO.
        #
        # THE DEFECT. A correlatable-but-invalid document left `seen` empty, so
        # the exchange branch below could not be reached however the launch was
        # meant to be spoken, and this fell into `read_frame(stdin)`. For a `/1`
        # container that is right -- a manager IS writing frames there. The
        # reported container was launched `/3` over the file exchange, and its
        # stdin was an open pipe with no writer: the read blocked forever, the
        # container stayed up with empty logs and empty events, the manager
        # observed a healthy runtime, and an incompatible image looked exactly
        # like a working one. It needed a `SIGKILL` to end.
        #
        # THE ONE MEMBER TRUSTED FROM A DOCUMENT THIS PROGRAM JUST REFUSED is
        # its declared `schema`, and it is trusted for ONE decision: which
        # channel this failure is reported on. It selects no transport, no
        # execution, no destination and no peer, and a document that declares
        # nothing readable is not `/1` and takes the prompt path.
        #
        # AND IT IS A CONSERVATIVE POLICY RATHER THAN KNOWLEDGE. A refused
        # `/3` or `/4` may have named no transport and may really have been a
        # framing-loop container; this program cannot tell, because the member
        # that would say so is in the document it just refused. The direction
        # is chosen deliberately: failing fast where a manager WOULD have
        # written frames costs a correlated fault and still leaves the same
        # sentence on stderr, while waiting where nobody will write costs the
        # whole Job and tells no one why.
        # W376586: A `/5` DELIVERY IS NOT `/1` AND TAKES THE PROMPT PATH,
        # which is the same conservative direction this policy already
        # chose: the wrapper exists to carry a file-exchange launch, so
        # nobody is writing frames to it.
        if document.get("schema") != ONE_SHOT_LAUNCH_SCHEMA:
            return _startup_refusal(sys.stderr if stderr is None else stderr,
                                    fault)
    # W81857: THE LAUNCH DOCUMENT SELECTS THE TRANSPORT, and it is the only
    # thing that does. `seen` is the VALIDATED document, so a `/1` container
    # cannot reach the branch below however its filesystem happens to look, and
    # a latched container -- one whose document is correlatable and wrong in
    # some other way -- has no validated transport at all and answers its one
    # correlated fault through the framing loop exactly as it did before.
    # W376586: THE ADAPTER IS RESOLVED HERE, AFTER THE DELIVERY IS VALIDATED
    # AND THE TRANSPORT SELECTED, and not before. `main` used to evaluate
    # `_scripted_default()` as an argument, so the default existed before this
    # function had read the launch at all; the amendment requires an
    # unsupported or unwrapped file-exchange launch to refuse before adapter
    # construction, and an argument evaluated by the caller cannot satisfy
    # that however this function is ordered.
    #
    # EVERY REFUSAL ABOVE RETURNS WITHOUT REACHING THIS LINE, which is what
    # makes "before the adapter" a property of the order rather than a claim.
    #
    # AND A LATCHED CONTAINER BUILDS NOTHING EITHER. The latched path answers
    # one correlated fault frame and returns without reaching `handle`, so the
    # agent is never used there -- resolving one would construct a provider
    # for a container that is already refusing. `/1` is the framed transport
    # and outside this feature, so this is a free uniformity rather than a
    # requirement of the amendment; it is here because the alternative is
    # building something nothing asks for.
    if agent is None and latched is None:
        agent = _scripted_default()
    if seen.get("transport") == EXCHANGE_TRANSPORT:
        return serve_exchange(agent, seen, expected, command_root, event_root,
                              sleep=sleep)
    spent = set()
    while True:
        try:
            request = read_frame(stdin)
        except Uncorrelated:
            return 1
        if request is None:
            # A clean end of input is the manager closing the channel. It is
            # NOT cancellation -- cancellation is the manager's runtime stop
            # path and this program never sees it as a message.
            return 1 if latched is not None else 0
        try:
            identity = identity_of(request)
        except Uncorrelated:
            return 1
        # THE BINDING FIRST, ON BOTH PATHS. Re-review [P1]: the latched return
        # below used to come before any correlation check, so a container that
        # had failed to start answered a frame minted for somebody else's
        # session and told them what had gone wrong inside it.
        try:
            bind(identity, expected)
        except WorkerFault as fault:
            write_frame(stdout, failure(identity, fault))
            # A LATCHED CONTAINER STILL ANSWERS EXACTLY ONCE AND EXITS
            # NON-ZERO. Which fault it names changed; how many frames it
            # writes, and that it dispatches nothing, did not.
            if latched is not None:
                return 1
            continue
        if latched is not None:
            write_frame(stdout, failure(identity, latched))
            return 1
        try:
            write_frame(stdout, success(
                identity,
                handle(request, identity, seen, agent, spent)))
        except WorkerFault as fault:
            write_frame(stdout, failure(identity, fault))
        except Exception as failed:                        # noqa: BLE001
            # THE AGENT'S FAILURE IS NOT THIS PROGRAM'S CRASH. It is reported
            # as a fault frame with a bounded description and no traceback: a
            # traceback would carry paths from inside the image out through the
            # channel.
            write_frame(stdout, failure(
                identity,
                WorkerFault("agent",
                            f"the agent failed: {type(failed).__name__}")))


def _scripted_default():
    """The M2 fixture agent, loaded ONLY when nobody injected one.

    W39770. The import lives here rather than at the top of `main` because
    where it lives decides what an image has to carry. `main` opened with an
    unconditional `from scripted_agent import ScriptedAgent`, before it looked
    at whether an agent was supplied -- so the DOCUMENTED INJECTION SEAM could
    not be used by any image that did not also ship the default it was
    overriding. W39357's provider image injects a real Claude adapter and
    carries no scripted agent; its entrypoint died `ModuleNotFoundError`
    before this program started, which its build gate caught and recipe
    inspection could not.

    THE REFERENCE IMAGE IS UNCHANGED. Its recipe ships `scripted_agent.py` and
    its entrypoint supplies no agent, so this is exactly the branch it takes
    and exactly the object it got before.
    """
    from scripted_agent import ScriptedAgent

    return ScriptedAgent()


# -- W198667: the wrapper's own earliest output -------------------------------


def _log_format():
    """The shared declaration format, if this image carries it.

    IMPORTED LAZILY AND OPTIONALLY, on purpose. The accepted images that are
    already built do NOT carry this module, and a worker that failed to start
    because its LOGGING was unavailable would be a worker that logging made
    less reliable -- which is the opposite of why any of this exists. An image
    without it simply captures nothing, and the manager reports every stream
    `absent`, which is the honest answer rather than a silent empty one.
    """
    try:
        import attempt_log_format
    except ImportError:
        return None
    return attempt_log_format


def _aggregate(fmt, state, carried, reason=None):
    """One writer's outcome, widened to the whole file's completeness.

    The wrapper's own streams are reopened by every incarnation, so this is
    the path a restart actually takes. W198667 review 2026-09-18T06-53-11Z:
    a new success cannot prove an earlier missing tail arrived.
    """
    held = carried[0] if carried else None
    if held is None:
        return state, reason
    worse = fmt.worst(state, held)
    if worse == state:
        return state, reason
    return worse, (f"an earlier capture of this stream declared {held!r} and "
                   f"those bytes were never restored; this writer's own turn "
                   f"ended {state!r}, and what is in the file is not whole")


class _TeeStream:
    """One text stream, passed through UNCHANGED and copied into a log.

    WHAT THIS MAY NOT DO, and it is the whole design constraint: the protocol
    bytes are not its business. It wraps a DIAGNOSTIC stream, writes what it was
    given to that stream first, and only then copies the same text into the
    attempt's log. If the copy fails, the diagnostic still went where it was
    going -- a tee that could break the thing it observes would be worse than
    no tee.

    THE EARLIEST OUTPUT IS THE POINT. A provider-side capture cannot retain a
    failure that happens before the provider starts, and the reported incident
    was exactly such a failure: an empty stderr, an empty event namespace, and a
    container indistinguishable from a working one.
    """

    def __init__(self, stream, room, name, fmt):
        self._stream = stream
        self._room = room
        self._name = name
        self._fmt = fmt
        self._handle = None
        self._wrote = 0
        self._lost = False
        self._bytes = None
        # WHY, WHEN THERE IS A WHY. W198667 review 2026-09-18T06-27-53Z: this
        # wrapper reaches the shared opener BEFORE its own startup diagnostic,
        # and that opener now refuses a stream that is not a regular file this
        # room owns. An operator meeting `failed` deserves the sentence.
        self._why = []
        # WHAT EARLIER GENERATIONS OF THIS STREAM ALREADY LOST.
        self._carried = []

    def _opened(self):
        if self._handle is None and not self._lost:
            self._handle = self._fmt.append_writer(self._room, self._name,
                                                   self._why, self._carried)
            if self._handle is None:
                self._lost = True
        return self._handle

    def write(self, text):
        # THE REAL STREAM FIRST, ALWAYS.
        count = self._stream.write(text)
        self.wrote(text.encode("utf-8", "replace"))
        return count

    def flush(self):
        return self._stream.flush()

    @property
    def buffer(self):
        """THE BYTE BOUNDARY, teed as well -- and this was the defect.

        Review 2026-09-18T03-10-39Z [R1]: `__getattr__` handed back the REAL
        buffer, and `main` passes `sys.stdout.buffer` to `serve` -- so every
        protocol frame reached the caller byte-identically and reached the log
        not at all. The reviewer's probe wrote a binary frame inside the
        capture context and found `worker.stdout` absent. Preserving the
        protocol bytes and RETAINING them are two requirements, and bypassing
        the capture satisfied only the first.

        ONE HANDLE, TWO WRITERS, AND NO DOUBLE-COUNTING. The text path writes
        through the real text stream into the real buffer, so a byte written as
        text never also passes here; both paths append to this stream's single
        log handle, which is what keeps the file one account of one stream.
        """
        if self._bytes is None:
            self._bytes = _ByteTee(self._stream.buffer, self)
        return self._bytes

    def __getattr__(self, name):
        return getattr(self._stream, name)

    def wrote(self, payload):
        """One payload, appended to this stream's log. Answers nothing.

        Shared by the text and byte paths so the bookkeeping -- how much
        reached the file, and whether any of it was lost -- has one owner.
        """
        handle = self._opened()
        if handle is None:
            return
        moved = self._fmt.write_all(handle, payload)
        self._wrote += moved
        if moved != len(payload):
            self._lost = True

    def declare(self):
        """The writer's own word about what it captured, made durable.

        `failed` IS NOT "NOTHING HAPPENED". A stream this wrapper could not
        keep whole is declared as one, and `missing is not empty` is the rule
        the whole vocabulary exists for -- so a stream with nothing to say says
        nothing at all and stays `absent`, while one that was cut short says so.
        """
        if self._handle is not None:
            try:
                os.close(self._handle)
            except OSError:
                pass
            self._handle = None
        if self._lost:
            state = "failed"
        elif self._wrote:
            state = "finished"
        else:
            return None
        # AND THE COMPLETENESS OF EVERYTHING IN THE FILE, not only of what
        # this writer did. W198667 review 2026-09-18T06-53-11Z: a writer that
        # detected a short write declared `failed`, a second writer appended
        # cleanly, and the reader answered `captured` over a file whose middle
        # never arrived. A new success cannot prove an earlier missing tail,
        # so the worst state any generation of this stream has declared is
        # published with this one's.
        state, reason = _aggregate(self._fmt, state, self._carried,
                                   self._why[0] if self._why else None)
        try:
            return self._fmt.write_declaration(self._room, self._name, state,
                                               reason=reason)
        except Exception:                                  # noqa: BLE001
            return None



class _ByteTee:
    """One BINARY stream, passed through unchanged and copied into a log.

    W198667 review 2026-09-18T03-10-39Z [R1]. This is the boundary the protocol
    actually uses: `serve` frames on `sys.stdout.buffer`, so a text wrapper
    alone never saw a frame. The bytes reach the caller first and exactly, and
    the copy is best-effort by construction -- a tee that could break the
    channel it observes would be worse than no tee.
    """

    def __init__(self, stream, owner):
        self._stream = stream
        self._owner = owner

    def write(self, payload):
        # THE REAL CHANNEL FIRST, ALWAYS, AND UNCHANGED. Nothing here reorders,
        # re-encodes, delays or splits a frame.
        count = self._stream.write(payload)
        self._owner.wrote(bytes(payload))
        return count

    def flush(self):
        return self._stream.flush()

    def __getattr__(self, name):
        return getattr(self._stream, name)


class _WorkerCapture:
    """The wrapper's room, its tee, and its ending. A no-op without a room."""

    def __init__(self, place=None):
        self._fmt = _log_format()
        self._room = None
        self._tee = None
        self._held = None
        if self._fmt is None:
            return
        self._room = self._fmt.open_room(place or self._fmt.TARGET)

    def __enter__(self):
        if self._room is None:
            return self
        # BOTH STREAMS. Review 2026-09-18T02-31-51Z [2]: the selected scope is
        # the wrapper's stdout AND stderr, and omitting stdout was my own
        # narrowing rather than the contract's.
        #
        # THE PROTOCOL BYTES ARE NOT CHANGED, and that is the constraint this
        # is written to. `serve` frames on the stdout BUFFER -- `sys.stdout
        # .buffer`, passed as an operand -- so a text wrapper here never sees a
        # frame and cannot reorder, re-encode or delay one. What it retains is
        # the ordinary prose a wrapper prints, which is what an operator reads
        # and what previously vanished with the container.
        self._held = (sys.stdout, sys.stderr)
        self._tee = (_TeeStream(sys.stdout, self._room, "worker.stdout",
                                self._fmt),
                     _TeeStream(sys.stderr, self._room, "worker.stderr",
                                self._fmt))
        sys.stdout, sys.stderr = self._tee
        return self

    def __exit__(self, kind, value, trace):
        if self._tee is not None:
            for one in self._tee:
                one.declare()
            sys.stdout, sys.stderr = self._held
        if self._room is not None:
            try:
                os.close(self._room)
            except OSError:
                pass
            self._room = None
        return False


def main(argv=None, stdin=None, stdout=None, agent=None,
         place=LAUNCH_DOCUMENT, command_root=COMMAND_ROOT,
         event_root=EVENT_ROOT):
    # NO ENVIRONMENT OPERAND AT ALL, W26291. It is not defaulted to `os.environ`
    # and then ignored: a parameter that still exists is a parameter something
    # can be threaded back through, and the supersession retains no fallback.
    #
    # `agent is None`, NOT `agent or`. W39770's review found the second half of
    # the same line: truthiness discarded an explicitly injected FALSEY adapter
    # and substituted the fixture, and only `None` means "nobody injected one".
    # An agent that defines `__bool__` or `__len__` is an ordinary object; a
    # seam that silently replaced it would run somebody else's agent under the
    # caller's assignment.
    # W198667: THE WRAPPER'S OWN STDERR IS RETAINED FROM HERE, which is before
    # the launch document is read and therefore before anything that can refuse
    # it. `_WorkerCapture` is a no-op in an image that does not carry the shared
    # format module, and it never fails this program: the diagnostic reaches the
    # real stream first and the copy is best-effort by construction.
    #
    # STDOUT IS TEED AT BOTH ITS LAYERS, and the earlier note here saying it was
    # deliberately not teed is superseded: retaining the protocol bytes and
    # preserving them are two requirements, and only the second was met. The
    # text layer and `sys.stdout.buffer` both append to one log handle, the real
    # channel is written first in each case, and nothing reorders or re-encodes
    # a frame. A wrapper that writes nothing at all still leaves `worker.stdout`
    # ABSENT, which is the honest answer -- missing is not empty.
    # W376586 review 2026-10-28T22-29-20Z, P1: THE AGENT IS PASSED THROUGH
    # UNRESOLVED, including `None`. `_scripted_default()` was evaluated HERE,
    # as an argument, so the reference image's adapter was constructed before
    # `serve` had read the launch -- and the amendment requires an unsupported
    # or unwrapped launch to refuse BEFORE adapter construction. `serve`
    # resolves the default after it has validated the delivery and selected
    # the transport. The injection seam is byte-unchanged for every caller
    # that supplies an agent.
    with _WorkerCapture():
        return serve(stdin or sys.stdin.buffer, stdout or sys.stdout.buffer,
                     agent, place, command_root, event_root)



def context_delivery(document):
    """Closed context launch validation at the image boundary."""
    import uuid
    fields = ("schema", "context_id", "use_id", "invocation_id", "attempt_id", "generation", "generation_digest", "mode", "conversation_id", "profile_digest", "delivery_digest", "invocation_binding_digest", "task_digest", "prompt_digest", "argv_digest", "cli_build", "model", "reported_model", "argv_policy_digest", "environment_policy_digest")
    held = document.get("provider_context")
    def refuse():
        raise WorkerFault("launch", "required provider context is malformed or disagrees")
    if document.get("schema") != CONTEXT_LAUNCH_SCHEMA or document.get("role") != "implementation" or document.get("transport") != EXCHANGE_TRANSPORT or type(held) is not dict or set(held) != set(fields):
        refuse()
    job = document.get("job_execution")
    if type(job) is not dict or held["attempt_id"] != job.get("attempt_id") or held["schema"] != "baton.provider-context-delivery/1":
        refuse()
    for key in fields:
        value = held[key]
        if key in ("generation", "generation_digest"):
            continue
        if type(value) is not str or not value or len(value) > 256:
            refuse()
        if key.endswith("digest") and (len(value) != 71 or not value.startswith("sha256:") or any(c not in "0123456789abcdef" for c in value[7:])):
            refuse()
    try:
        if str(uuid.UUID(held["conversation_id"])) != held["conversation_id"]:
            refuse()
    except ValueError:
        refuse()
    if type(held["generation"]) is not int or not 0 <= held["generation"] <= 2**53-1 or held["mode"] != ("restore" if held["generation"] else "open"):
        refuse()
    generation = held["generation_digest"]
    if held["generation"] == 0:
        if generation is not None:
            refuse()
    elif type(generation) is not str or len(generation) != 71 or not generation.startswith("sha256:") or any(c not in "0123456789abcdef" for c in generation[7:]):
        refuse()
    argv = {"program": "claude", "arguments": ["--print", "--dangerously-skip-permissions", "--output-format", "json"], "open": "--session-id", "restore": "--resume"}
    env = {"cwd": "/output", "home": "/run/baton/context/home", "keys": ["HOME", "PATH", "PYTHONPYCACHEPREFIX", "TMPDIR", "XDG_CACHE_HOME"], "ephemera": "fresh-per-child"}
    if held["argv_policy_digest"] != digest(argv) or held["environment_policy_digest"] != digest(env) or digest({key: value for key, value in held.items() if key != "invocation_binding_digest"}) != held["invocation_binding_digest"]:
        refuse()
    return dict(held)


def context_declaration(seen, declared):
    if seen.get("role") == "implementation" or seen.get("schema") == CONTEXT_LAUNCH_SCHEMA or "provider_context" in seen:
        context_delivery(seen)
    elif seen.get("role") not in ("review", "integration"):
        raise WorkerFault("input", "context receipt is reserved for implementation and isolated review")
    selected = [one for one in declared if one["name"] == "provider-context-receipt"]
    if len(selected) != 1:
        raise WorkerFault("input", "mandatory provider context receipt is missing")
    one = selected[0]
    limits = one["constraints"]
    if one["required"] is not False or one["type"] != "directory-result" or one["path"] != "provider-context-receipt" or limits["max_bytes"] != 16384 or limits["max_entries"] != 1 or limits["allowed_media_types"] != ["application/octet-stream"] or limits["link_policy"] != "forbid" or limits["validator_digest"] is not None:
        raise WorkerFault("input", "mandatory provider context receipt declaration disagrees")
    return one


if __name__ == "__main__":
    sys.exit(main())
