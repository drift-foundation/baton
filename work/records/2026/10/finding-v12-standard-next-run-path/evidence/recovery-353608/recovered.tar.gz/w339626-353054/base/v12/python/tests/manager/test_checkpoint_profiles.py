import os
import subprocess
import tempfile
import unittest

from baton_v12.checkpoint_profiles import (GitCheckpointProfile, checkpoint_ref,
                                           clean_vector, diff_vector,
                                           reset_vector, status_vector,
                                           tree_vector, update_ref_vector)
from baton_v12.source_profiles import ProfileRefusal


BASE = "a" * 40
HEAD = "b" * 40
TREE = "c" * 40


class CheckpointProfile(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.repository = os.path.join(self.temporary.name, "repository")
        os.mkdir(self.repository)
        self.commands = []

    def tearDown(self):
        self.temporary.cleanup()

    def runner(self, argv):
        self.commands.append(argv)
        if argv == tuple(status_vector(self.repository)):
            stdout = ""
        elif argv == tuple(["git", "-C", self.repository, "rev-parse",
                            "--verify", "HEAD"]):
            stdout = HEAD + "\n"
        elif argv == tuple(tree_vector(self.repository)):
            stdout = TREE + "\n"
        elif argv == tuple(diff_vector(self.repository, BASE, HEAD)):
            stdout = "a.txt\x00z.txt\x00"
        elif argv == tuple(update_ref_vector(
                self.repository, checkpoint_ref("line-1", 1), HEAD)):
            stdout = ""
        elif argv == tuple(["git", "-C", self.repository, "rev-parse",
                            "--verify",
                            checkpoint_ref("line-1", 1) + "^{commit}"]):
            stdout = HEAD + "\n"
        elif argv == tuple(tree_vector(
                self.repository, checkpoint_ref("line-1", 1))):
            stdout = TREE + "\n"
        else:
            self.fail(f"unexpected command: {argv!r}")
        return {"returncode": 0, "stdout": stdout, "stderr": ""}

    def test_freeze_retains_and_revalidates_exact_ref_tree_and_path_set(self):
        evidence = GitCheckpointProfile(self.runner).freeze(
            self.repository, line_id="line-1", revision=1,
            declared_base=BASE)
        self.assertEqual(evidence["reference"], checkpoint_ref("line-1", 1))
        self.assertEqual(evidence["head"], HEAD)
        self.assertEqual(evidence["tree"], TREE)
        self.assertEqual(evidence["paths"], ["a.txt", "z.txt"])
        self.assertIn(tuple(update_ref_vector(
            self.repository, checkpoint_ref("line-1", 1), HEAD)),
            self.commands)

    def test_checkpoint_refs_are_reserved_and_revision_vectors_are_unambiguous(self):
        reference = checkpoint_ref("line-1", 7)
        self.assertEqual(reference, "refs/baton/checkpoints/line-1/7")
        self.assertEqual(tree_vector(self.repository, reference)[-1],
                         reference + "^{tree}")
        with self.assertRaises(ProfileRefusal):
            update_ref_vector(self.repository, "refs/heads/main", HEAD)

    def test_dirty_candidate_refuses_before_ref_retention(self):
        def dirty(argv):
            if argv == tuple(status_vector(self.repository)):
                return {"returncode": 0, "stdout": "?? untracked\x00",
                        "stderr": ""}
            self.fail(f"unexpected command after dirty status: {argv!r}")
        with self.assertRaisesRegex(ProfileRefusal, "clean committed"):
            GitCheckpointProfile(dirty).freeze(
                self.repository, line_id="line-1", revision=1,
                declared_base=BASE)

    def test_runner_result_is_closed(self):
        with self.assertRaisesRegex(ProfileRefusal, "closed"):
            GitCheckpointProfile(lambda argv: {"returncode": 0}).freeze(
                self.repository, line_id="line-1", revision=1,
                declared_base=BASE)

    def test_real_git_keeps_an_old_checkpoint_after_the_line_advances(self):
        source = os.path.join(self.temporary.name, "source")
        line = os.path.join(self.temporary.name, "line")

        def git(*arguments):
            return subprocess.run(
                arguments, check=True, text=True, capture_output=True).stdout.strip()

        def runner(argv):
            completed = subprocess.run(argv, text=True, capture_output=True)
            return {"returncode": completed.returncode,
                    "stdout": completed.stdout, "stderr": completed.stderr}

        git("git", "init", "-q", source)
        git("git", "-C", source, "config", "user.name", "Baton Test")
        git("git", "-C", source, "config", "user.email", "baton@example.invalid")
        with open(os.path.join(source, "candidate.txt"), "w", encoding="utf-8") as writing:
            writing.write("base\n")
        git("git", "-C", source, "add", "candidate.txt")
        git("git", "-C", source, "commit", "-q", "-m", "base")
        base = git("git", "-C", source, "rev-parse", "HEAD")
        with open(os.path.join(source, "candidate.txt"), "w", encoding="utf-8") as writing:
            writing.write("source tip after declared base\n")
        git("git", "-C", source, "add", "candidate.txt")
        git("git", "-C", source, "commit", "-q", "-m", "later source tip")
        # Simulate a stop after clone and before the profile detached the line
        # to the declared base. Recovery adopts this checkout and clones no
        # second tree.
        git("git", "clone", "-q", source, line)
        profile = GitCheckpointProfile(runner)
        profile.materialize(source, line, base)
        self.assertEqual(git("git", "-C", line, "rev-parse", "HEAD"), base)
        git("git", "-C", line, "config", "user.name", "Baton Test")
        git("git", "-C", line, "config", "user.email", "baton@example.invalid")

        with open(os.path.join(line, "candidate.txt"), "w", encoding="utf-8") as writing:
            writing.write("first\n")
        git("git", "-C", line, "add", "candidate.txt")
        git("git", "-C", line, "commit", "-q", "-m", "first checkpoint")
        first = profile.freeze(line, line_id="line-real", revision=1,
                               declared_base=base)
        with open(os.path.join(line, "candidate.txt"), "w", encoding="utf-8") as writing:
            writing.write("second\n")
        git("git", "-C", line, "add", "candidate.txt")
        git("git", "-C", line, "commit", "-q", "-m", "second checkpoint")
        second = profile.freeze(line, line_id="line-real", revision=2,
                                declared_base=base)

        self.assertNotEqual(first["head"], second["head"])
        self.assertEqual(profile.validate(line, first, current=False), first)
        self.assertEqual(git("git", "-C", line, "rev-parse", first["reference"]),
                         first["head"])
        with self.assertRaisesRegex(ProfileRefusal, "no longer matches"):
            profile.validate(line, first, current=True)


if __name__ == "__main__":
    unittest.main()


class RestoringOneCheckoutToItsRetainedCheckpoint(unittest.TestCase):
    """W128692: `restore_checkpoint`, over a REAL disposable repository.

    A recorded runner proves which argv crossed; it cannot prove that the
    scratch is gone and the tree is the checkpoint's, which is the whole claim.
    So this builds an actual Git repository, dirties it the three ways an
    abandoned worker really does -- a modified tracked file, an untracked file
    and an ignored one -- and then asks whether the checkout came back.
    """

    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.repository = os.path.join(self.temporary.name, "line")
        os.mkdir(self.repository)
        self.environment = {"PATH": os.environ.get("PATH", "/usr/bin:/bin"),
                            "HOME": self.temporary.name,
                            "GIT_CONFIG_GLOBAL": os.devnull,
                            "GIT_CONFIG_SYSTEM": os.devnull,
                            "GIT_TERMINAL_PROMPT": "0",
                            "GIT_AUTHOR_NAME": "Baton Test",
                            "GIT_AUTHOR_EMAIL": "test@baton.invalid",
                            "GIT_COMMITTER_NAME": "Baton Test",
                            "GIT_COMMITTER_EMAIL": "test@baton.invalid"}
        self.git("init", "-q", "-b", "main")
        self.write("kept.txt", "the reviewed candidate\n")
        self.write(".gitignore", "ignored/\n")
        self.git("add", "--all")
        self.git("commit", "-q", "--message", "base")
        self.base = self.git("rev-parse", "HEAD").strip()
        self.write("kept.txt", "the corrected candidate\n")
        self.git("add", "--all")
        self.git("commit", "-q", "--message", "checkpoint")
        self.profile = GitCheckpointProfile(self.runner)
        self.evidence = self.profile.freeze(
            self.repository, line_id="line-1", revision=1,
            declared_base=self.base)

    def tearDown(self):
        self.temporary.cleanup()

    def runner(self, argv):
        """The deployment's command seam. NOT named `run`: that is
        `TestCase.run`, and shadowing it makes the case call itself."""
        answer = subprocess.run(list(argv), capture_output=True, text=True,
                                env=self.environment, timeout=30)
        return {"returncode": answer.returncode, "stdout": answer.stdout,
                "stderr": answer.stderr}

    def git(self, *arguments):
        answer = subprocess.run(["git", "-C", self.repository, *arguments],
                                capture_output=True, text=True,
                                env=self.environment, timeout=30)
        self.assertEqual(answer.returncode, 0, answer.stderr)
        return answer.stdout

    def write(self, name, body):
        place = os.path.join(self.repository, name)
        os.makedirs(os.path.dirname(place), exist_ok=True)
        with open(place, "w", encoding="utf-8") as handle:
            handle.write(body)

    def dirty(self):
        """The three kinds of scratch an abandoned worker really leaves."""
        self.write("kept.txt", "the abandoned round never finished this\n")
        self.write("scratch.txt", "untracked\n")
        self.write("ignored/build.log", "ignored\n")

    def test_a_dirty_checkout_comes_back_to_the_exact_checkpoint(self):
        head = self.git("rev-parse", "HEAD").strip()
        tree = self.git("rev-parse", "HEAD^{tree}").strip()
        body = open(os.path.join(self.repository, "kept.txt")).read()
        self.dirty()
        self.assertNotEqual(self.git("status", "--porcelain"), "")

        answered = self.profile.restore_checkpoint(self.repository,
                                                   self.evidence)

        self.assertEqual(answered, self.evidence)
        self.assertEqual(self.git("rev-parse", "HEAD").strip(), head)
        self.assertEqual(self.git("rev-parse", "HEAD^{tree}").strip(), tree)
        self.assertEqual(open(os.path.join(self.repository,
                                           "kept.txt")).read(), body)
        # THE SCRATCH IS GONE, tracked, untracked and ignored alike.
        self.assertEqual(self.git("status", "--porcelain",
                                  "--untracked-files=all"), "")
        self.assertFalse(os.path.exists(os.path.join(self.repository,
                                                     "scratch.txt")))
        self.assertFalse(os.path.exists(os.path.join(self.repository,
                                                     "ignored")))

    def test_the_retained_checkpoint_and_its_objects_survive_the_restore(self):
        """A restore that had to destroy the thing it restores to would be no
        recovery at all."""
        reference = self.evidence["reference"]
        self.dirty()
        self.profile.restore_checkpoint(self.repository, self.evidence)
        self.assertEqual(
            self.git("rev-parse", "--verify", reference + "^{commit}").strip(),
            self.evidence["head"])
        self.assertEqual(
            self.git("rev-parse", "--verify", reference + "^{tree}").strip(),
            self.evidence["tree"])
        # AND THE BASE OBJECT IS STILL REACHABLE, so nothing was pruned.
        self.assertEqual(
            self.git("rev-parse", "--verify",
                     self.evidence["base"] + "^{commit}").strip(),
            self.evidence["base"])
        # THE VALIDATION IS THE PROFILE'S OWN, run again from scratch.
        self.assertEqual(
            self.profile.validate(self.repository, self.evidence,
                                  current=True),
            self.evidence)

    def test_nothing_outside_the_nominated_checkout_is_named(self):
        """Each command addresses the held nominated object, preserving custody."""
        sibling = os.path.join(self.temporary.name, "custody")
        os.mkdir(sibling)
        with open(os.path.join(sibling, "retained.txt"), "w") as handle:
            handle.write("immutable sibling custody\n")
        seen = []
        real = self.runner
        nominated = os.stat(self.repository)

        def recording(argv):
            self.assertEqual(tuple(argv[:2]), ("git", "-C"), argv)
            # The descriptor must still be open at the receiving boundary.
            addressed = os.stat(argv[2])
            self.assertEqual((addressed.st_dev, addressed.st_ino),
                             (nominated.st_dev, nominated.st_ino), argv)
            self.assertNotIn(sibling, argv)
            seen.append(tuple(argv))
            return real(argv)

        self.profile = GitCheckpointProfile(recording)
        self.dirty()
        self.profile.restore_checkpoint(self.repository, self.evidence)
        self.assertTrue(seen)
        for argv in seen:
            self.assertEqual(argv[:2], ("git", "-C"), argv)
            self.assertNotIn(sibling, argv)
        target = seen[0][2]
        self.assertIn(tuple(reset_vector(target, self.evidence["head"])), seen)
        self.assertIn(tuple(clean_vector(target)), seen)
        self.assertEqual(
            open(os.path.join(sibling, "retained.txt")).read(),
            "immutable sibling custody\n")

    def test_a_moved_checkpoint_reference_refuses_before_any_write(self):
        """THE ORDERING IS THE CONTRACT. A restore that discovered its target
        was wrong AFTER discarding the scratch would have destroyed the only
        copy of the thing it cannot replace."""
        self.dirty()
        before = self.git("status", "--porcelain", "--untracked-files=all")
        self.git("update-ref", self.evidence["reference"], self.base)
        with self.assertRaises(ProfileRefusal):
            self.profile.restore_checkpoint(self.repository, self.evidence)
        self.assertEqual(
            self.git("status", "--porcelain", "--untracked-files=all"), before)

    def test_foreign_or_malformed_evidence_refuses_and_writes_nothing(self):
        self.dirty()
        before = self.git("status", "--porcelain", "--untracked-files=all")
        for spoiled in (dict(self.evidence, profile="not-git"),
                        {"profile": "git"},
                        dict(self.evidence, head="z" * 40)):
            with self.assertRaises(ProfileRefusal):
                self.profile.restore_checkpoint(self.repository, spoiled)
        self.assertEqual(
            self.git("status", "--porcelain", "--untracked-files=all"), before)

    def test_a_substituted_line_path_is_refused_before_any_destructive_act(
            self):
        """REVIEW 2026-09-09T15:50Z [P1], driven exactly as the reviewer drove
        it.

        The first cut validated the PATHNAME and the checkpoint CONTENTS. So
        renaming the nominated directory and leaving a symlink with its old
        name pointed the destructive commands at a tree OUTSIDE the line
        entirely: `-C` follows the link, and the outside checkout's scratch and
        tracked bytes went with it.
        """
        outside = os.path.join(self.temporary.name, "outside")
        os.rename(self.repository, outside)
        os.symlink(outside, self.repository)
        with open(os.path.join(outside, "outside-scratch.txt"), "w") as handle:
            handle.write("somebody else's uncommitted work\n")
        with open(os.path.join(outside, "kept.txt"), "w") as handle:
            handle.write("somebody else's tracked bytes\n")

        with self.assertRaises(ProfileRefusal):
            self.profile.restore_checkpoint(self.repository, self.evidence)

        # NOTHING OUTSIDE THE LINE WAS TOUCHED.
        self.assertTrue(os.path.exists(os.path.join(outside,
                                                    "outside-scratch.txt")))
        self.assertEqual(open(os.path.join(outside, "kept.txt")).read(),
                         "somebody else's tracked bytes\n")
        self.assertTrue(os.path.isdir(os.path.join(outside, ".git")))

    def test_a_substitution_between_the_writes_follows_the_held_object(self):
        """REVIEW 2026-09-09T16:04Z. A check before the command and another
        after it is still a PATHNAME comparison: the reviewer's runner replaced
        the path after the last check and before `reset` executed, and the
        outside tree was written anyway.

        The checkout is now HELD as an open directory descriptor and every
        command's path is derived from it immediately before running, so a
        substitution landing between the two writes redirects nothing: the
        second command follows the same object the first did, wherever its
        name has been moved to.
        """
        outside = os.path.join(self.temporary.name, "outside")
        os.mkdir(outside)
        with open(os.path.join(outside, "outside-scratch.txt"), "w") as handle:
            handle.write("somebody else's uncommitted work\n")
        moved = os.path.join(self.temporary.name, "moved")
        self.dirty()
        real = self.runner

        def substituting(argv):
            answer = real(argv)
            if "reset" in argv and not os.path.lexists(moved):
                os.rename(self.repository, moved)
                os.symlink(outside, self.repository)
            return answer

        GitCheckpointProfile(substituting).restore_checkpoint(
            self.repository, self.evidence)

        # THE OUTSIDE TREE IS UNTOUCHED, and the held checkout -- now under its
        # new name -- really was restored.
        self.assertTrue(os.path.exists(os.path.join(outside,
                                                    "outside-scratch.txt")))
        self.assertFalse(os.path.exists(os.path.join(moved, "scratch.txt")))
        self.assertFalse(os.path.exists(os.path.join(moved, "ignored")))

    def test_a_repository_that_is_a_link_is_refused_outright(self):
        linked = os.path.join(self.temporary.name, "linked")
        os.symlink(self.repository, linked)
        with self.assertRaises(ProfileRefusal):
            self.profile.restore_checkpoint(linked, self.evidence)

    def test_an_unsafe_repository_path_is_refused_by_the_vectors(self):
        for place in ("relative/line", "/tmp/../etc", "/tmp/a:b", ""):
            with self.assertRaises(ProfileRefusal):
                reset_vector(place, self.evidence["head"])
            with self.assertRaises(ProfileRefusal):
                clean_vector(place)

    def test_a_head_that_is_not_one_object_name_is_refused(self):
        """`reset --hard` takes one full object name and nothing else -- not a
        revision expression, not a ref, not a leading dash."""
        for head in ("HEAD~1", "refs/heads/main", "-f", "a" * 39, "A" * 40):
            with self.assertRaises(ProfileRefusal):
                reset_vector(self.repository, head)


class TheSupplementDeliversABaseTheSourceDoesNotHold(unittest.TestCase):
    """W202663 owner212383, review212486's pinned operands.

    The approved direct-target finalization delivers accepted candidates
    into the deployment's DEDICATED target repository and deliberately not
    into the separate nominated source -- so a next Job declaring that
    advanced base cloned a source that does not hold it (measured installed:
    the advanced commit present in the target, absent from the workspace).
    The supplement is PROFILE configuration, threaded from the deployment's
    own configured integration target: `materialize` reaches for it only
    when the declared base is absent after the source clone, fetches exactly
    that commit, and touches nothing otherwise. Line identity and the
    committed creation signature are unchanged.
    """

    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.source = os.path.join(self.temporary.name, "source")
        self.target = os.path.join(self.temporary.name, "target")
        self.line = os.path.join(self.temporary.name, "line")
        self.commands = []

        def runner(argv):
            self.commands.append(tuple(argv))
            completed = subprocess.run(argv, text=True, capture_output=True)
            return {"returncode": completed.returncode,
                    "stdout": completed.stdout, "stderr": completed.stderr}

        self.runner = runner
        self.vcs("init", "-q", self.source)
        self.configure(self.source)
        self.write(self.source, "candidate.txt", "base\n")
        self.vcs("-C", self.source, "add", "candidate.txt")
        self.vcs("-C", self.source, "commit", "-q", "-m", "base")
        self.base = self.vcs("-C", self.source, "rev-parse", "HEAD")
        # THE ADVANCED COMMIT LIVES ONLY IN THE TARGET, exactly the measured
        # installed shape: the target is a clone that moved one commit past
        # the source.
        self.vcs("clone", "-q", self.source, self.target)
        self.configure(self.target)
        self.write(self.target, "candidate.txt", "accepted candidate\n")
        self.vcs("-C", self.target, "add", "candidate.txt")
        self.vcs("-C", self.target, "commit", "-q", "-m", "accepted")
        self.advanced = self.vcs("-C", self.target, "rev-parse", "HEAD")

    def vcs(self, *arguments):
        return subprocess.run(
            ["git"] + list(arguments), check=True, text=True,
            capture_output=True).stdout.strip()

    def configure(self, place):
        self.vcs("-C", place, "config", "user.name", "Baton Test")
        self.vcs("-C", place, "config", "user.email", "baton@example.invalid")

    @staticmethod
    def write(place, name, body):
        with open(os.path.join(place, name), "w", encoding="utf-8") as handle:
            handle.write(body)

    def supplement_fetches(self):
        return [one for one in self.commands
                if "fetch" in one and self.target in one]

    def test_a_base_only_the_target_holds_materializes_through_it(self):
        profile = GitCheckpointProfile(self.runner, supplement=self.target)
        answer = profile.materialize(self.source, self.line, self.advanced)
        # THE CLOSED EVIDENCE SHAPE IS DELIBERATELY UNCHANGED -- create_line
        # validates exactly this set.
        self.assertEqual(set(answer), {"profile", "base", "head"})
        self.assertEqual(answer["base"], self.advanced)
        self.assertEqual(
            self.vcs("-C", self.line, "rev-parse", "HEAD"), self.advanced)
        self.assertEqual(len(self.supplement_fetches()), 1)

    def test_a_base_the_source_holds_never_touches_the_supplement(self):
        profile = GitCheckpointProfile(self.runner, supplement=self.target)
        profile.materialize(self.source, self.line, self.base)
        self.assertEqual(
            self.vcs("-C", self.line, "rev-parse", "HEAD"), self.base)
        self.assertEqual(self.supplement_fetches(), [])

    def test_a_base_in_neither_repository_refuses_naming_both(self):
        profile = GitCheckpointProfile(self.runner, supplement=self.target)
        with self.assertRaises(ProfileRefusal) as caught:
            profile.materialize(self.source, self.line, "f" * 40)
        self.assertIn(self.source, str(caught.exception))
        self.assertIn(self.target, str(caught.exception))
        # AND THE DELIVERY'S OWN CAUSE RIDES INSIDE, review212545 [R2]: a
        # supplement that does not hold the commit and one that cannot be
        # reached are different operator facts.
        self.assertIn("did not provide it", str(caught.exception))

    def test_a_non_absence_detach_refusal_speaks_as_itself(self):
        """Review212545 [R2]'s probe, as a regression: the base in BOTH
        repositories and the detach blocked by a private index.lock. The
        earlier catch-all fetched anyway and falsely claimed the base was in
        neither; absence is proved first now, so the checkout's own refusal
        propagates and the supplement is never touched."""
        self.vcs("clone", "-q", self.source, self.line)
        os.makedirs(os.path.join(self.line, ".git"), exist_ok=True)
        with open(os.path.join(self.line, ".git", "index.lock"), "w"):
            pass
        profile = GitCheckpointProfile(self.runner, supplement=self.target)
        with self.assertRaises(ProfileRefusal) as caught:
            profile.materialize(self.source, self.line, self.base)
        self.assertIn("declared-base checkout", str(caught.exception))
        self.assertNotIn("neither", str(caught.exception))
        self.assertEqual(self.supplement_fetches(), [])

    def test_a_failed_delivery_preserves_its_own_cause(self):
        """An unreachable supplement is not 'in neither': the named refusal
        carries the delivery failure verbatim."""
        nowhere = os.path.join(self.temporary.name, "not-a-repository")
        os.mkdir(nowhere)
        profile = GitCheckpointProfile(self.runner, supplement=nowhere)
        with self.assertRaises(ProfileRefusal) as caught:
            profile.materialize(self.source, self.line, self.advanced)
        said = str(caught.exception)
        self.assertIn("absent from the clone", said)
        self.assertIn(nowhere, said)
        self.assertIn("supplement object delivery failed", said)

    def test_a_fatal_presence_query_is_not_absence(self):
        """Review212593 [R2]: exit 128 is a repository/query FAILURE, and
        treating it as absence permitted a fetch over an unanswerable clone
        followed by a false absence assertion. The query failure now raises
        as itself, before any delivery."""
        self.vcs("clone", "-q", self.source, self.line)
        with open(os.path.join(self.line, ".git", "HEAD"), "w",
                  encoding="utf-8") as handle:
            handle.write("not a reference at all\n")
        profile = GitCheckpointProfile(self.runner, supplement=self.target)
        with self.assertRaises(ProfileRefusal) as caught:
            profile.materialize(self.source, self.line, self.advanced)
        self.assertIn("object-presence query failed", str(caught.exception))
        self.assertNotIn("neither", str(caught.exception))
        self.assertEqual(self.supplement_fetches(), [])

    def test_a_malformed_presence_answer_is_refused_not_read(self):
        """Every runner field is validated: stdout=None / stderr=[] violate
        the closed command-result contract and refuse rather than being
        read around."""
        real = self.runner

        def lying(argv):
            if "--verify" in argv and "--quiet" in argv:
                return {"returncode": 1, "stdout": None, "stderr": []}
            return real(argv)

        profile = GitCheckpointProfile(lying, supplement=self.target)
        with self.assertRaises(ProfileRefusal) as caught:
            profile.materialize(self.source, self.line, self.advanced)
        self.assertIn("streams are text", str(caught.exception))
        self.assertEqual(self.supplement_fetches(), [])

    def test_no_supplement_keeps_the_refusal_exactly_as_it_was(self):
        profile = GitCheckpointProfile(self.runner)
        with self.assertRaises(ProfileRefusal) as caught:
            profile.materialize(self.source, self.line, self.advanced)
        self.assertNotIn("supplement", str(caught.exception))
        self.assertEqual(self.supplement_fetches(), [])


class AnExistingCheckoutRecoversWhenTheSourceGainsTheBase(
        TheSupplementDeliversABaseTheSourceDoesNotHold):
    """W202663 claim225345 (review225331): the PR flow's human acceptance
    puts the accepted commit into the NOMINATED SOURCE after the line was
    cloned, and the resumed checkout used to reach only for the
    dedicated-target supplement -- so the retry looped on the same absence
    forever (measured installed at claim222268, B's reserved attempt). The
    nominated source is refreshed FIRST on the SAME line now, causes
    preserved, and the supplement fallback stands exactly as accepted.
    """

    def test_the_same_line_recovers_after_the_source_gains_the_base(self):
        from baton_v12.source_profiles.checkout import ProfileRefusal

        profile = GitCheckpointProfile(self.runner)  # NO supplement at all
        profile.materialize(self.source, self.line, self.base)
        # The retry declares the accepted commit, which for now lives only
        # in the separate target: absent from the source, absent from the
        # existing clone -- the measured installed shape.
        with self.assertRaises(ProfileRefusal):
            profile.materialize(self.source, self.line, self.advanced)
        # THE HUMAN ACCEPTANCE, ref-carrying, into the nominated source.
        self.vcs("-C", self.source, "fetch", "-q", self.target,
                 self.advanced + ":refs/heads/accepted")
        answer = profile.materialize(self.source, self.line, self.advanced)
        self.assertEqual(answer["base"], self.advanced)
        self.assertEqual(
            self.vcs("-C", self.line, "rev-parse", "HEAD"), self.advanced)
        self.assertEqual(self.supplement_fetches(), [],
                         "no supplement was configured or touched")

    def test_a_clean_refresh_finding_nothing_still_reaches_the_supplement(
            self):
        profile = GitCheckpointProfile(self.runner, supplement=self.target)
        profile.materialize(self.source, self.line, self.base)
        # The source never gains the commit; the refresh finds nothing and
        # the accepted supplement path delivers exactly as before.
        answer = profile.materialize(self.source, self.line, self.advanced)
        self.assertEqual(answer["base"], self.advanced)
        self.assertEqual(
            self.vcs("-C", self.line, "rev-parse", "HEAD"), self.advanced)
        self.assertEqual(len(self.supplement_fetches()), 1)


class AFailedRefreshTravelsWithTheSupplementRefusal(
        TheSupplementDeliversABaseTheSourceDoesNotHold):
    """review225408's diagnostic regression: when the nominated-source
    refresh itself fails AND the supplement then refuses, the refresh
    failure used to vanish -- an operator read only the supplement half
    and missed that the source could not even be asked. Both causes
    travel now, verbatim."""

    def test_both_failure_causes_appear_in_the_refusal(self):
        import shutil

        from baton_v12.source_profiles.checkout import ProfileRefusal

        profile = GitCheckpointProfile(self.runner, supplement=self.target)
        profile.materialize(self.source, self.line, self.base)
        # A commit that exists NOWHERE the line can reach, and a source
        # that cannot even be asked: the refresh fails, and the supplement
        # (which also lacks the commit) refuses after it.
        shutil.rmtree(self.source)
        absent = "d" * 40
        with self.assertRaises(ProfileRefusal) as caught:
            profile.materialize(self.source, self.line, absent)
        self.assertIn("supplement delivery", str(caught.exception))
        self.assertIn("nominated-source refresh also failed",
                      str(caught.exception))
