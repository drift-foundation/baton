"""W36540 — unconditional manager custody over an ended attempt's directories.

THE DEFECT THIS EXISTS TO REMOVE, measured on a real daemon under W33936's
corrected mechanism with the container proved absent: a directory the worker
created WITH CONTENT IN IT cannot be removed by the manager. Its mode comes
from the worker's umask -- measured `drwxr-sr-x`, so the group has no write --
and the manager owns neither the directory nor a way to `chmod` it. `os.chmod`
is EPERM and unlinking inside it is EACCES. Any real worker creates populated
subdirectories, so this leaves trees the manager cannot remove.

That is a CONSEQUENCE of the approved mechanism rather than a defect in it.
The configured group grants write on the workspace ROOT; what the worker
creates inside is the worker's, and W33936 correctly made the failure honest
rather than widening anything to get past it.

APPROVER RULING M36166 fixes both what is required and what may not be used.

THE REQUIRED INVARIANT is UNCONDITIONAL: after fencing and proving the exact
worker container absent, this manager must be able to inspect, read, hash,
archive, normalize and recursively delete EVERY object in that attempt's exact
workspace and result directories, REGARDLESS OF WORKER-SELECTED MODES.

EXPLICITLY NOT THE MECHANISM: a worker umask of `002`. It may improve the
cooperative path and it cannot be custody, because custody may not depend on
the worker having cooperated. A worker that sets its own umask back, or writes
one directory `0700` on purpose, defeats it -- and a custody property that an
uncooperative worker can switch off is not a property.

THE MECHANISM IS A SHORT-LIVED CUSTODY HELPER, and the whole of its design is
in three constraints:

ONE MOUNT, THE EXACT ATTEMPT DIRECTORY. Not the storage root, not the inputs,
not the launch or credential roots, not the repository. Absent rather than
denied: a path that is not mounted cannot be reached by any means, which is a
stronger statement than a permission check and one that survives a bug in the
program it is running.

THE OWNING WORKER IDENTITY. This is the part that makes the custody
unconditional, and it is worth stating plainly: the helper runs as the SAME
uid the worker ran as, so it OWNS every object the worker created. An owner
may always `chmod` its own objects, whatever mode they currently carry -- so
there is no mode a worker can choose that locks the custodian out. The manager
never acquires that ownership itself and never needs to.

TYPED MANAGER-OWNED OPERATIONS ONLY. The vocabulary below is closed and the
program that runs inside is a constant of this module. There is no operand
through which a worker or a caller names a command, a path outside the attempt
directory, or a second mount -- because there is no command operand at all,
only a verb this module recognises.

WHAT THE HELPER IS NOT TRUSTED TO DO. It normalizes; the MANAGER removes. The
containment rules, the "remove only what this component created" rule and the
storage-root check stay exactly where they are, on this side, because those
are the rules that make a deletion safe and they are not the helper's to
re-derive.
"""

import hashlib
import os
import re
import stat
from types import MappingProxyType

from ..contracts import ContractRefusal
from ..contracts.errors import name_value
from . import boundaries

# W36540 review [P0], round nine: `CustodyRoot` and `attempt_custody_root` are
# GONE from the surface rather than hardened again. Both were path-bearing
# objects a caller held between the authenticated lookup and the use, and every
# defence over nine rounds was a defence on the wrong side of that interval.
# There is no interval now: `custody_act` reads the durable record, composes
# the argv and runs it in one act.
#
# W36540 review [P0], round ten: `custody_vector` is GONE from the surface for
# the same reason `CustodyRoot` was. Returning the composed argv put the
# authenticated bind source in a caller-held mutable list between the durable
# lookup and the engine use -- the same interval, one layer further out, and a
# frozen argv would not have closed it either, because a caller holding a path
# can compose its own vector. `custody_act` performs the act: it looks up,
# composes, RUNS and answers, and what comes back is an answer rather than a
# capability.
__all__ = ["CUSTODY_OPERATIONS", "CUSTODY_ROOT", "CUSTODY_PROGRAM",
           "CUSTODY_ROOTS", "CustodyAnswer", "check_custody_operation",
           "custody_act"]


# THE CLOSED VOCABULARY, exactly M36166's six.
#
# `normalize` and `discard` are the two this build composes into an ending;
# the other four are the custody the ruling requires the manager to BE ABLE to
# perform over the same directory, and they are named here rather than added
# later because a vocabulary that grows one verb at a time is not closed.
CUSTODY_OPERATIONS = ("inspect", "read", "hash", "archive", "normalize",
                      "discard")

# WHAT EACH VERB ANSWERS, closed and typed, and it is the RECEIVING half of
# the same rule `check_custody_operation` is the sending half of.
#
# W36540 review (2026-08-30T04:07:53Z) [P1]: the act validated the verb it
# SENT and nothing about the document that came back, so a zero exit carrying
# any JSON object at all was reported as custody. A `normalize` act whose
# stdout ended `{"custody": "inspect", "entries": []}` was `ok`. Zero plus an
# unrelated document is no stronger an account than zero plus no document,
# which this module already refuses.
#
# `CUSTODY_PROGRAM` is a constant of this module, so what it can print is
# exactly known and is written down rather than guessed at. The two tables
# must agree, and a member added to one without the other fails here -- which
# is the point: an answer this manager cannot recognise is not one it accounts
# for.
# W257624 R2: `submission` IS PART OF EVERY RESULT. It is the token the
# manager committed for that exact act, echoed back by the program above, and
# it is what makes one answer belong to one submission rather than to any act
# over the same root. A result without it is not this contract's result.
_CUSTODY_RESULT = {
    "inspect": {"submission": str, "entries": list, "running_as": list},
    "read": {"submission": str, "entries": list, "total_bytes": int,
             "running_as": list},
    "hash": {"submission": str, "entries": list, "total_bytes": int,
             "running_as": list},
    "archive": {"submission": str, "entries": list, "total_bytes": int,
                "running_as": list, "content": str, "tree_digest": str},
    "normalize": {"submission": str, "entries": int, "not_ours": int,
                  "running_as": list},
    "discard": {"submission": str, "removed": int, "kept": int,
                "running_as": list},
}

# THE CUSTODIAN'S OWN REFUSAL, which is the other document the program can
# print. It is accountable -- it says the act did not happen and why -- but it
# is never a successful account of the verb that was asked for.
_CUSTODY_REFUSED = "refused"
_CUSTODY_REFUSAL = {"why": str}

# WHERE THE ONE MOUNT LANDS. Fixed rather than composed, because a container
# path a caller could choose is an operand that decides what the program walks.
CUSTODY_ROOT = "/custody"

# A NAME THIS MANAGER CAN RECOGNISE AFTERWARDS, and the reason it is a prefix
# rather than a label: a custody helper that outlives its act has to be
# findable by a restarted manager that never saw it start.
#
# W43974: IT IS READ NOW. For the whole of W36540 this was a constant the
# record mentioned and no code path used, while `name` arrived as an ordinary
# caller operand -- so the reclamation this Work owed was impossible by
# construction, because a name a caller chose is a name a restarted manager
# cannot re-derive. `_custody_identity` derives it; nothing takes it.
CUSTODY_NAME = "baton-custody"

# How much of the digest rides in the name. 128 bits, which is collision
# resistance nobody reaches, and it keeps the whole identity inside `_NAME`'s
# own bound rather than making the bound an exception for this one composer.
_IDENTITY_HEX = 32

_NAME = re.compile(r"[a-z0-9][a-z0-9._-]{0,60}")

# HOW LONG ONE CUSTODY ACT MAY TAKE, and it is this module's number rather
# than a caller's. The custodian arms it against itself -- see
# `CUSTODY_PROGRAM` -- because no engine has a run deadline and the injected
# run capability's timeout belongs to whoever injected it.
#
# Generous on purpose: a `discard` over a large worker tree is real work, and
# a bound that ordinary work reaches turns custody into a failure. What it
# rules out is an act that is not going to end.
CUSTODY_SECONDS = 1800

# THE MANAGER'S OWN BOUND ON THE WHOLE ENGINE CALL, and the review that
# required it is right that the alarm above cannot be it.
#
# W43974 review (2026-08-30T05:15:08Z) [P0]: `CUSTODY_SECONDS` starts when the
# custodian's Python program starts, so it bounds the act and nothing before
# it -- an image pull that stalls, a daemon that never answers, a call that
# loses its result after launch. The first round named an `EnginePort`
# deadline out of scope and left this child's central acceptance unmet.
#
# LARGER THAN THE ALARM DELIBERATELY. The inner refusal is how an overrun is
# ordinarily reported, because it is typed, accountable and names the bound it
# crossed; this is the backstop for a call that never reaches the program at
# all. If they were equal the backstop would race the account and an ordinary
# slow act would come back as a lost one.
CUSTODY_ACT_SECONDS = CUSTODY_SECONDS + 300

# THE SAME BOUND ON EVERY RECLAMATION CALL. Reclamation is what runs when
# something has already gone wrong, so an unbounded stop or inspect there is
# the failure mode this whole child exists to remove, one layer in.
CUSTODY_RECLAIM_SECONDS = 120

# How long a stop order is given before the removal forces it. Short, because
# a custodian has nothing to flush and nothing to shut down gracefully: it is
# being ended precisely because nobody can collect what it was going to say.
CUSTODY_STOP_SECONDS = 5


def _settled(port, argv, *, seconds, what):
    """One engine call that is OVER by the time this returns OR raises.

    W43974 review (2026-08-30T05:28:16Z) [P0]. The second round ran the call
    on a daemon thread and abandoned it on expiry, which bounded THE WAIT and
    nothing else. The abandoned call was still free to finish a stalled image
    pull and create the helper -- after recovery had listed, inspected and
    proved that exact name absent. **The deadline manufactured the stranded
    helper this child exists to prevent.**

    A thread this manager stops waiting for is not a cancelled engine
    operation, and it is not a reaped OS child. Nothing inside this process
    can cancel a synchronous callable it did not write; the party that spawned
    the child is the only one that can end it.

    SO THE CONTRACT MOVED TO THE BOUNDARY. The capability this manager is
    given must accept `seconds` and must have TERMINATED AND REAPED its child
    before it answers -- which is exactly what `subprocess.run(argv,
    timeout=seconds)` does: it kills the child, waits for it, and only then
    raises. There is no interval afterwards for a late mutation to happen in,
    because there is nothing still running. A capability that cannot even be
    given the deadline is refused on the act's FIRST call, which is a
    read-only listing -- so the wrong shape is found before anything has been
    created or removed.

    WHAT THIS MANAGER STILL CANNOT VERIFY, said plainly rather than implied: a
    capability that accepts `seconds` and ignores it. That is the same class
    of trust as handing it an argv and believing it ran that argv, and it is
    the trust boundary `EnginePort` has always been. What changed is that
    honouring the deadline is now part of the contract instead of an optional
    kindness, and a capability that cannot even receive it is refused before
    any engine call.

    Every failure becomes a typed refusal naming which call it was, because a
    reclamation that could not complete is UNRESOLVED, and unresolved is the
    one state a custody act must not proceed from.
    """
    from .oci import _denied

    try:
        return port(argv, seconds=seconds)
    except ContractRefusal:
        raise
    except TypeError:
        # THE CAPABILITY CANNOT BE GIVEN THE DEADLINE, which is refused rather
        # than worked around. This is the FIRST call a custody act makes and
        # it is a read-only listing, so a capability of the wrong shape is
        # discovered before anything has been created or removed.
        #
        # A pre-flight signature check was written and removed: `inspect` is
        # not in the manager's ruled dependency set, and adding a stdlib
        # module to that allowlist to gain a check the first call already
        # performs is the wrong trade. Failing on a `ps` is early enough.
        _denied(f"{what} could not be given this manager's deadline; a "
                f"custody act needs an engine capability that accepts "
                f"`seconds` and has terminated and reaped its child before it "
                f"answers, because one this manager cannot bound is one that "
                f"can strand the helper it is trying to reclaim")
    except Exception as failed:
        # `Exception` AND NOT `BaseException`. W43974 review
        # (2026-08-30T05:44:32Z) [P1]: the second round ruled that process
        # control propagates, and the third round kept that rule for the act's
        # own call while every reclamation step went through here and reversed
        # it -- so a `KeyboardInterrupt` during a read-only listing was
        # reported as an ordinary policy denial. An operator ending the
        # process is not an engine failure and this module does not get to
        # relabel it as one.
        _denied(f"{what} did not complete within {seconds}s or could not be "
                f"performed ({type(failed).__name__}); a custody act does not "
                f"proceed from a reclamation step whose outcome this manager "
                f"cannot settle")


def _custody_identity(store_place, assignment_id, which, operation):
    """The ONE name this act's helper can have, DERIVED and never chosen.

    W43974. `name` was a caller operand for eleven rounds, so a manager that
    restarted could not name the helper its predecessor had started, and
    `--rm` -- which reclaims only on the engine's normal completion path --
    was the whole of the lifetime story.

    WHAT IS IN THE DIGEST, and each part earns its place:

      * the configured workspace STORE, because the identity has to be unique
        to a DEPLOYMENT and not merely to an attempt -- two managers on one
        host with different stores may hold the same attempt name. It is a
        digest input and reaches no name, answer or diagnostic;
      * the ATTEMPT, the ROOT KIND and the VERB, because those are what make
        one act different from another over the same tree.

    WHAT IS DELIBERATELY NOT IN IT is the store's incarnation. A restarted
    manager is a new incarnation, and an identity it cannot re-derive is one
    it cannot reclaim -- which is the entire defect this function exists for.

    The derivation follows `oci._runtime_name`'s rule rather than inventing
    one: the manager's own identity decides the name, and the engine's
    alphabet never decides the identity.
    """
    from ..contracts.canonical import digest

    found = (CUSTODY_NAME + "-"
             + digest({"store": store_place, "assignment_id": assignment_id,
                       "which": which, "operation": operation})
             [len("sha256:"):][:_IDENTITY_HEX])
    if not _NAME.fullmatch(found):
        # UNREACHABLE BY CONSTRUCTION and asserted anyway: this is the one
        # place a name is made, so a derivation that stopped satisfying the
        # module's own rule must fail here rather than at a daemon.
        raise ContractRefusal(
            "integrity", "schema",
            f"the derived custody identity {name_value(found)} is not a name "
            f"this build composes")
    return found


def check_custody_operation(operation):
    """One verb from the closed vocabulary, or a refusal.

    THE RECEIVING END OF THE RULING'S "no worker-supplied command". A verb is
    not a command: it selects among programs this module owns, and a value
    that is not one of the six selects nothing at all.
    """
    boundaries.text(operation, "a custody operation")
    if operation not in CUSTODY_OPERATIONS:
        raise ContractRefusal(
            "integrity", "schema",
            f"{name_value(operation)} is not a custody operation; the six "
            f"this manager owns are {', '.join(CUSTODY_OPERATIONS)}, and a "
            f"custody act is chosen from that vocabulary rather than "
            f"described by its caller")
    return operation


def check_custody_root(which):
    """One root kind from the closed pair, or a refusal.

    W43977. The rule existed three times as an inline `if` -- in
    `_derived_root`, and again at each public entry that had to refuse before
    acting -- which is three places to edit and, as the boundary inventory
    puts it, a rule owned nowhere. It is the same shape
    `check_custody_operation` already has for the verb, and for the same
    reason: a root kind SELECTS among directories this manager allocated, so
    a value that is not one of the two selects nothing at all.
    """
    boundaries.text(which, "a custody root name")
    if which not in CUSTODY_ROOTS:
        raise ContractRefusal(
            "integrity", "schema",
            f"{name_value(which)} is not a custody root; the two an attempt "
            f"has are {', '.join(CUSTODY_ROOTS)}, and their parent holds the "
            f"deliveries and is never mounted")
    return which


# THE PROGRAM, AND IT IS A CONSTANT OF THIS MODULE.
#
# It takes ONE argument -- the verb -- and validates it against its own copy of
# the vocabulary, so the closed set is enforced at both ends of the crossing
# rather than only on the composing side. It walks nothing but its own mount.
#
# `normalize` is the act that removes the defect: running as the owner of the
# worker's objects, it restores group access on every directory and file under
# the mount, so the MANAGER's own removal walk can then proceed under its own
# containment rules. It does not delete, and it does not touch anything above
# its mount because there is nothing above its mount to touch.
_CUSTODY_SOURCE = r'''
import base64, hashlib, json, os, signal, sys

ROOT = "/custody"
VERBS = ("inspect", "read", "hash", "archive", "normalize", "discard")

# THE ACT'S OWN DEADLINE, armed against itself.
#
# W43974. No engine has a run deadline, and the manager's injected run
# capability owns whatever transport timeout exists -- which is somebody
# else's number and, more to the point, cannot tell a slow act from a wedged
# one. This can: the bound is enforced where the work happens, and expiry
# prints the module's own typed refusal rather than dying silently and
# leaving a zero-length stdout for the manager to fail to account for.
#
# SECONDS is substituted by the composing module, so the number lives in one
# place and travels into the program the manager ships.
SECONDS = __SECONDS__


def expired(number, frame):
    print(json.dumps({"custody": "refused",
                      "why": "the act did not finish within %ds" % SECONDS}))
    # `_exit`, not `SystemExit`: an alarm can land inside a `try` this program
    # does not own, and an exception an ordinary handler swallows is a
    # deadline that did not apply.
    sys.stdout.flush()
    os._exit(3)


signal.signal(signal.SIGALRM, expired)
signal.alarm(SECONDS)

# How much of a file is read at once. Constant memory is the whole point: a
# worker file larger than this container's memory bound must not be able to
# end the custody act.
CHUNK = 1 << 20

# How many bytes of one file `read` carries back in its answer. Bounded
# because the answer is one JSON document on a pipe, and stated in the answer
# itself through `complete` so a partial carry is never mistaken for the file.
MAX_CARRIED = 1 << 16

verb = sys.argv[1] if len(sys.argv) > 1 else ""
if verb not in VERBS:
    print(json.dumps({"custody": "refused", "why": "unknown operation"}))
    raise SystemExit(2)

# W257624 R2: THE SUBMISSION TOKEN, echoed so one answer belongs to one act.
#
# The manager commits an opaque per-submission value before this program is
# ever sent, and hands it in here as INERT INPUT: it is never a path, a mount,
# a command or a name this program acts on -- it is read, checked for shape,
# and printed back. Two submissions over one root are otherwise
# indistinguishable, because the helper identity deliberately excludes the
# episode so a restarted manager can re-derive it.
#
# CHECKED BEFORE ANYTHING IS TOUCHED. A missing or malformed token is a
# refusal, not a mutation with a bad label: the root is left exactly as it was.
SUBMISSION = sys.argv[2] if len(sys.argv) > 2 else ""
if type(SUBMISSION) is not str or not SUBMISSION \
        or len(SUBMISSION) > 128 \
        or any(one not in "0123456789abcdef" for one in SUBMISSION):
    print(json.dumps({"custody": "refused",
                      "why": "the act carries no readable submission token"}))
    raise SystemExit(2)

MINE = os.getuid()


def owned(place):
    held = os.lstat(place)
    return held.st_uid == MINE, held


def openable(place):
    """Make one OWNED directory traversable BEFORE anything descends into it.

    Review [P0]: the first cut walked bottom-up, so `os.walk` had to enter a
    directory before the pass that would have made it enterable -- and a
    mode-zero directory inside a mode-zero directory was silently omitted
    from the walk entirely. Only the outer one was ever changed, and the
    subtree below it stayed outside custody while the act reported success.

    Top-down, and each owned directory is opened on the way IN. That is the
    order that makes the property unconditional at any depth.
    """
    mine, held = owned(place)
    if mine and not held.st_mode & 0o100:
        os.chmod(place, (held.st_mode & 0o7777) | 0o700)


def walk():
    """Every entry under the mount, top-down, never following a link out.

    A SYMLINKED DIRECTORY IS EXCLUDED FROM DESCENT AND NOT FROM THE WALK.
    Review [P1]: the first correction dropped links out of `directories`
    before the yield, which stopped traversal -- correctly -- and also made
    the link OBJECT invisible. `inspect` answered an empty list for a root
    holding one directory symlink, and `discard` reported success while
    leaving it there. "Every object" includes the link itself: it stays
    observable and removable, and its target stays untouched.
    """
    for current, directories, files in os.walk(ROOT, topdown=True):
        descend, links = [], []
        for name in directories:
            place = os.path.join(current, name)
            if os.path.islink(place):
                links.append(name)
                continue
            openable(place)
            descend.append(name)
        directories[:] = descend
        # The links ride with the FILES, which is what they are to every act
        # here: one entry to report and one entry to unlink, never a way in.
        yield current, descend, files + links


def relative(place):
    return os.path.relpath(place, ROOT)


def every():
    for current, directories, files in walk():
        for name in files + directories:
            yield os.path.join(current, name)


if verb == "normalize":
    changed, skipped = 0, 0
    for place in every():
        if os.path.islink(place):
            continue
        mine, held = owned(place)
        if not mine:
            skipped += 1
            continue
        grant = 0o070 if os.path.isdir(place) else 0o060
        os.chmod(place, (held.st_mode & 0o7777) | grant)
        changed += 1
    print(json.dumps({"custody": "normalize", "submission": SUBMISSION,
                      "entries": changed,
                      "not_ours": skipped, "running_as": [MINE, os.getgid()]}))
    raise SystemExit(0)

if verb == "inspect":
    entries = []
    for place in every():
        held = os.lstat(place)
        entries.append({"path": relative(place),
                        "mode": oct(held.st_mode & 0o7777),
                        "uid": held.st_uid, "gid": held.st_gid,
                        "kind": ("link" if os.path.islink(place)
                                 else "directory" if os.path.isdir(place)
                                 else "file")})
    print(json.dumps({"custody": "inspect", "submission": SUBMISSION,
                      "entries": sorted(
        entries, key=lambda one: one["path"]),
        "running_as": [MINE, os.getgid()]}))
    raise SystemExit(0)

if verb in ("read", "hash", "archive"):
    # THE THREE READING ACTS SHARE ONE WALK and differ only in what they
    # answer about each file. A file this custodian cannot open after
    # `openable` has run is reported as unreadable rather than skipped: an
    # act that silently omitted an entry would be the same defect the
    # traversal correction removes.
    #
    # STREAMED, NEVER SLURPED. Review [P1]: every branch did
    # `handle.read()` into one bytes object before hashing it, so a worker
    # file larger than this container's 512 MiB terminated the custody act --
    # and an act a worker can end by writing a big file is not unconditional.
    # The digest is now computed over CHUNK reads at constant memory, so file
    # size decides how long the act takes and nothing else.
    #
    # AND THE HEAD IS BASE64 AND EXPLICITLY PARTIAL. It used to be
    # `body[:4096].decode("utf-8", "replace")`, which is lossy TWICE: it
    # stops at 4096 bytes without saying so, and it replaces every byte that
    # is not UTF-8 with U+FFFD -- so what came back was neither the file nor
    # a recoverable prefix of it. `complete` now says whether the carried
    # bytes ARE the file, and the bytes are carried unmangled.
    entries, total = [], 0
    for place in every():
        if os.path.islink(place) or os.path.isdir(place):
            continue
        mine, held = owned(place)
        if mine and not held.st_mode & 0o400:
            os.chmod(place, (held.st_mode & 0o7777) | 0o400)
        one = {"path": relative(place), "bytes": held.st_size}
        digest = hashlib.sha256()
        carried, measured = bytearray(), 0
        try:
            with open(place, "rb") as handle:
                while True:
                    chunk = handle.read(CHUNK)
                    if not chunk:
                        break
                    digest.update(chunk)
                    measured += len(chunk)
                    if verb == "read" and len(carried) < MAX_CARRIED:
                        carried += chunk[:MAX_CARRIED - len(carried)]
        except OSError as failure:
            one["unreadable"] = type(failure).__name__
            entries.append(one)
            continue
        total += measured
        # THE MEASURED SIZE, not the one `lstat` reported. A file that grew
        # or shrank between the two is a file whose recorded byte count would
        # otherwise disagree with its own digest.
        one["bytes"] = measured
        one["sha256"] = "sha256:" + digest.hexdigest()
        if verb == "read":
            one["content_base64"] = base64.b64encode(bytes(carried)).decode(
                "ascii")
            one["complete"] = measured <= MAX_CARRIED
        entries.append(one)
    answer = {"custody": verb, "submission": SUBMISSION,
              "entries": sorted(
        entries, key=lambda one: one["path"]), "total_bytes": total,
        "running_as": [MINE, os.getgid()]}
    if verb == "archive":
        # THE ARCHIVE IS A MANIFEST AND SAYS SO. What custody needs from this
        # act is a durable description of what was there; the bytes stay
        # where they are, and after `normalize` the manager reads them
        # directly under its own containment rules.
        #
        # WHETHER THAT SATISFIES "archive" IS AN OPEN RULING and is recorded
        # as one in the finding rather than decided here. Returning content
        # through this channel needs somewhere to put it, and M36166 fixes
        # ONE mount which is the custody subject itself -- writing an archive
        # into the tree under custody would change the thing being described.
        answer["content"] = "manifest-only"
        answer["tree_digest"] = "sha256:" + hashlib.sha256(json.dumps(
            [(one["path"], one.get("sha256"), one["bytes"])
             for one in answer["entries"]],
            sort_keys=True).encode("utf-8")).hexdigest()
    print(json.dumps(answer))
    raise SystemExit(0)

if verb == "discard":
    # RECURSIVE DELETE, bottom-up over a tree already made traversable on the
    # way down. Only what this custodian owns is removed; anything else is
    # counted and left, and the caller is told.
    removed, kept = 0, 0
    order = []
    for current, directories, files in walk():
        order.append((current, list(directories), list(files)))
    for current, directories, files in reversed(order):
        for name in files:
            place = os.path.join(current, name)
            mine, _held = owned(place)
            if not mine:
                kept += 1
                continue
            # A LINK IS UNLINKED, never followed: the entry goes and whatever
            # it pointed at is none of this act's business.
            os.unlink(place)
            removed += 1
        for name in directories:
            place = os.path.join(current, name)
            mine, _held = owned(place)
            if not mine:
                kept += 1
                continue
            try:
                os.rmdir(place)
                removed += 1
            except OSError:
                kept += 1
    print(json.dumps({"custody": "discard", "submission": SUBMISSION,
                      "removed": removed, "kept": kept,
                      "running_as": [MINE, os.getgid()]}))
    raise SystemExit(0)
'''

# THE FINISHED PROGRAM, with this module's deadline substituted in. The
# public constant is what actually runs -- the tests that drive the real
# custodian run THIS, so a template with an unsubstituted placeholder could
# not pass them unnoticed.
CUSTODY_PROGRAM = _CUSTODY_SOURCE.replace("__SECONDS__",
                                          str(CUSTODY_SECONDS))


# THE TWO DIRECTORIES A CUSTODY ACT MAY TOUCH, and they are the two the
# acceptance names: the attempt's exact workspace and its result directory.
# Never their parent, which is the assignment home and holds the deliveries.
CUSTODY_ROOTS = ("workspace", "result")


def _derived_root(store, assignment_id, which):
    """The one directory this act may mount, RE-OPENED from durable state.

    EIGHT REVIEW ROUNDS ENDED HERE, and the last two are one lesson. Rounds
    one to six closed doors onto a caller-held object the mint re-read -- a
    plain mapping, one with the expected basenames, the nominal
    `AllocatedRoots` type, that type with its `dict` mutators overridden, with
    `dict` removed from its bases, and with its members behind a private
    attribute. Round seven replaced the object with a derivation from
    `storage`, and found that deriving below a CALLER'S root is still caller
    path selection. Round eight made the store a configured record and handed
    it over as a `WorkspaceStorage`, and round nine found the same defect one
    layer out: `object.__setattr__` replaces a slotted member, so a capability
    minted from durable state and then HELD is a path a caller can still
    change before it is read.

    THE RULE THAT FINALLY FOLLOWS: the operation that selects the mount reads
    the durable record ITSELF, in the same act, and hands no path-bearing
    object to anybody. There is no interval between the authenticated lookup
    and the use, because they are one operation -- so there is nothing to
    retarget, no slot to overwrite and no later re-read to poison. This is
    why the function is private and why `_custody_vector` calls it rather than
    receiving its answer.

    THE STORE IS THE AUTHORITY, and it is not a path-bearing value object: it
    is this manager's own durable handle, and reading the deployment's
    configured store and group out of it is exactly the act the review asks
    for.
    """
    from .workspaces import (configured_workspace_group,
                             configured_workspace_storage, _real, _within)
    check_custody_root(which)
    boundaries.identity(assignment_id, "an assignment identity")
    # AN IDENTITY IS A NAME AND NEVER A PATH. `boundaries.identity` is
    # `boundaries.text` -- it owns durable text and says nothing about path
    # syntax -- so an attempt called `../../etc` would otherwise compose a home
    # outside the configured store before any containment check could see it.
    if os.sep in assignment_id or (os.altsep and os.altsep in assignment_id) \
            or assignment_id in (os.curdir, os.pardir):
        raise ContractRefusal(
            "policy", "denied",
            f"{name_value(assignment_id)} is not an assignment identity; an "
            f"attempt is NAMED and a name that carries a path separator is a "
            f"way to compose a home this manager never allocated")
    # READ HERE, USED HERE. The capability objects never leave this frame.
    group = configured_workspace_group(store)
    recorded = configured_workspace_storage(store).place
    root = _real(recorded, "the manager's workspace storage")
    home = os.path.join(root, assignment_id)
    workspace = os.path.join(home, "workspace")
    # EVERY EXISTING PARENT IS PROVED BEFORE ANYTHING IS CREATED. Review [P1],
    # round eight: this used to `os.makedirs` the result root FIRST, so a home
    # entry that was a symlink to another manager-owned directory had
    # `workspace/result` created inside the TARGET and only then raised. A
    # refusal that has already written through the alias has not preserved the
    # boundary it refused for.
    _no_link(home, what="the attempt home")
    _no_link(workspace, what="the attempt's workspace")
    if which == "workspace":
        place = workspace
    else:
        # THE MANAGER-OWNED RESULT LOCATOR, AND IT IS NEVER CREATED HERE.
        #
        # Review 2026-08-30T11:32:34Z [P0] and the approver's ruling that
        # settled it. Two things were wrong and they compounded:
        #
        #   THE PATH. This composed `workspace/result`. The retained untrusted
        #   directory every ending actually establishes is
        #   `workspace/result-<attempt-id>`, which is also `sealed_result`'s
        #   manager-derived `result_id`. Those are different directories, so
        #   wiring the old helper would have returned an accountable success
        #   over one tree while the attempt's real result sat untouched in the
        #   other.
        #
        #   THE CREATION. It made the directory when it was missing. A
        #   directory a cleanup act invents did not exist while the attempt
        #   ran, so "custody normalized the result root" would have been a
        #   true sentence about an empty tree this manager had just made --
        #   and the retained-mode caveat would have applied to the wrong
        #   object entirely.
        #
        # So the ruling: allocation establishes it before runtime start, this
        # derives that exact locator, and an absence is a CONTRADICTION rather
        # than something to repair. An empty one is ordinary -- logs may exist
        # with no accepted artifacts, and no artifacts at all is a result too.
        #
        # DERIVED FROM THE PROVED REAL WORKSPACE, so nothing below can
        # traverse a link that appears at the home after the proof.
        place = os.path.join(_real(workspace, "the attempt's workspace"),
                             f"result-{assignment_id}")
        if not os.path.lexists(place):
            raise ContractRefusal(
                "integrity", "path",
                f"attempt {name_value(assignment_id)} has no result root at "
                f"{name_value(place)}; this manager establishes it before the "
                f"runtime starts, so its absence contradicts an attempt that "
                f"ran -- and custody does not create one, because a directory "
                f"made now is not the directory the worker wrote into")
        _no_link(place, what="the attempt's result directory")
    resolved = _real(place, f"the attempt's {which} root")
    if not _within(resolved, root):
        raise ContractRefusal(
            "policy", "denied",
            f"{name_value(resolved)} resolves outside this deployment's "
            f"configured workspace store; a custody act is performed on an "
            f"attempt directory this manager allocated")
    # W43974: THE RECORDED STORE ROOT COMES BACK TOO, and it is the recorded
    # spelling rather than `root`'s resolved one. It is a digest input for the
    # helper identity, and an identity that moved when somebody re-pointed a
    # symlink would be one a restarted manager could not re-derive -- which is
    # the whole property `_custody_identity` exists to provide.
    return resolved, group.gid, recorded


def _no_link(place, *, what=None, missing_ok=False):
    """One EXACT directory this manager owns, asked with `lstat`.

    `os.path.isdir` follows a symlink and answers about its target, which is
    the question a worker gets to choose the answer to. `lstat` answers about
    the entry.
    """
    try:
        held = os.lstat(place)
    except FileNotFoundError:
        if missing_ok:
            return False
        raise ContractRefusal(
            "policy", "denied",
            f"{name_value(place)} does not exist; a custody root is a "
            f"directory this manager created")
    if not stat.S_ISDIR(held.st_mode) or stat.S_ISLNK(held.st_mode):
        raise ContractRefusal(
            "policy", "denied",
            f"{what or name_value(place)} is not a directory this manager "
            f"created: it is {'a symbolic link' if stat.S_ISLNK(held.st_mode)
                              else 'not a directory'}. The workspace is "
            f"worker-writable, so a name inside it is a name an ended worker "
            f"can point wherever the engine can resolve -- and a resolved "
            f"alias is not a capability")
    if held.st_uid != os.getuid():
        raise ContractRefusal(
            "policy", "denied",
            f"{what or name_value(place)} is owned by uid {held.st_uid} and "
            f"this manager is uid {os.getuid()}; a custody root is one this "
            f"manager created")
    return True


def _list_vector(engine, name):
    """Ask the engine for candidates whose name CONTAINS this identity.

    W43974. A NARROWING, NEVER A DECISION -- `_reconciled` compares every
    returned row for exact name equality here. That is `OciAdapter.list`'s own
    rule ("engine-side selection is not proof that a returned row has the
    values requested") applied to a selector that is not a label, and it is
    what leaves a same-prefix stranger untouched.

    A SUBSTRING FILTER RATHER THAN AN ANCHORED REGEX, deliberately. Both
    engines' `name` filter is a substring match, so it can over-match and
    cannot under-match a name that is present. An anchored `^...$` would be
    exact where it is honoured and would match NOTHING on an engine that
    treats the anchors literally -- and a false ABSENCE is the one answer this
    must never produce, because it launches into a name conflict or leaves a
    stranded helper behind forever.

    Composed here rather than through `oci.list_vector`, which selects by
    label and belongs to the attempt-runtime vocabulary. Custody composes its
    own run vector for the reason `_custody_vector` states, and the same
    reason applies to its selector.
    """
    from .oci import _engine

    return [_engine(engine), "ps", "--all", "--no-trunc",
            "--format", "{{json .}}", "--filter", f"name={name}"]


def _listed_name(entry):
    """The name in one listing row, across the engines' two spellings.

    Docker answers `Names` as one comma-separated string; Podman answers a
    list. Both are read, and anything else refuses rather than being coerced
    into something comparable.
    """
    from .oci import _one_of, _refuse

    found = _one_of(entry, ("Names", "Name"), "an engine listing entry")
    if type(found) is str:
        return [one.strip().lstrip("/") for one in found.split(",")
                if one.strip()]
    if type(found) is list and all(type(one) is str for one in found):
        return [one.strip().lstrip("/") for one in found if one.strip()]
    _refuse(f"an engine listing entry names {name_value(found)}; this "
            f"adapter reads the engines it speaks and guesses at nothing")


def _reconciled(engine, run, *, name, image_digest):
    """What is already answering to this identity, held to the state table.

    W43974, and the whole point of deriving the name. Every uncertain branch
    refuses, because launching a second helper over an attempt directory a
    first one may still be walking is the one outcome worse than failing.

      no candidate                       -> launch
      one candidate, this act's image    -> end it, prove absence, launch
      one candidate, another image       -> REFUSE
      more than one candidate            -> REFUSE
      the listing failed                 -> REFUSE

    A STRANDED HELPER IS ENDED, NEVER ADOPTED, and the reason is structural
    rather than a preference. A custody answer is the document the helper
    printed to the stdout THIS manager held; one started by a process that has
    since died printed to a pipe nobody holds, so its answer is unrecoverable.
    Attaching to a running container yields what it writes from now on, not
    what it already said. There is nothing to adopt, and awaiting is the same
    problem with a delay in front of it.

    Redoing the act is sound because every verb is safe to interrupt and
    repeat: `normalize` and `discard` are idempotent in effect, and the four
    reading verbs write nothing.
    """
    from .oci import (_LISTED_IMAGE, _absent_prose, _decoded, _denied,
                      _engine, _image_identity, _one_of, _refuse,
                      inspect_vector)

    answer = _settled(run, _list_vector(engine, name),
                      seconds=CUSTODY_RECLAIM_SECONDS,
                      what="the custody listing")
    if answer["status"] != 0:
        _denied(f"the engine could not be asked what is answering to "
                f"{name_value(name)}: "
                f"{name_value(answer['stderr'][:MAX_DIAGNOSTIC])}; a custody "
                f"act does not launch over an attempt directory whose "
                f"existing helpers this manager could not observe")
    found = []
    for line in answer["stdout"].splitlines():
        if not line.strip():
            continue
        entry = _decoded(line, "an engine listing entry")
        if type(entry) is not dict:
            _refuse(f"an engine listing entry is one record; this is "
                    f"{name_value(entry)}")
        # THE EXACT NAME, decided HERE. The filter returned everything
        # CONTAINING the identity, which on a busy host includes any stranger
        # whose name happens to carry it.
        if name not in _listed_name(entry):
            continue
        found.append(entry)
    if not found:
        return None
    if len(found) > 1:
        _denied(f"the engine reports {len(found)} runtimes named exactly "
                f"{name_value(name)}; one derived identity names one helper, "
                f"and a manager that cannot say which of them its predecessor "
                f"started reclaims neither")
    runtime_id = _one_of(found[0], ("ID", "Id", "ContainerID"),
                         "an engine listing entry")
    boundaries.identity(runtime_id, "a listed runtime id")
    # THE IMAGE IS ASKED OF `inspect`, NOT OF THE LISTING, and that is a
    # measured correction rather than a preference. `ps --format {{json .}}`
    # answers `Image` as the TAG the container was started from --
    # `baton-w6636-lifecycle:e4cc3eff` on a real daemon -- and a tag is a
    # pointer that was true when somebody last pushed, which `_image_identity`
    # refuses outright. The container's own record carries the digest.
    #
    # It costs one call and only when a candidate exists: the ordinary act,
    # which finds nothing, still asks the engine exactly `ps` and `run`.
    looked = _settled(run, inspect_vector(engine, runtime_id=runtime_id),
                      seconds=CUSTODY_RECLAIM_SECONDS,
                      what="the candidate inspection")
    if looked["status"] != 0:
        if _absent_prose(_engine(engine), looked["stderr"], runtime_id):
            # GONE BETWEEN THE TWO QUESTIONS, which is not an error: the
            # candidate this was going to reclaim reclaimed itself.
            return None
        _denied(f"a runtime named exactly {name_value(name)} was listed and "
                f"this manager could not then observe it: "
                f"{name_value(looked['stderr'][:MAX_DIAGNOSTIC])}; a helper "
                f"whose identity cannot be settled is not one to remove and "
                f"not one to launch beside")
    document = _decoded(looked["stdout"], "an engine inspection")
    if type(document) is not dict:
        _refuse(f"an engine inspection is one record; this is "
                f"{name_value(document)}")
    # THE ENGINE'S OWN ACCOUNT OF WHAT IS RUNNING, against this act's image.
    # A container answering to a name this manager derives, running an image
    # this manager did not compose, is not this manager's to end -- and it is
    # the sharper reading of the two, because it means either the derivation
    # collided with something or somebody took the name deliberately.
    image = _image_identity(_one_of(document, _LISTED_IMAGE,
                                    "an engine inspection"),
                            "the observed helper's image")
    if image != _image_identity(image_digest, "this act's image"):
        _denied(f"a runtime named exactly {name_value(name)} is running an "
                f"image this act did not compose; a name this manager derives "
                f"is not authority to remove somebody else's container, so "
                f"this refuses rather than reclaiming")
    # AND THE INSPECTION'S OWN NAME, against the identity that selected it.
    # The listing chose this row and the engine is being asked to confirm it
    # is about the same object -- the rule `OciAdapter.list` states, applied
    # to the second question rather than only the first.
    if name not in _listed_name(document):
        _denied(f"the engine listed {name_value(runtime_id)} as named "
                f"{name_value(name)} and its own record names it otherwise; "
                f"a helper this manager cannot identify twice over is not one "
                f"it removes")
    return runtime_id


def _reclaimed(engine, run, *, name, runtime_id):
    """End one helper and PROVE it is gone, never merely order it.

    W43974. `--rm` covers the engine's normal completion path and nothing
    else, so this is the path for every other ending: stop, force-remove,
    then INSPECT the exact identity and require this engine's own absence
    sentence to name it.

    AN ACKNOWLEDGEMENT IS NOT ABSENCE. `rm --force` exiting zero says the
    engine accepted the order; what this manager needs is what is true
    afterwards, which is the same rule `OciAdapter.stop` is written under. An
    inspect that neither succeeds nor produces that sentence leaves the
    reclamation UNRESOLVED, and unresolved refuses.
    """
    from .oci import (_absent_prose, _denied, _engine, destroy_vector,
                      inspect_vector, stop_vector)

    engine = _engine(engine)
    # THE STOP IS BEST-EFFORT AND THE REMOVAL IS NOT. A helper that already
    # exited refuses the stop, which is not a failure -- it is the state this
    # is trying to reach.
    _settled(run, stop_vector(engine, runtime_id=runtime_id,
                              seconds=CUSTODY_STOP_SECONDS),
             seconds=CUSTODY_RECLAIM_SECONDS, what="the stop order")
    removal = _settled(run, destroy_vector(engine, runtime_id=runtime_id),
                       seconds=CUSTODY_RECLAIM_SECONDS,
                       what="the removal order")
    _proved_absent(engine, run, name=name, runtime_id=runtime_id,
                   removal_said=removal["stderr"])


def _proved_absent(engine, run, *, name, runtime_id, removal_said=None):
    """The engine's own absence sentence, naming THIS identity, or a refusal.

    Factored out because two different questions need the same proof and
    neither may settle for anything weaker. After a removal it is "did the
    order take effect"; after a lost act that listed no candidate it is "is
    the helper this manager may have launched actually gone" -- and an empty
    `ps` filter result is engine-side SELECTION rather than an absence, which
    is the distinction `OciAdapter.list` already draws for the other
    direction.

    W43974 review (2026-08-30T05:15:08Z) [P1], second half: the pre-launch
    path can treat an empty listing as "nothing there" because `run --name`
    fails closed on a conflict if it was wrong. Recovery has no such backstop
    -- it would simply conclude the helper was reclaimed -- so it asks.
    """
    from .oci import MAX_DIAGNOSTIC as _ENGINE_DIAGNOSTIC, _absent_prose, \
        _denied, _engine, inspect_vector

    looked = _settled(run, inspect_vector(_engine(engine),
                                          runtime_id=runtime_id),
                      seconds=CUSTODY_RECLAIM_SECONDS,
                      what="the absence proof")
    if looked["status"] == 0 or not _absent_prose(_engine(engine),
                                                  looked["stderr"],
                                                  runtime_id):
        _denied(f"this manager could not prove the helper {name_value(name)} "
                f"absent"
                + (f" after ordering its removal (which said "
                   f"{name_value(removal_said[:_ENGINE_DIAGNOSTIC])})"
                   if removal_said is not None else "")
                + f"; an engine acknowledgement is not absence, and a custody "
                  f"act does not launch over a directory a helper may still "
                  f"hold")


def _custody_vector(engine, *, image_digest, store, assignment_id,
                    operation, submission, which="workspace"):
    """The closed argv that performs ONE custody act, restrictions and all.

    PRIVATE, and review [P0] round ten is why. It used to be the public
    surface, so the authenticated bind source came back in an ordinary list
    that its holder could rewrite before anything executed it. It is composed
    and consumed inside `custody_act` now, and it is reachable only by the
    engine port that runs it -- which is the party that executes every other
    vector this manager composes.

    IT SELECTS ITS OWN MOUNT, and review [P0] round nine is why that is the
    signature rather than an implementation detail. This used to take a minted
    `CustodyRoot` and a `WorkspaceGroup`, and read `.place` and `.gid` off
    them -- so a caller holding either could replace a slotted member with
    `object.__setattr__` after a valid mint and have the replacement land
    verbatim in `--mount source=...`. Nine rounds of setters, private slots
    and type checks were all on the wrong side of that interval.

    So there is no interval. What crosses is this manager's own durable STORE
    and the attempt's NAME; the configured store and group are read here, the
    root is derived and proved here, and the argv is composed here, in one
    act with nothing path-bearing handed to anybody.

    IT IS NOT A RUNTIME AND DOES NOT REUSE `run_vector`. The two compose
    different things: a runtime is given inputs, a launch document and
    credentials and is expected to run somebody's assignment; a custodian is
    given one directory and a verb. Sharing a composer would mean every
    restriction this needs is one an execution vector could later relax.

    `--rm` AND FOREGROUND, WHICH IS NOT YET A LIFETIME GUARANTEE. Review
    [P1], round ten: this docstring used to say a crash leaks no capability a
    later manager would have to reclaim, and that contradicts this dossier's
    own confirmed first-review finding. What `--rm` actually buys is
    reclamation on the engine's NORMAL removal path: the container goes when
    the act ends. A manager or client that dies mid-act leaves a helper the
    engine never reclaims and this build never looks for.

    `CUSTODY_NAME` exists so a restarted manager COULD find one, and nothing
    reads it yet. Bounded, derivable and restart-reclaimable helper lifetime
    is an owed outcome of this Work and is open in `PLAN.md`; it is named here
    so the code and the record say the same thing.
    """
    from .oci import _engine, _IMAGE, _refuse
    engine = _engine(engine)
    boundaries.text(image_digest, "an image digest")
    if not _IMAGE.match(image_digest):
        _refuse(f"{name_value(image_digest)} is not a sha256 image digest; a "
                f"custody act runs the image this manager can name exactly",
                code="digest")
    operation = check_custody_operation(operation)
    # THE ONE MOUNT AND THE ONE GROUP, both read from durable state in this
    # same act. There is no host path operand and no path-bearing object at
    # all, so a repository, a credential root or an unrelated sibling cannot
    # be selected -- there is nothing to select them WITH.
    source, gid, recorded = _derived_root(store, assignment_id, which)
    # W43974: THE NAME IS DERIVED IN THIS SAME ACT, from the same durable read
    # the mount comes from. It used to arrive as a caller operand -- the one
    # that had survived nine rounds of removing them -- and a name a caller
    # chose is a name a restarted manager cannot re-derive, which made the
    # reclamation this Work owes impossible rather than merely unwritten.
    name = _custody_identity(recorded, assignment_id, which, operation)
    # W194457: THE CUSTODIAN RUNS AS WHOEVER THE WORKER RAN AS, which is the
    # whole mechanism and is why this follows the execution identity rather
    # than a constant. Under the shared identity that is the manager's own
    # uid with the deployment's workspace group -- so the custodian still
    # owns what the worker created, and owning it is what lets it `chmod`.
    #
    # MINTED FROM THE SAME DURABLE READ THE MOUNT AND THE GROUP COME FROM.
    # `gid` was read from the store in this act; `identity_for` puts it behind
    # the capability and derives the uid from `os.geteuid()`, so there is no
    # integer here a caller chose -- the rule W33936 wrote for the group,
    # applied to the pair.
    from . import workspaces

    custodian = workspaces.identity_for(
        workspaces.WorkspaceGroup(gid, workspaces._MINT))
    argv = [engine, "run", "--rm", "--name", name]
    for flag, value in _CUSTODY_RESTRICTIONS:
        argv.append(flag)
        if flag == "--user":
            # THE SAME CHEAP DECLARED CHECK THE RUNTIME VECTOR MAKES, and for
            # the same reason: this is the second place the pair is spelled,
            # and two spellings agree until they don't. It reaches no engine.
            value = workspaces.declared_identity_mapping(
                custodian, f"{custodian.uid}:{custodian.gid}")
        if value is not None:
            argv.append(value)
    # THE CONFIGURED WORKSPACE GROUP, FOR THE SAME REASON THE WORKER GETS IT.
    #
    # Measured rather than reasoned: the first cut composed no group, and the
    # custodian could not so much as ENTER the workspace. The root is `02770`
    # and manager-owned, so uid 65532 without the group has no `x` on it --
    # the helper listed the attempt home and stopped there, reporting five
    # entries that were none of its business and never reaching the worker's.
    #
    # It is W33936's capability rather than a gid, on that Work's rule: a
    # group a caller can name is a group a caller chose -- and it is read from
    # the store above rather than handed in, for the same reason the mount is.
    argv += ["--group-add", str(gid)]
    argv += ["--mount",
             f"type=bind,source={source},target={CUSTODY_ROOT},readonly=false"]
    argv += ["--entrypoint", "python3", image_digest,
             "-c", CUSTODY_PROGRAM, operation, submission]
    # THE NAME COMES BACK BESIDE THE ARGV, and it is neither path-bearing nor
    # executable. `custody_act` needs it before the run to reconcile what may
    # already be answering to it, and deriving it twice would be two places
    # that must agree. It does not cross to a caller: this function is private
    # and has exactly one.
    return argv, name


class CustodyAnswer:
    """WHAT ONE CUSTODY ACT ANSWERED, and it is deliberately not a capability.

    Review [P0] round ten. The old shape handed back an executable argv
    carrying an authenticated host path; this carries the verb, the engine's
    exit status, the custodian's own document and a bounded diagnostic. There
    is no host path in it -- the program answers paths RELATIVE to its mount,
    which is the only namespace it knows -- and no command vector, so a holder
    has nothing to retarget and nothing to re-execute.

    Immutable for the ordinary reason every answer in this package is: an
    answer somebody can edit is an account of what happened that disagrees
    with what happened. Review (2026-08-30T04:07:53Z) [P1]: immutable ALL THE
    WAY DOWN, because a frozen outer mapping over live nested lists and
    records is an answer somebody can edit with one more subscript.

    AND IT IS TYPED, not merely present. The same review found that a zero
    exit plus any JSON object at all was reported as custody, so `ok` now
    requires the document to be the requested verb's own result in the shape
    that verb answers -- see `_accountable`.

    NO PUBLIC CONSTRUCTOR, and it is the same rule the capabilities in this
    package are under rather than a shape chosen for tidiness: an answer is
    what one act REPORTED, so a caller that could mint one could report an act
    that never happened. `_answered` below is the only way to make one, and it
    is called in exactly one place -- at the end of the act it describes.
    """

    __slots__ = ("_operation", "_status", "_answer", "_rendered",
                 "_unaccounted", "_diagnostic")

    def __setattr__(self, name, value):
        raise AttributeError(
            f"a custody answer records what one act did; {name_value(name)} "
            f"is not something a holder revises afterwards")

    __delattr__ = __setattr__

    @property
    def operation(self):
        """The verb this act performed, from the closed vocabulary."""
        return self._operation

    @property
    def status(self):
        """The engine's exit status for the act, or `None`.

        W43974: `None` means the wait ended without an engine answer at all --
        the injected run capability's own deadline, a killed client -- and the
        helper was reclaimed by its derived identity before this was minted.
        It is never `ok`, and the diagnostic says what ended it.
        """
        return self._status

    @property
    def answer(self):
        """The custodian's document, RECURSIVELY read-only, or `None`.

        `None` means the act produced no document this manager could account
        for -- unreadable, or readable and not one of the two things the
        program it ran is able to say. That is a fact about the act and never
        a reason to guess at what it did; `unaccounted` names which.

        W36540 review (2026-08-30T04:07:53Z) [P1]: a `MappingProxyType` froze
        only the OUTER mapping, so `answer["running_as"][0] = 0` succeeded and
        the retained account disagreed with what the custodian reported. Every
        level is frozen now -- see `_frozen`.
        """
        return self._answer

    @property
    def rendered(self):
        """The canonical serialization of that document, or `None`.

        One string, produced from the parsed document at mint time and never
        recomputed, so what a caller reads back is what this act accounted
        for. It exists because a read-only VIEW cannot be handed to
        `json.dumps` -- a `mappingproxy` is not a `dict` -- and a caller that
        rebuilt one to serialize it would be re-deriving the account instead
        of quoting it.
        """
        return self._rendered

    @property
    def unaccounted(self):
        """Why no document was accepted, in this module's words, or `None`.

        AUTHORED HERE, NOT QUOTED FROM THE ACT. A custodian document that does
        not match the requested verb and shape is not partially believed: none
        of it becomes `answer`, and what a reader gets instead is this
        module's own statement of what it could not account for. The act's own
        stderr stays separately in `diagnostic`, so the two provenances never
        blur.
        """
        return self._unaccounted

    @property
    def diagnostic(self):
        """A bounded window of what the act wrote to stderr."""
        return self._diagnostic

    @property
    def ok(self):
        """The act ended cleanly AND said what it did AND said THIS.

        Three halves now, and the third is the review's finding. A zero exit
        with no readable answer is an act this manager cannot account for; so
        is a zero exit carrying a document about some other verb, or one
        missing the members its own verb answers. Custody that cannot be
        accounted for is not custody, and an account of a different act is not
        an account of this one.
        """
        return (self._status == 0 and self._answer is not None
                and self._answer["custody"] == self._operation)

    def __repr__(self):
        return (f"CustodyAnswer(operation={self._operation!r}, "
                f"status={self._status!r}, ok={self.ok!r})")


def _frozen(value):
    """One JSON value, made read-only ALL THE WAY DOWN.

    W36540 review (2026-08-30T04:07:53Z) [P1]. `MappingProxyType` protects
    assignment to the mapping it wraps and nothing inside it, so every list
    and dictionary the custodian nested stayed live in the holder's hands.

    A LIST BECOMES A TUPLE RATHER THAN A GUARDED LIST, and that choice is this
    record's own rule applied to itself. A `list` subclass that refuses its
    mutators would compare equal to a list and serialize as one -- and
    `list.append(frozen, x)` reaches straight past it, exactly as
    `object.__setattr__` reached past six representations of `AllocatedRoots`
    in rounds one to six. A tuple has no such door. The cost is that a frozen
    sequence no longer equals the list it came from, which is a real change to
    what a reader compares against and is preferable to a defence this Work
    has already been taught not to accept.

    The mapping this wraps is built fresh here and is referenced by nothing
    else, so the proxy is not a window onto an object somebody still holds.
    """
    if type(value) is dict:
        return MappingProxyType({name: _frozen(one)
                                 for name, one in value.items()})
    if type(value) is list:
        return tuple(_frozen(one) for one in value)
    return value


def _accountable(operation, document):
    """The document this act may be accounted for by, and why not if not.

    Answers `(document, None)` when it is one of the two things
    `CUSTODY_PROGRAM` can print for this act -- the requested verb's own
    result, or the custodian's typed refusal -- and `(None, why)` otherwise.

    HELD TO A CLOSED MEMBER SET, exactly as the task and launch documents in
    this build are, rather than to "has the members I am about to read". A
    document with an unexpected member is a document from a program that is
    not the one this module ships, and reading the recognised parts out of it
    is how a manager ends up accounting for an act it did not understand.
    """
    if document is None:
        return None, "the act printed no document this manager could read"
    verb = document.get("custody")
    if verb == _CUSTODY_REFUSED:
        shape, what = _CUSTODY_REFUSAL, "a custodian refusal"
    elif verb == operation:
        shape, what = _CUSTODY_RESULT[operation], f"a {operation} result"
    else:
        return None, (
            f"the act answered for {name_value(verb)} and this manager asked "
            f"for {name_value(operation)}; an account of a different act is "
            f"not an account of this one")
    missing = sorted(one for one in shape if one not in document)
    extra = sorted(one for one in document
                   if one != "custody" and one not in shape)
    if missing or extra:
        return None, (
            f"the act's document is not {what}"
            + (f"; missing {', '.join(missing)}" if missing else "")
            + (f"; unexpected {', '.join(extra)}" if extra else ""))
    for one, expected in shape.items():
        if type(document[one]) is not expected:
            return None, (
                f"the act's {name_value(one)} is not the {expected.__name__} "
                f"{what} answers")
    if verb != _CUSTODY_REFUSED and (
            len(document["running_as"]) != 2
            or any(type(one) is not int for one in document["running_as"])):
        return None, ("the act did not say which identity it ran as, and an "
                      "act whose custodian identity is unstated is one this "
                      "manager cannot attribute")
    return document, None


def _answered(operation, status, answer, diagnostic):
    """Mint the one answer for one act. Private, and called in one place."""
    import json

    accounted, why = _accountable(operation, answer)
    made = object.__new__(CustodyAnswer)
    object.__setattr__(made, "_operation", operation)
    object.__setattr__(made, "_status", status)
    object.__setattr__(made, "_answer",
                       None if accounted is None else _frozen(accounted))
    object.__setattr__(made, "_rendered",
                       None if accounted is None
                       else json.dumps(accounted, sort_keys=True))
    object.__setattr__(made, "_unaccounted", why)
    object.__setattr__(made, "_diagnostic", diagnostic)
    return made


# W247941, owner 257086 and review 2026-09-24T13:36:43Z: THE DURABLE HOLD.
#
# A diagnostic told whoever read one refusal. A HOLD binds the next act. The
# two journal kinds below are that difference.
CUSTODY_HOLD_KIND = "directory-custody.hold"
CUSTODY_CLEARED_KIND = "directory-custody.hold-cleared"


def _hold_identity(kind, assignment_id, which, episode):
    # The module reaches for the canonical digest where it needs one rather
    # than importing it at module scope; this follows `_custody_identity`.
    """One identity per (attempt, root, EPISODE), never reused.

    THE EPISODE IS WHY THIS IS NOT THE ACT'S IDENTITY. Review
    2026-09-24T13:43:14Z: "distinct uncertainty episodes must defeat stale
    clearance even for the same tuple". Two uncertainties over one root are
    two facts, and a clearance written for the first must not lift the
    second -- so the episode is IN the identity rather than beside it.
    """
    from ..contracts.canonical import digest

    return kind + ":" + digest({"attempt_id": assignment_id, "root": which,
                                "episode": episode})[len("sha256:"):]


def surviving_helpers(engine, run, store, assignment_id, *, image_digest):
    """WHICH custody helpers of this attempt are still answering, as a list.

    W285465, TOK-12. Returning an old task generation needs `helpers` to be TRUE rather
    than convenient: `tokens.returned` refuses a cessation that reports a surviving
    writer, and `intake._resource_cessation` may answer `[]` only because committed
    custody means the roots are held by this manager. The recovery transition returns the
    old generation BEFORE any repair, so it has neither justification and must establish
    the fact.

    SO THIS ASKS BOTH HALVES, ROOT BY ROOT, AND NEITHER ALONE:

      * THE JOURNAL, for every RECORDED episode. Review 2026-09-28T02-10-01Z corrected me
        here: `_standing_overlap` answering `None` means no UNCLEARED episode, NOT that
        none was ever claimed -- `custody_holds` carries the history. An uncleared episode
        is an unresolved request that may still create its helper, so it is reported as
        surviving whatever the engine says.
      * THE ENGINE, for the derived name of each closed verb. A helper this manager
        launched and never reclaimed answers to exactly one derivable name, which is why
        the name is derived rather than chosen.

    THE ANSWER CROSSES AN `EnginePort`, wrapped here exactly as `custody_act` wraps it.
    MEASURED, and it is the defect I reported as an empty-listing blocker: I handed
    `_reconciled` a RAW callable, and the reviewer's probe then proved empty stdout works
    perfectly through the real port -- so the refusal I saw was about the port, not about
    the listing, and I reverted working evidence instead of reading the traceback.
    """
    from .oci import EnginePort as _EnginePort

    port = run if type(run) is _EnginePort else _EnginePort(run)
    place = _recorded_store(store)
    surviving = []
    for which in CUSTODY_ROOTS:
        for held in custody_holds(store, assignment_id, which):
            if not held.get("cleared"):
                surviving.append({"root": which, "episode": held.get("episode"),
                                  "helper_identity": held.get("helper_identity"),
                                  "why": "an uncleared uncertainty episode may still "
                                         "create its helper"})
        if image_digest is None:
            # W285465 review 2026-09-28T03-50-12Z [P1]: NOT ASKED IS NOT ABSENT.
            #
            # My previous cut answered "none" here, reasoning that a deployment with no
            # custodian image launches no helper. The reviewer's probe shows why that is
            # wrong: the derived NAMES do not depend on the image at all, so a
            # configuration that LOST its custodian still has names an earlier one could
            # have launched under -- and the same store and engine that report a live
            # helper with an image report nothing without one. A currently missing image
            # is not durable proof that no helper was ever possible.
            #
            # SO THE UNKNOWN IS REPORTED, WHICH HOLDS. The journal half above has already
            # run and still reports every uncleared episode; this adds the fact that the
            # engine half could not be asked, so a caller cannot read silence as absence.
            # Establishing fresh no-helper provenance, or reconciling the historical
            # runtime and image, is what would replace this -- and neither is invented
            # here.
            surviving.append({"root": which, "episode": None,
                              "helper_identity": None, "runtime_id": None,
                              "why": "this deployment configures no custodian image, so "
                                     "this manager cannot identify a helper an earlier "
                                     "configuration may have launched under the same "
                                     "derived names; the engine was NOT asked and helper "
                                     "absence is not established"})
            continue
        for operation in CUSTODY_OPERATIONS:
            name = _custody_identity(place, assignment_id, which, operation)
            answering = _reconciled(engine, port, name=name,
                                    image_digest=image_digest)
            if answering is not None:
                surviving.append({"root": which, "episode": None,
                                  "helper_identity": name,
                                  "runtime_id": answering,
                                  "why": "a helper is still answering to this "
                                         "attempt's derived custody name"})
    return surviving


def custody_holds(store, assignment_id, which):
    """Every uncertainty episode recorded for this root, oldest first.

    A READER. It opens nothing, writes nothing and decides nothing; what it
    answers is which episodes exist and which of them an operator has
    cleared, so a caller can refuse rather than guess.
    """
    import json as _json

    held = []
    absent = None
    for episode in range(_MOST_HOLDS + 1):
        record = store.operation_record(
            _hold_identity(CUSTODY_HOLD_KIND, assignment_id, which, episode))
        if record is None:
            # W257624 R2, review 2026-09-24T21-39-09Z: A GAP IS REFUSED RATHER
            # THAN READ AS AN END. This used to `break`, so an absent episode
            # made every LATER one invisible -- and an invisible uncertainty is
            # a root that reads as unheld. The scan continues to the bound
            # instead, and a present episode past an absent one is a record set
            # this reader will not act on. The bound is why it can: 65
            # primary-key lookups is what this reader already cost in the worst
            # case, and reaching the bound was always itself a refusal.
            if absent is None:
                absent = episode
            continue
        if absent is not None:
            raise ContractRefusal(
                "refused", "precondition",
                f"attempt {name_value(assignment_id)}'s {which} root records "
                f"uncertainty episode {episode!r} and no episode "
                f"{absent!r}; a gap means this manager cannot say what the "
                f"missing act did, and it is reconciled rather than read past")
        # EVERY MEMBER OF THE RECORD IS CHECKED, not merely its presence: a
        # row at a derived key is not evidence until its kind, its state and
        # its document all say what this reader is about to report.
        if record["state"] != "committed" or record["kind"] != \
                CUSTODY_HOLD_KIND:
            raise ContractRefusal(
                "refused", "precondition",
                f"attempt {name_value(assignment_id)}'s {which} root has an "
                f"uncertainty record at episode {episode!r} that is "
                f"{record['state']!r} of kind {record['kind']!r}; a hold this "
                f"manager cannot read is not one it may act past")
        try:
            document = _json.loads(record["result"])
        except (TypeError, ValueError):
            document = None
        if type(document) is not dict or not document.get("helper_identity"):
            raise ContractRefusal(
                "refused", "precondition",
                f"the uncertainty recorded for attempt "
                f"{name_value(assignment_id)}'s {which} root episode "
                f"{episode!r} names no helper; it is reconciled rather than "
                f"read past")
        # W257624 R2, review 2026-09-24T22-06-47Z: THE HOLD IS READ BACK THE
        # WAY THE CLEARANCE IS. `clear_custody_hold` verified the hold's
        # signature and its document's own coordinates; this reader did not, so
        # a swapped hold document was reported as a standing episode and only
        # refused if somebody tried to clear it.
        from .store import manager_signature as _signed

        if record["signature"] != _signed(CUSTODY_HOLD_KIND, document):
            raise ContractRefusal(
                "refused", "precondition",
                f"the uncertainty recorded for attempt "
                f"{name_value(assignment_id)}'s {which} root episode "
                f"{episode!r} does not carry the signature its operation "
                f"identity was committed under; a hold this manager cannot "
                f"bind to its own act is not one it may read")
        for one, expected in (("attempt_id", assignment_id),
                              ("root", which), ("episode", episode)):
            if document.get(one) != expected:
                raise ContractRefusal(
                    "refused", "precondition",
                    f"the uncertainty at {which} root episode {episode!r} "
                    f"records {one} {name_value(document.get(one))} and this "
                    f"reader asked for {name_value(expected)}; a record about "
                    f"another act is not this episode")
        cleared = store.operation_record(
            _hold_identity(CUSTODY_CLEARED_KIND, assignment_id, which,
                           episode))
        if cleared is not None and (cleared["state"] != "committed"
                                    or cleared["kind"]
                                    != CUSTODY_CLEARED_KIND):
            raise ContractRefusal(
                "refused", "precondition",
                f"the clearance recorded for attempt "
                f"{name_value(assignment_id)}'s {which} root episode "
                f"{episode!r} is {cleared['state']!r} of kind "
                f"{cleared['kind']!r}; an unreadable clearance lifts nothing")
        if cleared is not None:
            # W257624 R2: AND THE CLEARANCE CARRIES ITS OWN SIGNATURE. The kind
            # and the state say a clearance was committed here; the signature
            # says the document sitting in the row is the one it was committed
            # under. A lift is the one direction where believing an
            # unverifiable document is unsafe, so this reader checks it rather
            # than reporting `cleared` on the strength of a key.
            from .store import manager_signature

            try:
                lifting = _json.loads(cleared["result"])
            except (TypeError, ValueError):
                lifting = None
            if type(lifting) is not dict or cleared["signature"] != \
                    manager_signature(CUSTODY_CLEARED_KIND, lifting):
                raise ContractRefusal(
                    "refused", "precondition",
                    f"the clearance recorded for attempt "
                    f"{name_value(assignment_id)}'s {which} root episode "
                    f"{episode!r} does not carry the signature its operation "
                    f"identity was committed under; a lift this manager "
                    f"cannot bind to its own act lifts nothing")
            # W257624 R2 [P1], review 2026-09-24T21-39-09Z: AND A SIGNATURE IS
            # INTERNAL CONSISTENCY, NOT BINDING. A correctly signed body naming
            # another root and episode was accepted here, because the check
            # above asks only whether the document agrees with itself. What
            # makes a lift THIS episode's is that its own coordinates, the
            # helper it names and the evidence it carries all agree with the
            # hold it claims to lift.
            for one, expected in (("attempt_id", assignment_id),
                                  ("root", which), ("episode", episode),
                                  ("helper_identity",
                                   document["helper_identity"])):
                if lifting.get(one) != expected:
                    raise ContractRefusal(
                        "refused", "precondition",
                        f"the clearance recorded at attempt "
                        f"{name_value(assignment_id)}'s {which} root episode "
                        f"{episode!r} names {one} "
                        f"{name_value(lifting.get(one))} and the hold it "
                        f"would lift records {name_value(expected)}; a "
                        f"correctly "
                        f"signed document about another act lifts nothing")
            # EXACTLY ONE OF THE TWO LIFTS, and each says which it is. An
            # operator's reconciliation carries delivered evidence; the
            # manager's own receipt carries the marker `_clear_hold` writes.
            # A document carrying neither is a lift nobody can attribute, and
            # one carrying both claims to be two different acts.
            operator = type(lifting.get("settlement")) is dict
            direct = lifting.get("accounted") == CUSTODY_DIRECT_ACT
            if direct and not operator:
                # THE DIRECT RECEIPT IS READ BACK TOO. Its document is what the
                # act was accounted for by, so it is held to the same
                # accountability rule that let the act clear itself -- a
                # receipt whose document no longer answers for this verb is a
                # lift this manager cannot stand behind.
                receipt = lifting.get("accounted_document")
                accounted, why = _accountable(document.get("verb"), receipt)
                if accounted is None or (type(receipt) is not dict) or \
                        receipt.get("custody") != document.get("verb"):
                    raise ContractRefusal(
                        "refused", "precondition",
                        f"the direct-act receipt at attempt "
                        f"{name_value(assignment_id)}'s {which} root episode "
                        f"{episode!r} carries no accountable "
                        f"{document.get('verb')} document: "
                        + (why or "it answers for another act"))
                # W257624 R2 [P1], review 2026-09-24T23-02-34Z: AND THE TOKEN
                # IS COMPARED ON READBACK TOO.
                #
                # The direct receipt was held to accountability and never to
                # ATTRIBUTION, so a correctly signed receipt echoing another
                # submission's token read as a lift. The settlement path
                # compared the token and this one did not; both are lifts, so
                # both compare it.
                committed = document.get("claimant")
                if not committed:
                    raise ContractRefusal(
                        "refused", "precondition",
                        f"the uncertainty at {which} root episode {episode!r} "
                        f"committed no submission token, so no answer can be "
                        f"attributed to its act; a direct receipt cannot lift "
                        f"what this manager cannot attribute")
                if receipt.get("submission") != committed:
                    raise ContractRefusal(
                        "refused", "precondition",
                        f"the direct-act receipt at {which} root episode "
                        f"{episode!r} answers for submission "
                        f"{name_value(receipt.get('submission'))} and that "
                        f"episode submitted {name_value(committed)}; a "
                        f"receipt about another submission lifts nothing")
            if operator and not direct:
                # A DICTIONARY IS NOT A SETTLEMENT. Review
                # 2026-09-24T21-55-12Z: this accepted `settlement: {}` because
                # it asked only for the type. The lift is re-validated against
                # the hold it claims to lift, by the same contract that let it
                # be written -- so a clearance is readable as a lift only while
                # its evidence still answers for this episode.
                _settlement(document, lifting["settlement"],
                            attempt_id=assignment_id, which=which,
                            episode=episode)
            if operator == direct:
                raise ContractRefusal(
                    "refused", "precondition",
                    f"the clearance recorded for attempt "
                    f"{name_value(assignment_id)}'s {which} root episode "
                    f"{episode!r} is neither an operator reconciliation "
                    f"carrying its settlement nor this manager's own "
                    f"accountable-act receipt; a lift whose provenance is "
                    f"unstated lifts nothing")
        held.append({
            "episode": episode,
            "held": document,
            "cleared": cleared is not None,
        })
    if len(held) > _MOST_HOLDS:
        raise ContractRefusal(
            # W257624 R2: `limit` IS AN INTEGRITY CODE. This said
            # `refused`, which the contracts layer refuses as a
            # closed-pairing violation -- so every bound in this module
            # raised an AssertionError about its own refusal instead of
            # the refusal. Found by reaching it.
            "integrity", "limit",
            f"attempt {name_value(assignment_id)}'s {which} root carries more "
            f"uncertainty episodes than this manager counts")
    return held


# HOW MANY EPISODES ONE ROOT MAY ACCUMULATE BEFORE THIS REFUSES TO COUNT.
# Bounded for the reason every limit in this package is: an unbounded scan is
# a reader a caller can make expensive. Reaching it is itself a refusal.
_MOST_HOLDS = 64


# W257624 R2: WHAT ACTUALLY SETTLES ONE UNCERTAINTY EPISODE.
#
# Owner 260109 selects "a precise provider observation proving settlement of
# that submitted mutation", and the PLAN names what is NOT enough: plain
# observation text, a local CLI exit, an empty helper listing after a client
# timeout, or any nonzero or unaccountable answer. Every one of those is
# compatible with the request still sitting in the daemon's queue -- which is
# the exact possibility the hold exists to refuse to act past. An operator who
# looked and saw nothing has observed an absence, and an absence is not an
# ending.
#
# SO A CLEARANCE CARRIES THE DAEMON'S OWN ANSWER ABOUT THAT HELPER, held to
# the same accountability rule a live act is: `_accountable` already decides
# whether a document is the asked-for verb's own result, and it is reused here
# rather than restated. Nothing in this module asks an engine anything -- the
# answer is delivered to it, and what this owns is whether the delivered answer
# settles the episode it names.
CUSTODY_ENGINE_ANSWER = "engine-answer"

# AND THE OTHER LIFT, which is the manager's own. `custody_act` clears the
# episode it opened when the helper answered ACCOUNTABLY, because an
# accountable document could only have been printed by that helper. That lift
# carries no delivered evidence and needs none; what it must not be is
# indistinguishable from an operator reconciliation that simply omitted its
# evidence, which is why it says so.
CUSTODY_DIRECT_ACT = "direct-act"

# THE CLOSED SHAPE, for the reason every document in this package is closed: an
# unexpected member is a document from something other than the contract this
# validator is about, and reading the recognised parts out of it is how a
# manager ends up clearing a hold on the strength of a shape it did not check.
_SETTLEMENT = {"source": str, "helper_identity": str,
               "custodian_image_digest": str, "status": int, "document": dict}


def _settlement(held, settlement, *, attempt_id, which, episode):
    """The delivered answer, held against the episode it claims to settle.

    REFUSES RATHER THAN INTERPRETS. Every rule here is one the PLAN names, and
    each is about the same question: could this answer be true while the
    submitted request is still pending? If it could, it does not settle.
    """
    if type(settlement) is not dict:
        raise ContractRefusal(
            "integrity", "schema",
            "a settlement is the engine's own answer about the helper this "
            "episode recorded, as one document")
    missing = sorted(one for one in _SETTLEMENT if one not in settlement)
    extra = sorted(one for one in settlement if one not in _SETTLEMENT)
    if missing or extra:
        raise ContractRefusal(
            "integrity", "schema",
            "a settlement is exactly "
            + ", ".join(sorted(_SETTLEMENT))
            + (f"; missing {', '.join(missing)}" if missing else "")
            + (f"; unexpected {', '.join(extra)}" if extra else ""))
    for one, expected in sorted(_SETTLEMENT.items()):
        if type(settlement[one]) is not expected:
            raise ContractRefusal(
                "integrity", "schema",
                f"a settlement's {name_value(one)} is the "
                f"{expected.__name__} this contract answers")
    # ONLY THE ENGINE'S OWN ANSWER. A local exit status is this process's
    # account of its own client, and a listing is a question about what exists
    # rather than about what finished -- neither can exclude a delayed request,
    # so neither is a source this accepts.
    if settlement["source"] != CUSTODY_ENGINE_ANSWER:
        raise ContractRefusal(
            "refused", "precondition",
            f"a settlement source is {name_value(CUSTODY_ENGINE_ANSWER)} and "
            f"this one is {name_value(settlement['source'])}; an operator's "
            f"account, a local command's exit status and an empty helper "
            f"listing are all true while the submitted request is still "
            f"pending, so none of them settles it")
    # THE EXACT HELPER AND THE EXACT CUSTODIAN. An answer about another helper,
    # or about the same name under a different custodian image, is an answer
    # about a different act.
    for one, recorded in (("helper_identity", held.get("helper_identity")),
                          ("custodian_image_digest",
                           held.get("custodian_image_digest"))):
        if settlement[one] != recorded:
            raise ContractRefusal(
                "refused", "precondition",
                f"attempt {name_value(attempt_id)}'s {which} root episode "
                f"{episode!r} recorded {one} {name_value(recorded)} and this "
                f"settlement answers for {name_value(settlement[one])}; an "
                f"account of another act settles nothing here")
    # NONZERO IS NOT AN ENDING THIS MANAGER MAY READ. The PLAN says so, and the
    # reason is that a failing client says nothing about the daemon's queue.
    if settlement["status"] != 0:
        raise ContractRefusal(
            "refused", "precondition",
            f"the settlement for episode {episode!r} answers status "
            f"{settlement['status']!r}; a nonzero answer is an act this "
            f"manager cannot account for, and an unaccounted act is exactly "
            f"what this episode is holding")
    # AND THE DOCUMENT IS THE VERB'S OWN RESULT, by the same rule a live act is
    # held to. A custodian REFUSAL is accountable but is not a settled
    # mutation, and the PLAN's "unaccountable answer" bar is this one.
    verb = held.get("verb")
    if verb not in _CUSTODY_RESULT:
        raise ContractRefusal(
            "refused", "precondition",
            f"episode {episode!r} recorded verb {name_value(verb)}, which is "
            f"not one this manager can be shown the settlement of")
    accounted, why = _accountable(verb, settlement["document"])
    answered = settlement["document"].get("custody")
    if accounted is None or answered != verb:
        raise ContractRefusal(
            "refused", "precondition",
            f"the settlement for episode {episode!r} is not an accountable "
            f"{verb} result: "
            + (why or f"it answers {name_value(answered)} rather than "
                      f"{name_value(verb)}"))
    # W257624 R2, ATTRIBUTION-PLAN item 3: THE ECHOED TOKEN IS THE BINDING.
    # It is the one fact in a delivered document that only the act this episode
    # submitted could carry, so it -- not equality of ordinary result fields --
    # is what ties evidence to a submission. A legacy hold that committed no
    # token cannot be attributed and stays held, by the same rule.
    expected = held.get("claimant")
    offered = settlement["document"].get("submission") \
        if type(settlement["document"]) is dict else None
    if not expected:
        raise ContractRefusal(
            "refused", "precondition",
            f"episode {episode!r} committed no submission token, so no "
            f"delivered answer can be attributed to its act; it stays held "
            f"rather than being reconciled on evidence about some other "
            f"submission")
    if offered != expected:
        raise ContractRefusal(
            "refused", "precondition",
            f"the settlement for episode {episode!r} answers for submission "
            f"{name_value(offered)} and that episode submitted "
            f"{name_value(expected)}; an answer about another submission "
            f"settles nothing here, however ordinary its contents look")
    return {one: settlement[one] for one in sorted(_SETTLEMENT)}


def clear_custody_hold(store, *, attempt_id, which, episode, observed,
                       helper_identity, settlement):
    """An OPERATOR's reconciliation of ONE uncertainty episode.

    WHAT IT RECORDS IS WHAT WAS OBSERVED **AND** WHAT THE ENGINE ANSWERED.
    W257624 R2: the operator's account is still required -- somebody has to say
    what they did -- but it is no longer sufficient, because "I looked and the
    helper is gone" is true of a request that has not run yet. `_settlement`
    owns that bar.

    A CLEARANCE IS BOUND TO ONE EXACT EPISODE, member by member: the hold
    record must be committed AND of the hold kind, its retained document must
    carry the signature that identity was signed for, and the attempt, root and
    episode inside that document must be the ones this clearance names. A
    record found at a derived key is not evidence about this episode until all
    of that agrees.

    REPLAY IS THE STORE'S. An identical clearance at the same identity replays
    its own record, which is what a journal does; a DIFFERENT one at that
    identity is refused by §4.2, one identity carries one act. This function
    therefore does not add an "already cleared" refusal of its own, and an
    earlier draft of this docstring claimed it did.
    """
    from .store import manager_signature

    boundaries.identity(attempt_id, "an assignment identity")
    check_custody_root(which)
    observed = boundaries.text(observed, "what the operator observed")
    helper_identity = boundaries.text(helper_identity,
                                      "the helper identity reconciled")
    if not observed.strip():
        raise ContractRefusal(
            "integrity", "schema",
            "a reconciliation records what the operator OBSERVED; a blank "
            "account is not an observation")
    identity = _hold_identity(CUSTODY_HOLD_KIND, attempt_id, which, episode)
    record = store.operation_record(identity)
    if record is None or record["state"] != "committed":
        raise ContractRefusal(
            "refused", "precondition",
            f"attempt {name_value(attempt_id)}'s {which} root has no "
            f"uncertainty episode {episode!r} to reconcile; a clearance is "
            f"written against an episode this manager recorded")
    if record["kind"] != CUSTODY_HOLD_KIND:
        raise ContractRefusal(
            "refused", "precondition",
            f"the record at attempt {name_value(attempt_id)}'s {which} root "
            f"episode {episode!r} is of kind {record['kind']!r}; a clearance "
            f"lifts a hold and not whatever else shares its key")
    import json as _json

    try:
        document = _json.loads(record["result"])
    except (TypeError, ValueError):
        document = None
    if type(document) is not dict:
        raise ContractRefusal(
            "refused", "precondition",
            f"the uncertainty recorded for attempt {name_value(attempt_id)}'s "
            f"{which} root episode {episode!r} retained no document; there is "
            f"nothing to reconcile it against")
    # THE RETAINED DOCUMENT IS THE ONE THIS IDENTITY WAS SIGNED FOR. Without
    # this, a row whose document had been replaced would be reconciled as
    # though it were the hold that was committed.
    if record["signature"] != manager_signature(CUSTODY_HOLD_KIND, document):
        raise ContractRefusal(
            "refused", "precondition",
            f"the uncertainty recorded for attempt {name_value(attempt_id)}'s "
            f"{which} root episode {episode!r} does not carry the signature "
            f"its operation identity was committed under; a document this "
            f"manager cannot bind to its own act is not evidence about it")
    # AND THE DOCUMENT'S OWN BINDING, so a clearance cannot reconcile one
    # episode's record while naming another's coordinates.
    for one, named in (("attempt_id", attempt_id), ("root", which),
                       ("episode", episode)):
        if document.get(one) != named:
            raise ContractRefusal(
                "refused", "precondition",
                f"the uncertainty at {which} root episode {episode!r} records "
                f"{one} {name_value(document.get(one))} and this clearance "
                f"names {name_value(named)}; a reconciliation is written "
                f"against the episode it actually describes")
    if document.get("helper_identity") != helper_identity:
        raise ContractRefusal(
            "refused", "precondition",
            f"episode {episode!r} recorded helper "
            f"{name_value(document.get('helper_identity'))} and this "
            f"clearance names {name_value(helper_identity)}; a reconciliation "
            f"is evidence about the helper it actually observed")
    settled = _settlement(document, settlement, attempt_id=attempt_id,
                          which=which, episode=episode)
    # W257624 R2 [P1], review 2026-09-24T21-39-09Z: ONE ACCOUNTABLE ANSWER
    # ACCOUNTS FOR ONE ACT.
    #
    # `_custody_identity` deliberately excludes the episode -- that
    # exclusion is what lets a restarted manager re-derive the name -- so two
    # submissions
    # over one root share a helper name, and settlements composed for them
    # compare EQUAL. Every check above therefore passed for episode 0's
    # evidence offered against episode 1, and the reviewer's regression cleared
    # an unresolved act with a stale answer.
    #
    # SO A SETTLEMENT IS SPENT. Two submissions are two acts and one answer
    # cannot settle both, which is a rule about the EVIDENCE rather than about
    # the episode number a caller writes next to it.
    # ATTRIBUTION-PLAN item 6: THE DOCUMENT-EQUALITY SPENT CHECK IS RETIRED.
    # It was a stand-in for attribution and it was the wrong shape: two
    # legitimate submissions can report identical counts and identities, so
    # refusing a new observation because its ordinary fields repeat would block
    # valid evidence. The submission token above does the work exactly -- a
    # stale answer from any earlier act, successful or lost, echoes that act's
    # token and is refused by name.
    operation_id = _hold_identity(CUSTODY_CLEARED_KIND, attempt_id, which,
                                  episode)
    body = {"attempt_id": attempt_id, "root": which, "episode": episode,
            "helper_identity": helper_identity, "observed": observed,
            "settlement": settled}
    return store.transact(
        operation_id, CUSTODY_CLEARED_KIND,
        manager_signature(CUSTODY_CLEARED_KIND, body), lambda _c: dict(body))


def _claim_episode(store, assignment_id, which, operation, image_digest,
                   name):
    """Claim the next uncertainty episode EXCLUSIVELY, or refuse.

    W257624 R1. One caller owns the episode; every concurrent or restarted
    caller refuses before it has submitted or reclaimed anything.

    HOW THE EXCLUSION IS ACTUALLY WON, because a check and a write are two
    acts. `ControlStore.transact` takes `BEGIN IMMEDIATE` and re-reads inside
    the lock, so two connections serialize there -- but only if their operands
    DIFFER, because identical operands at one identity are a replay and the
    loser would be handed the winner's record as its own.

    SO THE CLAIM CARRIES A SUBMITTER TOKEN. It is a nonce and nothing else: it
    names no path, selects no resource and is never read back as authority.
    With it, the loser signs different operands at the same identity and the
    store refuses it by §4.2 -- one identity carries one act -- which is the
    refusal this stage wants and is the store's own rule rather than a new
    one.
    """
    import json as _json
    import uuid

    from .store import manager_signature

    standing = _standing_overlap(store, assignment_id, which)
    if standing is not None:
        held_root = standing["held"]["root"]
        raise ContractRefusal(
            "refused", "precondition",
            f"attempt {name_value(assignment_id)}'s {held_root} root carries "
            f"unreconciled uncertainty episode {standing['episode']!r}, and "
            f"this act would touch it by acting on the {which} root -- the two "
            f"roots of one attempt overlap, so neither is free while either is "
            f"held: an "
            f"earlier act submitted a request that produced no engine answer, "
            f"and the helper it would have created is "
            f"{name_value(standing['held']['helper_identity'])}. This root is "
            f"FROZEN -- no submission, no reclamation, no reuse and no "
            f"deletion on the strength of that act -- until an operator "
            f"records what they observed")
    held = custody_holds(store, assignment_id, which)
    if len(held) >= _MOST_HOLDS:
        raise ContractRefusal(
            # W257624 R2: `limit` IS AN INTEGRITY CODE. This said
            # `refused`, which the contracts layer refuses as a
            # closed-pairing violation -- so every bound in this module
            # raised an AssertionError about its own refusal instead of
            # the refusal. Found by reaching it.
            "integrity", "limit",
            f"attempt {name_value(assignment_id)}'s {which} root has "
            f"{len(held)} recorded uncertainty episodes, which is this "
            f"manager's bound; it is reconciled rather than acted on again")
    episode = len(held)
    body = {"attempt_id": assignment_id, "root": which, "episode": episode,
            "verb": operation, "custodian_image_digest": image_digest,
            "helper_identity": name, "claimant": uuid.uuid4().hex}

    def claiming(_connection):
        # W270664 F2: THE RECIPROCAL HALF OF THE REMOVAL EXCLUSION, read under the very
        # lock that makes this claim exclusive. Review 2026-09-26T06:21:32Z: this callback
        # read custody overlap and NOTHING about a removal, so a removal ownership on its
        # own excluded nothing -- a hold could commit while the tree was coming off the
        # disk. A removal admitted first is refused here; a hold admitted first is refused
        # by `_admitted_removal`. Neither side is trusted to check only its own side.
        from . import workspaces

        removing = workspaces.standing_removal(store, assignment_id)
        if removing:
            ordinal, _ = removing[0]
            raise ContractRefusal(
                "refused", "precondition",
                f"attempt {name_value(assignment_id)}'s roots are being removed under "
                f"removal ownership {ordinal}, which has recorded no completion; a hold "
                f"is not taken over a tree that is being deleted, and an uncertain "
                f"removal is reconciled rather than held around")
        # W285463 R1: AND THE RECIPROCAL HALF FOR A GOVERNED MAINTENANCE ACT, read
        # under this same lock. Review 2026-09-27T13-17-14Z: this callback knew about
        # removals and other custody holds and NOTHING about the token-bound
        # preparation that now writes into these roots -- so a custody hold could
        # commit while a maintenance container was mounted on the workspace, and each
        # side would have excluded the other only by luck of ordering.
        #
        # THE WINDOW IS WHAT IS READ, NOT THE TOKEN, and that is not a second lock:
        # the token's domain is `device:inode` of a root, so asking the token journal
        # here would mean an `lstat` UNDER `BEGIN IMMEDIATE` -- the external I/O DB-2
        # forbids inside a transaction. `standing_maintenance` is derived-identity
        # journal reads only, which is what makes it askable from in here.
        #
        # BOTH OVERLAPPING ROOTS, for `_standing_overlap`'s own reason: the result
        # root sits INSIDE the workspace, so a preparation on either is acting inside
        # material the other contains.
        # W285464 review 2026-09-27T16-41-41Z: AND THE HOST PREPARATION WINDOW.
        # The amended TOK-7 lets the Host manager allocate, stage, publish and set
        # permissions itself, so a preparation is a writer inside these roots -- and
        # this callback knew about removals and maintenance windows and nothing about
        # it. Read by derived identity, so no filesystem work happens under this lock.
        preparing = workspaces._preparation_refusal(
            store, assignment_id,
            f"claiming a custody episode for the {which} root")
        if preparing is not None:
            raise preparing
        # W285464 review 2026-09-27T18-00-36Z: AND A LIVE TASK TOKEN. A custody act is
        # a writer inside these roots, so it is not claimed beside a running governed
        # execution -- the token is returned first, which is the ownership transfer.
        governed = workspaces._task_token_refusal(
            store, assignment_id,
            f"claiming a custody episode for the {which} root")
        if governed is not None:
            raise governed
        from . import maintenance

        for root in CUSTODY_ROOTS:
            for ordinal, record in maintenance.standing_maintenance(
                    store, assignment_id, root):
                held = record["result"]
                held = (_json.loads(held) if type(held) is str
                        else (held or {}))
                raise ContractRefusal(
                    "refused", "precondition",
                    f"attempt {name_value(assignment_id)}'s {root} root carries "
                    f"unsettled maintenance window {ordinal} for "
                    f"{name_value(held.get('verb'))}, whose container is "
                    f"{name_value(held.get('helper_identity'))}; a custody hold is "
                    f"not taken over a tree a governed preparation may still be "
                    f"writing, and that window is reconciled rather than acted past")
        # RE-READ INSIDE THE LOCK, which is what makes this exclusive rather
        # than merely early.
        again = _standing_overlap(store, assignment_id, which)
        if again is not None:
            raise ContractRefusal(
                "refused", "precondition",
                f"attempt {name_value(assignment_id)}'s "
                f"{again['held']['root']} root was held at episode "
                f"{again['episode']!r} while this act was claiming one for the "
                f"overlapping {which} root; nothing was submitted")
        return dict(body)

    store.transact(
        _hold_identity(CUSTODY_HOLD_KIND, assignment_id, which, episode),
        CUSTODY_HOLD_KIND,
        manager_signature(CUSTODY_HOLD_KIND, body), claiming)
    # AND THE WINNER'S OWN TOKEN. Reading it back out of the row looked safer
    # and was worse: a refused row carries no result, so the read tripped over
    # its own `None`. It is also unnecessary. R1's rule is what makes this
    # sound -- the nonce puts every caller's operands at a different value, so
    # `transact` either commits THIS body, replays an identical one (same
    # nonce, same token), or refuses. If it returned, this body is the record.
    return episode, body["claimant"]


def _record_hold(store, assignment_id, which, operation, image_digest, name):
    """Commit the uncertainty BEFORE the request crosses, and answer its
    episode.

    THE EPISODE IS THE NEXT UNRECORDED ONE, read in the same breath. Two
    uncertainties over one root are two facts, and a clearance written for the
    first must not lift the second -- so the episode rides in the identity.

    FAIL-CLOSED ON OVERFLOW: a root that has accumulated this manager's bound
    of episodes is one an operator has to reconcile, not one to add another to.
    """
    from .store import manager_signature

    held = custody_holds(store, assignment_id, which)
    if len(held) >= _MOST_HOLDS:
        raise ContractRefusal(
            # W257624 R2: `limit` IS AN INTEGRITY CODE. This said
            # `refused`, which the contracts layer refuses as a
            # closed-pairing violation -- so every bound in this module
            # raised an AssertionError about its own refusal instead of
            # the refusal. Found by reaching it.
            "integrity", "limit",
            f"attempt {name_value(assignment_id)}'s {which} root has "
            f"{len(held)} recorded uncertainty episodes, which is this "
            f"manager's bound; it is reconciled rather than acted on again")
    episode = len(held)
    body = {"attempt_id": assignment_id, "root": which, "episode": episode,
            "verb": operation, "custodian_image_digest": image_digest,
            "helper_identity": name}
    store.transact(
        _hold_identity(CUSTODY_HOLD_KIND, assignment_id, which, episode),
        CUSTODY_HOLD_KIND,
        manager_signature(CUSTODY_HOLD_KIND, body), lambda _c: dict(body))
    return episode


def _clear_hold(store, assignment_id, which, episode, name, *, observed,
                accounted):
    """Clear ONE episode on the act's own accountable answer.

    W257624 R2: THE TWO LIFTS ARE NAMED APART. This one is the manager's own
    receipt for an act it watched end accountably; `clear_custody_hold` writes
    an operator's reconciliation carrying delivered evidence. The reader has to
    tell them apart, and review 2026-09-24T21-39-09Z is right that it must do
    so by a stated distinction rather than by which member happens to be
    absent -- so this records `accounted` and that one records `settlement`,
    and a clearance carrying neither or both is refused.
    """
    from .store import manager_signature

    body = {"attempt_id": assignment_id, "root": which, "episode": episode,
            "helper_identity": name, "observed": observed,
            "accounted": CUSTODY_DIRECT_ACT,
            "accounted_document": accounted}
    store.transact(
        _hold_identity(CUSTODY_CLEARED_KIND, assignment_id, which, episode),
        CUSTODY_CLEARED_KIND,
        manager_signature(CUSTODY_CLEARED_KIND, body), lambda _c: dict(body))


def _standing_hold(store, assignment_id, which):
    """The oldest UNCLEARED episode for this root, or `None`."""
    for one in custody_holds(store, assignment_id, which):
        if not one["cleared"]:
            return one
    return None


def _standing_overlap(store, assignment_id, which):
    """The oldest uncleared episode on ANY root whose tree overlaps `which`.

    W257624 R3 [P1], review 2026-09-25T04-25-17Z. THE TWO ROOTS OF ONE ATTEMPT
    ARE NOT SIBLINGS: `_derived_root` puts the result root at
    `<home>/workspace/result-<attempt>`, INSIDE the workspace. So a hold on
    either one covers material the other contains or is contained by, and a
    helper acting on the descendant is acting inside the held ancestor.

    ASKING ABOUT ONE ROOT WAS THEREFORE NOT ASKING. `_claim_episode` consulted
    `_standing_hold` for its own `which` only, so with the workspace held the
    ending's FIRST act -- the normalization intake then performed, visiting the
    nested result root first; the helper itself was removed under W285465's owner
    ruling and this history is why the containment argument stays -- claimed,
    SUBMITTED and settled a result helper, and only then
    refused at the workspace. The reviewer's regression measures the forbidden
    second submission at the engine boundary, and a later refusal does not undo
    an effect that already crossed.

    ONE ATTEMPT ONLY, WHICH IS WHAT KEEPS CONCURRENCY. The overlap being closed
    here is physical containment WITHIN one assignment home; two different
    attempts share no tree, so this says nothing about them and does not
    serialize them.
    """
    check_custody_root(which)
    for root in CUSTODY_ROOTS:
        standing = _standing_hold(store, assignment_id, root)
        if standing is not None:
            return standing
    return None


def normalize_directory(store, custody, *, assignment_id, which,
                        seconds=None, reclaim=None):
    """ONE ROOT NORMALIZED, ONCE, WITH A SIGNED RECEIPT.

    W43975 review 2026-08-30T11:32:34Z [P0]. `directory_custody` was a noun:
    the record pinned one operation identity per (attempt, root, verb) and
    defined no journal kind, no closed result and no way for a terminal
    cleanup to bind the two receipts. Reusing only the outer `runtime.destroy*`
    journal is not enough -- a crash after the result root settles and before
    the workspace root does would lose the first root's independent durable
    answer, and a changed custodian could not be stated as a collision PER
    ROOT.

    THE IDENTITY IS THE ONE THE RECORD PINS: the fixed attempt, the root kind
    and the closed verb, derived exactly as the helper's own name is so a
    restarted manager re-derives both from the same durable read.

    THE SIGNATURE BINDS WHAT WOULD MAKE THIS A DIFFERENT ACT: the custodian
    IMAGE identity and the durable workspace-store identity W43974 already
    made load-bearing. A changed helper or a retargeted deployment therefore
    COLLIDES rather than replaying an answer about another act over another
    tree.

    NOTHING IS COMMITTED UNLESS THE ANSWER IS ACCOUNTABLE. `CustodyAnswer.ok`
    is the whole gate -- a clean exit, a readable document, and a document
    about THIS verb. A refused, unaccounted or `UNRESOLVED` answer commits
    nothing at all and raises, so the ending above returns its existing
    retryable unsettled shape rather than recording a custody act that did not
    happen.

    THE CAPABILITY IS TYPED AND OWNED ELSEWHERE. The review refused to let
    `intake.py` reach through a nominally generic adapter to its mutable
    `engine`, `run` and `image_digest` fields; what crosses here is one object
    exposing `normalize_directory`, and composing the act stays inside the
    thing that holds those fields.
    """
    from . import documents
    from .store import manager_signature

    boundaries.capability(getattr(custody, "normalize_directory", None),
                          "the runtime adapter's directory-custody act")
    boundaries.identity(assignment_id, "an assignment identity")
    check_custody_root(which)
    # THE CUSTODIAN IMAGE IS THE CAPABILITY'S, READ THROUGH ITS OWN SURFACE.
    # It is a signature input rather than an operand: the act's meaning
    # depends on which helper performed it, so a changed helper must collide
    # rather than replay. Reading it off the custody is what keeps
    # `intake.py` from reaching into the adapter's mutable fields for it.
    image = boundaries.text(
        getattr(custody, "custodian_image_digest", None),
        "the custodian image identity this act is signed with")
    recorded = _recorded_store(store)
    operation_id = _custody_operation_id(assignment_id, which)
    signature = manager_signature(
        "directory-custody.normalize",
        {"attempt_id": assignment_id, "root": which, "verb": "normalize",
         "custodian_image_digest": image, "workspace_store": recorded})
    found, already = store.replay(operation_id, signature,
                                  kind="directory-custody.normalize")
    if found:
        # EXACT REPLAY BEFORE THE ACT, so a resumed ending does not normalize
        # a tree its predecessor already normalized and does not re-run a
        # helper over a home the manager may since have removed.
        return already
    if seconds is None:
        answered = custody.normalize_directory(
            store, assignment_id=assignment_id, which=which)
    else:
        answered = custody.normalize_directory(
            store, assignment_id=assignment_id, which=which, seconds=seconds,
            reclaim=reclaim)
    if not isinstance(answered, CustodyAnswer) or not answered.ok:
        # §9's pairing is CLOSED, so this refuses under a pair that exists
        # rather than minting a code for the occasion: an act this manager
        # cannot account for did not meet the precondition for recording one.
        # W247941, owner 257086: THE DIAGNOSTIC TRAVELS WITH THE REFUSAL.
        # An unaccountable act may be an UNRESOLVED one, and that answer names
        # the helper identity and the root it may still reach. A refusal that
        # dropped it would tell an operator an ending did not happen without
        # telling them what is frozen pending their reconciliation.
        held = getattr(answered, "unaccounted", None) or ""
        diagnostic = getattr(answered, "diagnostic", None) or ""
        raise ContractRefusal(
            "refused", "precondition",
            f"the directory custody act over attempt "
            f"{name_value(assignment_id)}'s {which} root did not answer "
            f"accountably; nothing is recorded, and an ending is not claimed "
            f"on an act this manager cannot account for"
            + (f". {held}" if held else "")
            + (f". {diagnostic}" if diagnostic else ""))
    return store.transact(
        operation_id, "directory-custody.normalize", signature,
        lambda _connection: documents.directory_custody_settled(
            attempt_id=assignment_id, root=which, verb="normalize",
            # THE CUSTODIAN'S OWN ACCOUNT, QUOTED. `rendered` is the
            # canonical serialization produced at mint time from the parsed
            # document; recomposing a dict here would be re-deriving the
            # account instead of recording the one that was accepted.
            account=answered.rendered,
            operation=answered.operation))


def adopted_directory_custody(store, custody, assignment_id, which,
                              prepared_store=None):
    """The committed receipt, READ BACK FROM THE JOURNAL.

    Review [P0] point 3: a terminal cleanup binds the receipts a caller HOLDS
    only if it read them from the journal itself. A caller-held document is
    one the caller composed, and the terminal claim's whole value is naming
    which directory acts authorized it.

    W270664 F2: a caller reading this INSIDE its own write transaction passes
    `prepared_store`, the frozen store it measured before the transaction
    opened, so that deriving the signature costs no filesystem call. What the
    receipt is read from -- the journal, through `replay`, at an identity
    derived from the attempt and the root -- is not changed by that operand.
    """
    from .store import manager_signature

    # HELD HERE TOO, and W43977 is what found it missing. This derives an
    # operation identity from the attempt and the root kind, so an unheld
    # identity would look one up for a name this manager never allocated --
    # a read, but a read of somebody else's act.
    boundaries.identity(assignment_id, "an assignment identity")
    check_custody_root(which)
    image = boundaries.text(
        getattr(custody, "custodian_image_digest", None),
        "the custodian image identity this act is signed with")
    recorded = _recorded_store(store, prepared_store)
    found, already = store.replay(
        _custody_operation_id(assignment_id, which),
        manager_signature(
            "directory-custody.normalize",
            {"attempt_id": assignment_id, "root": which, "verb": "normalize",
             "custodian_image_digest": image, "workspace_store": recorded}),
        kind="directory-custody.normalize")
    return already if found else None


def historical_directory_custody(store, assignment_id, which):
    """Read the exact committed normalization receipt without an adapter.

    The recorded image identifies the historical act; it does not select an
    image for this deployment. Identity derivation and journal interpretation
    stay here, with the normalization owner. No directory or helper is touched.
    """
    import json
    from .store import manager_signature

    boundaries.identity(assignment_id, "an assignment identity")
    check_custody_root(which)
    kind = "directory-custody.normalize"
    operation_id = _custody_operation_id(assignment_id, which)
    record = store.operation_record(operation_id)
    if record is None or record["kind"] != kind or record["state"] != "committed":
        raise ContractRefusal("refused", "precondition",
                              "historical directory custody requires its committed normalization")
    try:
        signature = json.loads(record["signature"])
    except (TypeError, ValueError):
        raise ContractRefusal("integrity", "schema",
                              "historical directory custody has an unreadable signature") from None
    signature = boundaries.document(signature, "a historical custody signature", required=("kind", "operands"))
    operands = boundaries.document(signature["operands"], "historical custody operands",
        required=("attempt_id", "root", "verb", "custodian_image_digest", "workspace_store"))
    image = boundaries.text(operands["custodian_image_digest"], "a historical custodian image identity")
    expected = manager_signature(kind, {
        "attempt_id": assignment_id, "root": which, "verb": "normalize",
        "custodian_image_digest": image, "workspace_store": _recorded_store(store)})
    found, receipt = store.replay(operation_id, expected, kind=kind)
    receipt = boundaries.document(receipt, "a historical directory custody receipt",
        required=("attempt_id", "root", "verb", "account", "operation"))
    if not found or receipt["attempt_id"] != assignment_id or receipt["root"] != which \
            or receipt["verb"] != "normalize" or receipt["operation"] != "normalize":
        raise ContractRefusal("integrity", "schema",
                              "historical directory custody receipt names another subject or act")
    try:
        account = json.loads(receipt["account"])
    except (TypeError, ValueError):
        raise ContractRefusal("integrity", "schema",
                              "historical directory custody has an unreadable account") from None
    account = boundaries.document(account, "a historical normalization account")
    accounted, why = _accountable("normalize", account)
    if accounted is None or accounted["custody"] != "normalize" \
            or json.dumps(accounted, sort_keys=True) != receipt["account"]:
        raise ContractRefusal("integrity", "schema",
                              "historical directory custody has no exact accountable normalization")
    return receipt


def _recorded_store(store, prepared=None):
    """The configured store's place, for the signature this act is written under.

    W270664 F2: `prepared` is a store ALREADY measured outside every
    transaction. Given one, the place is rebound to this database with no
    filesystem call -- see `workspaces.recorded_storage_place`, which is where
    the provenance and the staleness refusal live. Without one this is the
    accepted reader, unchanged, and every caller that is not under a lock keeps
    using it.
    """
    from .workspaces import (configured_workspace_storage,
                             recorded_storage_place)

    if prepared is not None:
        return recorded_storage_place(store, prepared)
    return configured_workspace_storage(store).place


def _custody_operation_id(assignment_id, which):
    """One identity per (attempt, root, verb), derived and never chosen.

    THE STORE AND THE IMAGE ARE SIGNATURE INPUTS AND NOT IDENTITY INPUTS, and
    the difference is the whole point of the collision the record requires.
    Review 2026-08-30T14:51:22Z [P0]: my first cut folded the recorded
    workspace store into the id, so a RETARGETED deployment derived a
    DIFFERENT identity and quietly performed a second act over the same
    attempt's root -- exactly the fork the collision exists to prevent. An
    identity that varies with the thing whose change must collide can never
    collide with it.

    So the identity is the three facts the record pins, and everything that
    would make this a different ACT over the same subject rides the signature.
    """
    material = "\n".join(("baton-v12-directory-custody",
                           assignment_id, which, "normalize"))
    return ("directory-custody-"
            + hashlib.sha256(material.encode("utf-8")).hexdigest())


def allowed(seconds, most):
    """`min(seconds left, this boundary's own maximum)`, or the maximum.

    W247941, owner selection 256143: ONE monotonic decreasing allowance across
    a whole ending, clamped at each supported boundary. Two rules make this
    safe to apply anywhere:

      * `None` IS TODAY. An unbounded caller gets the package's own maximum
        exactly as before, so no accepted caller changes.
      * A BOUNDED CALLER MAY ONLY ASK FOR LESS. The maximum is a ceiling the
        deployment chose; an allowance cannot raise it, only spend within it.

    A non-positive allowance answers zero, which every boundary here treats as
    "do not start" rather than "wait forever" -- the caller checked before
    calling, and this is the second reading that makes the race harmless.
    """
    if seconds is None:
        return most
    left = seconds() if callable(seconds) else seconds
    if left is None:
        return most
    # A WHOLE NUMBER, because `EnginePort` refuses anything else -- "an engine
    # deadline is a positive whole number of seconds" -- and rounded DOWN.
    #
    # Review 2026-09-24T11:02:29Z [R1] reproduced the defect exactly:
    # `allowed(lambda: 0.1, 120)` answered 1. Rounding UP hands a boundary
    # MORE time than the caller has left, which is the one direction an
    # allowance may never round. My reasoning for it -- that rounding down
    # turns a real remainder into an immediate refusal -- was solving the
    # wrong problem: a caller with a tenth of a second left should not be
    # STARTING anything, and that is the admission reserve's job rather than
    # this function's.
    #
    # SO A SUB-SECOND REMAINDER ANSWERS ZERO, and every boundary reads zero as
    # "do not start". The allowance never exceeds what is left.
    return max(0, min(int(left), int(most)))


def custody_act(engine, run, *, image_digest, store, assignment_id,
                operation, which="workspace"):
    """ONE CUSTODY ACT, PERFORMED -- lookup, composition, execution, answer.

    Review [P0] round ten, and it is the last interval this Work had left. The
    previous shape authenticated the bind source, composed it into `--mount`
    and RETURNED the list; every production ending would then have executed
    that list separately, so between the durable lookup and the engine use
    there was an ordinary mutable object in somebody else's hands. Nine
    earlier rounds closed that interval around progressively smaller objects.
    This one removes the interval instead: there is no return value a caller
    can execute, because the execution already happened here.

    `run` IS THE ENGINE PORT, the same one every other vector this manager
    composes goes through, and handing the argv to it is not a handoff -- it
    is the invocation. It is the boundary of the process rather than a party
    inside it, and routing custody through it also puts the act under the §13
    sweep `EnginePort` owns.

    WHAT COMES BACK IS AN ANSWER. `CustodyAnswer` carries the verb, the exit
    status, the custodian's document and a bounded diagnostic; it carries no
    host path and no command vector, so nothing a caller holds afterwards can
    select a directory or run anything.

    AND THE DOCUMENT IS HELD TO THE VERB THAT WAS ASKED FOR. Review
    (2026-08-30T04:07:53Z) [P1]: the exit status and the mere presence of JSON
    were the whole of `ok`, so an act that answered about a different verb, or
    left out the members its own verb reports, was accounted for as custody.
    `_accountable` decides that before anything can be `ok`, and `_frozen`
    makes what is retained read-only all the way down.
    """
    from .oci import EnginePort

    port = run if type(run) is EnginePort else EnginePort(run)
    # W257624 R2: THE CLAIM COMES FIRST, because the act now carries the token
    # that claim commits. The helper identity is derived the same way it always
    # was -- from the durable store, attempt, root and verb -- so the name the
    # claim records and the name the vector composes are still one derivation,
    # and reclamation is unchanged. What moved is only the ORDER, which R1
    # already wanted: nothing reaches an engine before admission.
    # THE VERB AND THE ROOT ARE CHECKED BEFORE ANYTHING IS CLAIMED. Found by
    # `tests.manager.test_custody`: with the claim moved ahead of the vector, a
    # refused verb was committing an uncertainty episode on its way out and
    # freezing the root, having submitted nothing. Admission is for acts this
    # manager would actually perform, so the closed-set checks the vector
    # already applies run here too -- the same functions, ahead of the claim.
    operation = check_custody_operation(operation)
    check_custody_root(which)
    name = _custody_identity(_recorded_store(store), assignment_id, which,
                             operation)
    episode, submission = _claim_episode(store, assignment_id, which,
                                         operation, image_digest, name)
    argv, composed = _custody_vector(engine, image_digest=image_digest,
                                     store=store, assignment_id=assignment_id,
                                     operation=operation, which=which,
                                     submission=submission)
    if composed != name:                                 # pragma: no cover
        raise ContractRefusal(
            "refused", "precondition",
            "the helper identity this act claimed and the one its vector "
            "composed disagree; one derivation answers both or neither")
    # W257624 R1: THE EXCLUSION IS CLAIMED BEFORE ANY HELPER ACT AT ALL.
    #
    # Owner 257693 selects "no submission OR RECLAMATION behind a standing
    # hold". It used to sit below the reconciliation, so a second caller
    # arriving behind a held root still issued its listing, and a stranded
    # candidate would have been stopped and removed before anything checked.
    # Those are destructive vectors on a path that must issue none.
    #
    # CLAIMED, NOT MERELY CHECKED. `_claim_episode` reads the standing holds
    # and writes the next episode inside ONE write transaction, so two
    # connections racing here serialize at the store: the loser sees the
    # winner's episode and refuses having submitted nothing.
    # W43974: WHAT IS ALREADY ANSWERING TO THIS IDENTITY, decided before
    # anything launches. `--rm` reclaims on the engine's normal completion
    # path and on no other, so a manager or client that died mid-act left a
    # helper this build never looked for -- and could not have looked for,
    # because the name was the caller's.
    stranded = _reconciled(engine, port, name=name, image_digest=image_digest)
    if stranded is not None:
        _reclaimed(engine, port, name=name, runtime_id=stranded)
    try:
        # THE ACT'S OWN CALL IS NOT WRAPPED BY `_settled`, because its
        # failure is not a refusal -- it is the lost ending that recovery and
        # the typed answer below exist for. What `_settled` gives the
        # reclamation steps is the conversion into a refusal; here the raw
        # ending is what decides.
        answered = port(argv, seconds=CUSTODY_ACT_SECONDS)
    except BaseException as failed:
        # EVERY ENDING THAT IS NOT AN ENGINE ANSWER GOES THROUGH RECOVERY, and
        # the exception's CLASS decides nothing about whether the helper ran.
        #
        # W43974 review (2026-08-30T05:15:08Z) [P1]: the first round treated a
        # `ContractRefusal` as proof that invocation never happened and
        # re-raised it untouched. `EnginePort.__call__` invokes the injected
        # capability and validates the answer AFTERWARDS, so a malformed
        # engine answer is a refusal that arrives with the helper already
        # launched. A pre-invocation refusal is harmless here anyway: recovery
        # finds nothing and does nothing.
        #
        # RECOVERY MAY ITSELF REFUSE and that refusal propagates. An unproved
        # or contradicted absence is exactly the state a caller must not be
        # told is a completed act.
        observed = _recovered(engine, port, name=name,
                              image_digest=image_digest)
        if not isinstance(failed, Exception) or isinstance(failed,
                                                           ContractRefusal):
            # A REFUSAL IS THIS MANAGER'S OWN JUDGEMENT and is reported as
            # one; `KeyboardInterrupt` and `SystemExit` are the operator
            # ending the process and are not this module's to swallow into an
            # answer. Review [P1]: the first round caught `BaseException` and
            # turned both into a typed result. The helper is reclaimed either
            # way -- that part is not conditional.
            raise
        # THE TYPE NAME AND NOT THE TEXT. An exception's message is composed
        # by whoever raised it, which here is the caller's own injected
        # capability, and this manager's account of an act does not quote
        # material it did not author.
        # AND THE HOLD STANDS. This is the one shape it exists for: no engine
        # answer, a submitted request that may still create the helper, and
        # nothing this manager may call settled. It is cleared by an operator
        # who records what they observed, never by a later act asserting it.
        # UNRESOLVED, AND IT SAYS SO. W43974 review (2026-08-30T05:44:32Z)
        # [P0]: this used to answer "its helper was reclaimed", which claimed
        # a property the CLI boundary cannot supply -- the daemon's
        # already-accepted request can create the derived name after any
        # observation this manager takes. What is true is what was observed
        # and removed at one instant, and that a submitted operation may still
        # land; a caller told "reclaimed" would stop looking.
        # W247941, owner 257086: AND WHAT IT MAY STILL TOUCH IS NAMED.
        #
        # The stopgap the owner selected for this packet qualifies the
        # no-background-effects condition for exactly this case: an uncertain
        # custody settlement is REPORTED held and unresolved, every resource
        # it may still reach is identified and frozen, reuse and success
        # claims are prohibited, and an operator reconciles it explicitly.
        # Nothing here asserts engine-side settlement and nothing here
        # deletes: a late helper carries this identity and mounts this root,
        # so an operator who reads this diagnostic knows which two things to
        # look at rather than being told the world is quiet.
        return _answered(operation, None, None,
                         f"UNRESOLVED: the act produced no engine answer "
                         f"({type(failed).__name__}); {observed}, and an "
                         f"engine operation already submitted may still "
                         f"create it, so this is not an absence proof. The "
                         f"identity is derivable and a later act reclaims "
                         f"what appears. FROZEN PENDING OPERATOR "
                         f"RECONCILIATION: helper identity {name_value(name)} "
                         f"and the {which} root of attempt "
                         f"{name_value(assignment_id)}; neither may be "
                         f"reused, reported settled, or deleted on the "
                         f"strength of this answer")
    printed = _custodian_document(answered["stdout"])
    minted = _answered(operation, answered["status"], printed,
                       answered["stderr"][-MAX_DIAGNOSTIC:])
    # W257624 R2 [P1], review 2026-09-24T21-39-09Z: AN ANSWER IS NOT AN ENDING;
    # AN ACCOUNTABLE ANSWER IS.
    #
    # This used to clear whenever the port returned at all, and said so: "a
    # refused or unaccountable ANSWER is this manager's own judgement about a
    # helper that ran and exited". That reasoning is wrong for the same reason
    # `_recovered` below stopped proving absence. Docker is client/server, so a
    # nonzero status with no document is the CLIENT's account of its own
    # failure -- it may have lost the response to a request the daemon is
    # still running, which is exactly the uncertainty this episode holds.
    #
    # WHAT DISTINGUISHES THEM IS ACCOUNTABILITY, not the exit status.
    #
    # I proposed the status twice and was corrected twice. "The engine answered
    # at all" cleared on a failed client that may have left a request running.
    # "Status 0" then cleared on a client that exited zero having printed
    # something illegible -- and review 2026-09-24T21-55-12Z is right that this
    # is no better: an answer this manager cannot account for does not say what
    # the helper did, so it cannot say the mutation finished.
    #
    # ONLY THE CUSTODIAN'S OWN DOCUMENT DOES. Nothing else can print one, so an
    # accountable answer establishes that this helper ran and reported. Any
    # other ending leaves the episode held, to be reconciled explicitly.
    # What is reported is `minted` either way: an unaccountable answer was
    # never custody and is not one now.
    #
    # AND THE DOCUMENT IT ACCOUNTED FOR IS RECORDED. An answer already spent on
    # one act must not be offered as evidence for another, and that is true of
    # the answers this manager consumed itself -- not only of ones an operator
    # delivered later.
    #
    # AND IT IS ONE CONDITION, NOT EITHER HALF. I checked `unaccounted is None`
    # alone, so a status-1 answer carrying a well-formed document cleared --
    # review 2026-09-24T22-06-47Z. `ok` is the settled name for all three:
    # the act ended cleanly, it said what it did, and it said THIS.
    # AND THE ECHO MUST BE THIS SUBMISSION'S. An accountable result for the
    # right verb is still an account of some act; the token is what says WHICH.
    # A result echoing another submission's token clears nothing.
    if minted.ok and printed.get("submission") != submission:
        return _answered(
            operation, answered["status"], None,
            f"the act answered for submission "
            f"{name_value(printed.get('submission'))} and this manager "
            f"submitted {name_value(submission)}; an account of another "
            f"submission is not an account of this one. FROZEN PENDING "
            f"OPERATOR RECONCILIATION: helper identity {name_value(name)} and "
            f"the {which} root of attempt {name_value(assignment_id)}")
    if minted.ok:
        _clear_hold(store, assignment_id, which, episode, name,
                    observed=f"the helper answered accountably with status "
                             f"{answered['status']!r} for this act",
                    accounted=printed)
    return minted


def _recovered(engine, run, *, name, image_digest):
    """Reclaim what is THERE after a lost act, and prove nothing about later.

    W43974 review (2026-08-30T05:15:08Z) [P1]: the first round called
    `_reclaimed` with the derived NAME as the runtime id, so it ordered a stop
    and a force-remove against whatever answered to that name without ever
    identifying it. This asks the same question the launch did -- list, match
    the exact name, inspect, hold the image and the name -- and removes only a
    candidate identified as THIS act's helper.

    W43974 review (2026-08-30T05:44:32Z) [P0]: AND IT NO LONGER PROVES
    ABSENCE, because on this path an absence proof is not a proof. Docker is
    client/server. `subprocess.run(timeout=)` terminates and reaps the local
    CLI, which is all it can do and all this module ever had a right to claim;
    the daemon's already-accepted request is a different process and may still
    create the derived name afterwards. An inspect taken at this instant would
    therefore be true when it was taken and false a moment later, and custody
    would have reported a recovery that had not happened.

    So what this does is bounded and honest: it removes a helper that IS
    there, and it says nothing about one that may yet be. `custody_act`
    answers UNRESOLVED either way -- see there -- and the derived identity is
    what makes a later manager able to finish the job.

    THE PROPERTY THIS CANNOT PROVIDE is named rather than approximated: a
    provider that can settle or CANCEL the engine-side operation, not merely
    reap its local client. The CLI cannot, and W44342 carries that work.
    """
    stranded = _reconciled(engine, run, name=name, image_digest=image_digest)
    if stranded is not None:
        _reclaimed(engine, run, name=name, runtime_id=stranded)
        return "a helper found under this identity was removed"
    return "no helper was answering to this identity when it was asked"


def _custodian_document(stdout):
    """The custodian's one JSON line, or `None`.

    THE LAST NON-EMPTY LINE, because an engine may write its own prose to the
    same stream -- a pull, a warning -- and the custodian's answer is the last
    thing printed by the program this module owns. It is read rather than
    trusted: a document that does not parse, or that is not one JSON object,
    is no document at all, and this answers `None` rather than a partial
    reading of it.
    """
    import json

    for line in reversed((stdout or "").splitlines()):
        if not line.strip():
            continue
        try:
            document = json.loads(line)
        except ValueError:
            return None
        return document if type(document) is dict else None
    return None


# How much of a failing act's stderr is kept. The diagnostic explains an
# ending; it is not a transcript, and an unbounded one is a custodian's output
# stored verbatim in this manager's own account of it.
MAX_DIAGNOSTIC = 4096


# THE SAME UNCONDITIONAL POSTURE THE RUNTIME IS UNDER, minus what a custodian
# has no use for. It is written out rather than imported from `RESTRICTIONS`
# because two of the entries differ for reasons that have to be visible:
#
#   * `--read-only` stays: the one writable place is the mount.
#   * `--network none` stays: a custodian has nothing to talk to, and a helper
#     that could reach a network is a helper that could carry the material it
#     is holding somewhere.
#   * `--user 65532:65532` is the WORKER's identity on purpose, and it is the
#     whole mechanism. As the owner of what the worker created, the custodian
#     may `chmod` it whatever mode the worker chose.
_CUSTODY_RESTRICTIONS = (
    ("--cap-drop", "ALL"),
    ("--security-opt", "no-new-privileges"),
    ("--security-opt", "label=disable"),
    # W194457: SUBSTITUTED AT COMPOSITION, like the runtime's. The pair here
    # is the historical one and is what a reader sees when nothing overrides
    # it; `custody_vector` replaces it with the deployment's shared execution
    # identity, because a custodian that is not the owner of the worker's
    # objects cannot `chmod` them -- which is measured, at `workspaces.py`'s
    # EPERM note.
    ("--user", "65532:65532"),
    ("--read-only", None),
    ("--network", "none"),
    ("--pids-limit", "128"),
    ("--memory", "512m"),
    ("--cpus", "1"),
    ("--tmpfs", "/tmp:rw,noexec,nosuid,nodev,size=16m"),
)
