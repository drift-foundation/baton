"""The REAL Claude provider adapter, injected into `baton_worker.main(agent=)`.

W39357, under `work/records/2026/08/finding-v12-first-useful-dogfood-task/
findings/finding-real-claude-adapter-image/`.

WHAT THIS IS. One agent object with the two methods `baton_worker` calls. It
runs a real provider against a private copy of the staged source and writes the
declared proposal tree. It is the first thing in this campaign that makes an
actual model turn happen inside a worker container.

WHAT IT IS EMPHATICALLY NOT, and each line is a boundary somebody could
reasonably have crossed:

  NOT THE WORKER. It does not frame, correlate, measure bytes, or publish
  `/output/output.json`. `baton_worker` does all of that, and it does it AFTER
  this returns -- which is what keeps a provider's output from ever becoming
  protocol framing or success identity.
  NOT W17110's SPIKE. Its pinned INSTALLATION facts are reused -- the base
  image, the exact CLI version, the trust store, the pre-owned home. Its
  `trial.mjs`, its `w17110-ping-pong` result shape and its direct Docker
  lifecycle are not.
  NOT A CREDENTIAL READER. It never opens, reads, hashes, prints, copies or
  inspects a bearer. It links the provider's expected path at the fixed slot
  and lets the provider do its own authentication.
  NOT A TRANSCRIBER OF ITS CHILDREN. It starts two processes that can read the
  attempt's credential, and it publishes NEITHER ONE'S OUTPUT. Both children
  run with both streams on `/dev/null`, so no byte a child wrote exists in
  this program to be interpolated into the proposal by accident or by a later
  edit. The evidence is the exit status and the frozen command, which this
  adapter and the operator authored.
  NOT A SETTLEMENT. A disposition is a CLAIM about what happened; the manager
  freezes, collects and settles. Nothing here can report `completed` for a turn
  that produced no candidate.

THE FOUR THINGS IT ACTUALLY DOES, in order, and every one of them in bounded
container-private space:

  1. read the frozen task at `/input/task.json`;
  2. copy `/input/source` into a private directory under the `/tmp` tmpfs --
     the staged source stays read-only and is never the copy destination;
  3. run the provider there, once, over a closed argv;
  4. author `proposal/{candidate,change.patch,result.json,verification.txt}`
     under the one declared output path.

WHY NO CHILD'S OUTPUT IS PUBLISHED. The provider holds the attempt's bearer,
and the task's own verification command is code out of the candidate the
provider has just edited, running as the same uid with the same mount still
readable. Their stream bytes are therefore exactly the class this proposal must
not carry, and no rule available here can tell one of those bytes from another
without reading the bearer -- which the confirmed boundary forbids, and forbids
for a good reason. So the bytes are not read at all. See the module-level
comment above `_ran`.

ONE STREAM IS NOW READ, AND ONLY TO CHOOSE ONE OF THIS FILE'S OWN WORDS.
W55360, approver ruling event 55479, narrowly supersedes the rule above for
PROVIDER STDOUT and nothing else: the adapter asks the CLI for a structured
JSON record, drains that stream through a bounded anonymous pipe, matches one
member against a closed map, and throws the bytes away. Provider stderr and
both verification streams are untouched and remain on `subprocess.DEVNULL`.
What crosses into `result.json` and the worker's recap is `api-error` or
`unclassified` -- words spelled in THIS file, never the provider's spelling of
them, never the document, never a parser's complaint about it.

`api-error` IS DESCRIPTIVE AND IS NOT A CAUSE. It says the provider's own
terminal record called the ending an API error. It is NOT evidence of an
expired credential, a limited or suspended account, a missing scope, or a
network fault, and no prose here, in the proposal, or in any operator
documentation may present it as one. Two supervised rounds under W51487 wanted
exactly that causal answer; this signal cannot give it, and saying otherwise
would make a supervised pilot act on a diagnosis nobody made.

WHY THE HOME IS PRIVATE AND THE CREDENTIAL IS A LINK. The runtime posture fixes
`--read-only` with tmpfs only at `/tmp` and `/dev/shm`, and the manager mounts
the bearer at `/run/baton/credentials/<slot>` rather than at the provider's own
path. A provider that writes anywhere under its home therefore cannot start at
all from an image-owned link. So the home is made at run time under `/tmp` and
the provider's credential path is a SYMLINK to the slot: the bytes are never
read by this program and never leave the mount, and the link dies with the
container.
"""

import hashlib
import itertools
import json
import os
import re
import select
import shutil
import stat
import subprocess
import tempfile
import threading
import time

__all__ = ["ClaudeAgent"]

# -- the fixed paths, all constants of the DOGFOOD WORKLOAD --------------------
#
# Named here rather than taken as operands for the reason the worker names its
# own: a path a payload can vary is a path a runtime can be pointed at wrongly.
# These are the workload's convention and NOT worker-control protocol
# vocabulary -- the same boundary the parent finding draws for Git.

INPUT_ROOT = "/input"
OUTPUT_ROOT = "/output"
CONTEXT_ROOT = "/run/baton/context"
CONTEXT_RECEIPT = "provider-context-receipt"

# The frozen task, and the staged tree it is about.
TASK_DOCUMENT = "task.json"
SOURCE_ROOT = "source"

# WHAT A TASK DOCUMENT IS, exactly. Closed, and versioned in the name, so a
# document from another generation is refused by an equality test rather than
# by parsing a version member and deciding what to do about it -- the same rule
# the launch document is under.
TASK_SCHEMA = "baton.dogfood-task/2"
TASK_MEMBERS = ("schema", "task_id", "instructions", "verification",
                "source_root", "source_profile", "declared_base")

# W71917: THE PROFILE PACKAGE, UNDER WHICHEVER NAME IT ARRIVED.
#
# `Dockerfile.claude` copies `source_profiles` in as a TOP-LEVEL package, not
# as `baton_v12.source_profiles`, and that is the image's pinned rule being
# kept rather than bent: nothing from `baton_v12` travels, because a worker
# that can import the manager is a worker one bug away from holding the
# manager's capabilities. The profile package is not the manager -- it imports
# nothing from `baton_v12`, and `baton_v12.worker_manager` imports nothing from
# it, which `tests/manager/test_source_boundary` holds both ways -- so it
# travels under its own name and the `baton_v12` namespace still does not exist
# in the image.
#
# ONE SPELLING, AND `baton_v12` IS NOT IT. An import naming that package --
# even in a fallback for the distribution's own test run -- would be this
# module able to spell the manager's namespace, which is the property
# `test_this_module_imports_nothing_from_the_manager` holds as a fact about
# this source rather than as a comment. The suites that drive this module put
# the package's directory on `sys.path` under this same top-level name, which
# is reproducing the image's layout rather than relaxing the rule.
import source_profiles as _profiles

# Where the checkout and the editable copy live. BOTH ARE IN THE WORKSPACE,
# which is W71917's whole subject: the workspace is disk-backed and the tmpfs
# is 64 MiB, so a real build or test pass cannot happen anywhere else.
CANDIDATE_NAME = "candidate"

# Version-control metadata, skipped by the copy and by the diff.
#
# NOT AN INFERENCE ABOUT THE TREE. This is applied only when the assignment
# DECLARED the git profile, so no tree is examined to decide whether it looks
# version-controlled; a generic profile carrying a directory of this name is
# ordinary material and is copied and diffed like any other.
VCS_METADATA = ".git"

# The private scratch root. `/tmp` is the adapter's tmpfs: `rw,noexec,nosuid,
# nodev,size=64m`, private to this container and gone when it ends.
PRIVATE_ROOT = "/tmp"

# -- the provider ------------------------------------------------------------

# WHERE THE MANAGER PUTS THE BEARER, and the slot this workload asks for. The
# root is the credential contract's; the slot name is this workload's request.
CREDENTIAL_ROOT = "/run/baton/credentials"
CREDENTIAL_SLOT = "claude"

# WHERE THE PROVIDER LOOKS FOR IT, relative to its own HOME. W17110 measured
# this: a FILE-shaped provider mount at `$HOME/.claude/.credentials.json`
# leaves the state directory writable, which the runtime needs.
PROVIDER_HOME_STATE = ".claude"
PROVIDER_CREDENTIAL = ".credentials.json"

# W61599: THE BOUNDS ON ONE ACTIVITY OBSERVATION, and every one of them fails
# toward UNKNOWN rather than toward a sample.
#
# `ACTIVITY_DEPTH` is deep enough for a vendor `projects/<slug>/<file>` shape
# with room to spare and shallow enough to bound the cost of a scan that runs
# once a second. `ACTIVITY_ENTRIES` is far above any plausible session count.
# `ACTIVITY_FILES` is the number of distinct file identities one turn may be
# tracked across. Exceeding ANY of them stops the observation for the rest of
# the operation and reports unknown -- it never samples, never estimates and
# never reports a smaller total.
ACTIVITY_SUFFIX = ".jsonl"
ACTIVITY_DEPTH = 4
ACTIVITY_ENTRIES = 256
ACTIVITY_FILES = 64
MAX_ACTIVITY_BYTES = 2 ** 53 - 1

# THE CLOSED ARGV, and the one place it departs from W17110.
#
# The spike ran `--print --permission-mode plan`, which is right for a
# ping-pong that must touch nothing and wrong for a task whose whole point is
# to edit files. W39364 then ran `--permission-mode acceptEdits`, and live
# dogfood measured what that actually was: an inner COMMAND allowlist. The
# agent could edit its private candidate but was refused the task's own Python
# verification, which the outer worker then ran itself -- proving the command
# belonged inside the container and was never a host-authority request.
#
# W64268 ruled that the container IS the boundary. Inside an accepted trusted
# worker runtime the agent may run the image's tools without per-command
# approval, so this tuple names the CLI's bypass ACTIVATION flag. Two nearby
# spellings are deliberately NOT used: `--allow-dangerously-skip-permissions`
# only permits bypass to be selected later, and `--permission-mode
# bypassPermissions` reintroduces the mode operand this Work removed.
#
# This is inner policy only. The external boundary -- read-only inputs, one
# private writable scratch, dropped capabilities, no host socket, no privilege,
# manager-owned lifecycle -- is `worker_manager.oci`'s and is UNCHANGED.
#
# `--print` is the non-interactive mode: one prompt, one answer, no terminal.
# `--output-format json` is W55360's operand and is the whole of that Work's
# departure from W39357. It asks the CLI for a STRUCTURED terminal record on
# stdout instead of prose, which is what makes reading that one stream a
# bounded, closed-vocabulary act rather than a diagnostic passthrough.
PROVIDER_PROGRAM = "claude"

# THE CREATION MASK THE PROVIDER CHILD RUNS UNDER, and it is the whole of
# W239528's custody correction. Owner 2026-09-23T03:06:11Z: "preserve
# private-context ownership, mode and symlink checks; make the provider
# execution/delivery path create compliant private directories."
#
# WHAT WENT WRONG. The manager's private-context custody rule refuses any
# directory carrying group or other bits -- `context_delivery._private`, which
# is unchanged and stays that way. A real provider turn created seven
# directories under its own HOME at `0o755`, the ordinary umask default, and
# the manager then could not seal the generation: the context use was held
# `custody-invalid`, the composed stage could not settle, and a run that had
# produced a correct attributed proposal reported nothing until its bound.
#
# WHY A MASK RATHER THAN A REPAIR. `mkdir` applies `mode & ~umask`, so a child
# under this mask cannot create a group- or other-readable directory EVEN WHEN
# IT ASKS FOR ONE, and the mask is inherited by its descendants. Walking the
# tree afterwards and chmodding it would be this adapter deciding that somebody
# else's bytes are acceptable after the fact; setting the mask means they are
# never wrong in the first place.
#
# WHY ONLY THE PROVIDER. A mask set for this whole process would also narrow
# what this adapter writes into the shared private line, whose group access the
# deployment configures on purpose. The provider is the only party that creates
# the context home's directories, so it is the only party whose mask moves.
#
# WHAT IT DOES NOT COVER, stated rather than implied: `chmod` is not masked, so
# a provider that explicitly made a directory permissive after creating it
# would still be refused by the manager. That is the right outcome and would be
# its own finding; the retained evidence shows no such directory.
PROVIDER_UMASK = 0o077
PROVIDER_ARGUMENTS = ("--print", "--dangerously-skip-permissions",
                      "--output-format", "json")

# HOW MUCH OF THE PROVIDER'S STRUCTURED STDOUT IS EVER HELD, and W39357's
# deleted ceilings are NOT back: those bounded a window onto prose that was
# then published, and this one bounds a document that is parsed and thrown
# away. Nothing derived from these bytes leaves this module except one word
# chosen from `PROVIDER_FAILURE_REASONS` below.
#
# The stream is drained to EOF whatever its size -- the ceiling bounds what is
# RETAINED, never what is read -- so a verbose provider can neither block on a
# full pipe nor make this process allocate without limit. Output past the
# ceiling makes the record `unclassified` rather than being reassembled.
MAX_PROVIDER_RECORD = 1 << 16

# HOW LONG THE DRAIN MAY OUTLIVE THE PROVIDER PROCESS ITSELF, and this bound
# is W55360 review (2026-09-01T03:35:56Z) [P1]. EOF on the read end arrives
# when the LAST writer closes it, not when the provider exits -- and a child
# the provider started inherits that descriptor. A provider that spawns a
# long-lived descendant and exits therefore left a reader waiting on an EOF
# nobody was going to send, which wedged the worker AFTER the turn was over
# and made `PROVIDER_SECONDS` not a bound at all.
#
# So completion is bounded independently of EOF. Once the provider process is
# gone, whatever it wrote is already in the pipe and readable at once; this is
# the grace for reading it, not for waiting on anybody else's descriptor. When
# it runs out the record is PARTIAL -- the stream was never proved finished --
# and a partial record is `unclassified` exactly as an over-ceiling one is.
PROVIDER_DRAIN_SECONDS = 2

# The drain's wait slice. It only decides how promptly the reader notices that
# the provider has ended; the reader is never idle-waiting on anything else.
PROVIDER_DRAIN_SLICE = 0.05

# THE CLOSED MAP, AND IT HAS ONE ENTRY ON PURPOSE. W55360's approver ruling:
# `api_error` is the single value the evidence has actually observed, so it is
# the single value that earns a word. Every other spelling -- unknown, absent,
# duplicated, malformed, over-ceiling, not a string, not an object -- becomes
# `UNCLASSIFIED`, and adding a second entry requires its own observed evidence
# and its own case.
#
# SUBSTRING AND PATTERN MATCHING ARE FORBIDDEN HERE. The value is compared by
# equality and nothing else: a regex over provider-authored text is the wider
# classifier W55360 explicitly declined to become.
PROVIDER_FAILURE_REASONS = {"api_error": "api-error"}

# W71879: exact constant from the installed 2.1.247 LWo authentication branch.
# A full equality match preserves useful detail without publishing arbitrary prose.
PROVIDER_OAUTH_EXPLANATION = "Failed to authenticate: OAuth session expired and could not be refreshed"

# The words this adapter publishes when it did not get one from the map. Each
# is THIS module's own vocabulary, not the provider's.
UNCLASSIFIED = "unclassified"
PROVIDER_TIMED_OUT = "timeout"
PROVIDER_START_ERROR = "start-error"

# How long one provider turn is given. A real turn is minutes; a bound that
# cannot be reached turns ordinary work into a failure, and a bound that does
# not exist turns a wedged provider into a wedged container.
#
# IT IS THIS MODULE'S DEFAULT AND NOT THE EFFECTIVE BOUND. `_bound` resolves
# what a turn actually runs under from the launch document's Job execution
# context, so the number below is what stands in when there is no Job behind
# the launch -- never what a result may report about a turn that ran under a
# different one. See `_resolved_bound` and `_bound_member`.
PROVIDER_SECONDS = 3600

# WHO CHOSE THE BOUND A RESULT PUBLISHES, and this vocabulary is exactly as
# wide as the delivered document can currently support -- no wider. W321528.
#
# WHY A SECOND MEMBER AT ALL. A bare `900` cannot say whether an operator
# picked fifteen minutes or whether nobody picked anything and fifteen minutes
# is simply what the boundary preserves; a reader deciding whether a timeout
# was a configuration problem needs to know which. The number alone made the
# two indistinguishable, and reporting the default constant for a turn that
# ran under something else made them indistinguishable in the wrong direction.
#
# THE DISTINCTION IS READ, NOT INFERRED. The manager's execution-limit owner
# already resolves each boundary with an ORIGIN beside its seconds, and that
# origin travels inside the sealed `execution_limits` this container is handed
# -- so the three answers below are what the delivery actually says rather
# than this module's guess about it. `_ORIGIN_SELECTION` maps the two words
# that owner uses; an origin it does not use is reported `unstated` rather
# than squeezed into one of them, because a delivery this module cannot read
# is not evidence that nobody configured anything.
#
# THE WORDS ARE SPELLED TWICE ON PURPOSE. The image carries no `baton_v12`, so
# the mirror is held against its owner by a case rather than by an import --
# the same arrangement `REVIEW_VERDICTS` has, and for the same reason.
WORKER_DEFAULT_BOUND = "worker-default"
JOB_SELECTED_BOUND = "job-selected"
JOB_DEFAULT_BOUND = "job-default"
UNSTATED_BOUND_SOURCE = "unstated"

# The execution-limit owner's own origin words, mirrored. `job` is a setting
# the Job stated; `compatibility` is the boundary's preserved runner default
# resolved for a Job that stated nothing.
_ORIGIN_SELECTION = {"job": JOB_SELECTED_BOUND,
                     "compatibility": JOB_DEFAULT_BOUND}

# How long the task's own verification command is given. Bounded separately
# because it is the WORKLOAD's command rather than the provider's, and the two
# have nothing to do with each other.
VERIFICATION_SECONDS = 900

# How long ONE source-checkout step is given. W71917. Bounded separately again,
# and smaller than either of the two above: a local clone from a mounted
# directory is seconds of disk copying with no network in the container and
# nothing to wait on, so a step still running after this is wedged rather than
# busy.
CHECKOUT_SECONDS = 900

# -- what this adapter writes ------------------------------------------------

CANDIDATE = "candidate"

# W85497: WHERE A CHILD'S EPHEMERA GO, and the reason they are named here.
#
# Both children run WITH `candidate` AS THEIR WORKING DIRECTORY, and the
# candidate is the tree this adapter walks, diffs, revalidates and publishes.
# Anything an interpreter drops beside the source it is reading therefore
# becomes a PROPOSED CHANGE. The first ordinary self-hosted W71917 retry is
# the measurement: `python3 -m compileall -q src tests tools` wrote 149
# `__pycache__` entries into the candidate and the resulting patch was
# 10,779,527 bytes for ten real paths.
#
# THE PROVIDER'S CACHES ARRIVE BEFORE THE WALK, which is why this is not only
# the verifier's problem. The provider is prompted to run the verification
# command itself before returning, and `work` diffs the tree AFTER that turn --
# so a provider that does as it is asked contaminates the proposal even if the
# adapter's own verification writes nothing at all.
#
# EACH NAME IS A DIRECTORY UNDER THE PRIVATE SCRATCH, never under `candidate`
# and never the ambient default: `TMPDIR` unset would put temporary files in
# `/tmp` (harmless but unbounded across turns), and `XDG_CACHE_HOME` unset
# resolves under `HOME` -- which for the provider is the directory holding its
# credential link.
PROVIDER_EPHEMERA = "provider-ephemera"
VERIFICATION_EPHEMERA = "verification-ephemera"
VERIFICATION_HOME = "verification-home"
PATCH = "change.patch"
RESULT = "result.json"
VERIFICATION = "verification.txt"

# -- W105575: the prepared private line --------------------------------------
#
# Under the `git-line` profile the workspace IS the manager's durable private
# repository, already detached at the declared base, and this adapter's job
# gains exactly one act: COMMIT. Everything below exists to make that commit
# an account somebody can check rather than a claim.

# The durable object transport, inside the declared output. INCREMENTAL, over
# the immutable base to the new head: the recipient of a proposal already holds
# the base -- it is the canonical target -- so shipping its history again would
# be a second copy of the thing the private line exists to avoid.
BUNDLE = "objects.bundle"

# The line workload's own result document. A SECOND GENERATION, because its
# declared output no longer carries a `candidate` tree: the candidate is a
# commit now. The existing readers of `/1` consume that tree, so the version is
# what keeps them reading the shape they were written for.
LINE_RESULT_SCHEMA = "baton.dogfood-proposal/2"

# THE WORKER-OWNED CLAIM, and its namespace. `result_metadata` is the frozen
# schema's opaque per-output extension point; `baton_worker` carries it without
# reading it and the generic manager never branches on it. What travels is
# WORKER-OWNED FACT ONLY -- what this turn was built on, what it produced, and
# where its objects are inside its own declared output.
#
# WHAT MAY NEVER TRAVEL HERE: an artifact id, media type, byte count, content
# digest or custody locator; any manifest, result, input, policy or profile
# digest; any assignment reference, generation or operation identity. Those are
# the manager's measurements and identities, and a worker that minted one would
# be certifying its own output.
CLAIM_NAMESPACE = "baton.git-proposal/1"
CLAIM_MEMBERS = ("base", "head", "transport", "recap")
MAX_TRANSPORT = 128

# W112029: THE ORDINARY-TEST OBSERVATION, and it is an OBSERVATION rather than
# a verdict. Under owner ruling M111752 this milestone's verification is the
# implementer running the ordinary required tests plus an independent review;
# there is no separate clean verifier. This adapter ALREADY runs the frozen
# task's own verification argv and publishes its answer in the result document,
# so nothing new is executed here -- what was missing is a way for integration
# admission to resolve that same fact from the frozen result.
#
# SIX CLOSED MEMBERS AND NO SEVENTH. What this turn was asked to run, which
# exact task bytes asked for it, what actually happened, and the two objects
# that say which candidate it happened over. There is no `passed`, no
# `verified` and no boolean: a status is what `wait` answered, and a decision
# about it belongs to the consumer that holds the requirements.
#
# WHAT MAY NEVER TRAVEL HERE, exactly as for the proposal claim: any manager
# measurement, artifact, custody, manifest or assignment identity. And nothing
# a MODEL wrote -- the status is this adapter's own read of a child's exit,
# never a flag a provider was asked to set.
ORDINARY_TESTS_NAMESPACE = "baton.git-ordinary-tests/1"
ORDINARY_TESTS_MEMBERS = ("argv", "base", "head", "status", "task_digest",
                          "task_id")

# -- W110772: the review turn ------------------------------------------------
#
# THE SAME CONTAINER, THE SAME IMAGE, THE SAME PROVIDER, AND A DIFFERENT JOB.
# A review reads a frozen checkpoint and decides about it; it edits nothing,
# commits nothing and proposes nothing. What selects the branch is the launch
# document's `role`, which `baton_worker` has already validated and which the
# manager fills from the worker's configured launch role -- so the workload is
# chosen by an operand this container was launched under rather than by
# inspecting the filesystem for a shape that looks reviewable.
REVIEW_ROLE = "review"

# WHICH DECLARED OUTPUTS A SHARED JOB CARRIES, and why they are common rather
# than per-stage. `single_worker._matches` compares every stage of a Job
# against that Job's ONE input manifest digest, so an implementation manifest
# and a review manifest cannot both satisfy it. The declaration set is
# therefore the union and each role produces its own half, answering the other
# half `missing-optional`. The assembly owns constructing that manifest; this
# adapter owns knowing which half is its.
COMMON_OUTPUTS = ("proposal", "findings", "logs", CONTEXT_RECEIPT)
IMPLEMENTATION_OUTPUTS = ("proposal",)
REVIEW_OUTPUTS = ("findings", "logs")

# WHERE THE PROVIDER WRITES ITS REPORT, and it is deliberately NOT under
# `/output`. Every declared output directory is measured, sealed and collected
# by the manager, so a provider-authored file inside one would be adopted
# custody material before this adapter had looked at it. The report lands in a
# fresh private directory under the tmpfs, is validated here, and the findings
# output is then AUTHORED from it.
REVIEW_ROOM = "review-room"
REVIEW_REPORT = "review-report.json"

# THE REPORT'S CLOSED CONTRACT. Versioned in the name, like every other
# document this workload reads, so one from another generation is refused by an
# equality test rather than read for the parts that look familiar.
REVIEW_REPORT_SCHEMA = "baton.review-report/1"
REVIEW_REPORT_MEMBERS = ("schema", "verdict", "findings")

# The reviewer's closed answer. THE SAME THREE WORDS THE MANAGER RECORDS, and
# they are spelled here rather than imported because nothing from `baton_v12`
# travels into this image -- `test_claude_agent` holds the two against each
# other so they cannot drift.
REVIEW_VERDICTS = ("accepted", "changes-requested", "rejected")

# How many bytes of report this adapter will read. A document written by the
# provider is input from outside this program, so the bound is this program's.
MAX_REPORT_BYTES = 1 << 20
MAX_FINDINGS = 1 << 16

# WHAT THE FINDINGS OUTPUT CARRIES, both authored by this adapter from the
# validated report. `report.json` is the closed document and `findings.txt` is
# its prose, because a human opening the findings of a review wants the words
# and a consumer wants the structure.
REVIEW_RESULT = "report.json"
REVIEW_FINDINGS = "findings.txt"

# AND WHAT THE LOGS OUTPUT CARRIES. Adapter-authored status and check
# summaries, and nothing a child wrote: the provider holds this attempt's
# bearer, so its streams are exactly the bytes W39357's boundary keeps out of
# published material. The findings are a deliberately authored artifact
# adopted from a validated document; they are NOT a diagnostic-stream
# exemption, and no raw stdout, stderr or credential content reaches either.
REVIEW_LOG = "review.json"
REVIEW_LOG_SCHEMA = "baton.review-log/1"

# THE WORKER-OWNED CHECKPOINT-REVIEW CLAIM, and its namespace. The same shape
# `CLAIM_NAMESPACE` establishes for a proposal, one layer over: what this turn
# decided, and what it observed about the source it decided over.
#
# WHAT MAY NEVER TRAVEL HERE, exactly as for the proposal claim: an artifact
# id, media type, byte count, content digest or custody locator; any manifest,
# result, input, policy or profile digest; any attachment, checkpoint,
# assignment reference, generation or operation identity. Those are the
# manager's, and it re-reads every one of them from its own owner.
REVIEW_CLAIM_NAMESPACE = "baton.checkpoint-review/1"
REVIEW_CLAIM_MEMBERS = ("base", "head", "tree", "verdict")

# THE COMMIT'S AUTHOR, spelled here and composed onto the argv. The container
# is `--read-only` with a private HOME under the tmpfs and no Git configuration
# at all, so an identity that is not on the command line is not an identity;
# and one taken from the environment would be whatever the image happened to
# leave behind.
COMMIT_NAME = "Baton worker"
COMMIT_EMAIL = "worker@baton.invalid"

# WHY EVERY VECTOR CARRIES `safe.directory`. The runtime posture pins
# `--user 65532:65532` while the line and the mount are the manager's, so Git's
# dubious-ownership check applies to a repository this worker was deliberately
# given. Composed as ONE per-command override: nothing writes a configuration
# file, and no global state outlives the vector it was composed for.
#
# AND WHY THE COMMIT ALSO CARRIES `core.hooksPath`. W105575 review 2026-09-07:
# `--no-verify` skips `pre-commit` and `commit-msg` and leaves
# `prepare-commit-msg` enabled, so it is not the no-hook guarantee it looks
# like. Pointing the hook path at a name that is not a directory is what makes
# "no hook runs" true for every hook rather than for the two that were named.
NO_HOOKS = "/dev/null"

# The worker's reserved names inside the workspace, which are NOT candidate
# material and must not become one.
#
# `output.json` is `baton_worker`'s completion envelope and `.publishing` is
# the name it stages that document under. BOTH ARRIVE AFTER THIS ADAPTER
# RETURNS -- the worker measures the declared outputs and publishes the
# envelope once `work` has answered -- so an adapter that excluded only what it
# writes itself would leave the line permanently dirty and the manager's own
# checkpoint freeze would refuse it. They are named here, and
# `test_claude_agent` holds them against `baton_worker`'s own literals so the
# two cannot drift.
COMPLETION_MANIFEST = "output.json"
COMPLETION_STAGING = COMPLETION_MANIFEST + ".publishing"

# The manager's per-attempt result root, whose exact name carries a runtime
# attempt id this adapter is never told. A deliberate ONE-GLOB reservation of
# that namespace rather than an exact name, and it is the only pattern here
# that is not literal.
RESULT_ROOT_PATTERN = "result-*"

# What a declared output path may not contain if it is to be written as an
# exact ignore pattern. A declared path is a PATH; an ignore entry is a
# PATTERN, and the characters below are the ones that make the two differ. A
# declared path carrying any of them is refused rather than escaped, because
# guessing at an escaping is how a reserved name silently stops being reserved.
IGNORE_METACHARACTERS = "*?[]!#\\"

# The two tree entry modes a candidate file may have. Everything else Git can
# put in a tree -- a symlink at `120000`, a gitlink at `160000`, a subtree --
# is the committed half of the walk's own type boundary, and is refused on the
# side a recipient actually resolves rather than only on the side this adapter
# happened to walk.
TREE_FILE_MODES = ("100644", "100755")

# The one remaining ceiling, and note what it is NOT. `recap` is composed by
# this adapter out of its own disposition vocabulary; the bound is there
# because the worker frames it, not because anything untrusted reaches it.
#
# There were two more here -- `MAX_DIAGNOSTIC` and `MAX_VERIFICATION` -- and
# they are gone rather than raised. They existed to bound how much of a CHILD'S
# stream crossed into this process, and no child's stream crosses at all now,
# so a ceiling on the amount is a ceiling on nothing. See `_ran`.
MAX_RECAP = 4000

# THE COOPERATIVE MODE, and it is a stated cooperation rather than custody.
# W36540 owns unconditional custody; until it lands, a worker that writes
# owner-only material leaves a tree the manager fails closed on. So this writes
# group-readable and says so out loud -- it is not a security boundary and does
# not pretend to be one.
DIRECTORY_MODE = 0o2775
FILE_MODE = 0o664

# A source tree this adapter will copy, bounded on both axes. The manager
# measured and staged it; this is the second bound, at the party that actually
# walks it.
MAX_SOURCE_ENTRIES = 2000
MAX_SOURCE_BYTES = 64 * 1024 * 1024

# W202663 D10 (owner 2026-09-21T12:47:17Z): THE LINE PROFILE'S COLLECTION
# BOUND. The owner is the integrator and the line profile COLLECTS a faithful
# proposal; it does not police the repository. What is bounded is the ACTUAL
# collection -- how many changed entries one turn's inventory will carry --
# and never the size or the contents of the pre-existing checkout. The
# payload ceilings above still bound what a turn AUTHORS.
MAX_LINE_STATUS_ENTRIES = 20000

# How many excluded paths the disclosure names outright; the count is always
# whole. A disclosure that could grow without bound would be a report sized
# by the thing it reports on.
MAX_COLLECTION_DISCLOSED = 50

_TASK_ID = re.compile(r"\A[a-zA-Z0-9][a-zA-Z0-9._-]{0,127}\Z")


# -- W198667: the streams this adapter used to discard -------------------------

# WHICH PROCESS HOLDS THE ROOM, by name. W202663 (owner 227095): the attempt's
# log room is a delivery to the ONE process the manager launched, not to every
# process in the container that can import this module. The entry names the
# room here in the worker's own environment; `_closed_environment` composes
# both children's environments member by member and never forwards this name,
# so nothing the provider starts -- and nothing a nested test constructs --
# holds a room at all. Deliberately NOT `BATON_WORKER_*`: that transport was
# retired with no fallback (W26291) and this is not it; it is the entry
# speaking to its own adapter, one process apart.
ROOM_VARIABLE = "BATON_ATTEMPT_LOG_ROOM"


def _log_room():
    """The attempt's log room and the shared format, or `(None, None)`.

    OPTIONAL BY CONSTRUCTION. The accepted images already built do not carry
    `attempt_log_format`, and an adapter that failed because its logging was
    unavailable would be one logging made less reliable. No room means no
    capture, and the manager reports every stream `absent` -- which is the
    honest answer rather than a silent empty one.

    AND EXPLICIT BY DELIVERY NOW, W202663 (owner 227095). This used to open
    the fixed `/run/baton/logs` for ANY process that could import this module,
    and Job2 measured what that means: the provider's own background test run
    constructed adapters out of the checkout, each opened the REAL attempt
    room, and their killed writers declared `failed` into the real sidecars --
    which the aggregation below then honestly carried into the authoritative
    capture. The room is the delivery of exactly one process, the worker the
    manager launched, so only the process whose environment NAMES a room
    holds one: `dogfood_entry` sets `BATON_ATTEMPT_LOG_ROOM` in the worker's
    own process, and `_closed_environment` composes both children's
    environments member by member and never forwards it. The docstrings
    saying `os.environ` is never consulted are about THOSE compositions and
    remain true; this read is of the worker's own inherited environment,
    which is the one place the entry can speak to this module from.
    """
    place = os.environ.get(ROOM_VARIABLE)
    if not place:
        return None, None
    try:
        import attempt_log_format
    except ImportError:
        return None, None
    return attempt_log_format.open_room(place), attempt_log_format


def _aggregate(fmt, state, carried, reason=None):
    """One writer's outcome, widened to the whole file's completeness.

    THE TWO FACTS ARE DIFFERENT and the reader is given the one it asks about:
    the sidecar describes the bytes in the file, and those include every
    earlier generation's. A `finished` published over a file an earlier writer
    is known to have lost bytes from is the false picture this whole
    vocabulary exists to prevent.

    THE REASON SAYS SO, because `failed` alone would send an operator looking
    at the wrong writer.
    """
    held = carried[0] if carried else None
    if held is None:
        return state, reason
    worse = fmt.worst(state, held)
    if worse == state:
        return state, reason
    return worse, (f"an earlier capture of this stream declared {held!r} and "
                   f"those bytes were never restored; this writer's own turn "
                   f"ended {state!r}, and what is in the file is not whole")


class _Captured:
    """One stream's log handle, its byte count, and its honest ending.

    THE OWNER'S SUPERSESSION IS RECORDED AT THIS SITE, which is where it
    actually takes effect. W39357 ruled these streams unreadable and
    `_ran` below still states that reasoning in full, because it remains
    correct about what it was deciding. The owner superseded it on
    2026-09-17 FOR THESE PRIVATE DEVELOPMENT DEPLOYMENTS and in one
    direction only:

      *"I'm not concerned about logged credentials -- this is dev use --
      and credentials aren't printed out anyway. We need to capture
      evidence so we don't chase tails."*

    WHAT THAT DOES AND DOES NOT CHANGE. It supersedes the requirement to
    DISCARD these streams. It does not claim process output cannot contain
    a credential, it does not authorize reading a credential in order to
    log one, and it does not touch the mounted bearer, which this module
    still never opens. The bytes go to a room the manager made, under the
    attempt's own identity, and nothing in the manager ever reads them to
    decide anything.
    """

    def __init__(self, room, fmt, name):
        self._room = room
        self._fmt = fmt
        self._name = name
        self._handle = None
        self._bytes = 0
        self._lost = False
        # WHY THE LOG IS UNAVAILABLE, IF IT IS. W198667 review
        # 2026-09-18T06-27-53Z: the shared opener now refuses a stream that is
        # not a regular file this room owns, and "failed" with the default
        # prose would tell an operator that bytes were lost without saying
        # that none were ever accepted. The refusal travels into the
        # declaration a reader actually meets.
        self._why = []
        # WHAT EARLIER GENERATIONS OF THIS STREAM ALREADY LOST, carried out of
        # the declaration this acquisition clears.
        self._carried = []
        if room is not None and fmt is not None:
            self._handle = fmt.append_writer(room, name, self._why,
                                             self._carried)
            self._lost = self._handle is None

    @property
    def fileno_or_devnull(self):
        """What the child's stream is attached to.

        `DEVNULL` remains the answer when there is no room, so an image
        without the capture module behaves exactly as it did before.
        """
        return self._handle if self._handle is not None else subprocess.DEVNULL

    def wrote(self, payload):
        if self._handle is None:
            return
        moved = self._fmt.write_all(self._handle, payload)
        self._bytes += moved
        if moved != len(payload):
            self._lost = True

    def declare(self, state=None):
        """The writer's own word, once, and then the handle is done with.

        `state` IS THE CHILD'S OUTCOME AND NOT A DEFAULT. Review
        2026-09-18T02-31-51Z [4], and it was a defect I shipped: this was
        called from a `finally` with no operand, so a child that NEVER STARTED
        -- an injected `FileNotFoundError` at the subprocess boundary -- left
        both verification streams declared `finished`, zero bytes, carrying the
        prose "the writer saw this stream to its end". A failure to start
        reported as a complete capture is the exact sentence this vocabulary
        exists to forbid, and it is worse than the discard it replaced.

        So callers say which of the three really happened and `None` is no
        longer spelled "finished": see `_Outcome`.
        """
        if self._handle is not None:
            try:
                os.close(self._handle)
            except OSError:
                pass
            self._handle = None
        if self._room is None or self._fmt is None:
            return None
        # A LOST WRITE OUTRANKS EVERY OUTCOME. Whatever the child did, bytes
        # this process could not put in the file are bytes that are not there.
        if self._lost:
            state = "failed"
        if state is None:
            # NOBODY SAID, so nothing is asserted. An unclaimed stream reads
            # back as `live` or `empty` from the file alone, which is "we do
            # not know" -- and not knowing is the honest answer when the caller
            # did not tell us how its child ended.
            return None
        # AND THE COMPLETENESS OF EVERYTHING IN THE FILE, not only of what
        # this writer did. W198667 review 2026-09-18T06-53-11Z: a writer that
        # detected a short write declared `failed`, a second writer appended
        # cleanly, and the reader answered `captured` over a file whose middle
        # never arrived. A new success cannot prove an earlier missing tail,
        # so the worst state any generation of this stream has declared is
        # published with this one's.
        state, reason = _aggregate(self._fmt, state, self._carried,
                                   self._why[0] if self._why else None)
        try:
            return self._fmt.write_declaration(self._room, self._name, state,
                                               reason=reason)
        except Exception:                                  # noqa: BLE001
            return None




def _retain_native(scratch, room, fmt, seen=None):
    """Copy the provider's OWN session files into the delivery's native corner.

    CALLED REPEATEDLY AND INCREMENTALLY. Review 2026-09-18T03-10-39Z [R2]: an
    end-of-turn copy cannot satisfy "survives interruption and container loss",
    because a wrapper killed before its `finally` copies nothing. The drain
    thread already ticks while the provider runs, so this runs from there too;
    `seen` carries how much of each file has already been retained, so a tick
    appends only what is new.

    STREAMED, NOT READ WHOLE. The earlier cut read `MAX_NATIVE_FILE` bytes and
    counted the file retained -- so anything larger was SILENTLY TRUNCATED
    while being reported complete, which is the one thing this vocabulary
    forbids. Bytes move in bounded chunks and nothing is capped away.

    NAMES ARE UNAMBIGUOUS. `a/b` and `a__b` both flattened to `a__b`, so three
    files were counted and two existed and one source's bytes were overwritten.
    The separator is a character a POSIX path component cannot contain.

    DESCRIPTOR-CONFINED, WHICH THE DOCSTRING USED TO CLAIM AND THE CODE DID NOT
    DO. `islink` then `open(path)` is a check on one object and an open of
    whichever object the name resolves to next, and every ancestor was followed
    besides. Every step is opened relative to the descriptor above it,
    `O_NOFOLLOW` at each component, so a link swapped in after the check is
    refused rather than followed -- and the CREDENTIAL slot is excluded by that
    open failing, not by an earlier name check.

    A FAILURE IS REPORTED, NOT SKIPPED. The answer carries what was retained
    and what could not be, so the caller can declare `failed` rather than let
    an empty corner read as "the provider wrote nothing".
    """
    # THE CALLER'S OWN MAP, MUTATED IN PLACE -- and this was the defect.
    # Review 2026-09-18T03-27-44Z [R1]: this made a COPY, the drain discarded
    # the returned dictionary, and so every poll started at byte zero and
    # appended the whole file again. The reviewer's fake-child probe found
    # `abc` retained seventeen times. A caller that must remember something
    # across calls is given the thing to remember, not a copy of it.
    kept = seen if seen is not None else {}
    # AND THE FAILURES ACCUMULATE ACROSS TICKS TOO. They were per-call, so an
    # intermediate retention failure followed by a clean final tick vanished
    # from the declared outcome -- capture uncertainty must survive the turn.
    failed = kept.setdefault("", [])
    found = {"retained": kept, "failed": failed, "reached": False}
    if room is None or fmt is None:
        return found
    try:
        os.mkdir(fmt.NATIVE, 0o750, dir_fd=room)
    except FileExistsError:
        pass
    except OSError as failure:
        _noted_once(failed, f"the native corner could not be made "
                            f"({type(failure).__name__})")
        return found
    try:
        native = os.open(fmt.NATIVE,
                         os.O_RDONLY | os.O_NOFOLLOW | os.O_DIRECTORY,
                         dir_fd=room)
    except OSError as failure:
        _noted_once(failed, f"the native corner could not be opened "
                            f"({type(failure).__name__})")
        return found
    # EVERY COMPONENT, NO-FOLLOW -- including the ROOT's own ancestors. The
    # earlier cut opened the composite `scratch/home/.claude` path, so
    # `O_NOFOLLOW` covered only the last component and the claim that every
    # step is held was not true of root acquisition.
    top, why = _descended(scratch, ("home", PROVIDER_HOME_STATE))
    if top is None:
        # ABSENCE IS NOT A FAILURE -- the provider may simply not have made its
        # state directory yet, which is the ordinary case on an early tick.
        # ANYTHING ELSE IS, and is declared rather than read as "it wrote
        # nothing".
        if why:
            _noted_once(failed, why)
        os.close(native)
        return found
    found["reached"] = True
    try:
        _walked(top, native, (), kept, failed, fmt)
    finally:
        os.close(top)
        os.close(native)
    return found


def _noted_once(failed, said):
    """One distinct failure, kept once however many ticks repeat it."""
    if said not in failed:
        failed.append(said)


def _descended(root, components):
    """`(descriptor, why)` -- one no-follow component at a time.

    `os.open(a/b/c, O_NOFOLLOW)` holds only `c`: every ancestor is resolved
    normally and a link among them is followed. This walks them, so a link
    anywhere on the way is refused rather than traversed.

    AND ABSENCE IS NOT INACCESSIBILITY. Review 2026-09-18T03-39-32Z [R2]: this
    collapsed every `OSError` into `None` and its caller described that as an
    ordinary not-yet-created directory -- so a permission failure or a link
    where the state directory belongs produced an EMPTY CORNER reported as "the
    provider wrote nothing". `ENOENT` is the ordinary early tick; anything else
    is a reason, and the caller declares it.
    """
    try:
        here = os.open(root, os.O_RDONLY | os.O_NOFOLLOW | os.O_DIRECTORY)
    except FileNotFoundError:
        return None, None
    except OSError as failure:
        return None, f"a native capture root could not be opened " \
                     f"({type(failure).__name__})"
    for name in components:
        try:
            below = os.open(name,
                            os.O_RDONLY | os.O_NOFOLLOW | os.O_DIRECTORY,
                            dir_fd=here)
        except FileNotFoundError:
            os.close(here)
            return None, None
        except OSError as failure:
            os.close(here)
            return None, f"a native capture root component could not be " \
                         f"entered ({type(failure).__name__}); a link or an " \
                         f"unreadable directory is not an absent one"
        os.close(here)
        here = below
    return here, None



def _declare_native(room, fmt, found, outcome):
    """The native corner's own honest word, so an empty one cannot lie.

    Review 2026-09-18T03-10-39Z [R2]: "do not report an empty directory as
    proof the provider wrote nothing when capture failed." The retention's
    count was computed and thrown away, so a corner that failed to fill looked
    exactly like one the provider never wrote to.

    THE NATIVE CORNER IS NOT ONE OF THE SIX STREAMS, so it has no sidecar of
    its own; what this does is put the failure where a reader will meet it --
    beside the provider's stdout, whose turn produced the files. A retention
    that lost bytes makes that stream's word `failed`, because an operator
    reading a complete-looking provider record beside a silently empty corner
    is exactly the false picture this Work exists to remove.
    """
    if room is None or fmt is None or not found.get("failed"):
        return None
    try:
        return fmt.write_declaration(
            room, "provider.stdout", "failed",
            reason="this turn's provider record is here and its own session "
                   "files were not all retained: "
                   + "; ".join(found["failed"][:4]))
    except Exception:                                      # noqa: BLE001
        return None


def _flat(prefix, name):
    """One source path as one REVERSIBLE file name.

    `__` collided: `a/b` and `a__b` both became `a__b`, so three files were
    counted retained and two existed and one source's bytes were overwritten.
    Choosing a different literal separator moves the collision rather than
    removing it, because any character a separator can be is a character a
    component can contain.

    SO THE COMPONENTS ARE ESCAPED BEFORE THEY ARE JOINED, which is what makes
    the mapping injective: `%` becomes `%25` first, so the `%2F` that stands
    for the separator cannot be produced by any component. `a/b` is `a%2Fb`
    and `a__b` stays `a__b`.

    AND THE BOOKKEEPING NAME IS ESCAPED TOO, in the same scheme. Review
    2026-09-18T05-32-05Z [R2]: a provider file literally called
    `.retention.json` was SILENTLY DROPPED -- `_walked` skipped the source
    because the DESTINATION directory keeps the record under that name, so a
    real transcript was neither retained nor reported, with `reached` true and
    `failed` empty. A capture whose whole vocabulary exists to distinguish
    "missing" from "empty" cannot have a filename it quietly refuses.
    THE NAMESPACE ANSWERS IT rather than a skip: a flattened name that would
    collide with the record or its staging has its leading `.` escaped as
    `%2E`, so `.retention.json` is retained as `%2Eretention.json`. The
    mapping stays injective because a literal per-cent is already `%25`, so a
    provider file really called `%2Eretention.json` becomes
    `%252Eretention.json` and the two are held apart. `_confined` still
    refuses the record's own name as a destination, and now no source can ask
    for it.
    """
    held = "%2F".join(one.replace("%", "%25")
                      for one in prefix + (name,))
    if held == RETENTION or held.startswith(RETENTION + "."):
        return "%2E" + held[1:]
    return held


def _walked(here, native, prefix, kept, failed, fmt, depth=0):
    # `kept` maps a flattened name to how many of its bytes are already
    # retained, and carries this turn's accumulated failures under the empty
    # key -- one object the caller holds across every tick.
    """One directory, copied incrementally, every step no-follow.

    DEPTH-BOUNDED. A provider that made a deep tree is not a reason for this to
    recurse without end; the bound is generous and the refusal is recorded.
    """
    if depth > NATIVE_DEPTH:
        _noted_once(failed, "a native directory is nested deeper than this "
                            "deployment retains")
        return
    try:
        with os.scandir(here) as listing:
            entries = sorted(listing, key=lambda one: one.name)
    except OSError as failure:
        _noted_once(failed, f"a native directory could not be listed "
                            f"({type(failure).__name__})")
        return
    for entry in entries:
        name = entry.name
        try:
            held = os.stat(name, dir_fd=here, follow_symlinks=False)
        except OSError as failure:
            _noted_once(failed, f"a native entry could not be inspected "
                                f"({type(failure).__name__})")
            continue
        if stat.S_ISDIR(held.st_mode):
            try:
                below = os.open(name,
                                os.O_RDONLY | os.O_NOFOLLOW | os.O_DIRECTORY,
                                dir_fd=here)
            except OSError as failure:
                # A LINK WHERE A DIRECTORY SHOULD BE is refused by the open
                # rather than by a name check that a swap could outrun -- and
                # the refusal is RECORDED, because a directory this manager
                # could not enter is evidence it did not retain.
                _noted_once(failed, f"a native directory could not be entered "
                                    f"({type(failure).__name__})")
                continue
            try:
                _walked(below, native, prefix + (name,), kept, failed, fmt,
                        depth + 1)
            finally:
                os.close(below)
            continue
        if not stat.S_ISREG(held.st_mode):
            # A SYMLINK, A FIFO OR A DEVICE IS NOT A SESSION FILE. The one
            # symlink this adapter puts in that home is the CREDENTIAL slot,
            # and it is excluded here and again by the no-follow open below.
            continue
        # NO SOURCE NAME IS SKIPPED. This used to `continue` on a provider
        # file called `.retention.json`, on the reasoning that the name is
        # this corner's bookkeeping -- but the bookkeeping lives in the
        # DESTINATION and this walk is over the SOURCE, so the only file that
        # could ever match is a real one the provider wrote. `_flat` escapes
        # the collision instead, and what a capture cannot retain it reports.
        flat = _flat(prefix, name) or "."
        _appended(here, name, native, flat, kept, failed, fmt)



# THE RETENTION RECORD'S OWN NAME, inside the native corner so it survives the
# process that wrote it. Review 2026-09-18T03-48-00Z: the generation mapping
# lived in a local variable and in a per-run dictionary, so every tick measured
# the ORIGINAL destination again and a restart with a fresh map inferred
# nothing at all. A binding that does not outlive its process is not a binding.
# THE NAME IS THE SHARED FORMAT'S, so the manager's reader and this writer
# cannot disagree about which entry is bookkeeping. Read through the module the
# caller hands in, because this file must not import the manager.
RETENTION = ".retention.json"

# THE GENERATION NAMESPACE, and it is disjoint from every name a source can
# produce. `_flat` emits `%25` for a literal per-cent and `%2F` for the
# separator and nothing else, so `%23` cannot be the image of any source
# path -- while the earlier `#N` suffix collided with a real source file
# called `x#2`.
GENERATION = "%23"


# HOW MUCH RECORD THIS CORNER WILL READ BACK. Metadata a later incarnation
# reads is INPUT like any other, and an unbounded read of a file somebody else
# can grow is not a read this adapter controls.
MAX_RETENTION = 1 << 20

# A RETAINED HEAD DIGEST, written by `_fingerprint`: empty when nothing is
# retained yet, and one lower-case sha256 otherwise.
_HEAD = re.compile(r"\A(?:[0-9a-f]{64})?\Z")

# EVERY MEMBER A RECORD ENTRY HAS, and no other. A closed document, because the
# members an attacker would want to add are exactly the ones this then trusts.
_ENTRY = ("destination", "head", "identity", "retained")

# A GENERATION SUFFIX, DECIDED AS A BOUNDED ASCII NUMERAL rather than by
# converting it. Review 2026-09-18T04-53-08Z [R1]: `str.isdigit` is true of the
# superscript `²` and `int()` is not, and a run of 4301 ASCII digits is refused
# by Python's own integer-conversion limit -- so two record documents well
# under `MAX_RETENTION` raised `ValueError` OUT of the drain instead of being
# discarded as malformed. Validation over untrusted input has to be TOTAL, and
# the way to make it total is to decide the SHAPE without converting it.
# `_next_generation` counts up from 2, so what a destination may carry is a
# decimal numeral with no leading zero, greater than one, and no longer than
# any run of rotations this corner could ever reach.
_GENERATION = re.compile(r"\A[1-9][0-9]{0,17}\Z")

# One staging name per call, never reused. Review 2026-09-18T04-07-54Z: a fixed
# pid name opened `O_TRUNC` is not an exclusively owned staging file -- two
# threads draining two sources share a pid, and the name is guessable by
# anything that can see this corner. This provides NAMING; `O_CREAT|O_EXCL`
# and removing only what this call created are what make the act safe.
_STAGING = itertools.count()


def _confined(name):
    """ONE ENTRY IN THIS CORNER, and the check is what confines it.

    Review 2026-09-18T04-07-54Z [R2]: a synthetic record naming
    `destination: "../escaped"` had the source's bytes appended OUTSIDE the
    native directory, with `failed` empty. `O_NOFOLLOW` governs the FINAL
    component only and `dir_fd` resolves `..` exactly as any path does, so a
    descriptor-relative open is not confinement -- the NAME is, and this is the
    one place a record's name becomes something that gets opened.
    """
    return (type(name) is str and name
            and "/" not in name and "\0" not in name
            and name not in (".", "..")
            and name != RETENTION
            and not name.startswith(RETENTION + "."))


def _generation_of(source, destination):
    """Whether this destination is a NAME THIS SOURCE COULD HAVE BEEN GIVEN.

    The relationship is part of the record's meaning: a destination is either
    the flattened source itself or one of its own generations. A record
    claiming some other source's file is not a record about this source, and
    accepting it would let one entry redirect another's bytes.

    AND THE ANSWER IS ALWAYS AN ANSWER. This used to ask `str.isdigit` and then
    `int()`, which are not the same question: the first is true of digits from
    every script and the second accepts only ASCII and only up to a length
    limit. Whatever this cannot recognise is FALSE -- a malformed entry, which
    the caller drops and declares -- rather than an exception thrown through a
    capture whose whole purpose is to keep working when something else has
    already gone wrong.
    """
    if destination == source:
        return True
    if not destination.startswith(source + GENERATION):
        return False
    suffix = destination[len(source) + len(GENERATION):]
    return suffix != "1" and _GENERATION.match(suffix) is not None


def _believed(found):
    """The record, VALIDATED whole, or the parts of it that can be believed.

    `_read_retention` used to return any JSON object it could parse, and
    `_destination` then trusted the nested `destination`, `retained`,
    `identity` and `head` straight out of it. This is the seam where a
    document becomes a decision, so this is where the document is checked.

    ENTRY BY ENTRY, and a bad one is DROPPED rather than taking the rest with
    it: the record describes many sources and one unreadable entry is not a
    reason to lose the bindings that are provable. The caller declares the
    uncertainty; nothing here silently substitutes a value.
    """
    kept, dropped = {}, 0
    if type(found) is not dict:
        return {}, 1
    for source, was in found.items():
        if not _confined(source) or type(was) is not dict \
                or tuple(sorted(was)) != _ENTRY:
            dropped += 1
            continue
        identity, destination = was["identity"], was["destination"]
        retained, head = was["retained"], was["head"]
        if type(identity) is not list or len(identity) != 2 \
                or any(type(one) is not int or type(one) is bool
                       for one in identity):
            dropped += 1
            continue
        if not _confined(destination) \
                or not _generation_of(source, destination):
            dropped += 1
            continue
        if type(retained) is not int or type(retained) is bool or retained < 0:
            dropped += 1
            continue
        if type(head) is not str or not _HEAD.match(head):
            dropped += 1
            continue
        kept[source] = {"identity": identity, "destination": destination,
                        "retained": retained, "head": head}
    return kept, dropped


def _read_retention(native, failed=None):
    """What this corner already knows about which source it retained.

    ABSENT IS AN ANSWER and it is the ordinary first tick. A record that cannot
    be read or BELIEVED is treated as absent too, and the caller then refuses
    to infer a correspondence it cannot prove.

    A REGULAR FILE, ASKED OF THE DESCRIPTOR. `O_NOFOLLOW` refuses a symlink at
    the name; it says nothing about a fifo, which would block this drain
    forever on a read, or a device. What was opened is what is measured.
    """
    try:
        handle = os.open(RETENTION, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK,
                         dir_fd=native)
    except OSError:
        return {}
    try:
        try:
            held = os.fstat(handle)
        except OSError:
            return {}
        if not stat.S_ISREG(held.st_mode):
            _noted_once(failed, "the retention record is not a regular file, "
                                "so nothing about which source filled which "
                                "retained file can be proved from it")
            return {}
        raw = b""
        while len(raw) <= MAX_RETENTION:
            try:
                piece = os.read(handle, MAX_RETENTION + 1 - len(raw))
            except OSError:
                return {}
            if not piece:
                break
            raw += piece
    finally:
        os.close(handle)
    if len(raw) > MAX_RETENTION:
        _noted_once(failed, "the retention record is larger than this capture "
                            "reads back, so it is treated as absent rather "
                            "than partly believed")
        return {}
    try:
        found = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, ValueError, RecursionError):
        # RECURSION IS ONE OF THE PARSER'S ANSWERS, and it is not a
        # `ValueError`. Review 2026-09-18T04-53-08Z asked for the malformed
        # bounded document to be handled under one contract, and a record of
        # two hundred thousand open brackets -- comfortably under
        # `MAX_RETENTION` -- exhausts the decoder's stack rather than failing
        # to parse. A bound on BYTES is not a bound on DEPTH, so the answer is
        # caught where every other unreadable record is.
        _noted_once(failed, "the retention record could not be read as this "
                            "capture's own document; correspondence is not "
                            "inferred from it")
        return {}
    kept, dropped = _believed(found)
    if dropped:
        _noted_once(failed, "the retention record held entries this capture "
                            "will not act on, so the sources they named start "
                            "their own generations rather than resuming a "
                            "correspondence nothing proves")
    return kept


def _write_retention(native, held, fmt):
    """The record, replaced atomically inside the corner it describes.

    THE ENTRY IS CREATED, NEVER OPENED, and only an entry THIS CALL made is
    ever removed -- the two lessons `attempt_log_format.write_declaration`
    already carries, applied here rather than restated differently. An
    ordinary truncating open at a guessable name follows whatever is there.

    AND THE ANSWER MATTERS. Review 2026-09-18T04-07-54Z [R1]: this returned
    `False` and its caller ignored it, so a record that never reached disk was
    reported as no failure at all.
    """
    payload = json.dumps(held, sort_keys=True).encode()
    staging = f"{RETENTION}.{os.getpid()}.{next(_STAGING)}.staging"
    try:
        handle = os.open(staging,
                         os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW,
                         0o640, dir_fd=native)
    except OSError:
        return False
    try:
        try:
            if fmt.write_all(handle, payload) != len(payload):
                return False
        finally:
            os.close(handle)
        os.replace(staging, RETENTION, src_dir_fd=native, dst_dir_fd=native)
    except OSError:
        return False
    else:
        return True
    finally:
        # ONLY WHAT THIS CALL CREATED, and only if the replace did not consume
        # it. A handler that unlinked on any failure would delete somebody
        # else's entry the day the exclusive create is what failed.
        try:
            os.unlink(staging, dir_fd=native)
        except OSError:
            pass


# HOW MUCH OF A SOURCE'S HEAD IS FINGERPRINTED. Identity and length cannot see
# an in-place REWRITE: review 2026-09-18T03-48-00Z's second probe replaced a
# two-byte source with two different bytes, and inode, device and size all
# still agreed. So the record also keeps a digest of the head of what was
# actually retained, and a tick that finds different bytes there knows the
# source is a different stream wearing the same name.
#
# BOUNDED ON PURPOSE. A provider's session file is not bounded by anything this
# adapter controls and re-digesting all of it every tick would make retention
# quadratic in the file. The honest limit is stated rather than hidden: a
# rewrite that preserves the first `FINGERPRINT` bytes AND does not shorten the
# file is indistinguishable from an append, and is treated as one.
FINGERPRINT = 4096


def _fingerprint(reading, upto):
    """A digest of the head of this source, from the descriptor already open.

    `pread` rather than a seek, because the caller's position is the read
    position and this must not disturb it. An unreadable head answers None,
    which the caller treats as "cannot prove correspondence".
    """
    wanted = min(int(upto), FINGERPRINT)
    if wanted <= 0:
        return ""
    held = b""
    while len(held) < wanted:
        try:
            piece = os.pread(reading, wanted - len(held), len(held))
        except OSError:
            return None
        if not piece:
            # SHORTER THAN WHAT WAS RETAINED, which is a rotation in itself.
            return None
        held += piece
    return hashlib.sha256(held).hexdigest()


def _reconciled(native, was, reading, failed):
    """How much of this source is REALLY retained, across the commit window.

    THE BYTES GO DOWN FIRST AND THE RECORD FOLLOWS, and that order is the whole
    of the recovery story. Review 2026-09-18T04-07-54Z [R1]: `_write_retention`
    could fail -- or a process could stop between the append and the replace --
    leaving the record saying three bytes while the destination already held
    six. `_destination` trusted the record, seeked the source to 3, opened the
    destination `O_APPEND`, and produced `abcdefdef` with `failed` empty.

    An atomic REPLACE of the record is not a transaction over the separately
    appended data, and calling it one was my own description. Only one of the
    two orders is recoverable: with data first, the destination can only ever
    be AHEAD of the record, and being ahead is a fact on disk this can read.

      THE SAME -- the ordinary tick, and nothing is declared.

      AHEAD -- the window. The record's own head describes fewer bytes than
      are there, so it cannot settle this; what CAN is comparing the retained
      file's head against THE SOURCE'S over the same reconciled length. If
      those agree the extra bytes are this source's own and retention resumes
      from what is on disk, with the recovery DECLARED -- an operator reading
      this log should know a record was rebuilt rather than believed.

      BEHIND, or unreadable, or disagreeing -- the destination holds bytes
      nothing here can account for. `None`, and the caller starts a new
      generation rather than writing into a file it cannot explain.

    BOUNDED, and the bound is the same `FINGERPRINT` the rest of this uses: a
    reconciliation that re-read the whole retained file every tick would make
    recovery quadratic in it. Bytes past the window are covered by the prefix
    agreeing and by nothing else, and that is said here rather than implied.
    """
    already = int(was["retained"])
    actual = _retained_size(native, was["destination"])
    if actual is None:
        # NOT A RETAINED FILE AT ALL -- a fifo, a device, a directory, or an
        # entry this cannot even measure. The record's word is not evidence
        # about what is on disk.
        _noted_once(failed, "a retained native file is not a regular file "
                            "this capture can account for, so the source "
                            "starts its own generation rather than writing "
                            "into whatever is there")
        return None
    if actual == already:
        return already
    if actual < already:
        _noted_once(failed, "a retained native file holds fewer bytes than "
                            "the retention record counted, so its bytes are "
                            "kept and the source starts its own generation "
                            "rather than resuming a correspondence nothing "
                            "proves")
        return None
    kept = _retained_head(native, was["destination"], actual)
    if kept is None or kept != _fingerprint(reading, actual):
        _noted_once(failed, "a retained native file could not be reconciled "
                            "with the source it is supposed to hold, so its "
                            "bytes are kept and the source starts its own "
                            "generation")
        return None
    _noted_once(failed, "a retention record was behind the bytes it "
                        "describes, which is what a failed or interrupted "
                        "record update leaves; retention resumed from what is "
                        "on disk rather than from the stale offset")
    return actual


def _retained_head(native, flat, upto):
    """A digest of the head of a RETAINED file, for the same bounded window.

    Read through a descriptor this opens and closes, and refused unless it is a
    regular file: this is the corner's own entry, and the whole point is to
    establish that the bytes there are the ones the record describes.
    """
    wanted = min(int(upto), FINGERPRINT)
    if wanted <= 0:
        return ""
    try:
        handle = os.open(flat, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK,
                         dir_fd=native)
    except OSError:
        return None
    try:
        try:
            if not stat.S_ISREG(os.fstat(handle).st_mode):
                return None
        except OSError:
            return None
        held = b""
        while len(held) < wanted:
            try:
                piece = os.pread(handle, wanted - len(held), len(held))
            except OSError:
                return None
            if not piece:
                return None
            held += piece
    finally:
        os.close(handle)
    return hashlib.sha256(held).hexdigest()


def _destination(native, flat, held, now, size, reading, failed):
    """Where this source's bytes go, and from which offset, PROVED.

    THE RECORD DECIDES, never the length. Review 2026-09-18T03-48-00Z: "after
    restart never infer correspondence from length alone" -- so a destination
    that exists with no record of WHICH source filled it is not resumed. The
    old bytes stay exactly where they are and a new generation begins, with the
    uncertainty declared rather than papered over.

      NO RECORD AND NO DESTINATION -- an ordinary first sight of this source.

      A RECORD THAT MATCHES this source's identity AND whose retained head is
      still the source's head -- resume at the offset the record holds, which
      is what makes a restart continue rather than repeat.

      A RECORD THAT DISAGREES, or a destination nobody can account for -- the
      source was truncated, replaced, rewritten or is simply unprovable, and
      either way the answer is a new generation rather than a splice.
    """
    was = held.get(flat)
    if type(was) is dict and was.get("identity") == list(now):
        already = _reconciled(native, was, reading, failed)
        if already is None:
            return _next_generation(native, flat, held), 0, was
        if size < already:
            # SHORTER THAN WHAT IS RETAINED. Truncated without a new inode,
            # which the identity alone cannot see.
            _noted_once(failed, "a native source was truncated in place; its "
                                "later bytes are kept as a separate "
                                "generation")
        elif already != int(was["retained"]):
            # RECONCILED UPWARD, and `_reconciled` proved the retained file's
            # head against THE SOURCE'S over the whole reconciled length --
            # a stronger statement than the record's own stale digest. Resume
            # from what is on disk; the recovery is already declared.
            return was["destination"], already, was
        elif _fingerprint(reading, already) != was["head"]:
            # SAME FILE, SAME LENGTH, DIFFERENT STREAM. Rewritten under
            # itself, which nothing the kernel offers can see.
            _noted_once(failed, "a native source was rewritten in place while "
                                "it was being retained; its later bytes are "
                                "kept as a separate generation")
        else:
            return was.get("destination", flat), already, was
        return _next_generation(native, flat, held), 0, was
    if was is None and not _exists(native, flat):
        return flat, 0, None
    if was is None:
        _noted_once(failed, "a retained native file has no record of which "
                            "source filled it, so its bytes are kept and the "
                            "new source starts its own generation rather than "
                            "resuming a correspondence nothing proves")
    else:
        _noted_once(failed, "a native source was truncated or replaced while "
                            "it was being retained; its later bytes are kept "
                            "as a separate generation")
    return _next_generation(native, flat, held), 0, was


def _next_generation(native, flat, held):
    """A destination this corner is not already using, in its own namespace."""
    taken = {one.get("destination") for one in held.values()
             if type(one) is dict}
    generation = 2
    while True:
        candidate = f"{flat}{GENERATION}{generation}"
        if candidate not in taken and not _exists(native, candidate):
            return candidate
        generation += 1


def _retained_size(native, flat):
    """How many bytes are at one destination, from the DISK -- if it IS one.

    WHAT IT IS COMES BEFORE HOW BIG IT IS. Review 2026-09-18T04-53-08Z [R2]: a
    fifo's size is zero, which reads exactly like an empty retained file, so a
    valid-looking record pointed the capture at one and the later `O_WRONLY`
    open sat waiting for a reader that was never coming. A record can say a
    destination is this source's retained copy; only the DISK can say it is a
    file. `None` means nothing here can be proved about it, and the caller
    starts a new generation rather than writing into it.

    ABSENT IS STILL ZERO, because a destination that is not there yet is the
    ordinary first tick and not a reason to rotate.
    """
    try:
        held = os.stat(flat, dir_fd=native, follow_symlinks=False)
    except FileNotFoundError:
        return 0
    except OSError:
        return None
    return held.st_size if stat.S_ISREG(held.st_mode) else None


def _exists(native, flat):
    """Whether this corner already holds an entry under that name."""
    try:
        os.stat(flat, dir_fd=native, follow_symlinks=False)
        return True
    except OSError:
        return False


def _recorded(native, record, fmt, failed):
    """Put the record down, and SAY SO when it does not go.

    Review 2026-09-18T04-07-54Z [R1]: the answer was discarded, so a record
    that never reached disk was reported as no failure at all -- and the next
    incarnation then had bytes nobody could account for and no note saying why.
    """
    if _write_retention(native, record, fmt):
        return True
    _noted_once(failed, "a native retention record could not be written; the "
                        "bytes already retained are unaffected and the next "
                        "tick reconciles from what is on disk, but until then "
                        "this corner cannot say which source filled which "
                        "retained file")
    return False


def _remember(record, source, now, flat, already, reading):
    """What this corner knows about one source, after moving its bytes.

    THE HEAD DIGEST IS PART OF THE BINDING, not an extra: without it the record
    could only say WHICH FILE it was reading, and a file rewritten under itself
    is the same file by every measure the kernel offers.
    """
    record[source] = {"identity": list(now), "destination": flat,
                      "retained": already,
                      "head": _fingerprint(reading, already)}


def _acquired(native, source, flat, already, held, failed):
    """A destination descriptor this capture OWNS, or None.

    Review 2026-09-18T05-32-05Z [R1]: `S_ISREG` proves the opened thing is a
    file; it does not prove it is THIS corner's file. The reviewer hard-linked
    a sibling from outside the native directory at `native/s.jsonl`, supplied a
    valid record for it, and watched a supposedly confined writer append the
    provider's transcript to BOTH names with `failed` empty. `O_NOFOLLOW`
    refuses a symlink and a confined name refuses traversal; NEITHER can see an
    alias, because a hard link is not a second name for a path, it is a second
    name for the INODE.

    SO THE INODE'S OWN LINK COUNT IS THE QUESTION, asked of the descriptor
    being written to. A retained file this capture created and has kept has
    exactly one link; anything else is a destination somebody else also holds,
    and bytes written into it leave this corner by definition.

    AND A NEW DESTINATION IS CREATED, NOT OPENED. `O_CREAT` alone adopts
    whatever is already at the name -- which is how the aliased file became a
    destination in the first place. When this decides it is claiming a name
    nothing holds yet, `O_EXCL` is what makes that true rather than assumed,
    and an `EEXIST` means the answer changed under it.

    A REFUSAL KEEPS THE BYTES AND MOVES ON. What is already at that name is
    not touched, the uncertainty is declared, and the source is retained as
    its own generation -- the same answer a truncation, a rewrite or a fifo
    gets, because from this capture's side they are the same fact: the
    destination it was going to write is not one it can account for. ONE
    rotation, because a corner where the fresh name is also unusable is not
    one more attempt away from working.
    """
    for rotated in (False, True):
        fresh = not _exists(native, flat)
        flags = (os.O_WRONLY | os.O_CREAT | os.O_APPEND
                 | os.O_NOFOLLOW | os.O_NONBLOCK)
        if fresh:
            flags |= os.O_EXCL
            already = 0
        try:
            writing = os.open(flat, flags, 0o640, dir_fd=native)
        except OSError as failure:
            _noted_once(failed, f"a native file could not be retained "
                                f"({type(failure).__name__})")
            return None
        try:
            kind = os.fstat(writing)
        except OSError as failure:
            os.close(writing)
            _noted_once(failed, f"a retained native file could not be "
                                f"measured ({type(failure).__name__})")
            return None
        if not stat.S_ISREG(kind.st_mode):
            os.close(writing)
            _noted_once(failed, "a retained native file is not a regular "
                                "file, so this capture wrote nothing into it "
                                "rather than into whatever is there")
        elif kind.st_nlink != 1:
            os.close(writing)
            _noted_once(failed, "a retained native file is also linked "
                                "elsewhere, so writing into it would put this "
                                "attempt's bytes outside its own room; the "
                                "bytes already there are kept and the source "
                                "is retained separately")
        else:
            return writing, flat, already
        if rotated:
            return None
        flat, already = _next_generation(native, source, held), 0
    return None


def _appended(here, name, native, flat, kept, failed, fmt):
    """Whatever is NEW in one file, appended to its retained copy.

    THE RESUME POSITION IS THE RETAINED COPY'S OWN SIZE, not an in-memory
    integer. Review 2026-09-18T03-39-32Z [R2]: offsets were per-call-lifetime
    numbers, so a FRESH map over the same durable room appended `abc` a second
    time and a restarted capture could not recover its position. What is
    already retained is a fact on disk; asking the disk makes restart work by
    construction rather than by remembering.

    AND THE SOURCE'S IDENTITY IS BOUND TO IT. A source that was TRUNCATED or
    REPLACED is shorter than what was retained, or is a different inode -- and
    appending its new bytes onto the old ones would silently splice two
    generations into one file while omitting nothing visibly. Each generation
    gets its own retained name and the change is DECLARED, so an operator sees
    two files and a note rather than one plausible lie.

    AND BOTH DESCRIPTORS ARE TAKEN NONBLOCKING AND CHECKED FOR WHAT THEY ARE.
    Review 2026-09-18T04-53-08Z [R2]: every type check here was on a NAME
    somebody else can replace, so a fifo where a source or a retained copy
    belongs left this waiting for a peer inside the drain the provider's own
    turn joins. A logging failure must not strand the path it is logging.

    AND THE DESTINATION IS ONE THIS CAPTURE OWNS, which `_acquired` decides.
    A regular file at a confined name can still be an ALIAS of a file outside
    this room, and writing into it writes outside the room.
    """
    if "retention" not in kept:
        kept["retention"] = _read_retention(native, failed)
    record = kept["retention"]
    try:
        # NONBLOCKING ACQUISITION, because acquiring a descriptor is the one
        # step here that can wait forever. Review 2026-09-18T04-53-08Z [R2]:
        # `_walked` checks a NAME and this opens it, and a swap in between
        # invalidates the check -- an `O_RDONLY` open of a fifo blocks for a
        # writer, and `_ran_provider` waits on this drain with `reader.join()`.
        # On a regular file the flag changes nothing, which is the point: the
        # ordinary case is untouched and the exotic one cannot strand the
        # provider path.
        reading = os.open(name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK,
                          dir_fd=here)
    except OSError as failure:
        # A SYMLINK IS THE ORDINARY CASE HERE and is not a capture failure:
        # `_walked` already refused it by type, so what reaches this is a file
        # that could not be opened.
        _noted_once(failed, f"a native file could not be opened "
                            f"({type(failure).__name__})")
        return
    try:
        # MEASURED THROUGH THE DESCRIPTOR THIS WILL READ, not by name. A name
        # measured and then opened is two objects whenever anything moves in
        # between, and what this decides from the measurement is which stream
        # the bytes belong to.
        try:
            held = os.fstat(reading)
        except OSError as failure:
            _noted_once(failed, f"a native file could not be measured "
                                f"({type(failure).__name__})")
            return
        if not stat.S_ISREG(held.st_mode):
            # THE DESCRIPTOR, NOT THE NAME `_walked` STATTED. A nonblocking
            # open of a fifo with no writer succeeds and then READS EOF, so
            # without this the swap would be retained as an empty file and
            # reported as an ordinary success -- the exact false picture this
            # capture exists to remove.
            _noted_once(failed, "a native file changed into something that is "
                                "not a regular file between being listed and "
                                "being opened, so nothing was read from it")
            return
        now = (held.st_dev, held.st_ino)
        source = flat
        # ONE PLACE DECIDES. The rotation checks used to be split between this
        # caller and the helper, and a split decision is one that disagrees
        # with itself the first time either half changes.
        flat, already, was = _destination(native, flat, record, now,
                                          held.st_size, reading, failed)
        # THE DESTINATION IS ACQUIRED BEFORE THE SOURCE IS POSITIONED, because
        # acquiring it can ROTATE: a destination this capture cannot own sends
        # the source to a fresh generation at offset zero, and a seek taken
        # before that decision would be a seek to the old one's offset.
        acquired = _acquired(native, source, flat, already, record, failed)
        if acquired is None:
            return
        writing, flat, already = acquired
        try:
            try:
                os.lseek(reading, already, os.SEEK_SET)
            except OSError as failure:
                _noted_once(failed, f"a native file could not be positioned "
                                    f"({type(failure).__name__})")
                return
            while True:
                try:
                    piece = os.read(reading, NATIVE_CHUNK)  # noqa: PLW2901
                except OSError as failure:
                    _noted_once(failed, f"a native file could not be read "
                                        f"({type(failure).__name__})")
                    return
                if not piece:
                    _remember(record, source, now, flat, already, reading)
                    _recorded(native, record, fmt, failed)
                    return
                moved = fmt.write_all(writing, piece)
                already += moved
                # THE DATA FAILURE IS THE FIRST THING SAID, because it is the
                # one an operator is looking for: bytes that did not reach the
                # room at all. The record is still updated for what DID reach
                # it, so the next tick starts from a true offset rather than
                # re-copying what is already there.
                short = moved != len(piece)
                if short:
                    _noted_once(failed,
                                "a native file's bytes could not all be "
                                "written")
                _remember(record, source, now, flat, already, reading)
                recorded = _recorded(native, record, fmt, failed)
                if short or not recorded:
                    # THE BYTES ARE DOWN AND THE RECORD IS NOT. Stopping here
                    # keeps the two one append apart rather than many, and the
                    # next tick reconciles from the destination's own size.
                    return
        finally:
            os.close(writing)
    finally:
        os.close(reading)


# HOW MUCH MOVES AT A TIME. A provider's own session log is not bounded by
# anything this adapter controls, so the bound that matters is on MEMORY rather
# than on the file: bytes stream in chunks and nothing is capped away. The
# earlier `MAX_NATIVE_FILE` read that many bytes and counted the file retained,
# which silently truncated anything larger while reporting it complete.
NATIVE_CHUNK = 1 << 16

# How deep a provider's own state tree is followed. Generous, and a refusal
# rather than an unbounded walk.
NATIVE_DEPTH = 8


class _Outcome:
    """What actually happened to a child, as the three cases that differ.

    Review 2026-09-18T02-31-51Z [4]. A `finally` cannot tell these apart, and
    declaring from one made "never started" indistinguishable from "ran to the
    end" -- which is the whole distinction the capture vocabulary exists for.

      NEVER STARTED -- the subprocess boundary raised. There is no stream and
      there never was one; `failed` says so, and its prose says there may be no
      file at all.

      INTERRUPTED -- a timeout or a signal ended the child. Whatever reached the
      file is a prefix of what the child would have written, which is `partial`.

      COMPLETED -- the child ran and exited, whatever its status. Its streams
      ended because it ended, and `finished` is the honest word for that.

    AN EXIT STATUS IS NOT AN OUTCOME HERE. A child that exits 1 wrote whatever
    it wrote and then stopped; the capture is complete even though the command
    failed, and conflating the two would report every failing verification as a
    broken log.
    """

    NEVER_STARTED = "failed"
    INTERRUPTED = "partial"
    COMPLETED = "finished"


class _ActivityUnknown(Exception):
    """W61599: this observation cannot be made, so activity is unknown.

    PRIVATE AND NEVER ESCAPES. It is caught by `observed_activity`, which
    freezes the running total; nothing outside this file sees it, and no
    provider turn ever fails because of it.
    """


class TaskRefusal(Exception):
    """Something this adapter will not proceed from.

    Raised rather than answered, because `baton_worker` turns an agent
    exception into a bounded correlated fault frame with no traceback -- which
    is exactly the right shape and is not this module's to reimplement.
    """


class ClaudeAgent:
    """One real provider turn, over one staged source tree."""

    def __init__(self, *, run=None, home=None):
        """`run` and `home` are SEAMS FOR TESTS and are not operands.

        A caller inside the image supplies neither: `main(agent=ClaudeAgent())`
        is the whole construction. They exist so the argv, the environment and
        the write boundary can be proved without a provider, a credential or a
        network -- which is what this checkpoint's acceptance asks for and what
        no live run could establish deterministically anyway.
        """
        self._run = run if run is not None else subprocess.run
        self._home = home
        # W61599: WHAT THIS TURN HAS OBSERVED OF ITS OWN NATIVE STREAM.
        #
        # `None` is UNKNOWN and is the state this adapter starts in and returns
        # to: no provider has been launched, or the home this one ran under was
        # not provably empty, or the source became ambiguous. It is never a
        # zero, because "observed, and empty" is a different claim from
        # "nothing observed yet" and only one of them is true here.
        #
        # THE LOCK IS REAL. `baton_worker`'s publisher reads this from its own
        # thread once a second while the provider runs, and the turn binds it
        # from the main thread immediately before the launch.
        self._activity_lock = threading.Lock()
        self._activity = None

    # -- the provider turn, for a workload this adapter does not own ---------

    def invoke_provider(self, *, prompt, room, seen=None):
        """One provider turn, under this adapter's existing rules.

        W110935. ADDITIVE, AND IT OWNS NO NEW MECHANISM. Everything that makes
        a provider turn safe here already exists and is proved by this file's
        own suite: the closed argv, the environment that is COMPOSED rather
        than inherited so no ambient credential variable can outrank the
        prepared one, the credential home `_prepared_home` builds, the
        continuously drained and bounded stdout, and the closed failure
        classification that publishes one of this module's own words rather
        than the provider's prose. This exposes that turn under one public
        name so the integration workload does not grow a second copy of those
        rules -- which is the only way two workloads stay under one credential
        boundary.

        WHAT IT DOES NOT DECIDE. It runs a turn and reports how the turn
        ended. It reads no target, imports nothing, and its answer is a claim
        about a PROCESS: `ok` says the provider exited zero, and says nothing
        whatever about what the provider did. The caller's own read-back is
        what turns that into an outcome, and W110935's workload owns it.

        THE PROMPT IS THE CALLER''S AND IS REQUIRED. `work` composes its
        prompt from the task it was given; a workload with a different task
        document has a different prompt, and defaulting to this file's would
        hand the provider an instruction about work it is not doing.
        """
        # AND THE LAUNCH IT WAS DELIVERED UNDER. W156162, review
        # 2026-09-13T03:27:43Z [P1]: `_seen` is set by `work()` and this entry
        # never calls it, so an integrator whose Job requested 60 seconds
        # reached the production run seam with 3600 and the per-Job provider
        # ceiling stopped at the ordinary path. The caller passes the launch it
        # has ALREADY PROVED, and it is held for THIS TURN only: an adapter
        # remembering one delivery's ceilings across turns would be a second
        # account of a fact the delivery carries.
        #
        # `None` IS THE DELIVERY THAT CARRIES NO JOB -- `/1` and `/2` -- and it
        # takes this module's own default exactly as before. It is not a way to
        # opt out of a Job's ceilings: a `/3` whose boundary is missing or
        # malformed is refused by `_bound` rather than defaulted.
        if type(prompt) is not str or not prompt:
            raise TaskRefusal("a provider turn is invoked with a prompt")
        if type(room) is not str or not room or not os.path.isabs(room):
            raise TaskRefusal(
                "a provider turn runs in one absolute working directory")
        if os.path.islink(room) or not os.path.isdir(room) \
                or os.path.realpath(room) != room:
            raise TaskRefusal(
                "a provider turn's working directory is a real directory of "
                "its own, reached by its own canonical name")
        if seen is not None and not isinstance(seen, dict):
            raise TaskRefusal(
                "a provider turn's launch delivery is the document its caller "
                "proved, or nothing at all")
        scratch = self._scratch()
        environments = self._child_environments(scratch)
        # `task` IS UNUSED WHEN A PROMPT IS SUPPLIED -- `_provider` reads it
        # only to compose the default one -- so `None` is passed deliberately
        # rather than a document this adapter would have to invent.
        held, self._seen = self._seen, seen
        try:
            return self._provider(None, room, scratch,
                                  environments["provider"], prompt=prompt)
        finally:
            self._seen = held

    # -- the two methods `baton_worker` calls --------------------------------

    def consider(self, seen, request):
        """This runtime is not entitled to be asked, and says so if it is.

        The one-container topology means `consider` never reaches an agent --
        `baton_worker` refuses the operation as an entitlement fault before
        dispatch. This exists so the object satisfies the whole agent contract
        rather than the half that happens to be reachable, and it declines
        rather than inventing a decision it has no basis for: a provider-backed
        adapter has not looked at anything at this point.
        """
        return {"decision": "decline",
                "contract_digest": _digest(seen.get("contract", "")),
                "reason": "this dogfood adapter does not consent; the "
                          "operator selected the task before the container "
                          "started"}

    # W156162: THE LAUNCH DOCUMENT THIS TURN WAS GIVEN, held for the two
    # boundaries that need its ceilings. `None` is a composition that was
    # handed none -- focused verification, and the review branch below, which
    # runs no provider turn.
    _seen = None

    # W156162: THE CEILINGS THIS TURN ACTUALLY USES.
    #
    # `PROVIDER_SECONDS` and `VERIFICATION_SECONDS` are this module's defaults
    # and stay exactly what they were. What changes is that a launch document
    # carrying a Job context supplies the numbers instead -- which is the whole
    # point of the Work: the operator configures a Job, and the command this
    # container runs is given what the operator configured.
    #
    # THE DEFAULT IS FOR A LAUNCH WITH NO JOB BEHIND IT, not for a Job that
    # configured nothing. A Job that configured nothing resolves to these same
    # numbers at its own owner and delivers them explicitly, so falling back
    # here would only ever cover a `/1` or `/2` delivery.
    def _bound(self, seen, boundary, default):
        held = (seen or {}).get("job_execution")
        if not isinstance(held, dict):
            return default
        limits = held.get("execution_limits") or {}
        one = (limits.get("boundaries") or {}).get(boundary) or {}
        seconds = one.get("seconds")
        # A JOB-BOUND DELIVERY NEVER FALLS BACK. Review 2026-09-13T02:41:57Z
        # [P1]: this returned the module default for a boundary the delivery
        # did not carry, so a resealed configuration missing `provider_turn`
        # ran for an hour when the operator had written a minute. `launched`
        # now refuses an incomplete configuration, and this refuses too rather
        # than trusting that it did -- a silent default here is the whole
        # defect the Work exists to remove, arriving one layer in.
        if type(seconds) is not int or type(seconds) is bool:
            raise TaskRefusal(
                f"this launch carries a Job execution context and names no "
                f"usable {boundary} bound; a configured Job does not fall "
                f"back to this worker's own default")
        return seconds

    # W321528: THE SAME NUMBER, WITH THE FACT A READER NEEDS BESIDE IT.
    #
    # WHAT WAS WRONG. Every result publisher below spelled `PROVIDER_SECONDS`
    # into its `provider.seconds_bound` member while `_provider` ran the child
    # under `_bound`'s answer, so a turn the operator had bounded at 600 or at
    # 900 seconds published 3600 -- and did it next to a `why` that named the
    # real bound, which is how the two historic runs were caught. The number
    # was not stale by accident: it was a SECOND source for a fact that
    # already had one.
    #
    # SO THERE IS ONE SOURCE. This resolves the bound once, `_provider` calls
    # it once per turn, and what the child is given and what the result
    # reports are the same value by construction. The publishers read it off
    # the turn's own record through `_bound_member` and name no constant.
    #
    # AND NOT ONLY THE NUMBER. See `WORKER_DEFAULT_BOUND`: the delivered
    # configuration already carries an ORIGIN beside each boundary's seconds,
    # so which of the three answers applies is READ off the same operand
    # `_bound` reads rather than inferred from the shape of the document.
    #
    # THE SEMANTICS ARE UNTOUCHED. `_bound` decides, including its refusal of
    # a Job context that names no usable bound; this calls it first and then
    # describes the operand it must have used. Nothing here changes what any
    # turn runs under, and nothing here can make a turn run at all -- a
    # launch `_bound` refuses still refuses, before any source is named.
    def _resolved_bound(self, seen, boundary, default):
        seconds = self._bound(seen, boundary, default)
        held = (seen or {}).get("job_execution")
        if not isinstance(held, dict):
            source = WORKER_DEFAULT_BOUND
        else:
            limits = held.get("execution_limits") or {}
            one = (limits.get("boundaries") or {}).get(boundary) or {}
            source = _ORIGIN_SELECTION.get(one.get("origin"),
                                           UNSTATED_BOUND_SOURCE)
        return {"seconds_bound": seconds, "seconds_bound_source": source}

    def work(self, seen, declared):
        """Run the frozen task and author the declared proposal.

        `seen` is the validated launch document and `declared` is the manager's
        output declaration list, both handed over by `baton_worker`. Neither is
        second-guessed here: what is declared is what is written to, and the
        worker measures the result afterwards.
        """
        # W110772: WHICH JOB THIS CONTAINER WAS LAUNCHED FOR. The launch
        # document's validated `role` selects the branch; nothing here
        # inspects the filesystem to decide what kind of turn it is.
        # HELD BEFORE ANY BRANCH, because the ceilings belong to the turn
        # rather than to one of its shapes.
        # A DECLARATION LIST IS A LIST, held before anything reads an entry.
        # PRE-EXISTING AND FOUND IN PASSING (W198667 claim199285): the
        # context-receipt scan below indexes each entry, so a `declared` that
        # was a STRING faulted with a `TypeError` out of a generator instead of
        # refusing -- and `test_exactly_one_declared_output_is_honoured` has
        # been asserting a `TaskRefusal` for exactly that operand. The single
        # -output branch further down already refuses every other wrong shape;
        # this is the one that crashed before reaching it.
        if type(declared) is not list:
            raise TaskRefusal(
                f"the manager's output declarations are a list; this is a "
                f"{type(declared).__name__}")
        self._seen = seen
        self._context_pins = None
        self._context_receipt = None
        contextual = self._context_bound()
        selected_declarations = declared
        if contextual is not None:
            import baton_worker
            baton_worker.context_declaration(seen, declared)
            selected_declarations = [one for one in declared if one["name"] != CONTEXT_RECEIPT]
        elif any(one["name"] == CONTEXT_RECEIPT for one in declared):
            import baton_worker
            baton_worker.context_declaration(seen, declared)
        if seen.get("role") == REVIEW_ROLE:
            return self._review(declared)
        if len(selected_declarations) == 1:
            # THE ORIGINAL SINGLE-OUTPUT WORKLOAD, byte-for-byte unchanged.
            one, absent = _one_declaration(selected_declarations), []
        else:
            produce, absent = _selected(selected_declarations, IMPLEMENTATION_OUTPUTS,
                                        "implementation")
            one = produce[0]
        proposal = os.path.join(OUTPUT_ROOT, one["path"])
        # W112029: THE BYTES AS WELL AS THE DOCUMENT, so the ordinary-test
        # observation can name the exact task this turn consumed.
        task, task_bytes = _read_task()
        if contextual is not None and _task_digest(task_bytes) != contextual["task_digest"]:
            raise TaskRefusal("context task bytes disagree with launch")
        scratch = self._scratch()
        # W71917: THE PLAN RUNS, AND IT RUNS IN THE WORKSPACE.
        #
        # What this replaces: the source mount was copied into a directory
        # under the 64 MiB tmpfs and the profile was never consulted at all.
        # Run7 review [P0] -- the profile package composed plans that no
        # component executed, so the ruled read-only-source-to-workspace
        # transition did not happen and a real build could not fit anywhere.
        #
        # `OUTPUT_ROOT` IS THE WORKSPACE. The manager binds one disk-backed
        # manager-created workspace there; the tmpfs keeps only the child
        # ephemera roots below, which is what bounded scratch is for.
        source = os.path.join(INPUT_ROOT, task["source_root"])
        plan = self._checkout(task, source)
        baseline = plan["source_root"]
        line = plan["profile"] == _profiles.checkout.GIT_LINE_PROFILE
        if contextual is not None and not line:
            raise TaskRefusal("context serving requires the private implementation line")
        if line:
            # W105575: THERE IS NOTHING TO COPY. The workspace IS the durable
            # private repository the manager materialized and detached before
            # this container existed, so the candidate is the mounted worktree
            # and the baseline is a COMMIT rather than a second tree on disk.
            #
            # THE EXCLUSIONS ARE WRITTEN FIRST, before anything asks whether
            # the line is clean: the manager's own result root is already
            # sitting in this workspace, and an entry check taken before the
            # reservation would refuse the arrangement it was handed.
            candidate = OUTPUT_ROOT
            reserved = _reserved(declared)
            _reserve(candidate, reserved)
            entry = self._entered(candidate, plan["base"], reserved)
            skip, walk_skip, copied = None, reserved | {VCS_METADATA}, None
        else:
            # WHAT THE PROVIDER EDITS IS A COPY OF THE BASELINE, so the diff
            # has something unmodified to be a diff against. Both live in the
            # workspace: an editable tree on the tmpfs is the ceiling this Work
            # exists to remove.
            candidate = os.path.join(OUTPUT_ROOT, CANDIDATE_NAME)
            skip = VCS_METADATA if plan["profile"] == _profiles.GIT_PROFILE \
                else None
            copied = _copy_tree(baseline, candidate, skip=skip)
            entry, walk_skip = None, None
        what = "the candidate line" if line else "the candidate copy"
        # W85497 review 2026-09-04T14:44:23Z: every predictable child root is
        # created EXCLUSIVELY before the provider runs. The provider owns the
        # candidate turn and must not get a window in which an absent verifier
        # name can be replaced with a link into that candidate.
        environments = self._child_environments(scratch)
        verification_environment, verification_directories = (
            self._pinned_environment(scratch, environments["verification"]))
        try:
            provider = self._provider(task, candidate, scratch,
                                      environments["provider"])
            # THE PROVIDER OWNED THIS TREE, so it is held to the staged tree's
            # own rules before anything reads or copies it. Review [P1]: the
            # source check ran before Claude and nothing ran after, so a link
            # the provider created was dereferenced by the diff and copied as
            # regular bytes into the host-visible proposal -- and the
            # credential mount is one of the things a link can name.
            # THE PROVIDER'S ENDING DECIDES NOTHING ON ITS OWN. What is written
            # is decided by what is ON DISK afterwards, which is why the diff
            # is taken before the disposition is chosen: a provider that
            # exited 0 and changed nothing produced no candidate, and one that
            # exited non-zero after editing left something an operator still
            # has to see.
            # AGAINST THE BASELINE, WHICH IS WHAT THE COPY WAS MADE FROM.
            # For a git profile that is the checkout at the DECLARED BASE, so
            # the patch is against the revision the assignment named rather
            # than against whatever the mount happened to be on.
            if line:
                # W202663 D10: THE SUBJECT IS THE DELTA. The committed
                # checkout is manager-delivered line custody -- the real
                # repository, with its own committed links and its own size
                # -- and the provider answers for what it CHANGED, measured
                # by this adapter's own no-follow walk against the pinned
                # baseline tree, never by Git's opinion of what changed.
                self._unmoved(candidate, entry)
                written, measured, removed, collection = self._line_delta(
                    candidate, what)
                patch = bool(written) or bool(removed)
            else:
                written = _checked_tree(candidate, what=what, skip=walk_skip)
                removed = None
                patch, measured = _diff(baseline, candidate, written, skip=skip)
            verification = (self._verify(
                task, candidate, verification_environment,
                verification_directories)
                            if provider["ok"] and patch else None)
            # THE VERIFICATION COMMAND IS THE PAYLOAD'S, and it ran between
            # the measurement and the publication. Review [P1]: proving the
            # paths were still regular held their TYPE and not their BYTES, so
            # a command that overwrote a checked file in place published
            # contents the patch never described. What is proved here is the
            # measurement itself.
            if line:
                self._line_revalidated(candidate, measured, removed, what)
            else:
                _revalidated(candidate, written, measured, what=what,
                             skip=walk_skip)
            disposition, why = _disposition(provider, patch, verification)
            if line:
                # THE COMMIT HAPPENS WHATEVER THE DISPOSITION IS, and that is
                # deliberate. The manager freezes an immutable checkpoint over
                # this line after every ending, and its profile refuses a dirty
                # worktree -- so a turn that produced changes and declined to
                # commit them would leave the line unfreezable and the Work
                # stuck. What the disposition decides is whether anything is
                # PUBLISHED, not whether the private history is honest.
                head = self._commit(candidate, task, entry, measured,
                                    removed=removed) if patch else None
                changed = self._changed(candidate, plan["base"], head)
                self._publish_line(proposal, candidate, plan["base"], head,
                                   verification,
                                   result={"schema": LINE_RESULT_SCHEMA,
                                      "task_id": task["task_id"],
                                      "disposition": disposition,
                                      "why": why,
                                      # W202663 D10 (owner 12:47:17Z): what
                                      # the collection EXCLUDED, disclosed
                                      # to the human integrator; absent on
                                      # a turn with nothing excluded.
                                      "collection": collection,
                                      "changed_paths": changed,
                                      "base": plan["base"],
                                      "entry_head": entry,
                                      "head": head,
                                      "provider": {
                                          "status": provider["status"],
                                          "failure_reason":
                                              provider.get("failure_reason"),
                                          **_bound_member(provider),
                                          **_diagnostic_member(provider)},
                                      "verification": (
                                          {"status": verification["status"],
                                           "argv": list(task["verification"])}
                                          if verification is not None
                                          else None)})
            else:
                head, changed = None, sorted(patch)
                _publish(proposal, candidate, written, measured, patch,
                         verification,
                         result={"schema": "baton.dogfood-proposal/1",
                                 "task_id": task["task_id"],
                                 "disposition": disposition,
                                 "why": why,
                                 "changed_paths": changed,
                                 "source_entries": copied,
                                 # W55360: the mapped word, or null on a clean
                                 # turn. W71879 additionally permits typed HTTP
                                 # status and one exact static explanation in
                                 # diagnostic; arbitrary child text stays out.
                                 "provider": {
                                     "status": provider["status"],
                                     "failure_reason":
                                         provider.get("failure_reason"),
                                     **_bound_member(provider),
                                     **_diagnostic_member(provider)},
                                 "verification": (
                                     {"status": verification["status"],
                                      "argv": list(task["verification"])}
                                     if verification is not None else None)})
        finally:
            for _name, descriptor in verification_directories:
                os.close(descriptor)
        receipt_output = []
        if contextual is not None:
            if disposition == "candidate" and (self._context_receipt is None or not self._context_receipt["complete"]):
                raise TaskRefusal("healthy context implementation requires measured receipt")
            self._publish_context_receipt()
            receipt_output = [{"name": CONTEXT_RECEIPT, "status": "present", "result_metadata": {}}]
        recap = (f"{disposition}: {why}"
                 f" ({len(changed)} changed path(s))")[:MAX_RECAP]
        return {"disposition": ("completed" if disposition == "candidate"
                                else "unable"),
                "outputs": [{"name": one["name"], "status": "present",
                             # W112029: THE OBSERVATION RIDES WITH THE CLAIM,
                             # because both are facts about the same published
                             # candidate and admission resolves them from the
                             # same frozen proposal output. A turn that
                             # published nothing carries neither: there is no
                             # candidate for either to be about.
                             "result_metadata": (
                                 {**_claim(plan["base"], head, recap),
                                  **_ordinary_tests(task, task_bytes,
                                                    verification,
                                                    plan["base"], head)}
                                 if head is not None else {})}]
                           + receipt_output + _absent(absent),
                "recap": recap}

    # -- W110772: the review turn --------------------------------------------

    def _review(self, declared):
        """Assess a frozen checkpoint and author a findings and a logs output.

        WHAT THIS DOES NOT DO, and each line is something the implementation
        branch above does that a review must not: it does not check out, copy,
        reserve, edit, commit, bundle or verify anything, and it never writes
        into the source it was given. The manager mounted the line READ-ONLY
        for exactly that reason and this reads it in place.

        THE OBSERVATION BRACKETS THE PROVIDER TURN. The head and tree are read
        before the provider runs and again afterwards, and a difference is a
        refusal rather than a disposition: a review of a tree that moved under
        it is a review of nothing in particular, and the manager would compare
        the second reading against a checkpoint frozen over the first.

        THE PROVIDER'S ENDING DECIDES NOTHING ON ITS OWN, which is the same
        rule the implementation branch keeps for the same reason. What decides
        the verdict is a report this adapter validated; a provider that exited
        0 and wrote nothing reviewed nothing, and one that exited non-zero
        after writing a valid report still did not earn a decision, because a
        turn that failed is a turn whose account is incomplete.
        """
        produce, absent = _selected(declared, REVIEW_OUTPUTS, "review")
        findings_output, logs_output = produce
        findings = os.path.join(OUTPUT_ROOT, findings_output["path"])
        logs = os.path.join(OUTPUT_ROOT, logs_output["path"])
        task = _task()
        # THE FIRST REVIEW WORKLOAD IS THE PREPARED LINE, EXPLICITLY. Another
        # profile is refused rather than attempted: what a review reads is a
        # frozen checkpoint on a private Git line, and there is no second
        # arrangement this adapter knows how to observe a base, head and tree
        # over.
        if task["source_profile"] != _profiles.checkout.GIT_LINE_PROFILE:
            raise TaskRefusal(
                f"this review workload reads the "
                f"{_profiles.checkout.GIT_LINE_PROFILE!r} profile and this "
                f"task names {task['source_profile']!r}; another review "
                f"profile is a workload this adapter does not have")
        source = os.path.join(INPUT_ROOT, task["source_root"])
        observed = self._observed(source, task)
        scratch = self._scratch()
        room = self._new_directory(scratch, REVIEW_ROOM)
        # A FRESH DESTINATION, PROVED. A previous turn's report standing in for
        # this one would be a verdict about a checkpoint nobody looked at, and
        # `_new_directory` creates exclusively -- so this is the second half of
        # that guarantee rather than a repetition of it.
        if os.path.lexists(os.path.join(room, REVIEW_REPORT)):
            raise TaskRefusal(
                f"the review report destination already exists; a report is "
                f"authored by this turn and never inherited")
        environments = self._child_environments(scratch)
        provider = self._provider(
            task, room, scratch, environments["provider"],
            prompt=_review_prompt(task, source, REVIEW_REPORT))
        report = _review_report(room) if provider["ok"] else None
        # THE SOURCE IS RE-READ AFTER THE TURN, whatever the turn did.
        again = self._observed(source, task)
        if again != observed:
            raise TaskRefusal(
                "the reviewed line moved while it was being reviewed; a "
                "verdict is about the exact objects this turn observed")
        _made(logs)
        _written(os.path.join(logs, REVIEW_LOG),
                 json.dumps({"schema": REVIEW_LOG_SCHEMA,
                             "task_id": task["task_id"],
                             "verdict": report["verdict"] if report else None,
                             "reviewed": observed,
                             "report_bytes": (len(report["findings"])
                                              if report else 0),
                             "provider": {
                                 "status": provider["status"],
                                 "failure_reason":
                                     provider.get("failure_reason"),
                                 **_bound_member(provider),
                                 **_diagnostic_member(provider)},
                             "verification": None},
                            indent=1, sort_keys=True) + "\n")
        if report is None:
            # NO CLAIM ON ANY OUTPUT. The manager's reader finds none and
            # holds, which is what an unanswered review is worth. Answering
            # findings absent rather than empty is the same statement made in
            # the manager's own vocabulary.
            return {"disposition": "unable",
                    "outputs": [{"name": findings_output["name"],
                                 "status": "missing-optional",
                                 "result_metadata": {}},
                                {"name": logs_output["name"],
                                 "status": "present", "result_metadata": {}}]
                            + _absent(absent),
                    "recap": (f"unable: the review produced no usable report "
                              f"({provider.get('failure_reason') or 'absent'})"
                              )[:MAX_RECAP]}
        _made(findings)
        _written(os.path.join(findings, REVIEW_RESULT),
                 json.dumps(report, indent=1, sort_keys=True) + "\n")
        _written(os.path.join(findings, REVIEW_FINDINGS),
                 report["findings"] + ("" if report["findings"].endswith("\n")
                                       else "\n"))
        return {"disposition": "completed",
                "outputs": [{"name": findings_output["name"],
                             "status": "present",
                             "result_metadata": _review_claim(
                                 report["verdict"], observed)},
                            {"name": logs_output["name"], "status": "present",
                             "result_metadata": {}}] + _absent(absent),
                "recap": (f"{report['verdict']}: reviewed "
                          f"{observed['base'][:12]}..{observed['head'][:12]}"
                          )[:MAX_RECAP]}

    def _observed(self, source, task):
        """The three objects this turn is reviewing, read from the line.

        `head` AND `tree` ARE OBSERVED AND `base` IS PROVED. A repository
        cannot say which of its commits a checkpoint was declared against --
        the checkpoint profile takes that as an operand -- so the base is the
        one the frozen task names, and what this establishes is that the line
        actually contains it. Naming a base the mounted line has never heard of
        is a refusal here; naming one the checkpoint does not record is a
        refusal at the manager, which is where a claim about the checkpoint
        belongs.
        """
        declared = task["declared_base"]
        if declared is None:
            raise TaskRefusal(
                "this review task declares no base; a verdict is about a "
                "change from one revision to another and there is no first one")
        # `^{commit}` RATHER THAN THE BARE NAME. `rev-parse --verify` accepts
        # a well-formed forty-character object name as SYNTAX and echoes it
        # back whether or not the repository holds the object, so a base this
        # line has never seen would have verified itself. The peel is what
        # makes this a question about the line rather than about the spelling.
        base = self._revision(source, f"{declared}^{{commit}}",
                              "reviewed base")
        if base != declared:
            raise TaskRefusal(
                f"this review task declares base {declared!r} and the line "
                f"resolves it to {base!r}; a review names the object it read")
        return {"base": base,
                "head": self._revision(source, "HEAD", "reviewed head"),
                "tree": self._revision(source, "HEAD^{tree}",
                                       "reviewed tree")}

    # -- the private half ----------------------------------------------------

    def _checkout(self, task, source):
        """Turn the read-only mount into somewhere this worker may work.

        W71917. THE PLAN IS COMPOSED ELSEWHERE AND RUN HERE, which is the
        separation the profile package exists for: it never starts a process
        and imports no capability to, and this is the party that owns the
        failure of every command it named.

        EVERY STEP'S OUTPUT IS COMPARED WHEN THE PLAN SAYS SO. Run7 review
        [P1]: exit status alone cannot express "the worktree is at this exact
        commit", because the command that reports which commit it is on
        succeeds whatever the answer. A step carrying an expectation is
        checked against it, and a mismatch is a refusal rather than a
        disposition -- a worker that edited the wrong revision and said so
        afterwards would already have written the wrong patch.
        """
        try:
            plan = _profiles.checkout_plan(
                source, OUTPUT_ROOT, profile=task["source_profile"],
                declared=task["declared_base"])
        except _profiles.ProfileRefusal as refusal:
            raise TaskRefusal(
                f"this assignment's source profile cannot be planned: "
                f"{refusal}") from None
        for step in plan["steps"]:
            argv = list(step["argv"])
            try:
                answer = self._run(argv, capture_output=True, text=True,
                                   timeout=CHECKOUT_SECONDS)
            except OSError as failure:
                raise TaskRefusal(
                    f"the source checkout could not run {argv[0]!r} "
                    f"({type(failure).__name__})") from None
            except subprocess.TimeoutExpired:
                raise TaskRefusal(
                    f"the source checkout step {argv[0]!r} did not finish "
                    f"within {CHECKOUT_SECONDS} seconds") from None
            if answer.returncode != 0:
                # THE STEP'S OWN OUTPUT IS NOT REPRODUCED. It is composed from
                # a tree this worker was handed, which is the same reason
                # `verification.txt` carries no child output.
                raise TaskRefusal(
                    f"the source checkout step {argv[0]!r} failed with "
                    f"status {answer.returncode}")
            expect = step["expect_stdout"]
            if expect is not None \
                    and (answer.stdout or "").strip() != expect:
                raise TaskRefusal(
                    "the checkout is not at the base this assignment "
                    "declared; the source that was mounted contains that "
                    "commit or the step would have failed, so what differs "
                    "is which revision the worktree ended up on")
        return plan

    # -- W105575: the prepared private line ----------------------------------

    def _git(self, repository, *arguments, what, binary=False, allow=(0,),
             stdin=None):
        """One closed Git vector against the line, run through the same seam.

        THE OVERRIDES ARE COMPOSED, NEVER CONFIGURED. `safe.directory` is here
        because the repository is the manager's and this process is uid 65532;
        a configuration file written to make that go away would outlive the
        vector and apply to repositories nobody reviewed.

        `allow` EXISTS FOR THE ONE QUESTION GIT ANSWERS WITH A STATUS. An
        ancestry test is not an error when the answer is "no", and a helper
        that could not tell those apart would turn a fact into a failure.

        THE HOOK PATH IS ON EVERY VECTOR, not only on the commit. W105575
        candidate review 2026-09-07: `post-index-change` runs on an INDEX
        WRITE, so staging and even a status refresh reach a hook that a
        commit-only override never covers -- and the hooks directory belongs to
        a repository this worker did not create. One composed prefix rather
        than a policy applied at each call site, because a per-site rule is a
        rule with a gap in it the moment somebody adds a site.
        """
        argv = ["git", "-c", f"safe.directory={_line_path(repository)}",
                "-c", f"core.hooksPath={NO_HOOKS}",
                "-C", repository, *arguments]
        try:
            answer = self._run(argv, capture_output=True, text=not binary,
                               timeout=CHECKOUT_SECONDS, input=stdin) \
                if stdin is not None else \
                self._run(argv, capture_output=True, text=not binary,
                          timeout=CHECKOUT_SECONDS)
        except OSError as failure:
            raise TaskRefusal(
                f"the private line could not run {what} "
                f"({type(failure).__name__}); this profile is handed a "
                f"repository and never creates or repairs one") from None
        except subprocess.TimeoutExpired:
            raise TaskRefusal(
                f"the private line's {what} did not finish within "
                f"{CHECKOUT_SECONDS} seconds") from None
        if answer.returncode not in allow:
            raise TaskRefusal(
                f"the private line's {what} failed with status "
                f"{answer.returncode}")
        return answer

    def _revision(self, repository, revision, what):
        """One object name this line actually resolves, held to its grammar."""
        found = self._git(repository, "rev-parse", "--verify", revision,
                          what=what).stdout.strip()
        try:
            return _profiles.check_declared_base(found)
        except _profiles.ProfileRefusal as refusal:
            raise TaskRefusal(f"the private line's {what} is not one object "
                              f"name: {refusal}") from None

    def _pending(self, repository):
        """What the worktree is carrying that its HEAD commit is not.

        `--untracked-files=all` so a whole new directory is not one line, and
        `-z` so a path with a newline in it cannot forge an entry. Reserved
        names do not appear here at all: they are ignored, which is what
        `_reserve` established before this was ever asked.
        """
        return self._git(repository, "status", "--porcelain=v1", "-z",
                         "--untracked-files=all",
                         what="worktree status").stdout

    def _entered(self, repository, base, reserved):
        """The head this turn was ADMITTED at, proved rather than declared.

        TWO FACTS, AND THE WHOLE CORRECTION ROUND DEPENDS ON KEEPING THEM
        APART. `base` is the immutable revision this Work publishes against --
        the line's declared base, unchanged for every checkpoint the manager
        ever freezes. The ENTRY HEAD is where the line actually is right now:
        the base itself on the first turn, and the previous correction's
        checkpoint on every turn after that.

        An entry check that demanded `HEAD == base` would therefore reject the
        second round, and a claim that reported the entry head AS the base
        would publish a proposal whose source base is not the canonical target.
        So this proves the relationship instead of either equality: the line is
        clean, and the base is an ancestor of where it is.

        NOTHING TELLS THIS WORKER THE ENTRY HEAD. The manager's writer grant
        already validated it against the checkpoint it admitted; what is left
        for the worker is to confirm the line it received still descends from
        the revision it was told to build on, and to remember where it started
        so its own commit can be proved to continue it.
        """
        if not os.path.isdir(os.path.join(repository, VCS_METADATA)):
            raise TaskRefusal(
                f"this assignment declares a prepared development line and "
                f"{repository} is not a repository; a line is materialized by "
                f"the manager before the runtime starts and is never cloned, "
                f"reset or rebuilt here")
        # AN IGNORE RULE CANNOT UNTRACK ANYTHING, which is why this is a
        # refusal and not a repair. A line whose own history carries a file at
        # one of the reserved names would be dirty the moment the worker or
        # the manager wrote there, and no reservation this adapter makes can
        # change that -- so the arrangement is rejected while it is still
        # somebody's to correct.
        tracked = _paths(self._git(
            repository, "ls-files", "-z", "--", *sorted(reserved),
            what="reserved-name inventory").stdout)
        if tracked:
            raise TaskRefusal(
                f"the prepared development line already tracks "
                f"{tracked[0]}, which this workload reserves for the "
                f"manager's or the worker's own material; an ignore rule "
                f"cannot remove tracked content from a candidate")
        standing = self._pending(repository)
        if standing:
            raise TaskRefusal(
                "the prepared development line already carries uncommitted "
                "changes; this turn commits exactly what it produces, and a "
                "worktree that was handed over dirty makes that account "
                "impossible to take")
        entry = self._revision(repository, "HEAD", "admitted entry head")
        if entry != base:
            # THE BASE HAS TO BE IN THIS REPOSITORY BEFORE ANCESTRY MEANS
            # ANYTHING. An object the line does not hold makes the ancestry
            # question unanswerable rather than false, and the two deserve the
            # same refusal here for one reason: neither is a line this
            # assignment may publish against.
            if self._git(repository, "rev-parse", "--verify", "--quiet",
                         f"{base}^{{commit}}", what="declared base lookup",
                         allow=(0, 1)).returncode != 0 \
                    or self._git(repository, "merge-base", "--is-ancestor",
                                 base, entry, what="entry ancestry",
                                 allow=(0, 1)).returncode != 0:
                raise TaskRefusal(
                    "the prepared development line is not the base this "
                    "assignment publishes against, nor a descendant of it; a "
                    "correction continues one private history and this "
                    "worktree is on another")
        return entry

    def _unmoved(self, repository, entry):
        """The line is still where this turn was admitted, and nobody else
        wrote history into it.

        ASKED WHETHER OR NOT THE WORKTREE IS DIRTY, which is the correction
        this method exists for. A provider that COMMITS its own work leaves a
        clean worktree and an advanced head, so a check reached only on the way
        to committing would have adopted that history and reported it as this
        adapter's own account. Exactly one commit per turn is this module's,
        and that has to be true before anything is measured or published.
        """
        standing = self._revision(repository, "HEAD", "post-provider head")
        if standing != entry:
            raise TaskRefusal(
                "the private line's HEAD moved during the provider turn; this "
                "adapter authors exactly one commit per turn, and a history "
                "it did not write is not one it can give an account of")

    def _commit(self, repository, task, entry, measured, removed=None):
        """ONE worker-authored commit, and the proof that it is this candidate.

        THE PROVIDER DOES NOT COMMIT, and `_unmoved` has already proved it --
        before the turn was measured, and whether or not the worktree was left
        dirty. This is the act, not the check.

        HOOKS ARE OFF BY PATH, NOT BY `--no-verify`. W105575 review 2026-09-07:
        that flag leaves `prepare-commit-msg` running, so it never was the
        no-hook guarantee it reads as. The override is composed by `_git` onto
        EVERY vector rather than onto this one, because the index write that
        stages the candidate reaches a hook of its own.

        THE MESSAGE IS THIS MODULE'S OWN WORDS. Nothing a child wrote is
        interpolated into it, for the reason `verification.txt` carries no
        child output: the provider holds the attempt's bearer.
        """
        self._git(repository, "add", "--all", "--", ".", what="candidate "
                  "staging")
        self._git(repository,
                  "-c", f"user.name={COMMIT_NAME}",
                  "-c", f"user.email={COMMIT_EMAIL}",
                  "commit", "--no-gpg-sign", "--allow-empty-message",
                  "--message", f"baton candidate: {task['task_id']}",
                  what="candidate commit")
        head = self._revision(repository, "HEAD", "committed head")
        if self._revision(repository, "HEAD^", "committed parent") != entry:
            raise TaskRefusal(
                "the commit this turn authored does not continue the head it "
                "was admitted at")
        self._identical(repository, entry, head, measured, removed=removed)
        return head

    def _identical(self, repository, entry, head, measured, removed=None):
        """The COMMITTED change and the MEASURED change, proved to be one.

        W105575 review 2026-09-07. An empty status is a cleanliness gate and
        not this proof: a clean filter makes the committed blob differ from the
        bytes on disk while every status stays quiet, so the equality has to be
        taken over the objects themselves.

        AND IT IS PROVED IN BOTH DIRECTIONS. W105575 candidate review
        2026-09-07 found the hole that one direction leaves: a path Git IGNORES
        is not staged, does not appear in any status, and never enters the
        change set -- so a candidate whose verification passed BECAUSE that
        file was on disk committed a tree without it, and a recipient resolving
        the published head received something that was never verified. Reading
        the committed change and checking only its members against the measured
        tree cannot see that, because the missing path is in neither.

        So the equality that is actually taken is the one that matters to a
        recipient: THE COMMITTED TREE, RESTRICTED TO CANDIDATE MATERIAL, IS THE
        MEASURED TREE. The measured side comes from a filesystem walk that
        knows nothing about Git and cannot be talked out of seeing a file; an
        unrepresentable candidate is REFUSED rather than published, because the
        alternative is this adapter overriding a repository's own rules about
        what belongs in it.

        THREE MORE THINGS, AND A DELETION IS THE ONE WITH NO BLOB. Added and
        modified paths are compared byte for byte against what this adapter
        measured; a deleted path is proved ABSENT from that measurement, which
        is the only equality a removal has. Anything else Git can report --
        a type change, a rename, a submodule -- is refused rather than
        interpreted, because this adapter publishes an account of regular
        candidate bytes and nothing else.

        AND A TRANSFORMING FILTER IS REFUSED OUTRIGHT. `check-attr` is asked
        about exactly the paths in this change: an attribute that rewrites
        content on the way into the object store breaks the equivalence
        between what was verified and what was committed, and no comparison
        performed afterwards can restore it.
        """
        if self._pending(repository):
            raise TaskRefusal(
                "the private line is still not clean after its own commit; "
                "the worktree, the index and the new commit have to be one "
                "tree before anything is published")
        changed = _statuses(self._git(
            repository, "diff", "--name-status", "-z", "--no-renames",
            entry, head, what="committed change").stdout)
        for mark, relative in changed:
            if mark not in ("A", "M", "D"):
                raise TaskRefusal(
                    f"the commit carries a {mark!r} change at {relative}, "
                    f"which is not an added, modified or deleted regular path")
            _under(relative)
        _filterless(self._git(
            repository, "check-attr", "-z", "filter", "--",
            *[relative for _mark, relative in changed],
            what="candidate attribute inventory").stdout if changed else "")
        for mark, relative in changed:
            if mark == "D":
                if relative in measured:
                    raise TaskRefusal(
                        f"the commit deletes {relative} and this adapter "
                        f"measured bytes there; the account and the commit "
                        f"disagree about what the candidate contains")
                continue
            if relative not in measured:
                raise TaskRefusal(
                    f"the commit carries {relative} and this adapter measured "
                    f"nothing there; every committed byte is one this turn "
                    f"walked, bounded and read")
        if removed is None:
            self._representable(repository, head, measured)
        else:
            # W202663 D10: THE DELTA-SCOPED HALF OF THE SAME CONTRACT. The
            # published head's whole tree is the pinned baseline plus this
            # turn's change, so representability is proved over the change
            # -- both directions on both sets, the ignored-addition refusal
            # exactly where it always was -- and the committed MODE of every
            # measured path is proved regular from the tree itself, because
            # `_identical_bytes`' blob-kind proof cannot tell a file from a
            # link.
            self._representable_delta(changed, measured, removed)
            self._measured_modes(repository, head, measured)
        self._identical_bytes(repository, head, measured)
        return changed

    def _identical_bytes(self, repository, head, measured):
        """EVERY measured path's bytes against its committed blob, not only
        the ones Git said had changed.

        W105575 correction review 2026-09-07, and this is the third time one
        version of the same mistake has been caught, which is the reason the
        comparison finally does not consult Git's opinion at all. Equal PATH
        SETS still permit different BYTES: an index entry marked
        assume-unchanged makes a real edit invisible to status and to every
        diff, so the file is in both accounts, is absent from the reported
        change, and its committed blob is the ORIGINAL while the verification
        that passed read the new one. A recipient resolving the published head
        then receives something nobody verified.

        The lesson is the one the previous two rounds also taught and I kept
        re-learning too narrowly: a proof that asks Git WHICH paths matter
        inherits every reason Git might answer wrongly. So the subject here is
        the whole measured tree, one path at a time, and the only thing Git is
        asked for is the bytes it stored.

        ONE BATCH RATHER THAN ONE PROCESS PER FILE, bounded by the same ceiling
        `_checked_tree` already applies to the candidate. `-Z` so a path
        carrying any byte at all is still one request.
        """
        if not measured:
            return
        order = sorted(measured)
        request = b"".join(f"{head}:{one}".encode("utf-8") + b"\x00"
                           for one in order)
        raw = self._git(repository, "cat-file", "--batch", "-Z",
                        what="committed blob inventory", binary=True,
                        stdin=request).stdout
        offset = 0
        for relative in order:
            oid, kind, size, offset = _batch_header(raw, offset, relative)
            body = raw[offset:offset + size]
            if len(body) != size:
                raise TaskRefusal(
                    f"the committed blob for {relative} ended early")
            offset += size
            if raw[offset:offset + 1] not in (b"\n", b"\x00"):
                raise TaskRefusal(
                    f"the committed blob for {relative} is not delimited")
            offset += 1
            if kind != "blob":
                raise TaskRefusal(
                    f"the committed tree holds a {kind} at {relative}; this "
                    f"adapter publishes an account of regular candidate files")
            if _bytes_digest(body) != measured[relative]:
                raise TaskRefusal(
                    f"the bytes committed at {relative} are not the bytes "
                    f"this adapter measured and verified there; the object "
                    f"is {oid}")
        if offset != len(raw):
            raise TaskRefusal(
                "the committed blob inventory carries more records than this "
                "turn asked for")

    def _representable(self, repository, head, measured):
        """The committed tree and the measured tree, path for path.

        THE MEASURED SIDE IS THE INDEPENDENT ONE. It came from `_checked_tree`
        walking the filesystem, which is why this comparison can catch what
        Git's own reported change set cannot: an ignored addition is invisible
        to status, to staging and to every diff, and is sitting in the walk.

        `ls-tree -r` RATHER THAN A DIFF, for the same reason. A diff answers
        what CHANGED between two commits and this question is about what the
        published tree CONTAINS -- and the file that went missing never changed
        anything, because it was never in either commit.

        THE MODE IS CHECKED HERE TOO, and it is the committed half of the walk's
        own type boundary: `_checked_tree` refuses a link or a device in the
        worktree, and a gitlink or a symlink entry in the tree is the same
        refusal on the side a recipient actually resolves.
        """
        committed = {}
        for mode, relative in _tree_entries(self._git(
                repository, "ls-tree", "-r", "-z", head,
                what="committed tree inventory").stdout):
            if mode not in TREE_FILE_MODES:
                raise TaskRefusal(
                    f"the committed tree carries a {mode} entry at "
                    f"{relative}; this adapter publishes an account of regular "
                    f"candidate files and nothing else")
            committed[relative] = mode
        missing = sorted(set(measured) - set(committed))
        if missing:
            raise TaskRefusal(
                f"the candidate carries {missing[0]} and the commit does not; "
                f"a path this repository ignores is still material the turn "
                f"was measured and verified over, and a proposal whose own "
                f"head cannot carry it is not one this adapter will publish")
        extra = sorted(set(committed) - set(measured))
        if extra:
            raise TaskRefusal(
                f"the commit carries {extra[0]} and the candidate does not; "
                f"the published tree and the tree this turn measured are one "
                f"tree or this account is not about what was verified")

    def _line_status(self, repository, *, ignored=False):
        """One status listing, parsed closed, as the collection inventory.

        W202663 D10, owner 2026-09-21T12:47:17Z: the owner is the INTEGRATOR
        and this profile collects a faithful proposal for a human; it does
        not re-derive the repository's state behind Git's back. The
        superseded broad regime walked and hashed the whole checkout to
        catch what an index trick can hide from status; the ruling retires
        that guarantee by name, and what remains is honest: the delivered
        changes are still proved byte-for-byte (`_identical_bytes`), and a
        path status cannot see is neither measured nor delivered.

        `-z` so any byte in a path is data; a record that does not parse,
        and a rename/copy record (impossible for the unstaged worktree this
        adapter measures, so its appearance means something else composed
        the index), refuse rather than being interpreted.
        """
        argv = ["status", "--porcelain", "-z", "--untracked-files=all"]
        if ignored:
            argv.append("--ignored=matching")
        raw = self._git(repository, *argv, what="collection inventory").stdout
        found = []
        for record in raw.split("\0"):
            if not record:
                continue
            if len(record) < 4 or record[2] != " ":
                raise TaskRefusal(
                    "the collection inventory carries a record this "
                    "adapter cannot read")
            marks, relative = record[:2], record[3:]
            if "R" in marks or "C" in marks:
                raise TaskRefusal(
                    f"the collection inventory reports a rename or copy at "
                    f"{relative}; this adapter measures an unstaged "
                    f"worktree, and a staged rename is somebody else's act")
            found.append((marks, relative))
            if len(found) > MAX_LINE_STATUS_ENTRIES:
                raise TaskRefusal(
                    f"the collection inventory exceeds this adapter's bound "
                    f"of {MAX_LINE_STATUS_ENTRIES} changed entries; actual "
                    f"collection is bounded, and a change list this large "
                    f"is not one turn's proposal")
        return found

    def _line_delta(self, candidate, what):
        """The turn's changes, collected -- not the repository, judged.

        W202663 D10 as narrowed by owner 2026-09-21T12:47:17Z. Each listed
        path is one of exactly four honest things:

          * a REGULAR FILE: measured through the anchored no-follow read,
            with the payload ceilings applied to exactly this changed set;
          * a LINK: refused. A committed link the turn left alone never
            appears in this inventory, so a listed link is authored,
            retargeted or replacing -- and a delivered link is how a
            recipient's checkout reaches credential and external files.
            This is the retained no-follow/external-file protection, and
            it is the only per-entry veto left;
          * a SPECIAL FILE: excluded and DISCLOSED, never read -- Git
            cannot deliver it and a fifo would block the reader;
          * ABSENT: a deletion, collected as its own set.

        Ignored files never enter this inventory at all, which is what
        makes an unrelated ignored file STRUCTURALLY not a veto; a second
        listing feeds the DISCLOSURE, so the human integrator is told what
        the collection excluded and that verification ran over a worktree
        that contained it.
        """
        measured = {}
        removed = []
        specials = []
        payload_entries, payload_bytes = 0, 0
        for marks, relative in self._line_status(candidate):
            _under(relative)
            place = os.path.join(candidate, relative)
            try:
                held = os.lstat(place)
            except OSError:
                removed.append(relative)
                continue
            if stat.S_ISLNK(held.st_mode):
                raise TaskRefusal(
                    f"{what} carries a link at {relative} among its "
                    f"changes; this adapter neither authors nor alters "
                    f"links, and a delivered link is how a recipient "
                    f"reaches credential and external files")
            if not stat.S_ISREG(held.st_mode):
                specials.append(relative)
                continue
            payload_entries += 1
            payload_bytes += held.st_size
            _bounded(payload_entries, payload_bytes, what)
            measured[relative] = _bytes_digest(
                _read_under(candidate, relative, what))
        ignored = [relative for marks, relative
                   in self._line_status(candidate, ignored=True)
                   if marks == "!!"]
        disclosure = None
        if ignored or specials:
            disclosure = {
                "excluded_ignored": sorted(ignored)[:MAX_COLLECTION_DISCLOSED],
                "excluded_ignored_count": len(ignored),
                "excluded_special": sorted(specials)[:MAX_COLLECTION_DISCLOSED],
                "excluded_special_count": len(specials),
                "note": "these worktree paths were present while the "
                        "task's verification ran and are NOT part of the "
                        "delivered proposal; whether the verification "
                        "relied on any of them is the integrator's "
                        "question, disclosed rather than adjudicated here"}
        return sorted(measured), measured, sorted(removed), disclosure

    def _line_revalidated(self, candidate, measured, removed, what):
        """The collected delta, PROVED UNCHANGED, after provider code ran.

        The same protection `_revalidated` gives the copy profile, over
        the collected set: every measured path still carries its measured
        bytes and every collected deletion is still a deletion. What
        verification ADDED is decided at the commit, exactly as before:
        unignored, it reaches the committed change and `_identical`
        refuses it by name; ignored, it is never staged, never delivered,
        and joins the disclosure's subject matter.
        """
        for relative, digest in measured.items():
            if _bytes_digest(_read_under(candidate, relative, what)) \
                    != digest:
                raise TaskRefusal(
                    f"{what} changed at {relative} after its own "
                    f"verification command ran; the proposal's patch "
                    f"describes the bytes this adapter measured, and a "
                    f"candidate whose contents no longer match that "
                    f"account is not one to publish")
        for relative in removed:
            if os.path.lexists(os.path.join(candidate, relative)):
                raise TaskRefusal(
                    f"{what}'s deletion of {relative} was undone after its "
                    f"own verification command ran; the account and the "
                    f"tree disagree about what this turn removed")

    def _representable_delta(self, changed, measured, removed):
        """The committed change and the measured change are ONE change.

        The delta-scoped half of `_representable`'s contract, both
        directions on both sets. The ignored-addition protection lands
        exactly where it always did: a measured path Git quietly declines
        to stage is missing from the committed change, and the refusal
        names it rather than publishing a head that cannot carry it.
        """
        touched = {relative for mark, relative in changed
                   if mark in ("A", "M")}
        deletions = {relative for mark, relative in changed if mark == "D"}
        missing = sorted(set(measured) - touched)
        if missing:
            # NOT an ignored-file veto: an ignored path never enters the
            # inventory, so a measured path the commit cannot carry means
            # the delivered change set and the verified one diverged --
            # an embedded repository, an attribute, an index state this
            # adapter did not compose. Delivered and verified are one set
            # or nothing is delivered.
            raise TaskRefusal(
                f"the commit does not carry {missing[0]}, which this turn "
                f"measured and verified; the delivered changes and the "
                f"verified ones are one set or this account is not about "
                f"what was verified")
        extra = sorted(touched - set(measured))
        if extra:
            raise TaskRefusal(
                f"the commit carries {extra[0]} and this adapter measured "
                f"nothing there; every committed byte is one this turn "
                f"walked, bounded and read")
        if deletions != set(removed):
            first = sorted(deletions.symmetric_difference(removed))[0]
            raise TaskRefusal(
                f"the commit and this adapter's inventory disagree about "
                f"the removal of {first}; the published deletions and the "
                f"measured ones are one set or this account is not about "
                f"what was verified")

    def _measured_modes(self, repository, head, measured):
        """Every measured path's COMMITTED mode is a regular file's.

        `_identical_bytes` proves the object KIND is a blob, and a
        symlink's target is a blob too -- so the mode is asked of the tree
        itself, in bounded batches over exactly the measured set, which is
        the committed half of the walk's own type boundary scoped to what
        this turn actually publishes.
        """
        order = sorted(measured)
        for start in range(0, len(order), 500):
            for mode, relative in _tree_entries(self._git(
                    repository, "ls-tree", "-z", head, "--",
                    *order[start:start + 500],
                    what="published mode inventory").stdout):
                if mode not in TREE_FILE_MODES:
                    raise TaskRefusal(
                        f"the committed tree carries a {mode} entry at "
                        f"{relative}; this adapter publishes an account of "
                        f"regular candidate files and nothing else")

    def _changed(self, repository, base, head):
        """The paths this proposal changes, CUMULATIVELY from the base.

        FROM THE BASE AND NOT FROM THE ENTRY HEAD, because a proposal is
        offered against the canonical target rather than against the previous
        correction round. On the first turn the two ranges are the same; on
        every later one this is the whole of what the reviewer and the
        integrator are being asked to take.
        """
        if head is None:
            return []
        return sorted(_paths(self._git(
            repository, "diff", "--name-only", "-z", "--no-renames",
            f"{base}..{head}", what="proposed path inventory").stdout))

    def _publish_line(self, proposal, repository, base, head, verification,
                      result):
        """The declared tree for a prepared line: a patch, a transcript, a
        record, and the objects.

        NO CANDIDATE TREE. That is the whole difference from `_publish`, and it
        is a removal rather than a substitution: the candidate is a commit on a
        durable private line now, so a copy of its files beside it would be a
        second account of the same bytes for somebody to have to reconcile.

        THE BUNDLE IS CREATED LAST AND ONLY WHEN THERE IS A HEAD, AND A STALE
        ONE IS REMOVED FIRST. A turn that produced no commit has no objects to
        carry, and an empty bundle is a file that looks like evidence of one.

        W105575 candidate review 2026-09-07: on a persistent line the declared
        output directory SURVIVES the turn that wrote it, so a no-op correction
        left the previous attempt's bundle sitting byte-for-byte inside this
        turn's declared output -- objects for a head this turn does not claim,
        collected and sealed as though it did. The three text members are
        rewritten unconditionally and so were never exposed to this; the bundle
        is the one member whose absence is meaningful, so its absence is made
        rather than assumed.

        ONLY THIS WORKER'S OWN MEMBER IS REMOVED, by exact name and through a
        descriptor. Whatever else a previous attempt or another party left in
        the workspace is not this adapter's to clean up, and sealed custody and
        retained checkpoint refs are emphatically not.

        `HEAD` RATHER THAN THE OBJECT NAME in the range. A bundle carries the
        references it was asked for, and a raw object name is not a reference;
        the commit was taken immediately above, so `HEAD` is that exact object
        and is also a name the recipient can resolve.
        """
        _made(proposal)
        _discarded(proposal, BUNDLE)
        _written(os.path.join(proposal, PATCH),
                 self._git(repository, "diff", "--no-renames",
                           f"{base}..{head}",
                           what="proposed patch").stdout if head else "")
        _written(os.path.join(proposal, VERIFICATION),
                 verification["text"] if verification is not None
                 else "no verification was attempted\n")
        _written(os.path.join(proposal, RESULT),
                 json.dumps(result, indent=1, sort_keys=True) + "\n")
        if head is not None:
            self._git(repository, "bundle", "create", "--quiet",
                      os.path.join(proposal, BUNDLE), f"{base}..HEAD",
                      what="object transport")
            os.chmod(os.path.join(proposal, BUNDLE), FILE_MODE)

    def _scratch(self):
        """One bounded private directory under the tmpfs, mode 0700.

        WHAT IS STILL HERE, AND WHAT MOVED. The child ephemera roots below --
        the byte-code cache, the temporary directory and the cache home -- stay
        on the tmpfs: they are private, non-executable, and are meant to be
        destroyed with the container.

        THE EDITABLE TREE NO LONGER DOES, and the superseded reason is worth
        keeping because it reads as a rule. It said the workspace was "the
        host-visible output bind, and an editable copy left there would be
        material the manager has to collect and reason about". Collection is by
        DECLARATION, not by presence: `output._compare_declared` refuses an
        undeclared path outright -- "an undeclared path is never collected
        merely because the agent wrote there" -- so a checkout and a candidate
        beside the declared proposal are workspace material that goes away with
        the workspace. What the old placement did cost was real: the tmpfs is
        64 MiB, which is W71917's whole subject.
        """
        if self._home is not None:
            return self._home
        made = tempfile.mkdtemp(prefix="dogfood-", dir=PRIVATE_ROOT)
        os.chmod(made, 0o700)
        return made

    # THE THREE ROOTS EACH CHILD IS GIVEN, by environment name.
    #
    # Named in one place because they are made and pointed at in one place. A
    # name added here without a directory, or a directory made without a name,
    # is the review [P1] this structure exists to make impossible.
    EPHEMERA_ROOTS = (("PYTHONPYCACHEPREFIX", "pycache"),
                      ("TMPDIR", "tmp"),
                      ("XDG_CACHE_HOME", "cache"))

    def _new_directory(self, scratch, name):
        """Create one predictable child root exclusively, without repair.

        `exist_ok=True` is forbidden at this boundary. An existing name is not
        ours merely because it has the desired spelling, and chmodding it can
        follow a provider-created link. Production scratch is new, so a
        collision is a custody failure rather than reusable state.
        """
        made = os.path.join(scratch, name)
        try:
            os.mkdir(made, 0o700)
        except FileExistsError as failed:
            raise TaskRefusal(
                f"the private child root {made} already exists; predictable "
                f"runtime paths are created exclusively and never repaired") from failed
        os.chmod(made, 0o700)
        return made

    def _new_ephemera(self, scratch, name):
        made = self._new_directory(scratch, name)
        roots = {}
        for variable, leaf in self.EPHEMERA_ROOTS:
            roots[variable] = self._new_directory(made, leaf)
        return made, roots

    def _child_environments(self, scratch):
        """Create both child environments before either child may execute."""
        contextual = self._context_bound()
        provider_home = self._context_home() if contextual is not None else self._prepared_home(scratch)
        _provider_root, provider_roots = self._new_ephemera(
            scratch, PROVIDER_EPHEMERA)
        verification_home = self._new_directory(scratch, VERIFICATION_HOME)
        _verification_root, verification_roots = self._new_ephemera(
            scratch, VERIFICATION_EPHEMERA)
        return {
            "provider": self._closed_environment(
                home=provider_home, roots=provider_roots, scratch=scratch),
            "verification": self._closed_environment(
                home=verification_home, roots=verification_roots,
                scratch=scratch),
        }

    @staticmethod
    def _checked_directory(scratch, place):
        """Prove every path component is an ordinary owned scratch directory.

        This check is repeated immediately before each child. The provider can
        write as the worker uid and knows the scratch layout, so creation alone
        is not evidence that a verifier path still names what we created.
        """
        import stat

        scratch = os.path.abspath(scratch)
        place = os.path.abspath(place)
        try:
            scratch_state = os.lstat(scratch)
        except OSError as failed:
            raise TaskRefusal(
                f"private scratch {scratch} cannot be validated "
                f"({type(failed).__name__})") from failed
        if not stat.S_ISDIR(scratch_state.st_mode):
            raise TaskRefusal(
                f"private scratch {scratch} is not an ordinary directory")
        try:
            inside = os.path.commonpath((scratch, place)) == scratch
        except ValueError:
            inside = False
        if not inside or place == scratch:
            raise TaskRefusal(
                f"the child root {place} is not beneath private scratch "
                f"{scratch}")
        current = scratch
        for component in os.path.relpath(place, scratch).split(os.sep):
            current = os.path.join(current, component)
            try:
                held = os.lstat(current)
            except OSError as failed:
                raise TaskRefusal(
                    f"the private child root component {current} cannot be "
                    f"validated ({type(failed).__name__})") from failed
            if not stat.S_ISDIR(held.st_mode):
                raise TaskRefusal(
                    f"the private child root component {current} is not an "
                    f"ordinary directory; links and special files are "
                    f"refused")
            if stat.S_IMODE(held.st_mode) != 0o700:
                raise TaskRefusal(
                    f"the private child root component {current} has mode "
                    f"{stat.S_IMODE(held.st_mode):04o}, not 0700")
        resolved = os.path.realpath(place)
        if os.path.commonpath((scratch, resolved)) != scratch:
            raise TaskRefusal(
                f"the private child root {place} resolves outside scratch "
                f"to {resolved}")
        return place

    def _closed_environment(self, *, home, roots, scratch):
        """The whole environment a child gets, composed member by member.

        `HOME` and `PATH` are what this adapter always gave. The three cache
        and temporary names are W85497's correction and they all point INSIDE
        `ephemera`, which is under the private scratch and outside `candidate`.
        Nothing else is added and `os.environ` is still never consulted.

        EVERY NAMED ROOT IS CREATED HERE, and review 2026-09-04T13-56-04Z [P1]
        is why that is not a detail. Only the OUTER directory was made; the
        three children were named and absent, and an absent directory is one
        the child silently ignores -- a probe of the composed environment found
        Python presented with that `TMPDIR` selecting `/tmp` instead. A
        boundary that depends on a directory existing is declarative until the
        directory exists, so the loop below makes each one at the same mode as
        its parent before either child is started.
        """
        composed = {"HOME": self._context_home() if self._context_bound() is not None and home == os.path.join(CONTEXT_ROOT, "home") else self._checked_directory(scratch, home),
                    "PATH": "/usr/local/bin:/usr/bin:/bin"}
        for name, _leaf in self.EPHEMERA_ROOTS:
            # `compileall` WRITES BYTECODE AS ITS PURPOSE and ignores
            # `PYTHONDONTWRITEBYTECODE`; `PYTHONPYCACHEPREFIX` is the name that
            # decides WHERE, and it is the one that keeps the candidate clean.
            composed[name] = self._checked_directory(scratch, roots[name])
        return composed

    def _revalidated_environment(self, scratch, environment):
        """Re-prove the prepared paths after the provider had write access."""
        checked = dict(environment)
        checked["HOME"] = self._context_home() if self._context_bound() is not None and checked["HOME"] == os.path.join(CONTEXT_ROOT, "home") else self._checked_directory(scratch, checked["HOME"])
        for name, _leaf in self.EPHEMERA_ROOTS:
            checked[name] = self._checked_directory(scratch, checked[name])
        return checked

    def _pinned_environment(self, scratch, environment):
        """Open verifier roots before the provider can create descendants.

        Review 2026-09-04T18-59-48Z [P1]: checking a pathname immediately
        before launch still leaves a check/use interval. A provider descendant
        can outlive its leader, replace the checked name with a link to the
        candidate, and let the verifier resolve that link.

        These descriptors hold the exact directory objects created before the
        provider runs. The verifier inherits them explicitly and resolves only
        `/proc/self/fd/<n>`; replacing a scratch pathname cannot redirect an
        already-open object. The ordinary names remain useful for the provider
        environment and for operator inspection, but they are no longer the
        verifier's authority.
        """
        checked = self._revalidated_environment(scratch, environment)
        pinned = {"PATH": checked["PATH"]}
        held = []
        flags = os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW
        try:
            for name in ("HOME", *(one for one, _leaf in self.EPHEMERA_ROOTS)):
                descriptor = os.open(checked[name], flags)
                state = os.fstat(descriptor)
                named = os.lstat(checked[name])
                if (not stat.S_ISDIR(state.st_mode)
                        or stat.S_IMODE(state.st_mode) != 0o700
                        or (state.st_dev, state.st_ino)
                        != (named.st_dev, named.st_ino)):
                    os.close(descriptor)
                    raise TaskRefusal(
                        f"the private verifier root {checked[name]} did not "
                        f"remain the exact owned mode-0700 directory while "
                        f"it was opened")
                held.append((name, descriptor))
                pinned[name] = f"/proc/self/fd/{descriptor}"
        except BaseException:
            for _name, descriptor in held:
                os.close(descriptor)
            raise
        return pinned, tuple(held)

    @staticmethod
    def _revalidated_directories(environment, directories):
        """Validate held objects, never provider-writable pathnames."""
        for name, descriptor in directories:
            try:
                state = os.fstat(descriptor)
            except OSError as failed:
                raise TaskRefusal(
                    f"the held verifier root {name} cannot be validated "
                    f"({type(failed).__name__})") from failed
            if not stat.S_ISDIR(state.st_mode):
                raise TaskRefusal(
                    f"the held verifier root {name} is not a directory")
            if stat.S_IMODE(state.st_mode) != 0o700:
                raise TaskRefusal(
                    f"the held verifier root {name} has mode "
                    f"{stat.S_IMODE(state.st_mode):04o}, not 0700")
            if state.st_nlink == 0:
                raise TaskRefusal(
                    f"the held verifier root {name} was removed after the "
                    f"provider ran")
            if environment[name] != f"/proc/self/fd/{descriptor}":
                raise TaskRefusal(
                    f"the verifier environment no longer names its held "
                    f"{name} directory")
        return tuple(descriptor for _name, descriptor in directories)

    def _provider(self, task, candidate, scratch, environment, prompt=None):
        """One provider turn, over a closed argv and a closed environment.

        THE ENVIRONMENT IS COMPOSED, NEVER INHERITED. `os.environ` is not
        forwarded, and that is the point rather than tidiness: a credential
        variable present in this process would silently outrank every other
        source and decide which account the trial ran as. What the child gets
        is `HOME`, `PATH` and W85497's three ephemeral roots -- nothing else.

        THE HOME IS STILL THE PREPARED CREDENTIAL HOME. The cache correction
        moves where bytecode and temporaries LAND; it does not move the
        provider's credential, which stays exactly where `_prepared_home` puts
        it and is the one thing this turn cannot run without.
        """
        contextual = self._context_bound()
        if prompt is None:
            prompt = _prompt(task, self._context_feedback(contextual))
        argv = [PROVIDER_PROGRAM, *PROVIDER_ARGUMENTS, prompt]
        if contextual is not None:
            if candidate != OUTPUT_ROOT:
                raise TaskRefusal("context provider working directory disagrees")
            argv = [PROVIDER_PROGRAM, *PROVIDER_ARGUMENTS, "--model", contextual["model"], "--session-id" if contextual["mode"] == "open" else "--resume", contextual["conversation_id"], prompt]
            import baton_worker
            if _task_digest(prompt.encode()) != contextual["prompt_digest"] or baton_worker.digest(argv) != contextual["argv_digest"]:
                raise TaskRefusal("actual context prompt or argv disagrees")
            self._context_intent(contextual)
            self._context_receipt = self._context_result(contextual, status=None, record=None, partial=True)
        # W61599: THE ONE ACT THE LAUNCH PATH PERFORMS FOR THE DIAGNOSTIC, and
        # it is an assignment rather than a filesystem call. See
        # `_bound_activity`: the baseline is proved by construction, so binding
        # it costs the provider nothing.
        self._bound_activity(scratch)
        # W321528: RESOLVED ONCE, BEFORE THE CHILD, AND CARRIED ON EVERY
        # ANSWER. The number below is what `_ran_provider` is given AND what
        # the publishers report; there is no second resolution and no constant
        # spelled at a publication site. The timeout branch reads it off this
        # same mapping rather than asking `_bound` again, which is how its
        # sentence and its `seconds_bound` member came to disagree with each
        # other in the first place.
        bound = self._resolved_bound(self._seen, "provider_turn",
                                     PROVIDER_SECONDS)
        seconds = bound["seconds_bound"]
        try:
            status, record, partial = self._ran_provider(
                argv, cwd=candidate, seconds=seconds, scratch=scratch,
                env=self._revalidated_environment(scratch, environment),
                umask=PROVIDER_UMASK)
        except subprocess.TimeoutExpired:
            return {"ok": False, "status": None,
                    "failure_reason": PROVIDER_TIMED_OUT, **bound,
                    "why": f"the provider did not finish within "
                           f"{seconds}s"}
        except OSError as failed:
            return {"ok": False, "status": None,
                    "failure_reason": PROVIDER_START_ERROR, **bound,
                    "why": f"the provider could not be started: "
                           f"{type(failed).__name__}"}
        if contextual is not None:
            self._context_receipt = self._context_result(contextual, status=status, record=record, partial=partial)
            if self._context_receipt["complete"] is not True:
                return {"ok": False, "status": status, "failure_reason": PROVIDER_START_ERROR, **bound, "why": "provider context terminal identity is unproved"}
        if status == 0:
            # A CLEAN TURN PUBLISHES NO REASON. There is nothing to classify,
            # and a `failure_reason` on a success would be a field readers
            # learn to ignore.
            return {"ok": True, "status": 0, "failure_reason": None,
                    **bound, "why": None}
        # THE DIAGNOSTIC IS STILL NOT THE PROVIDER'S PROSE. This read
        # `f"...{status}: {errors}"`, and `errors` was the provider's own
        # stderr -- the process that had just authenticated with the attempt's
        # bearer. It reached `result.json` through `why` AND the worker's
        # protocol `/output/output.json` through `recap`.
        #
        # W55360 CHANGES EXACTLY ONE THING: the STRUCTURED stdout record is
        # read, matched against a closed map, and discarded. What crosses the
        # boundary below is one of this module's own words -- never the
        # provider's spelling of it, never the document, never a parser
        # complaint. W71879 adds the separately bounded detail reader below;
        # stderr is still on `DEVNULL` and was never opened.
        reason = _failure_reason(record, partial=partial)
        return {"ok": False, "status": status, "failure_reason": reason,
                "diagnostic": _provider_diagnostic(record, partial=partial),
                **bound,
                "why": f"the provider exited {status} ({reason}); its own "
                       f"unrestricted diagnostic is withheld; supported "
                       f"nonsecret detail is in provider.diagnostic"}

    def _context_bound(self):
        seen = self._seen or {}
        if seen.get("schema") != "baton.worker-launch/4" and "provider_context" not in seen:
            return None
        import baton_worker
        return baton_worker.context_delivery(seen)

    def _context_open(self):
        flags = os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW
        fd = os.open("/", flags)
        try:
            for part in CONTEXT_ROOT.strip("/").split("/"):
                child = os.open(part, flags, dir_fd=fd)
                os.close(fd)
                fd = child
            info = os.fstat(fd)
            if info.st_uid != os.getuid() or stat.S_IMODE(info.st_mode) != 0o700:
                raise TaskRefusal("context use root ownership disagrees")
            return fd
        except BaseException:
            os.close(fd)
            raise

    def _context_feedback(self, contextual):
        """The delivered review feedback for a RESTORE, or None for the rest.

        W177936. The manager binds the restore prompt over the opening
        verdict's findings and delivers the same bytes as one 0600,
        digest-bound `feedback` file in the context-use root; this reads it
        no-follow and bounded, composes the twin prompt, and the bound
        prompt/argv digests refuse any disagreement BEFORE the provider
        runs -- the file is transport, the digests are the authority. A
        restore without the file, and an open turn that finds one, both
        refuse by name.

        `O_NONBLOCK`, review231132 [R1]: without it a FIFO standing at this
        name blocks the OPEN itself, before `fstat`, the byte bound and the
        digest gates ever run -- a hang where every neighbouring check is a
        refusal. Nonblocking open cannot block on a FIFO, the `fstat` right
        behind it refuses every non-regular file by name, and a regular
        file's reads are unaffected.
        """
        if contextual is None:
            return None
        root = self._context_open()
        try:
            try:
                fd = os.open("feedback",
                             os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK,
                             dir_fd=root)
            except FileNotFoundError:
                if contextual["mode"] == "restore":
                    raise TaskRefusal(
                        "restore invocation has no delivered feedback") \
                        from None
                return None
        finally:
            os.close(root)
        try:
            if contextual["mode"] != "restore":
                raise TaskRefusal(
                    "an open invocation carries no review feedback and "
                    "this delivery has one")
            if not stat.S_ISREG(os.fstat(fd).st_mode):
                raise TaskRefusal("delivered feedback is not a regular file")
            raw = os.read(fd, MAX_FEEDBACK_BYTES + 1)
        finally:
            os.close(fd)
        if not raw or len(raw) > MAX_FEEDBACK_BYTES:
            raise TaskRefusal("delivered feedback is bounded non-empty bytes")
        try:
            return raw.decode("utf-8", "strict")
        except UnicodeDecodeError:
            raise TaskRefusal("delivered feedback is not UTF-8") from None

    def _context_home(self):
        slot = os.path.join(CREDENTIAL_ROOT, CREDENTIAL_SLOT)
        if not os.path.exists(slot) or not os.access(slot, os.R_OK):
            raise TaskRefusal("context credential slot is absent or unreadable")
        root = self._context_open()
        try:
            home = os.open("home", os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=root)
            try:
                info, outer = os.fstat(home), os.fstat(root)
                pins = (outer.st_dev, outer.st_ino, info.st_dev, info.st_ino)
                if info.st_uid != os.getuid() or stat.S_IMODE(info.st_mode) != 0o700 or (getattr(self, "_context_pins", None) is not None and self._context_pins != pins):
                    raise TaskRefusal("context HOME ownership or original object disagrees")
                self._context_pins = pins
                try:
                    os.mkdir(".claude", 0o700, dir_fd=home)
                except FileExistsError:
                    pass
                state = os.open(".claude", os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=home)
                try:
                    try:
                        os.symlink("/run/baton/credentials/claude", ".credentials.json", dir_fd=state)
                        os.fsync(state)
                    except FileExistsError:
                        pass
                    if os.readlink(".credentials.json", dir_fd=state) != "/run/baton/credentials/claude":
                        raise TaskRefusal("context credential link disagrees")
                finally:
                    os.close(state)
            finally:
                os.close(home)
        finally:
            os.close(root)
        return os.path.join(CONTEXT_ROOT, "home")

    def _context_intent(self, contextual):
        import baton_worker
        self._context_home()
        root = self._context_open()
        try:
            try:
                fd = os.open("invocation", os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600, dir_fd=root)
            except FileExistsError:
                raise TaskRefusal("context invocation already intended; outcome remains unknown") from None
            try:
                raw = baton_worker.canonical({key: contextual[key] for key in ("invocation_id", "use_id", "task_digest", "prompt_digest", "argv_digest", "invocation_binding_digest")})
                with os.fdopen(fd, "wb", closefd=False) as stream:
                    stream.write(raw)
                    stream.flush()
                    os.fsync(fd)
            finally:
                os.close(fd)
            os.fsync(root)
        finally:
            os.close(root)

    def _context_result(self, contextual, *, status, record, partial):
        value = None
        def pairs(items):
            result = {}
            for key, item in items:
                if key in result:
                    raise ValueError("duplicate terminal key")
                result[key] = item
            return result
        def finite(text):
            value = float(text)
            if not __import__("math").isfinite(value):
                raise ValueError("nonfinite terminal number")
            return value
        if not partial and type(record) is bytes and len(record) <= MAX_PROVIDER_RECORD:
            try:
                value = json.loads(record, object_pairs_hook=pairs, parse_float=finite, parse_constant=lambda text: (_ for _ in ()).throw(ValueError()))
            except (ValueError, UnicodeError, RecursionError):
                pass
        good = (type(value) is dict and value.get("type") == "result" and value.get("subtype") == "success" and value.get("is_error") is False and value.get("session_id") == contextual["conversation_id"] and type(status) is int and status == 0)
        # Model attribution is diagnostic, not proof of session continuity.
        diagnostics = {key: value[key] for key in ("model", "modelUsage") if key in value} if type(value) is dict else {}
        observed = diagnostics.get("model")
        if type(observed) is not str or re.fullmatch(r"[A-Za-z0-9._:/-]{1,256}", observed) is None:
            observed = None
        job = self._seen["job_execution"]
        return {"schema": "baton.provider-context-receipt/3", **{key: contextual[key] for key in ("context_id", "use_id", "attempt_id", "conversation_id", "profile_digest", "invocation_id", "model", "cli_build", "mode", "delivery_digest", "task_digest", "prompt_digest", "argv_digest", "invocation_binding_digest")}, "status": status, "complete": bool(good), "observed_model": observed, "model_diagnostics_digest": _digest(diagnostics), "provider_result_digest": "sha256:" + _bytes_digest(record).hex() if type(record) is bytes else None, "observed_conversation_id": contextual["conversation_id"] if good else None, "terminal": "success" if good else "unproved", "input_digest": job["runtime_input_digest"], "policy_digest": job["runtime_policy_digest"]}

    def _publish_context_receipt(self):
        import baton_worker
        if self._context_receipt is None:
            raise TaskRefusal("context invocation receipt is absent")
        root = os.open(OUTPUT_ROOT, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
        try:
            try:
                os.mkdir(CONTEXT_RECEIPT, 0o700, dir_fd=root)
            except FileExistsError:
                pass
            held = os.open(CONTEXT_RECEIPT, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=root)
            try:
                # A private line preserves declared outputs across corrections.
                # Replace only our regular output member; retained custody is
                # outside this mount. The exclusive use intent fences execution.
                if set(os.listdir(held)) - {"receipt.json"}:
                    raise TaskRefusal("context receipt output contains an unexpected member")
                if "receipt.json" in os.listdir(held):
                    old = os.stat("receipt.json", dir_fd=held, follow_symlinks=False)
                    if not stat.S_ISREG(old.st_mode) or old.st_nlink != 1:
                        raise TaskRefusal("previous context receipt output is not a regular owned member")
                    os.unlink("receipt.json", dir_fd=held)
                fd = os.open("receipt.json", os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600, dir_fd=held)
                try:
                    raw = baton_worker.canonical(self._context_receipt)
                    if len(raw) > 16384:
                        raise TaskRefusal("context receipt exceeds bound")
                    with os.fdopen(fd, "wb", closefd=False) as stream:
                        stream.write(raw)
                        stream.flush()
                        os.fsync(fd)
                finally:
                    os.close(fd)
                os.fsync(held)
            finally:
                os.close(held)
            os.fsync(root)
        finally:
            os.close(root)

    # -- W61599: the native-session activity observation ---------------------

    def _bound_activity(self, scratch):
        """Bind this turn's baseline BEFORE the provider is launched.

        THE BASELINE IS PROVED BY CONSTRUCTION AND NEVER MEASURED, and the
        earlier revisions of this design that measured it were wrong. An
        `mtime` cannot reconstruct one: a native file holding 1000 bytes with
        10 appended before the first observation has 1010 bytes AND a new
        mtime, so a rule that admitted it counted 1010 when the true answer is
        10. mtime says a file changed; it cannot say how much of it is new.

        SO THE ONLY PROVABLE BASELINE IS A DIRECTORY THIS PROCESS JUST MADE.
        An uninjected `_scratch` is a `tempfile.mkdtemp` this process created,
        and `_prepared_home` puts exactly one entry -- the credential SYMLINK
        -- beneath its `.claude`. That home is therefore provably empty of
        native files at this instant, with NO SCAN AND NO STAT, which is a true
        pre-launch zero admitted without the launch waiting for anything.

        AN INJECTED, REUSED OR RESTORED HOME IS UNKNOWN for the whole
        operation. Nothing is estimated, no scan reconstructs a baseline and no
        restored history is subtracted. The one thing recorded here is a
        boolean this adapter already knows.

        NOTHING ON THIS PATH TOUCHES THE FILESYSTEM. A diagnostic that made the
        provider wait behind a directory walk would be a diagnostic charged to
        the turn.
        """
        created = self._home is None and not (self._seen or {}).get("provider_context")
        with self._activity_lock:
            self._activity = (
                None if not created
                else {"root": os.path.join(scratch, "home",
                                           PROVIDER_HOME_STATE),
                      "seen": {}, "total": 0, "frozen": False})

    def observed_activity(self):
        """How many bytes of THIS turn's native stream have appeared, or None.

        W61599, approver ruling M61707. A LENGTH IS CONTENT-FREE BY
        CONSTRUCTION, which is the only reason any of this may cross a
        container boundary at all: no line, record, name or byte of what the
        provider wrote is read, and nothing here opens a file.

        IT IS A MONOTONIC RUNNING TOTAL, not a difference against a baseline.
        The obvious formula -- the sum over files of `max(0, size - baseline)`
        -- can go BACKWARDS: a file that had grown to 100 and is replaced by a
        smaller one whose baseline is still 0 drops the total to 80. A count
        that can fall is exactly the lie this projection must not tell, so what
        is kept per file is its IDENTITY and its LAST OBSERVED SIZE, and each
        scan adds the growth of every surviving file of unchanged identity.

        SHRINK, DISAPPEARANCE AND IDENTITY CHANGE FREEZE IT. Any of the three
        makes the source ambiguous: the total stops advancing, is never
        reduced, and does not resume if the file comes back. Ambiguity is
        unknown-from-here rather than a smaller number.

        AND IT NEVER REPORTS A PROVIDER FAILURE. A missing home, an unreadable
        directory or an overrun bound leaves activity unknown; none of those is
        a fact about whether the turn is going well.

        CALLED FROM THE PUBLISHER'S OWN THREAD, once a second, for the life of
        one `work` operation.
        """
        with self._activity_lock:
            held = self._activity
            if held is None:
                return None
            if held["frozen"]:
                # FROZEN REPORTS THE LAST GOOD TOTAL and stops advancing.
                # Reporting `None` here would retract an observation this
                # manager already made, and the owner refuses a regression.
                return held["total"] or None
            try:
                found = self._activity_scan(held["root"])
            except _ActivityUnknown:
                held["frozen"] = True
                return held["total"] or None
            seen = held["seen"]
            for key in tuple(seen):
                if key not in found:
                    # A TRACKED FILE THAT IS GONE is a source this adapter can
                    # no longer account for.
                    held["frozen"] = True
                    return held["total"] or None
            for key, size in found.items():
                last = seen.get(key)
                if last is None:
                    # FIRST SEEN AFTER A PROVED-EMPTY BASELINE, so every byte
                    # of it is this invocation's.
                    held["total"] += size
                elif size < last:
                    held["frozen"] = True
                    return held["total"] or None
                else:
                    held["total"] += size - last
                seen[key] = size
            if held["total"] > MAX_ACTIVITY_BYTES:
                held["frozen"] = True
                held["total"] = 0
                return None
            return held["total"] or None

    @staticmethod
    def _activity_scan(root):
        """Bounded native-file metadata from no-follow directory descriptors.

        Open each directory relative to its held parent and compare the opened
        object with the checked entry. Renames cannot redirect a later scan to
        a symlink target. No native file is opened or its content read. All
        descriptors belong to this scan and close even on ambiguity/overflow.
        """
        found = {}
        examined = 0
        flags = os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC

        def scan(directory, depth):
            nonlocal examined
            if depth > ACTIVITY_DEPTH:
                raise _ActivityUnknown()
            with os.scandir(directory) as entries:
                for entry in entries:
                    examined += 1
                    if examined > ACTIVITY_ENTRIES:
                        raise _ActivityUnknown()
                    held = entry.stat(follow_symlinks=False)
                    if stat.S_ISDIR(held.st_mode):
                        child = os.open(entry.name, flags, dir_fd=directory)
                        try:
                            opened = os.fstat(child)
                            if (opened.st_dev, opened.st_ino) != (held.st_dev, held.st_ino):
                                raise _ActivityUnknown()
                            scan(child, depth + 1)
                        finally:
                            os.close(child)
                    elif stat.S_ISREG(held.st_mode) and entry.name.endswith(ACTIVITY_SUFFIX):
                        found[(held.st_dev, held.st_ino)] = held.st_size
                        if len(found) > ACTIVITY_FILES:
                            raise _ActivityUnknown()

        directory = None
        try:
            # Acquire the root without following a substituted ancestor either.
            # This happens only on the publisher thread, never at launch.
            if not os.path.isabs(root):
                raise _ActivityUnknown()
            directory = os.open(os.path.sep, flags)
            for component in root.split(os.path.sep):
                if not component:
                    continue
                if component in (".", ".."):
                    raise _ActivityUnknown()
                child = os.open(component, flags, dir_fd=directory)
                os.close(directory)
                directory = child
            scan(directory, 0)
        except OSError:
            raise _ActivityUnknown() from None
        finally:
            if directory is not None:
                os.close(directory)
        return found



    def _ran_provider(self, argv, *, cwd, seconds, env, scratch=None,
                      umask=-1):
        """The provider child, whose STDOUT ALONE is read, bounded and drained.

        W55360's approver ruling narrowly supersedes W39357's no-read rule for
        this one stream, because two supervised rounds established that `exit
        1 and nothing else` costs more than it protects. Everything else about
        that rule stands, and the shape here is what keeps it standing:

        STDERR IS UNTOUCHED, on `DEVNULL`, exactly as before. The provider's
        prose is where a bearer would appear and this module still has no
        descriptor onto it. The verification command's two streams are
        `_ran`'s and are not changed by this method's existence.

        THE PIPE IS DRAINED CONTINUOUSLY AND THE RETENTION IS BOUNDED, and
        those are two properties rather than one. A reader that stopped at the
        ceiling would leave a chatty provider blocked on a full pipe forever;
        a reader with no ceiling would let it decide this process's memory. So
        every byte is read and at most `MAX_PROVIDER_RECORD` are kept, with
        the rest dropped as they arrive.

        THE DRAIN RUNS BESIDE THE CHILD, in a thread, because `self._run`
        blocks until the child exits and the pipe would fill first otherwise.
        The parent's write end is closed after the run returns, which is what
        gives the reader its EOF; without that close the reader would wait on a
        descriptor this process itself still holds.

        AND THE DRAIN ENDS ON ITS OWN CLOCK, NOT ON EOF, which is W55360
        review (2026-09-01T03:35:56Z) [P1] and the sharper half of the same
        sentence. This process closing its write end is NOT enough to
        guarantee EOF: any descendant the provider started inherited the
        descriptor, so a leader that spawns something long-lived and exits
        leaves the read end open with nobody left who intends to close it.
        Waiting for that EOF wedged the worker after `self._run` had already
        returned -- past `PROVIDER_SECONDS`, which was supposed to be the
        bound on exactly this. So the reader carries `PROVIDER_DRAIN_SECONDS`
        of grace from the moment the provider ends and then STOPS, whether or
        not it saw EOF and whether or not bytes are still arriving, and a
        stream that was never proved finished is PARTIAL.

        THE READER OWNS THE READ END and closes it itself. Closing a
        descriptor another thread may still be reading is a use-after-close
        this module has no way to make safe, and the alternative -- leaking it
        -- would be a descriptor left open for the life of the turn. Handing
        the one thread that touches it the job of closing it is neither.

        NO PATHNAME AND NO FILE. W39357's first two review rounds were both
        about capture plumbing -- a path a child could replace, then a
        descriptor read back too late -- so this creates neither. The pipe is
        anonymous, lives in this process, and its contents never reach a host
        filesystem.
        """
        room, fmt = _log_room()
        # W198667: THE PARSED STDOUT IS RETAINED BYTE-IDENTICALLY BESIDE BEING
        # PARSED. The drain below already reads every byte and keeps a bounded
        # prefix in memory; what is added is that each piece is also appended to
        # the attempt's own log as it arrives. The record this method RETURNS is
        # unchanged, so nothing downstream reads different bytes than it did.
        recorded = _Captured(room, fmt, "provider.stdout")
        # AND STDERR IS NO LONGER OPENED ONTO /dev/null. It goes straight to the
        # log's own descriptor, so this process never holds the bytes at all --
        # there is no buffer and no variable here that a later edit could
        # interpolate somewhere, which was the property `_ran`'s reasoning was
        # protecting. See `_Captured` for the owner ruling this rests on.
        complaint = _Captured(room, fmt, "provider.stderr")
        read_fd, write_fd = os.pipe()
        os.set_blocking(read_fd, False)
        held = bytearray()
        partial = [False]
        ended = threading.Event()

        retained = {}

        def drain():
            deadline = None
            try:
                while True:
                    # W198667 [R2]: INCREMENTALLY, WHILE THE PROVIDER RUNS. An
                    # end-of-turn copy cannot survive a wrapper killed before
                    # its `finally`, which is the case the selected scope names.
                    # This thread already ticks on its own clock, so the
                    # retention rides it and appends only what is new.
                    if scratch is not None:
                        # THE SAME MAP EVERY TICK. It is mutated in place, so
                        # a poll appends only what is new -- discarding a
                        # returned copy is what duplicated `abc` seventeen
                        # times in the reviewer's probe.
                        _retain_native(scratch, room, fmt, retained)
                    if deadline is None and ended.is_set():
                        deadline = time.monotonic() + PROVIDER_DRAIN_SECONDS
                    waiting = PROVIDER_DRAIN_SLICE
                    if deadline is not None:
                        waiting = min(waiting, deadline - time.monotonic())
                        if waiting <= 0:
                            # NOT FINISHED, JUST OVER. Somebody the provider
                            # started still holds the write end, so what was
                            # read is a prefix of a record rather than a
                            # record, and it is treated as one.
                            partial[0] = True
                            return
                    try:
                        if not select.select([read_fd], (), (), waiting)[0]:
                            continue
                        piece = os.read(read_fd, 4096)
                    except (BlockingIOError, InterruptedError):
                        continue
                    except OSError:
                        partial[0] = True
                        return
                    if not piece:
                        # EOF: every writer is gone and the record is whole.
                        return
                    # EVERY BYTE TO THE LOG, and only a bounded prefix to
                    # memory. The ceiling exists so a chatty provider cannot
                    # decide this process's memory; it is not a reason to
                    # forget what it said, which is the whole finding.
                    recorded.wrote(piece)
                    space = MAX_PROVIDER_RECORD - len(held)
                    if space > 0:
                        held.extend(piece[:space])
                    if len(piece) > max(space, 0):
                        # READ AND DROPPED, which is the whole difference
                        # between a bound on memory and a bound on the child.
                        partial[0] = True
            finally:
                os.close(read_fd)

        reader = threading.Thread(target=drain, daemon=True)
        reader.start()
        outcome = _Outcome.NEVER_STARTED
        try:
            try:
                # THE MASK IS THE CHILD'S, APPLIED AFTER FORK. `Popen`'s
                # own `umask` operand rather than `preexec_fn`: this spawn
                # already runs beside the reader thread above, and
                # `preexec_fn` is documented as unsafe in the presence of
                # threads. See `PROVIDER_UMASK`.
                return_code = self._run(argv, cwd=cwd, env=env,
                                        timeout=seconds, stdout=write_fd,
                                        stderr=complaint.fileno_or_devnull,
                                        umask=umask
                                        ).returncode
            except subprocess.TimeoutExpired:
                outcome = _Outcome.INTERRUPTED
                raise
            else:
                outcome = _Outcome.COMPLETED
        finally:
            # THE CLOSE AND THE SIGNAL ARE IN `finally`, in that order. A
            # timeout or a missing executable still leaves this process
            # holding the write end and still has to start the reader's
            # clock: `subprocess.run` kills its DIRECT child on timeout and
            # nothing else, so the descendant case above is reachable from
            # the timeout path too.
            os.close(write_fd)
            ended.set()
            reader.join()
            # THE DECLARATIONS ARE IN THE `finally`, so a timeout and a missing
            # executable declare what they captured too -- those are exactly the
            # turns an operator has nothing else to read. `partial` is the
            # drain's own word: it ended on its clock rather than at EOF, or it
            # dropped bytes at the ceiling, and either way what is on disk is a
            # prefix rather than the stream.
            # STDOUT'S WORD IS THE DRAIN'S: it ended on its own clock or at
            # EOF, and that is a fact about the READER rather than about the
            # child -- unless the child never started, in which case there was
            # nothing to drain.
            recorded.declare(
                outcome if outcome == _Outcome.NEVER_STARTED
                else (_Outcome.INTERRUPTED if partial[0]
                      else _Outcome.COMPLETED))
            # STDERR'S WORD IS THE CHILD'S, because this process never touches
            # that descriptor: the child writes to the log directly.
            complaint.declare(outcome)
            # W198667 [3]: AND THE PROVIDER'S OWN SESSION FILES, retained here
            # because HERE is where they exist. `_prepared_home` builds the
            # provider's state directory under the SCRATCH tree, which is
            # destroyed with the container -- so a copy taken after the turn is
            # over and before anything is torn down is the only moment the
            # bytes are both complete and still there. A failure to start wrote
            # none, which is why the outcome decides whether this is even
            # attempted.
            if scratch is not None:
                # ONE LAST PASS, so whatever arrived after the final tick is
                # retained too. `retained` carries what the drain already
                # copied, so this appends rather than repeats.
                found = _retain_native(scratch, room, fmt, retained)
                _declare_native(room, fmt, found, outcome)
            if room is not None:
                try:
                    os.close(room)
                except OSError:
                    pass
        return return_code, bytes(held), partial[0]

    def _ran(self, argv, *, cwd, seconds, env, pass_fds=()):
        """One child, bounded, WITH BOTH STREAMS ON `/dev/null`.

        THIS IS THE WHOLE BOUNDARY, and it is one line rather than a
        discipline, which is the point. W39357 review (2026-08-30T04:01:29Z)
        [P1]: no pathname race and no link were needed to put the mounted
        bearer in the host-visible proposal. The provider is handed the
        credential and its stderr was interpolated into `result.json`; the
        task's verification command is code out of the candidate the provider
        just edited, running as the same uid with the same mount readable, and
        its two streams were copied verbatim into `verification.txt`. Printing
        the bearer was enough.

        THE OTHER REMEDY WAS UNAVAILABLE, and it is worth saying which. Making
        the mount unreachable to a child would end the class outright -- but
        the accepted posture is `--cap-drop ALL`, `--security-opt
        no-new-privileges`, one fixed uid and a read-only root, so this adapter
        has no mount namespace to alter, no second identity to drop to, and no
        way to revoke a read-only bind mount. Whatever the provider can read,
        a child of this process can read; if it could not, the provider could
        not authenticate and there would be no turn.

        REDACTION WAS NOT AVAILABLE EITHER, and for a better reason than
        difficulty: a redactor has to know the bearer's bytes, which means
        reading them, which the confirmed boundary forbids -- and a program
        holding the bearer in its own memory to scrub it is one formatting bug
        away from being the discloser.

        So the bytes are not read. Not bounded, not windowed, not held and
        discarded: `subprocess.DEVNULL` at both call sites, so there is no
        descriptor, no capture file, no buffer and no variable in this module
        that a later edit could interpolate somewhere. The two previous review
        rounds were both about capture plumbing -- a pathname a child could
        replace, then a descriptor read back too late -- and deleting the
        plumbing retires that class rather than defending it a third time.

        WHAT IS LOST IS REAL and is recorded rather than shrugged off: a failed
        provider turn now says only that it failed. The parent finding already
        rules that the evidence carries no provider diagnostic, and the
        operator's authoritative signal was always its own rerun of the frozen
        command against the collected candidate, never this file. If bringing
        up the first live turn (W39364) needs provider diagnostics, that is an
        explicitly operator-authorized diagnostic mode for a later pass and not
        a reason to publish untrusted bytes by default.
        """
        # W198667: AND THESE TWO ARE RETAINED NOW, under the owner supersession
        # recorded at `_Captured`. EVERYTHING ABOVE REMAINS TRUE about what
        # W39357 was deciding and why -- the bearer is still never read, still
        # never interpolated, and no redactor exists here. What changed is the
        # OWNER's requirement: for these private development deployments the
        # evidence is worth more than the discard, and the destination is the
        # manager's own per-attempt room rather than the result surface.
        #
        # THE DESCRIPTOR, NOT A BUFFER. The child writes to the log directly and
        # this process never holds the bytes, which keeps the exact property the
        # discard was protecting: there is no variable here to interpolate.
        room, fmt = _log_room()
        out = _Captured(room, fmt, "verification.stdout")
        err = _Captured(room, fmt, "verification.stderr")
        # THE OUTCOME IS DECIDED BY WHAT HAPPENED, not by reaching a `finally`.
        outcome = _Outcome.NEVER_STARTED
        try:
            answered = self._run(argv, cwd=cwd, env=env, timeout=seconds,
                                 pass_fds=pass_fds,
                                 stdout=out.fileno_or_devnull,
                                 stderr=err.fileno_or_devnull)
        except subprocess.TimeoutExpired:
            outcome = _Outcome.INTERRUPTED
            raise
        except Exception:                                  # noqa: BLE001
            # THE CHILD NEVER RAN. A missing executable, a refused fork, a
            # permission failure: there is no stream, and saying `finished`
            # about one would be this module inventing an ending.
            raise
        else:
            outcome = _Outcome.COMPLETED
            return answered.returncode
        finally:
            out.declare(outcome)
            err.declare(outcome)
            if room is not None:
                try:
                    os.close(room)
                except OSError:
                    pass

    def _prepared_home(self, scratch):
        """A private HOME whose credential path POINTS AT the mounted slot.

        THE BEARER IS NEVER READ. `os.symlink` writes a path, not bytes; this
        program never opens the target, and nothing about it reaches argv, the
        environment, the result or the evidence. What it buys is that a
        provider whose root filesystem is read-only can still write beside its
        own credential, which W17110 measured as the difference between
        reaching an authentication decision and failing before one.

        AN ABSENT SLOT IS A REFUSAL, not a fallback. The finding forbids a
        home-directory default, so a container started without the explicit
        credential delivery must not quietly try an ambient one.
        """
        slot = os.path.join(CREDENTIAL_ROOT, CREDENTIAL_SLOT)
        if not os.path.exists(slot):
            raise TaskRefusal(
                f"this container has no credential at {slot}; the operator "
                f"authorizes the exact credential source and this adapter "
                f"has no home-directory or ambient fallback")
        # PRESENT IS NOT READABLE, and W52800 is what that distinction cost.
        #
        # The check above is a `stat`, which needs only search permission on
        # the parents -- so a slot delivered at a mode this container's fixed
        # uid cannot open passed it, was symlinked into the private home, and
        # became a provider that printed `Not logged in` and exited 1. The
        # manager's mode was the defect and is corrected there; this is the
        # half that makes the SAME failure say what it is. Three attempts and
        # a day of probing separated the symptom from the cause, and the
        # question that would have closed the gap is one line.
        #
        # `os.access` AND NOT AN OPEN. It answers for this process's effective
        # identity, which is exactly the question, and it does so without a
        # descriptor onto bearer bytes. This adapter must not read the
        # credential to find out whether it could have.
        if not os.access(slot, os.R_OK):
            raise TaskRefusal(
                f"this container cannot READ its credential at {slot}; the "
                f"delivery exists and its permissions do not admit this "
                f"runtime's identity, so the provider would fail to "
                f"authenticate for a reason no diagnostic of its own may "
                f"publish")
        home = os.path.join(scratch, "home")
        state = os.path.join(home, PROVIDER_HOME_STATE)
        os.makedirs(state, exist_ok=True)
        os.chmod(home, 0o700)
        os.chmod(state, 0o700)
        link = os.path.join(state, PROVIDER_CREDENTIAL)
        if not os.path.lexists(link):
            os.symlink(slot, link)
        return home

    def _verify(self, task, candidate, environment, directories):
        """The task's OWN command, in the candidate copy, bounded.

        Run here so the proposal carries evidence the worker produced; the
        operator reruns it outside the container, and the acceptance says
        plainly that this answer is not what an operator trusts.

        ITS OUTPUT IS NOT PUBLISHED AT ALL -- see `_ran`. This command is
        provider-edited code running with the attempt's credential mount
        readable, and its two streams were copied verbatim into the
        host-visible transcript.

        The capture this once handed the command is gone entirely, which
        retires two earlier corrections with it: the first round put the
        adapter's stream files in the command's own working directory, and the
        third moved them to an anonymous descriptor. There is nothing left to
        place safely.
        """
        # REMOVING THE PROVIDER'S CREDENTIAL LINK FIRST WAS CONSIDERED AND
        # REJECTED, because it is the shape this record has already ruled
        # against once. It would take away ONE NAME that points at the slot
        # while the slot's own fixed absolute path stays readable to anything
        # running as this uid, so it narrows nothing an attacker relies on --
        # it only makes the module look defended. The capture-directory move
        # was rejected for the same reason in the third round: a defence that
        # depends on the child not knowing a path is not a boundary. `_ran` is
        # the boundary.
        #
        # ITS HOME IS NO LONGER THE CANDIDATE, which W85497 corrects. `HOME`
        # pointed at the tree being measured, so anything the command wrote to
        # its own home wrote into the proposal. It now gets a private,
        # CREDENTIAL-FREE home beside the candidate rather than inside it: the
        # provider's prepared home is deliberately NOT shared with this child,
        # because that home exists to hold the link to the bearer and this
        # command is provider-edited code.
        try:
            pass_fds = self._revalidated_directories(environment, directories)
            seconds = self._bound(self._seen, "ordinary_verification",
                                  VERIFICATION_SECONDS)
            status = self._ran(
                list(task["verification"]), cwd=candidate,
                seconds=seconds,
                env=environment, pass_fds=pass_fds)
        except subprocess.TimeoutExpired:
            # W321528: THE BOUND THE CHILD WAS GIVEN, not a second resolution
            # of it. `seconds` is bound before `_ran` can raise this, and
            # re-deriving it here is how a sentence and the number beside it
            # came to disagree one layer up.
            return {"status": None,
                    "text": _transcript(
                        task,
                        f"did not finish within {seconds}s")}
        except OSError as failed:
            return {"status": None,
                    "text": _transcript(task, f"could not be started "
                                              f"({type(failed).__name__})")}
        return {"status": status, "text": _transcript(task, f"exit: {status}")}


def _transcript(task, ending):
    """`verification.txt`, composed ENTIRELY from things a child did not write.

    W39357 review (2026-08-30T04:01:29Z) [P1]. The parent finding requires this
    file to carry no credential and no provider diagnostic content, and the
    previous form copied the command's stdout and stderr into it verbatim --
    from provider-edited code, running with the attempt's credential mount
    readable. There is no rule this adapter can apply to those bytes that does
    not require reading the bearer.

    So the file carries the frozen command, which the OPERATOR wrote into
    `/input/task.json` and this adapter read from a read-only mount, and the
    ending, which this adapter got from `wait` rather than from a stream. Both
    are already published in `result.json`; stating them here keeps the
    transcript a transcript rather than an empty file.

    AND IT SAYS WHAT IS MISSING AND WHY, because a reader who does not know
    the output was withheld will read its absence as the command being silent.
    """
    return (f"$ {' '.join(task['verification'])}\n"
            f"{ending}\n"
            f"\n"
            f"The command's own stdout and stderr are deliberately not\n"
            f"reproduced here. It is code from the candidate tree this turn's\n"
            f"provider edited, and it runs with the attempt's credential mount\n"
            f"readable -- so its output is exactly the content this proposal\n"
            f"must not carry, and nothing here can tell one of its bytes from\n"
            f"another without reading the bearer.\n"
            f"\n"
            f"Rerun the command yourself, from the collected candidate tree,\n"
            f"outside the worker. The acceptance already says that rerun and\n"
            f"not this file is what an operator trusts.\n")


def _failure_reason(record, *, partial):
    """One of THIS module's words for a nonzero provider turn.

    EVERY PATH OUT OF HERE IS A CONSTANT. The parameter is provider-authored
    bytes and nothing derived from them is returned, interpolated or reported:
    not the document, not a member name, not an unmatched `terminal_reason`,
    not the exception a parser raised, not a length and not an excerpt. The
    answer is `PROVIDER_FAILURE_REASONS[value]` or `UNCLASSIFIED`, and both are
    written in this file.

    WHY THE FAILURES ARE NOT DISTINGUISHED. Malformed JSON, invalid UTF-8, a
    non-object root, a missing reason, a duplicated reason, a non-string
    reason, an unknown reason, a partial record and a document the parser
    could not finish all answer the same word. Telling them apart in the
    published record would be publishing a parser's reading of untrusted bytes
    -- a channel with fewer values than the document but a channel all the
    same -- and the operator's next act is identical for all of them.

    DUPLICATES ARE REFUSED RATHER THAN RESOLVED. `json.loads` keeps the last
    of two equal keys, so a document carrying `terminal_reason` twice would be
    read as whichever the provider put second. That is a choice this module
    has no basis to make, so `object_pairs_hook` catches it and the record is
    unclassified.

    AND THE PARSER IS MADE STRICT AND MADE TOTAL, which is W55360 review
    (2026-09-01T03:35:56Z) [P1] and the reason the two guards below are not
    decoration. `json.loads` is PERMISSIVE by default and it is not a total
    function, so the approved rule -- every unusable document becomes
    `unclassified` -- was not what the code did:

      `NaN`, `Infinity` and `-Infinity` are not JSON, and Python accepts them
      anyway. A record carrying one earned `api-error` from a document this
      module had just called well-formed, so `parse_constant` refuses them and
      the extension is not silently part of the accepted grammar.

      A deeply nested record inside the 64 KiB ceiling raises `RecursionError`,
      which is not a `ValueError` and escaped this function entirely -- so a
      provider could fault the worker rather than be classified by it. It is
      caught here and answers the same one word, still without the exception.
    """
    document = _provider_document(record, partial=partial)
    if document is None:
        return UNCLASSIFIED
    found = document.get("terminal_reason")
    if not isinstance(found, str):
        return UNCLASSIFIED
    return PROVIDER_FAILURE_REASONS.get(found, UNCLASSIFIED)


def _provider_document(record, *, partial):
    """Strict bounded parsing shared by the category and detail readers."""
    if partial or not record or len(record) > MAX_PROVIDER_RECORD:
        return None

    def paired(items):
        seen = {}
        for name, value in items:
            if name in seen:
                raise ValueError("a duplicated member")
            seen[name] = value
        return seen

    def refused(literal):
        raise ValueError("a non-standard constant")

    try:
        # STRICT UTF-8 AND A COMPLETE DOCUMENT. `json.loads` refuses trailing
        # data of its own, which is the other half of "one document": a record
        # with a second object after it is not a record this module read.
        document = json.loads(record.decode("utf-8"), object_pairs_hook=paired,
                              parse_constant=refused)
    except (UnicodeDecodeError, ValueError, RecursionError):
        return None
    if not isinstance(document, dict):
        return None
    return document


def _provider_diagnostic(record, *, partial):
    """Publish only typed HTTP status and an evidence-backed exact constant.

    W71879's static 2.1.247 trace is pinned in its diagnostic dossier. Result
    text can contain arbitrary exception prose, so unrecognized text and IDs
    never leave this parser. HTTP status alone does not diagnose authentication.
    Malformed, partial, oversized or unsupported records retain explicit gaps.
    """
    result = {"schema": "baton.provider-diagnostic/1", "http_status": None,
              "classification": "unknown", "explanation": None,
              "explanation_status": "unavailable", "request_id": None,
              "request_id_status": "unavailable"}
    document = _provider_document(record, partial=partial)
    if document is None or document.get("type") != "result" or document.get("subtype") != "success" or document.get("is_error") is not True or document.get("terminal_reason") != "api_error":
        return result
    code = document.get("api_error_status")
    if type(code) is int and 400 <= code <= 599:
        result["http_status"] = code
    explanation = document.get("result")
    if explanation == PROVIDER_OAUTH_EXPLANATION:
        result.update(classification="authentication_failed",
                      explanation=PROVIDER_OAUTH_EXPLANATION,
                      explanation_status="supported-constant")
    elif explanation is not None and explanation != "":
        result["explanation_status"] = "withheld"
    return result


def _diagnostic_member(provider):
    """Older injected providers and clean turns retain their existing shape."""
    diagnostic = provider.get("diagnostic")
    return {"diagnostic": diagnostic} if diagnostic is not None else {}


def _bound_member(provider):
    """WHAT ACTUALLY BOUNDED THIS TURN, for the record that reports it.

    W321528, and the one place every result publisher gets these two members
    from. Each of the three used to write `PROVIDER_SECONDS` itself, which is
    three independent chances to report a number the turn never ran under --
    and all three took it.

    SUBSCRIPTED RATHER THAN `get`. `_provider` carries the resolved bound on
    every one of its answers, including the two that never reached a child, so
    a missing member is this module disagreeing with itself and a `KeyError`
    is the correct noise. A default here would quietly restore exactly the
    defect: a publisher inventing `3600` for a turn it knows nothing about.
    """
    return {"seconds_bound": provider["seconds_bound"],
            "seconds_bound_source": provider["seconds_bound_source"]}


def _disposition(provider, patch, verification):
    """What happened, and it can only be `candidate` when everything held.

    FAILURE IS HONEST, which is the acceptance's own word. Each branch below
    is a way the turn did not produce a useful result, and none of them may be
    reported as one -- a missing credential, a provider that would not run, a
    turn that changed nothing, or a change whose own verification failed.
    """
    if not provider["ok"]:
        return "provider-failed", provider["why"]
    if not patch:
        return "no-candidate", ("the provider ended cleanly and changed "
                                "nothing in the candidate copy")
    if verification is None:
        return "no-candidate", "no verification was attempted"
    if verification["status"] != 0:
        return "verification-failed", (
            f"the task's own command ended {verification['status']}")
    return "candidate", "the candidate changed the source and its own "\
                        "verification passed"


def _line_path(place):
    """One absolute, canonical, option-safe repository path.

    Every use of this value is ARGUMENT POSITION on a command line, which is
    what makes each rule here about safety rather than tidiness: a leading dash
    is read as an option by the program that receives it, and a relative or
    traversing spelling is a path this adapter computed rather than one it was
    handed.
    """
    if type(place) is not str or not place or not place.startswith("/") \
            or place.startswith("-") or "\x00" in place \
            or ".." in place.split("/") or os.path.normpath(place) != place:
        raise TaskRefusal(
            "a prepared development line is one canonical absolute path")
    return place


def _reserved(declared):
    """The names inside this workspace that are NEVER candidate material.

    THREE KINDS, AND EACH IS SOMEBODY ELSE'S. `output.json` and its staging
    name belong to `baton_worker` and are written after this adapter returns;
    `result-*` is the manager's per-attempt result root, whose exact name
    carries a runtime attempt id this adapter is never told; and each declared
    output path is where this adapter is required to write.

    A DECLARED PATH IS A PATH, NOT A PATTERN, and one carrying a character that
    would make it behave as a pattern is refused rather than escaped. Guessing
    at an escaping is how a reservation silently stops covering the thing it
    named -- and the consequence here is not cosmetic: an unreserved output
    directory is committed into somebody's candidate.
    """
    reserved = {COMPLETION_MANIFEST, COMPLETION_STAGING, RESULT_ROOT_PATTERN}
    for one in declared:
        relative = one["path"]
        if type(relative) is not str or not relative:
            raise TaskRefusal("a declared output path is non-empty text")
        _under(relative, what="a declared output path")
        if relative != RESULT_ROOT_PATTERN and any(
                mark in relative for mark in IGNORE_METACHARACTERS):
            raise TaskRefusal(
                f"the declared output path {relative!r} carries a character "
                f"this adapter cannot reserve as an exact name; a declared "
                f"path is not an ignore pattern and is not escaped into one")
        if relative != relative.rstrip() or relative.endswith("/"):
            raise TaskRefusal(
                f"the declared output path {relative!r} has more than one "
                f"spelling as an exact reservation")
        reserved.add(relative)
    return reserved


def _reserve(repository, reserved):
    """Put the reserved names out of the candidate's reach, in the repository.

    `.git/info/exclude` IS THE RIGHT HOME and the alternatives are not. A
    committed ignore file would be this adapter proposing a change to somebody
    else's tree; a global one would outlive the container. This is repository-
    local, is never committed, and dies with the line.

    ROOT-ANCHORED, so `output.json` reserves the workspace's own completion
    envelope and not a file of that name three directories down inside the
    candidate. Every entry is written on its own line and the file is REPLACED
    rather than appended, so a resumed turn reserves exactly this set.

    OPENED BY DESCRIPTOR AT EVERY COMPONENT, for the reason every other write
    in this module is: the provider owns this workspace for part of the turn,
    and `.git` replaced by a link is how a write lands somewhere nobody
    authorized.
    """
    walking = os.open(_line_path(repository),
                      os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        # THE REPOSITORY IS REQUIRED AND `info` IS ESTABLISHED. A missing
        # `.git` is a workspace that is not the prepared line this profile was
        # promised, and creating one here would be this adapter quietly
        # building the arrangement it was supposed to have been handed.
        step = os.open(VCS_METADATA,
                       os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW,
                       dir_fd=walking)
        os.close(walking)
        walking = step
        try:
            os.mkdir("info", 0o755, dir_fd=walking)
        except FileExistsError:
            pass
        step = os.open("info", os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW,
                       dir_fd=walking)
        os.close(walking)
        walking = step
        opened = os.open("exclude",
                         os.O_WRONLY | os.O_CREAT | os.O_TRUNC | os.O_NOFOLLOW,
                         0o644, dir_fd=walking)
    except OSError as refused:
        os.close(walking)
        raise TaskRefusal(
            f"the prepared development line's own repository directory could "
            f"not be opened as its own directory ({type(refused).__name__}); "
            f"a line is materialized by the manager before the runtime starts "
            f"and is never cloned, reset or rebuilt here") from None
    os.close(walking)
    with os.fdopen(opened, "w", encoding="utf-8") as writing:
        writing.write("".join(f"/{name}\n" for name in sorted(reserved)))


def _statuses(raw):
    """`--name-status -z` as pairs, and a trailing field is a refusal.

    NUL-SEPARATED because a path may carry a newline, and `--no-renames` so
    every record is exactly two fields; a three-field rename record would make
    this parse mean something it was not written for.
    """
    fields = [one for one in raw.split("\x00") if one != ""]
    if len(fields) % 2:
        raise TaskRefusal(
            "the committed change could not be read as status-and-path pairs")
    return [(fields[index], fields[index + 1])
            for index in range(0, len(fields), 2)]


def _paths(raw):
    """`--name-only -z` as a list, held to the same canonical-path rule."""
    return [_under(one) for one in raw.split("\x00") if one != ""]


def _batch_header(raw, offset, relative):
    """One `cat-file --batch` record header: object, kind, size, and where the
    contents start.

    TERMINATED BY EITHER DELIMITER. `-Z` asks for NUL and older spellings use a
    newline; accepting whichever arrives first keeps this a parse of what was
    actually written rather than of what a flag was expected to change. A
    `missing` answer has two fields and is refused here, which is the honest
    place for it: path-set equality already proved the object should be there.
    """
    end = len(raw)
    for mark in (b"\n", b"\x00"):
        found = raw.find(mark, offset)
        if found != -1:
            end = min(end, found)
    if end >= len(raw):
        raise TaskRefusal(
            f"the committed blob inventory ends without a record for "
            f"{relative}")
    fields = raw[offset:end].decode("utf-8", "replace").split(" ")
    if len(fields) != 3 or not fields[2].isdigit():
        raise TaskRefusal(
            f"the committed tree holds no readable object for {relative}")
    return fields[0], fields[1], int(fields[2]), end + 1


def _tree_entries(raw):
    """`ls-tree -r -z` as mode-and-path pairs.

    One record is `<mode> SP <type> SP <object> TAB <path>` and the records are
    NUL-separated, which is what makes a path carrying a tab or a newline
    unable to forge a second entry. Split from the LEFT on the fixed prefix and
    once on the tab, so nothing in the path can be read as a field.
    """
    entries = []
    for record in raw.split("\x00"):
        if record == "":
            continue
        head, tab, relative = record.partition("\t")
        fields = head.split(" ")
        if not tab or len(fields) != 3:
            raise TaskRefusal(
                "the committed tree could not be read as mode, type, object "
                "and path")
        entries.append((fields[0], _under(relative, what="a committed tree "
                                          "path")))
    return entries


def _under(relative, what="a committed path"):
    """One relative, canonical path inside the candidate, and nothing else."""
    if type(relative) is not str or not relative or relative.startswith("/") \
            or ".." in relative.split("/") or "\x00" in relative:
        raise TaskRefusal(f"{what} is relative and canonical; {relative!r} "
                          f"is not")
    return relative


def _filterless(raw):
    """No path in this change may be rewritten on its way into the object.

    `check-attr -z` answers path, attribute and value in threes. A `filter`
    that is set to anything means content this adapter measured is not content
    the commit stores, and no comparison afterwards can tell the difference
    back apart -- so the turn refuses rather than publishing an account of
    bytes the object store does not hold.
    """
    fields = [one for one in raw.split("\x00") if one != ""]
    if len(fields) % 3:
        raise TaskRefusal(
            "the candidate's attribute inventory could not be read in threes")
    for index in range(0, len(fields), 3):
        relative, _attribute, value = fields[index:index + 3]
        if value not in ("unspecified", "unset"):
            raise TaskRefusal(
                f"{relative} is subject to a content filter; the bytes this "
                f"adapter verified and the bytes a commit would store are not "
                f"the same object, and this turn will not publish an account "
                f"of the difference")


# `_measured` LIVED HERE AND IS RETIRED WITH D10, not relocated: it digested
# "every checked path" for the line profile, and the line profile's checked
# set was the whole repository -- the exact whole-tree assumption the owner's
# 2026-09-21T12:41:22Z ruling removes. The delta inventory measures its own
# bytes in the same anchored no-follow read, so a second digester would be a
# second account of the same bytes.


def _task_digest(raw):
    """The frozen task's identity, as prefixed text a document may carry.

    `_bytes_digest` answers raw bytes for an in-process comparison and is
    deliberately left alone; this is the same hash rendered the way every other
    digest that crosses a boundary in this campaign is rendered, because a
    document member has to be JSON and a consumer has to be able to compare it
    to one it computed itself.
    """
    import hashlib

    return "sha256:" + hashlib.sha256(raw).hexdigest()


def _ordinary_tests(task, task_bytes, verification, base, head):
    """The actual ordinary-test observation this turn produced.

    W112029. EVERY MEMBER IS ALREADY TRUE OF THIS TURN and none of it is new
    work: the argv is the frozen task's own, the status is what this adapter
    read from the child it already ran, the digest names the exact bytes it
    read that task from, and the two objects are the ones the proposal claim
    already carries.

    UNRUN IS EXPLICITLY NULL RATHER THAN ABSENT OR ZERO. `_verify` is skipped
    when the provider failed or produced no patch, and a timeout or a failed
    start answers `None` too. All three are "this command did not produce a
    status", and a consumer that must refuse on anything but an actual zero
    needs to see the difference between that and a status it can compare. A
    missing member would make the same statement by omission, which is the one
    shape a closed reader cannot tell from a producer that forgot.
    """
    return {ORDINARY_TESTS_NAMESPACE: {
        "task_id": task["task_id"],
        "task_digest": _task_digest(task_bytes),
        "argv": list(task["verification"]),
        "status": None if verification is None else verification["status"],
        "base": base, "head": head}}


def _claim(base, head, recap):
    """The worker-owned proposal claim, and every member is this turn's own.

    FOUR FACTS AND NO FIFTH. What this turn was built on, what it produced,
    where its objects are inside its own declared output, and what it did in
    words. The manager's measurements and identities are deliberately absent:
    a worker that named an artifact id, a content digest or a custody locator
    would be certifying its own output, and the composer that reads this
    refuses exactly that.

    THE BASE IS THE IMMUTABLE ONE. On a correction round this is still the
    revision the proposal is offered against, not the head the turn started
    from -- the publication driver requires the proposal's source base to be
    the canonical target, and the entry head is not that.

    PLAIN HEX rather than an algorithm-and-name pair: the width IS the
    namespace, and the party that composes the manifest derives it by the same
    rule the profile package already fixes.
    """
    transport = _under(BUNDLE, what="the object transport")
    if len(transport) > MAX_TRANSPORT:
        raise TaskRefusal("the object transport's name is not bounded")
    return {CLAIM_NAMESPACE: {"base": base, "head": head,
                              "transport": transport,
                              "recap": recap[:MAX_RECAP]}}


def _selected(declared, produce, what):
    """Which declared outputs this role writes, and which it answers absent.

    W110772. `_one_declaration` below is unchanged and still owns the original
    single-output workload; this owns the SHARED Job, whose declaration set is
    the union of what its stages produce. The two are separate functions rather
    than one with a mode, because the single-output rule is a statement about a
    workload that declares one thing and this is a statement about a workload
    whose stages declare each other's.

    AMBIGUITY REFUSES RATHER THAN BEING GUESSED AT. A name this workload does
    not recognise is not something to spread a proposal over -- which is
    exactly the mistake `_one_declaration`'s refusal exists to prevent, and
    admitting several declarations must not quietly reintroduce it.

    AND AN OUTPUT THIS ROLE DOES NOT WRITE MAY NOT BE REQUIRED. `answered`
    refuses a required output answered `missing-optional`, which is right; a
    manager that declared the other stage's half required has made a
    declaration no single turn can satisfy, and saying so here names the
    declaration rather than the answer.
    """
    if type(declared) is not list or not declared:
        raise TaskRefusal(
            f"a {what} turn needs its declared outputs and this assignment "
            f"declares "
            f"{len(declared) if type(declared) is list else 0}")
    names = [one["name"] for one in declared]
    if len(set(names)) != len(names):
        raise TaskRefusal("this assignment declares one output name twice; a "
                          "declaration answered twice is answered by neither")
    unknown = sorted(one for one in names if one not in COMMON_OUTPUTS)
    if unknown:
        raise TaskRefusal(
            f"this assignment declares {', '.join(unknown)} and a shared Job "
            f"declares {', '.join(COMMON_OUTPUTS)}; an unrecognised "
            f"declaration is not one this workload writes to")
    by = {one["name"]: one for one in declared}
    missing = [one for one in produce if one not in by]
    if missing:
        raise TaskRefusal(
            f"a {what} turn writes {', '.join(produce)} and this assignment "
            f"declares no {', '.join(missing)}")
    absent = [by[one] for one in names if one not in produce]
    for one in absent:
        if one["required"]:
            raise TaskRefusal(
                f"output {one['name']!r} is declared required and a {what} "
                f"turn does not write it; a shared Job's stages each produce "
                f"their own half and answer the rest missing-optional")
    return [by[one] for one in produce], absent


def _absent(declarations):
    """The answer for every declared output this turn did not write."""
    return [{"name": one["name"], "status": "missing-optional",
             "result_metadata": {}} for one in declarations]


def _no_duplicates(pairs):
    """One JSON object, refused if a name is answered twice.

    A duplicate key is not a document with a last-writer-wins rule; it is a
    document whose author and whose reader disagree about what it says, and
    `json` resolves that silently in the reader's favour.
    """
    held = {}
    for name, value in pairs:
        if name in held:
            # A `ValueError`, because that is what an unreadable document
            # raises and this IS one: `json` would otherwise resolve the
            # collision silently in the reader's favour, which is a document
            # whose author and whose reader disagree about what it says.
            raise ValueError(
                f"the review report names {name!r} twice; a document with two "
                f"answers to one question has none")
        held[name] = value
    return held


def _review_report(room):
    """The provider's report, read from a proved regular file and validated.

    EVERY RULE HERE IS THIS ADAPTER'S. The report is written by the provider --
    the least trusted thing in this container and the one holding the attempt's
    bearer -- so its size, its shape, its member set and its vocabulary are all
    bounded before one byte of it reaches an output. What is adopted is a
    closed three-member document; what is published from it is the verdict word
    and the findings prose, and nothing else the provider wrote exists here to
    be published by accident.

    A MISSING OR MALFORMED REPORT IS NOT A VERDICT. It answers `None`, the turn
    is `unable`, no claim is placed on any output, and the manager's own reader
    then finds no claim and holds. An exit status is not a decision and this
    adapter will not map one into a verdict.
    """
    raw = _read_bounded(room, REVIEW_REPORT, "the review report")
    if raw is None:
        return None
    try:
        document = json.loads(raw.decode("utf-8"),
                              object_pairs_hook=_no_duplicates)
    except (UnicodeDecodeError, ValueError, RecursionError):
        # AND RECURSION IS ONE OF THE PARSER'S ANSWERS. Found by the sweep
        # review 2026-09-18T04-53-08Z [R1] asked for: this read is bounded in
        # BYTES, which is not a bound on DEPTH, and the `RecursionError` a
        # deeply nested document raises is not a `ValueError`. A malformed
        # report is not a verdict, and that has to hold for every way it can
        # be malformed.
        return None
    if type(document) is not dict \
            or sorted(document) != sorted(REVIEW_REPORT_MEMBERS):
        return None
    if document["schema"] != REVIEW_REPORT_SCHEMA:
        return None
    if document["verdict"] not in REVIEW_VERDICTS:
        return None
    findings = document["findings"]
    if type(findings) is not str or not findings.strip() \
            or len(findings) > MAX_FINDINGS:
        return None
    # AND IT MUST BE TEXT THIS ADAPTER CAN ACTUALLY WRITE. REVIEW
    # 2026-09-07T15-19-16Z [P1]: `json` decodes an escaped lone surrogate into
    # a `str` that no UTF-8 encoder will accept, so a report carrying one
    # passed every check here and then raised `UnicodeEncodeError` from the
    # `findings.txt` writer -- after the logs output had been published and
    # while the findings output was half written. Adopting text is adopting
    # the obligation to publish it, so the encode is proved at the point the
    # document is adopted and a failure takes the ordinary unable path with
    # no claim and no partial output.
    try:
        findings.encode("utf-8")
    except UnicodeEncodeError:
        return None
    return {"schema": REVIEW_REPORT_SCHEMA, "verdict": document["verdict"],
            "findings": findings}


def _read_bounded(root, relative, what):
    """At most `MAX_REPORT_BYTES` from a descriptor proved regular, or `None`.

    THE BOUND IS ON THE READ AND NOT ON A LATER CHECK. A file whose size is
    decided by the provider is a file whose read has to be bounded by this
    program, and one byte past the ceiling makes the report unusable rather
    than truncated -- a truncated JSON document is a different document.

    AND THE OPEN IS NON-BLOCKING, WHICH IS THE HALF THAT WAS MISSING. REVIEW
    2026-09-07T15-19-16Z [P1]: this routed the report through `_open_under`,
    whose final open is a blocking `O_RDONLY | O_NOFOLLOW` performed BEFORE
    `fstat` proves a regular file. A provider that creates
    `review-report.json` as a FIFO and exits successfully therefore leaves
    this adapter waiting for a writer that will never arrive -- outside the
    provider's own bounded invocation, so `PROVIDER_SECONDS` bounds nothing
    about it and the container hangs after the turn is over. The reviewer's
    probe reproduced exactly that.

    THIS BOUNDARY GETS ITS OWN OPENER RATHER THAN A REDESIGN OF THE OTHER
    ONE. `_open_under` walks every component of a path inside a tree this
    adapter measured and is correct for that; the report is one fixed name in
    a directory this adapter created exclusively for it, written by the least
    trusted process in the container. So the ordering here is
    `O_NONBLOCK` first, regular-file proof on the DESCRIPTOR second, bounded
    read third -- which is the same rule `baton_worker` and the integration
    delivery already apply to runtime-written documents, applied here.

    THE PARENT IS STILL OPENED NO-FOLLOW AND THE CHILD IS RELATIVE TO IT, so
    a link swapped in at either level is refused rather than resolved.
    """
    flags = os.O_RDONLY | os.O_NOFOLLOW | os.O_DIRECTORY
    try:
        parent = os.open(root, flags)
    except OSError:
        return None
    try:
        try:
            handle = os.open(relative,
                             os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK,
                             dir_fd=parent)
        except OSError:
            # ABSENT, A LINK, OR A DEVICE THIS PROGRAM WILL NOT OPEN. All
            # three are "no usable report", which is the unable path.
            return None
    finally:
        os.close(parent)
    try:
        found = os.fstat(handle)
        if not stat.S_ISREG(found.st_mode):
            # A FIFO REACHES HERE RATHER THAN BLOCKING ABOVE, which is the
            # whole point of the ordering: `O_NONBLOCK` on a FIFO with no
            # writer opens immediately for reading, and this is where it is
            # refused as not being a document.
            return None
        raw = os.read(handle, MAX_REPORT_BYTES + 1)
    except OSError:
        return None
    finally:
        os.close(handle)
    return None if len(raw) > MAX_REPORT_BYTES else raw


def _review_claim(verdict, observed):
    """The worker-owned checkpoint-review claim, and every member is this
    turn's own.

    FOUR FACTS AND NO FIFTH. What this reviewer decided, and the base, head and
    tree of the source it decided over. The manager compares the three objects
    against the checkpoint's own frozen evidence, so a reviewer that named
    another line's objects is refused there rather than believed here.
    """
    return {REVIEW_CLAIM_NAMESPACE: {"verdict": verdict,
                                     "base": observed["base"],
                                     "head": observed["head"],
                                     "tree": observed["tree"]}}


def _review_prompt(task, source, report):
    """The one review prompt, composed from the frozen task and nothing else.

    THE PROVIDER IS STILL NOT TOLD ABOUT THE PROTOCOL. It learns where the
    source is, that the source is read-only, what the requirements are, and
    where to put its report. It learns nothing about `/output`, the assignment,
    the attachment, the checkpoint, the session or the manager.

    THE INSTRUCTIONS ARE PRESENTED AS REQUIREMENTS TO ASSESS, not as work to
    do. This is the difference between a reviewer and a second implementer, and
    it is stated in the prompt because the same provider and the same image run
    both roles.

    AND THE VERIFICATION COMMAND IS NAMED AS A CLAIM RATHER THAN AS EVIDENCE.
    A task that names a command is not a task whose command passed; a reviewer
    that reported it as passing without running it would be reporting an
    unsubstantiated check, which is the one thing a review must not do.
    """
    return (f"You are reviewing a change on a read-only source tree at "
            f"{source}. Do not modify anything there, and do not attempt to "
            f"build, commit or edit it.\n\n"
            f"The change was made to satisfy these requirements:\n\n"
            f"{task['instructions']}\n\n"
            f"Assess whether the change at {source} meets them. Report only "
            f"checks you actually substantiated by reading the tree; the task "
            f"names the command\n"
            f"  {' '.join(task['verification'])}\n"
            f"but naming it is not evidence that it passed, and you must not "
            f"report it as passing unless you ran it yourself.\n\n"
            f"When you are done, write your decision to {report} as a JSON "
            f"object with exactly these three members:\n"
            f'  "schema": "{REVIEW_REPORT_SCHEMA}"\n'
            f'  "verdict": one of {", ".join(REVIEW_VERDICTS)}\n'
            f'  "findings": non-empty text explaining the verdict\n'
            f"Write nothing else to that path and write no other file.\n")


def _one_declaration(declared):
    """Exactly one declared output, and this workload knows which.

    A second declaration is not something to guess about: the proposal is one
    tree with one identity, and an adapter that spread itself over several
    would be inventing a shape the manager never declared.
    """
    if type(declared) is not list or len(declared) != 1:
        raise TaskRefusal(
            f"this dogfood workload declares exactly one output and this "
            f"assignment declares {len(declared) if type(declared) is list else 0}")
    return declared[0]


def _task(place=None):
    """The frozen task, held to its own closed contract."""
    return _read_task(place)[0]


def _read_task(place=None):
    """The frozen task AND the exact bytes it was read from.

    W112029: the ordinary-test observation binds `task_digest`, the SHA-256 of
    the exact bounded task bytes this turn consumed, so a consumer comparing
    its requirements against the observation compares the same document rather
    than two readings of one path. The bytes are answered from the SAME read
    that produced the document -- a second open would be a second file, and the
    whole point of the digest is that it names the first one.

    `_task` keeps exactly the contract it had, so every existing caller and
    case is unchanged.
    """
    place = place or os.path.join(INPUT_ROOT, TASK_DOCUMENT)
    try:
        with open(place, "rb") as reading:
            raw = reading.read(1 << 20)
    except OSError:
        raise TaskRefusal(
            f"this assignment has no readable {place}; the dogfood task is "
            f"one versioned document at a path this workload fixes") from None
    try:
        document = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, ValueError, RecursionError):
        # THE SAME SWEEP. A bounded read of a document this workload did not
        # write must refuse it rather than raise through the refusal
        # vocabulary that exists to describe exactly this.
        raise TaskRefusal(f"{place} is not a readable document") from None
    if type(document) is not dict:
        raise TaskRefusal(f"{place} is one JSON object")
    missing = sorted(one for one in TASK_MEMBERS if one not in document)
    extra = sorted(one for one in document if one not in TASK_MEMBERS)
    if missing or extra:
        raise TaskRefusal(
            f"{place} is exactly {', '.join(TASK_MEMBERS)}"
            + (f"; missing {', '.join(missing)}" if missing else "")
            + (f"; unexpected {', '.join(extra)}" if extra else ""))
    if document["schema"] != TASK_SCHEMA:
        raise TaskRefusal(
            f"{place} says it is {document['schema']!r} and this adapter "
            f"reads {TASK_SCHEMA!r}; a task from another generation is not "
            f"one to read the recognised parts out of")
    # W44424: TEXT BEFORE IT IS MATCHED. This read `_TASK_ID.match(str(...))`,
    # so a JSON number reached the regex as its decimal spelling and passed --
    # the identity of a versioned document decided by a coercion this module
    # performed rather than by what the document says. Every other member here
    # is held to its type before its shape, and this one was not.
    #
    # Found at the SENDER: W39358's operator refuses a numeric identity, so
    # the two ends disagreed about the same task document while an agreement
    # test compared the regex TEXT and reported them identical. That test now
    # asserts the asymmetry; this removes it.
    if type(document["task_id"]) is not str \
            or not _TASK_ID.match(document["task_id"]):
        raise TaskRefusal(f"{place} carries no usable task identity")
    for name in ("instructions", "source_root"):
        if type(document[name]) is not str or not document[name]:
            raise TaskRefusal(f"{place} carries a {name} that is not bounded "
                              f"non-empty text")
    # W39357 review [P2]: HELD BY EQUALITY, exactly as `schema` is. The
    # confirmed boundary says the adapter copies exactly `/input/source`, and
    # `SOURCE_ROOT` said so while nothing read it -- so the effective source
    # was selected by the task payload while the module and the dossier both
    # claimed it was a constant. A contained relative path is not the rule;
    # the rule is the one path this workload stages.
    if document["source_root"] != SOURCE_ROOT:
        raise TaskRefusal(
            f"{place} names source_root {document['source_root']!r} and this "
            f"workload stages exactly {SOURCE_ROOT!r}; the source is a "
            f"constant of the contract rather than a value the task selects")
    verification = document["verification"]
    if type(verification) is not list or not verification \
            or not all(type(one) is str and one for one in verification):
        raise TaskRefusal(
            f"{place} carries a verification that is a non-empty list of "
            f"words; a command this adapter has to assemble from a string is "
            f"a shell, and there is no shell here")
    # W71917: THE PROFILE AND ITS BASE, READ HERE AND NOWHERE ELSE.
    #
    # The manager carries a profile word through the input manifest as opaque
    # text for its own boundary composition and compares it against nothing;
    # this is the party that consumes the word, so this is the party that says
    # what the values are. `_task_bytes` on the host deliberately does not
    # parse this document for the same reason -- one contract, one reader.
    #
    # THE PAIRING IS THE PROFILE PACKAGE'S RULE, not a second copy of it:
    # `checkout_plan` refuses a git profile with no base and a generic profile
    # WITH one, so the pairing is validated where it is defined. What is
    # checked here is only that the two members are the shapes this document
    # may carry, which is this reader's job.
    if document["source_profile"] not in _profiles.PROFILES:
        raise TaskRefusal(
            f"{place} names source_profile "
            f"{document['source_profile']!r} and this workload consumes "
            f"{' and '.join(_profiles.PROFILES)}")
    declared = document["declared_base"]
    if declared is not None:
        try:
            _profiles.check_declared_base(declared)
        except _profiles.ProfileRefusal as refusal:
            raise TaskRefusal(f"{place} carries a declared_base this "
                              f"workload cannot use: {refusal}") from None
    return document, raw


# W177936: how much review feedback one restore prompt may carry, in UTF-8
# BYTES -- the worker twin of `provider_context.MAX_FEEDBACK_BYTES`, spelled
# here because this file travels into images that carry no manager code.
MAX_FEEDBACK_BYTES = 32768


def _prompt(task, feedback=None):
    """The one prompt, composed from the frozen task and nothing else.

    THE PROVIDER IS NOT TOLD ABOUT THE PROTOCOL. It gets the instructions, the
    working directory it is already in, and the command that will judge it --
    nothing about `/output`, the assignment, the session or the manager. A
    provider that could see those could write into them.

    W177936: A RESTORE ADDS THE REVIEW'S FEEDBACK, and this is the manager's
    `context_prompt`'s asserted twin -- the two compose byte-identical
    prompts or the bound digests refuse the turn before the provider runs.
    """
    opening = (f"{task['instructions']}\n\n"
               f"You are working in a private copy of the source tree, which "
               f"is the current working directory. Edit files here "
               f"directly.\n"
               f"When you are done, the following command will be run from "
               f"this directory and must pass:\n"
               f"  {' '.join(task['verification'])}\n")
    if feedback is None:
        return opening
    if type(feedback) is not str or not feedback \
            or len(feedback.encode("utf-8")) > MAX_FEEDBACK_BYTES:
        raise TaskRefusal("serving feedback is bounded non-empty text")
    return (f"{opening}\n"
            f"An independent review of your previous proposal in this same "
            f"working copy requested changes. Revise your work here "
            f"accordingly; the verification command above is unchanged and "
            f"must still pass.\n\n"
            f"THE REVIEW'S FINDINGS:\n{feedback}\n")


def _open_under(root, relative, what):
    """One descriptor on a regular file, proved AT EVERY PATH COMPONENT.

    W39357 review (2026-08-29T22:18:55Z) [P1]. The first round opened the
    final name with `O_NOFOLLOW`, which refuses a link only at the LAST
    component -- so `candidate/nested/claude` was still resolved through
    whatever `nested` happened to be at the moment of the open. The task's own
    verification command runs after the tree was checked and before it is
    published, it is provider-authored, and it owns that directory: replacing
    `nested` with a link to the credential root turned the mounted bearer into
    an ordinary final file.

    So the walk is done by DESCRIPTOR rather than by name. Each component is
    opened `O_NOFOLLOW | O_DIRECTORY` relative to the one above it, the final
    name is opened `O_NOFOLLOW` relative to its proved parent, and `fstat`
    proves what was actually opened. No component of the path is ever resolved
    by the kernel from a string this module composed, so there is no lookup
    left for a rename to redirect.

    A list of relative path strings is not a set of checked objects. This is
    what makes them one.
    """
    parts = relative.split(os.sep)
    try:
        walking = os.open(root, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
        try:
            for name in parts[:-1]:
                step = os.open(name,
                               os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW,
                               dir_fd=walking)
                os.close(walking)
                walking = step
            opened = os.open(parts[-1], os.O_RDONLY | os.O_NOFOLLOW,
                             dir_fd=walking)
        finally:
            os.close(walking)
    except OSError as refused:
        # THE KERNEL SPELLS IT TWO WAYS and both mean the same thing here:
        # ELOOP for a link at the final name under `O_NOFOLLOW`, ENOTDIR for
        # one at an intermediate component under `O_DIRECTORY | O_NOFOLLOW`.
        # Either says a path this module already checked is a link now, which
        # is a REFUSAL and not a fault.
        raise TaskRefusal(
            f"{what} could not be reopened at {relative} without following a "
            f"link at some component ({type(refused).__name__}: "
            f"{refused.strerror}); a link is how the credential mount reaches "
            f"an output") from None
    try:
        if not stat.S_ISREG(os.fstat(opened).st_mode):
            raise TaskRefusal(f"{what} carries a non-regular entry at "
                              f"{relative}")
    except BaseException:
        os.close(opened)
        raise
    return opened


def _read_under(root, relative, what):
    """One file under `root`, read whole from a descriptor proved regular."""
    descriptor = _open_under(root, relative, what)
    try:
        with os.fdopen(descriptor, "rb", closefd=False) as reading:
            return reading.read()
    finally:
        os.close(descriptor)


def _revalidated(root, written, measured, *, what, skip=None):
    """The checked tree, PROVED UNCHANGED, before one output byte is written.

    W39357 review (2026-08-29T22:51:53Z) [P1]. The first cut of this reopened
    each recorded path and proved it was still a regular file -- which holds
    the path's TYPE and says nothing about its bytes. The verification command
    is provider-authored, it runs after `_diff` measured the candidate and
    before `_publish` reads it, and overwriting an already-checked regular
    file in place needs no link, no rename and no new inode. The proposal then
    carried bytes that neither `change.patch` nor `changed_paths` described,
    and the mounted bearer is one of the things those bytes could be.

    So this proves three things, in the order that makes each cheap:

      1. THE CEILINGS AGAIN, over a fresh walk. A fixed list could not see
         what verification ADDED or how much it GREW, so the bound the module
         advertises stopped applying at exactly the moment untrusted code ran.
      2. EVERY MEASURED PATH IS STILL THERE. A checked file the command
         deleted is not something to publish an account of.
      3. EVERY MEASURED FILE STILL HAS THE BYTES THE PATCH DESCRIBES.

    WHAT IT DOES NOT DO is decide whether an ADDITION is allowed. A
    verification command that leaves a cache directory behind has not
    invalidated anybody's evidence: what it added was never measured and is
    never published, and the fresh walk still counts it against the ceilings.
    Refusing those would make ordinary tooling a fault; publishing them would
    put unmeasured bytes in the proposal. Neither is what this wants.
    """
    _checked_tree(root, what=what, skip=skip)
    for relative in written:
        if _bytes_digest(_read_under(root, relative, what)) \
                != measured[relative]:
            raise TaskRefusal(
                f"{what} changed at {relative} after its own verification "
                f"command ran; the proposal's patch describes the bytes this "
                f"adapter measured, and a candidate whose contents no longer "
                f"match that account is not one to publish")


def _checked_tree(root, *, what, skip=None):
    """Every entry under a tree, REVALIDATED, whoever wrote it.

    W105575: `skip` NAMES TOP-LEVEL ENTRIES THIS WALK DOES NOT DESCEND, and it
    is passed in rather than decided here for `_copy_tree`'s reason. Under a
    prepared development line the candidate root IS the workspace, so it holds
    the repository's own object store and the reserved names the manager and
    the worker write into -- none of which is candidate material, and all of
    which would otherwise be measured, bounded and published as though it
    were. A caller with no such arrangement passes nothing and walks
    everything, exactly as before.

    W39357 review [P1]: `_copy_tree` checked the STAGED source, and the
    provider owns the candidate afterwards -- so the diff walked and the
    publication copied a tree nothing had looked at since. Both follow a file
    symlink, and one of the things reachable through the container is the
    credential mount.

    So the provider-authored tree is held to the same rules the staged one is,
    at the moment it is used rather than at the moment it was made: regular
    files and directories only, no link at any depth, and bounded on both
    axes. Answers the sorted relative paths, which is all either caller needs.

    W39357 review (2026-08-29T22:18:55Z) [P2]: EVERY ENTRY THE WALK TOUCHES
    counts against the ceiling, directories as well as files. Counting only
    files left the traversal bounded by tmpfs inodes and wall-clock rather
    than by the number this module advertises -- a provider that made a
    million empty directories crossed no stated bound at all.
    """
    found, entries, total = [], 0, 0
    for base, directories, files in os.walk(root, followlinks=False):
        if skip is not None and base == root:
            # ONLY AT THE ROOT. A reservation is an anchored name -- the
            # workspace's own `output.json`, not one three directories down
            # inside somebody's candidate -- so a walk that pruned the same
            # names at every depth would be silently dropping material this
            # turn is supposed to publish.
            directories[:] = [name for name in directories
                              if not _reservation(name, skip)]
            files[:] = [name for name in files if not _reservation(name, skip)]
        for name in directories:
            if os.path.islink(os.path.join(base, name)):
                raise TaskRefusal(
                    f"{what} carries a link at "
                    f"{os.path.relpath(os.path.join(base, name), root)}")
            entries += 1
            _bounded(entries, total, what)
        for name in files:
            full = os.path.join(base, name)
            held = os.lstat(full)
            if not stat.S_ISREG(held.st_mode):
                raise TaskRefusal(
                    f"{what} carries a non-regular entry at "
                    f"{os.path.relpath(full, root)}"
                    + ("; a link is how the credential mount reaches an output"
                       if stat.S_ISLNK(held.st_mode) else ""))
            found.append(os.path.relpath(full, root))
            entries += 1
            total += held.st_size
            _bounded(entries, total, what)
    return sorted(found)


def _reservation(name, skip):
    """Whether one top-level entry is reserved, the same way Git ignores it.

    The reserved set is literal names plus the ONE deliberate namespace glob
    this workload owns, and that glob is matched here by the same prefix rule
    the pattern written into the exclude file expresses. Nothing else in the
    set is treated as a pattern, which is why `_reserved` refuses a declared
    path that could be read as one.
    """
    if name in skip:
        return True
    return RESULT_ROOT_PATTERN in skip \
        and name.startswith(RESULT_ROOT_PATTERN[:-1])


def _bounded(entries, total, what):
    """The one ceiling both walks are held to, counted the same way."""
    if entries > MAX_SOURCE_ENTRIES or total > MAX_SOURCE_BYTES:
        raise TaskRefusal(
            f"{what} exceeds this adapter's bound of "
            f"{MAX_SOURCE_ENTRIES} entries / {MAX_SOURCE_BYTES} bytes")


def _copy_tree(source, into, *, skip=None):
    """The baseline tree, copied into the workspace, bounded and no-follow.

    REGULAR FILES AND DIRECTORIES ONLY. A link in the staged tree is a way for
    the copy to reach outside it, and the manager already refuses one at
    delivery -- this is the second party proving it rather than assuming the
    first did.

    W71917: `skip` NAMES ONE DIRECTORY THIS COPY DOES NOT DESCEND, and it is
    passed in rather than decided here. The only caller passes the
    version-control metadata directory, and only when the assignment DECLARED
    the git profile -- so nothing is inferred from what a tree looks like, and
    a generic profile's directory of the same name is ordinary material. A
    checkout's object store is not part of the candidate: copying it would put
    tens of thousands of entries through the bound below and describe every one
    of them in a patch nobody asked for.
    """
    if not os.path.isdir(source):
        raise TaskRefusal(f"this assignment stages no source tree at {source}")
    what = "the staged source"
    entries, total, copied = 0, 0, 0
    for base, directories, files in os.walk(source, followlinks=False):
        if skip is not None and skip in directories:
            directories.remove(skip)
        for name in directories:
            if os.path.islink(os.path.join(base, name)):
                raise TaskRefusal(
                    f"{what} carries a link at "
                    f"{os.path.relpath(os.path.join(base, name), source)}")
            # Review [P2]: directories count here too. The staged tree is the
            # manager's and already measured, but this is the second party
            # proving it -- and a second party that counts differently from
            # the walk it is checking is not proving the same thing.
            entries += 1
            _bounded(entries, total, what)
        for name in files:
            full = os.path.join(base, name)
            if os.path.islink(full) or not os.path.isfile(full):
                raise TaskRefusal(
                    f"{what} carries a non-regular entry at "
                    f"{os.path.relpath(full, source)}")
            entries += 1
            copied += 1
            total += os.path.getsize(full)
            _bounded(entries, total, what)
            relative = os.path.relpath(full, source)
            landing = os.path.join(into, relative)
            os.makedirs(os.path.dirname(landing), exist_ok=True)
            shutil.copyfile(full, landing)
    if not copied:
        raise TaskRefusal(f"the staged source at {source} is empty")
    return copied


def _diff(source, candidate, written, *, skip=None):
    """Which paths the provider changed, the unified diff, AND what was read.

    W39357 review (2026-08-29T22:51:53Z) [P1]: this measured the candidate and
    kept nothing about what it had measured, so `change.patch` described one
    set of bytes and `_publish` copied whatever was on disk later. It answers
    the digest of every candidate file it read as well, and that digest is
    what binds the two.

    COMPUTED IN THE WORKER, WITHOUT GIT. `change.patch` is a review
    convenience and never the custody identity -- the operator diffs the
    collected candidate tree against the recorded input manifest, which is a
    comparison this file cannot influence. Git is a workload convention this
    image deliberately does not carry.
    """
    import difflib

    changed, measured = {}, {}
    for relative in written:
        # EVERY READ IS ROOTED AND NO-FOLLOW AT EVERY COMPONENT. The candidate
        # side is the provider's tree; the staged side is the read-only bind
        # `_copy_tree` already proved, and it is read the same way so that one
        # rule covers both rather than two rules covering one each.
        raw = _read_under(candidate, relative, "the candidate copy")
        measured[relative] = _bytes_digest(raw)
        after = _split(raw)
        original = (_lines(source, relative, "the staged source")
                    if os.path.exists(os.path.join(source, relative))
                    else None)
        if original == after:
            continue
        changed[relative] = "".join(difflib.unified_diff(
            original or [], after,
            fromfile=f"a/{relative}" if original is not None else "/dev/null",
            tofile=f"b/{relative}"))
    for base, directories, files in os.walk(source, followlinks=False):
        # THE SAME DIRECTORY THE COPY SKIPPED. Walking it here would report
        # every object file as a deletion, because the candidate never had one.
        if skip is not None and skip in directories:
            directories.remove(skip)
        for name in files:
            relative = os.path.relpath(os.path.join(base, name), source)
            if relative in written:
                continue
            changed[relative] = "".join(difflib.unified_diff(
                _lines(source, relative, "the staged source"), [],
                fromfile=f"a/{relative}", tofile="/dev/null"))
    return changed, measured


def _lines(root, relative, what):
    """One file's lines, opened no-follow at EVERY component.

    Review [P1]: this was `open(place)`, which follows a link at any depth --
    so the diff read whatever a provider-created link named and the bearer
    landed in `change.patch`.
    """
    return _split(_read_under(root, relative, what))


def _split(raw):
    return raw.decode("utf-8", "replace").splitlines(True)


def _bytes_digest(raw):
    """One file's identity as BYTES, which is the only thing that binds them.

    W39357 review (2026-08-29T22:51:53Z) [P1]. Path type is not content: the
    provider-authored verification command can overwrite an already-checked
    REGULAR file in place, no link and no rename involved, and a walk that
    proves shape accepts it. The bytes the patch measured and the bytes the
    proposal carries are held together by this and nothing else.

    IT IS NOT AN INSPECTION. Nothing here decides what the bytes MEAN, no
    digest is published, and a mismatch refuses rather than reporting what it
    saw -- which matters because the thing a verification command is most
    usefully caught substituting is the mounted bearer.
    """
    import hashlib

    return hashlib.sha256(raw).digest()


def _publish(proposal, candidate, written, measured, patch, verification,
             result):
    """The declared tree, written group-readable and in one order.

    `result.json` LAST of the four, so a reader that finds it finds the rest
    beside it. It is bounded application metadata and the acceptance says in
    terms that it is never an identity substitute -- the worker's own
    `/output/output.json`, published after this returns, is the protocol
    document.
    """
    _made(proposal)
    tree = os.path.join(proposal, CANDIDATE)
    _made(tree)
    # THE CHECKED LIST, AND A NO-FOLLOW READ OF EACH ENTRY. `shutil.copyfile`
    # opens the source by NAME and follows a link, which is exactly how the
    # credential became an output file; the copy is done from a descriptor
    # this module proved regular instead.
    for relative in written:
        landing = os.path.join(tree, relative)
        _made(os.path.dirname(landing))
        # READ ONCE, PROVED, THEN WRITTEN -- the bytes that go into the
        # proposal are the same object that was just held against the patch's
        # measurement, so there is no third reading for anything to differ
        # between. `_revalidated` has already refused a mismatch before this
        # function created anything; this is the same proof at the moment of
        # use, which is what keeps the guarantee from resting on the interval
        # between the two.
        raw = _read_under(candidate, relative, "the candidate copy")
        if _bytes_digest(raw) != measured[relative]:
            raise TaskRefusal(
                f"the candidate copy changed at {relative} while its proposal "
                f"was being written")
        with open(landing, "wb") as writing:
            writing.write(raw)
        os.chmod(landing, FILE_MODE)
    _written(os.path.join(proposal, PATCH),
             "".join(patch[one] for one in sorted(patch)))
    _written(os.path.join(proposal, VERIFICATION),
             verification["text"] if verification is not None
             else "no verification was attempted\n")
    _written(os.path.join(proposal, RESULT),
             json.dumps(result, indent=1, sort_keys=True) + "\n")


def _made(place):
    os.makedirs(place, exist_ok=True)
    os.chmod(place, DIRECTORY_MODE)


def _discarded(place, name):
    """One member of this adapter's own declared output, removed if it is there.

    BY EXACT NAME AND THROUGH A DESCRIPTOR on the directory, so the removal
    cannot be redirected by a link that appeared at the output root. Absence is
    the ordinary case and is not an error: this exists to make a member's
    ABSENCE a fact about THIS turn rather than an inheritance from the last one
    that used the same persistent workspace.
    """
    try:
        holding = os.open(place, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    except OSError as refused:
        raise TaskRefusal(
            f"the declared output at {place} is not its own directory "
            f"({type(refused).__name__})") from None
    try:
        os.unlink(name, dir_fd=holding)
    except FileNotFoundError:
        pass
    except OSError as refused:
        raise TaskRefusal(
            f"a previous attempt's {name} could not be removed from this "
            f"turn's declared output ({type(refused).__name__}); a member "
            f"this turn did not produce is not one it will publish") from None
    finally:
        os.close(holding)


def _written(place, body):
    with open(place, "w", encoding="utf-8") as writing:
        writing.write(body)
    os.chmod(place, FILE_MODE)


# `_window` WAS HERE, and it is gone rather than corrected a third time. It
# read a bounded window of a captured child stream back into this process --
# first from a pathname a child could replace, then from a held descriptor.
# Both were answers to "how do we read this untrusted stream safely", and
# W39357 review (2026-08-30T04:01:29Z) [P1] is the finding that the question
# was wrong: the stream is written by a process holding this attempt's
# credential, so no amount of care about HOW it is read makes the bytes
# publishable. Nothing reads a child stream now, so nothing needs a window.


def _digest(value):
    import hashlib

    return "sha256:" + hashlib.sha256(
        json.dumps(value, sort_keys=True,
                   separators=(",", ":")).encode("utf-8")).hexdigest()
