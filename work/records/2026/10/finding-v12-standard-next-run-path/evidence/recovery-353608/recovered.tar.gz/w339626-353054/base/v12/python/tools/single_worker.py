"""One trusted production composition for one v12 implementation worker.

W76207.  The persistent Job Manager intentionally knows how to derive WHEN an
offer, claim or launch is owed and knows nothing about HOW a deployment opens
an Authority, stages input, delivers credentials or starts an OCI runtime.
This module is that missing deployment half for the bootstrap worker only.

The public factory is ``tools.single_worker:factory``.  It reads one closed
configuration document from the absolute path named by
``BATON_V12_SINGLE_WORKER_CONFIG``.  The environment carries only that path:
the offer bearer is fresh process memory and provider credential bytes are
read lazily through ``tools.user_credentials`` from the private registry path
the document names.

This is deliberately not a pool.  One configuration fixes one Authority,
participant/principal, implementation Work input, profile, OCI adapter and
workspace policy.  Anything else refuses; worker choice and capacity belong
to W71877.
"""

import json
import os
import re
import stat
import subprocess
import threading
from datetime import datetime, timezone

from baton_v12.authority import Authority, Refusal, claim_signature
from baton_v12.worker_manager import tokens
from baton_v12.contracts import (ContractRefusal, check_manifest_structure,
                                 check_no_durable_secret, digest,
                                 digest_of_bytes, job_input_identity)
from baton_v12.contracts.errors import label_of
from baton_v12.job_manager import ManagerOperations, RefreshUnavailable
from baton_v12.worker_manager import (AuthorityPort, DISPOSITIONS,
                                      RETENTION_DISPOSITIONS, accept_offer,
                                      activate_assignment,
                                      attempt_preparation_failure_of,
                                      attempt_runtime_of,
                                      attempt_start_failure_of,
                                      authorize_cleanup, certify_profile,
                                      claimed_offers_for,
                                      configure_workspace_group,
                                      configured_workspace_group,
                                      decide_retention, label_context,
                                      load_manifest, observe,
                                      pin_boundary_identity,
                                      reconcile_runtime, record_attempt,
                                      refuse_runtime_preparation,
                                      request_freeze, request_intake,
                                      request_runtime_start, retain_manifest,
                                      boundary_identity_of)
from baton_v12.worker_manager import (ControlStore, attempts, boundaries,
                                      credentials, exchange, intake, launch,
                                      source_boundary, workspaces)
from baton_v12.worker_manager.oci import ENGINES, EnginePort, OciAdapter

from tools.user_credentials import SourceRefusal, UserCredentialSources

__all__ = ["CONFIG_ENV", "CONFIG_SCHEMA", "factory", "operations_from",
           "worker_operations", "worker_preflight",
           "JudgmentExecution"]

CONFIG_ENV = "BATON_V12_SINGLE_WORKER_CONFIG"
# W81115 MOVED THIS TO `/2`, and its reason is kept because the rule is the
# same one applied twice. `/2` added one required member -- the frozen task
# document -- and adding a required member to a closed, version-named document
# is a NEW CONTRACT rather than a compatible reading of the old one. A `/1`
# document is refused by the equality test below rather than accepted with a
# task nobody named.
#
# W81857: SCHEMA `/3`, AND THE VERSION MOVED BECAUSE THE DOCUMENT DID AGAIN.
#
# `/3` carries three required members `/2` never had, and every one of them is
# a decision this deployment could not previously make because it had nothing
# to make it about: until now the composition started a container and stopped.
# `review_route` is where an answered, frozen, taken-into-custody result is
# handed on; `retention_policy_digest` and `retention_disposition` are what is
# decided about the untrusted bytes before that handoff. There is deliberately
# no fallback and no default for any of them -- a deployment that could end an
# attempt without saying where the result goes would be choosing a destination
# nobody named.
#
# W71917: SCHEMA `/4`, AND THE SOURCE MEMBER MEANS SOMETHING ELSE NOW.
#
# `/3`'s `input_source` was an ALREADY-STAGED directory this deployment
# measured and COPIED into the input root. `/4` replaces it with
# `nominated_source`: a directory this deployment validates and MOUNTS
# read-only, and never walks, copies, snapshots, enumerates or hashes.
#
# THE MEMBER IS RENAMED RATHER THAN REDEFINED, and that is the point of doing
# it at a version boundary. The two mean different things about the same host
# path -- one is material this manager took custody of, the other is material
# it agreed not to touch -- and a member that quietly changed meaning under one
# name is exactly how a deployment ends up believing a copy happened. A `/3`
# document naming `input_source` is refused by the member set below rather than
# read as a nomination.
#
# `workspace_capacity` ARRIVES WITH IT because the two are one decision. Once
# the source is not copied in, the writable workspace is the only place a
# checkout, a build cache, test artifacts, the output and the logs can live --
# so how large it needs to be stops being incidental and becomes something the
# deployment has to say. There is no default: a size inherited from whatever
# the host happened to have is not a deployment's decision.
#
# IT DECLARES A NEED AND DOES NOT IMPOSE A CEILING, and W71917 rules that the
# member says so. This factory proves the workspace's filesystem currently has
# the declared bytes free before it starts anything; the bind it then composes
# is ordinary and writable, so a worker can fill that filesystem afterwards.
# Naming the member `workspace_quota` over that mechanism is the defect the
# run7 review found, and a deployment reading its own configuration is exactly
# who the wrong name misleads.
CONFIG_SCHEMA = "baton.v12.single-worker-deployment/4"
CONTEXT_CONFIG_SCHEMA = "baton.v12.single-worker-deployment/5"
MAX_CONFIG_BYTES = 1024 * 1024

# W81115: THE TWO NAMES THE CERTIFIED WORKLOAD FIXES, mirrored here rather than
# imported. `claude_agent` runs INSIDE the image, on its own interpreter and
# import path; a host composer that imported it would be reaching across the
# boundary the whole delivery exists to cross, and would take its
# provider-specific task parser with it. What keeps the two copies honest is
# not an import but a test: the receiving-end fixture drives the real worker
# entry over the root this deployment composes and asserts these names against
# the workload's own constants.
TASK_DOCUMENT = "task.json"
SOURCE_DESTINATION = "source"
# THE WORKER'S OWN READ CEILING. `claude_agent._task` reads at most 1 MiB and
# a document wider than that is one it will never see whole, so this refuses it
# at configuration time rather than delivering material the receiving end
# cannot accept.
MAX_TASK_BYTES = 1024 * 1024

_MEMBERS = (
    "schema", "authority_store", "authority_uuid", "participant",
    "principal", "profile_name", "profile_digest", "policy_digest",
    "adapter_name", "adapter_digest", "engine", "image_digest", "network",
    "workspace_storage", "workspace_group", "launch_home",
    "credential_home", "credential_sources", "credential_slots",
    "credential_profile", "nominated_source", "workspace_capacity",
    "input_manifest", "task_document",
    "launch_contract", "launch_role", "review_route",
    "retention_policy_digest", "retention_disposition")
_DIGEST = re.compile(r"\Asha256:[0-9a-f]{64}\Z")
_NETWORK = re.compile(r"\A[a-zA-Z0-9][a-zA-Z0-9_.-]{0,127}\Z")


def _refuse(message, *, category="integrity", code="schema"):
    raise ContractRefusal(category, code, message)


def _text(value, what):
    if type(value) is not str or not value:
        _refuse(f"{what} is non-empty text; this is {type(value).__name__}")
    try:
        value.encode("utf-8")
    except UnicodeEncodeError:
        _refuse(f"{what} is text this deployment can encode")
    return value


def _path(value, what):
    held = _text(value, what)
    if "\x00" in held or held.startswith("//") or not os.path.isabs(held) \
            or os.path.normpath(held) != held:
        _refuse(f"{what} is one absolute canonical path", code="path")
    return held


def _digest(value, what):
    held = _text(value, what)
    if not _DIGEST.match(held):
        _refuse(f"{what} is one lower-case sha256 digest", code="digest")
    return held


def _document(value, what, members):
    if type(value) is not dict:
        _refuse(f"{what} is one JSON object; this is {type(value).__name__}")
    missing = sorted(one for one in members if one not in value)
    extra = sorted(one for one in value if one not in members)
    if missing or extra:
        _refuse(f"{what} has exactly {', '.join(members)}"
                + (f"; missing {', '.join(missing)}" if missing else "")
                + (f"; unexpected {', '.join(extra)}" if extra else ""))
    return value


def _read(path):
    """Read one ordinary no-follow configuration file, bounded at the read."""
    place = _path(path, "the single-worker configuration path")
    try:
        handle = os.open(place, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
    except OSError as failure:
        _refuse(f"the single-worker configuration could not be opened "
                f"({type(failure).__name__})", code="path")
    try:
        found = os.fstat(handle)
        if not stat.S_ISREG(found.st_mode):
            _refuse("the single-worker configuration is one ordinary file",
                    code="path")
        pieces = []
        remaining = MAX_CONFIG_BYTES + 1
        while remaining:
            part = os.read(handle, remaining)
            if not part:
                break
            pieces.append(part)
            remaining -= len(part)
    finally:
        os.close(handle)
    raw = b"".join(pieces)
    if len(raw) > MAX_CONFIG_BYTES:
        _refuse(f"the single-worker configuration is wider than "
                f"{MAX_CONFIG_BYTES} bytes", code="limit")
    try:
        return json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, ValueError) as failure:
        _refuse(f"the single-worker configuration is one UTF-8 JSON "
                f"document ({type(failure).__name__})")


def _held(document, *, roles=("implementation",)):
    """Own and relate every static deployment choice before an offer exists."""
    contextual = type(document) is dict and document.get("schema") == CONTEXT_CONFIG_SCHEMA
    given = dict(_document(document, "a single-worker configuration", _MEMBERS + (("provider_context",) if contextual else ())))
    if given["schema"] not in (CONFIG_SCHEMA, CONTEXT_CONFIG_SCHEMA):
        _refuse(f"a single-worker configuration says {given['schema']!r}; "
                f"this deployment reads {CONFIG_SCHEMA!r}")
    for member in ("authority_store", "workspace_storage", "launch_home",
                   "credential_home", "nominated_source", "task_document"):
        given[member] = _path(given[member], f"the configuration's {member}")
    if given["credential_sources"] is not None:
        given["credential_sources"] = _path(
            given["credential_sources"],
            "the configuration's credential_sources")
    for member in ("authority_uuid", "participant", "principal",
                   "profile_name", "adapter_name", "engine", "network",
                   "launch_contract", "launch_role", "review_route",
                   "retention_disposition"):
        given[member] = _text(given[member],
                              f"the configuration's {member}")
    for member in ("profile_digest", "policy_digest", "adapter_digest",
                   "image_digest", "retention_policy_digest"):
        given[member] = _digest(given[member],
                                f"the configuration's {member}")
    if len(given["authority_uuid"]) != 32:
        _refuse("the configuration's authority_uuid is 32 characters")
    if given["engine"] not in ENGINES:
        _refuse(f"the configured engine is one of {', '.join(ENGINES)}",
                category="policy", code="denied")
    if not _NETWORK.match(given["network"]):
        _refuse("the configured network is one bounded OCI network name",
                category="policy", code="denied")
    group = given["workspace_group"]
    if type(group) is not int or type(group) is bool or group <= 0:
        _refuse("the configured workspace_group is one positive group id")
    manifest = check_manifest_structure(
        given["input_manifest"], "inputManifest",
        what="the configured bootstrap input manifest")
    given["input_manifest"] = manifest
    if manifest["runtime_profile_digest"] != given["profile_digest"]:
        _refuse("the bootstrap input manifest names another runtime profile",
                category="refused", code="precondition")
    if manifest["policy_digest"] != given["policy_digest"]:
        _refuse("the bootstrap input manifest names another policy",
                category="refused", code="precondition")
    if manifest["worker_image_digest"] != given["image_digest"]:
        _refuse("the bootstrap input manifest names another worker image",
                category="refused", code="precondition")
    if manifest["work_ref"]["authority_uuid"] != given["authority_uuid"]:
        _refuse("the bootstrap input manifest names another Authority",
                category="refused", code="precondition")
    if manifest["assignment_contract"] != given["launch_contract"]:
        _refuse("the bootstrap input manifest names another assignment "
                "contract", category="refused", code="precondition")
    # W81857: THE RETENTION DISPOSITION IS THE MANAGER'S OWN CLOSED
    # VOCABULARY, checked here rather than at the act. A configuration naming a
    # word `decide_retention` refuses would start a container, run a provider,
    # freeze and collect its result, and only then discover that nothing may be
    # decided about it -- which is the whole class of failure this preflight
    # exists to move to startup.
    if given["retention_disposition"] not in RETENTION_DISPOSITIONS:
        _refuse(f"the configured retention_disposition is one of "
                f"{', '.join(RETENTION_DISPOSITIONS)}",
                category="policy", code="denied")
    # W103083: WHICH ROLES THIS READING ADMITS, and the default is exactly the
    # rule that stood here. The bootstrap deployment launches one
    # implementation worker and nothing else, so `operations_from`, `factory`
    # and `observation_from` all read with the default and refuse `review` and
    # `integration` as they always did. A composer that serves three stages
    # over one Authority passes the roles it composes -- which is a widening
    # made at ONE call site by a caller that owns the composition, rather than
    # a second copy of this whole preflight with one word changed.
    if given["launch_role"] not in roles:
        _refuse(f"this deployment launches "
                f"{' or '.join(roles)} and this configuration names "
                f"{given['launch_role']!r}", category="policy", code="denied")
    if len(manifest["sources"]) != 1:
        _refuse("the bootstrap deployment accepts exactly one staged source",
                category="policy", code="denied")
    # W81115: AND ITS DESTINATION IS THE ONE THE WORKLOAD STAGES.
    #
    # The certified task contract fixes `source_root` to `source` and the
    # adapter copies exactly `/input/source`, so a manifest naming any other
    # destination composes a root the worker cannot use -- which is how this
    # deployment reached `running` with both fixed worker paths absent. The
    # check also reserves the task document's name from a source directory
    # that would collide with it.
    #
    # W71917 REPLACES THE COPY, NOT THIS RULE. Its ruled direct read-only mount
    # lands the same fixed path; what this pins is the path, which is the part
    # the worker fixes.
    if manifest["sources"][0]["destination"] != SOURCE_DESTINATION:
        _refuse(f"the bootstrap input manifest stages its source at "
                f"{manifest['sources'][0]['destination']!r} and the certified "
                f"workload reads exactly {SOURCE_DESTINATION!r}",
                category="policy", code="denied")
    # W71917: THE SOURCE IS NOMINATED, NOT STAGED, and the descriptor beside
    # it has to say so. `declared_profile` refuses a descriptor carrying no
    # boundary declaration, which is what a `/3` manifest for a COPIED source
    # is -- so a deployment that moved its configuration to `/4` and left its
    # frozen manifest describing a staging is refused here rather than
    # delivering a mount the manifest does not describe. The profile it
    # answers is bounded opaque text; this deployment carries it and reads
    # nothing into it, exactly as the manager does.
    given["source_profile"] = source_boundary.declared_profile(
        manifest["sources"][0])
    # AND THE NOMINATION IS PROVED BEFORE THE AUTHORITY IS OPENED, which is
    # where every other static check in this preflight already happens: a
    # source that is a link, is not a directory, or has a linked ancestor is a
    # configuration mistake, and finding it here means no attempt root exists
    # to leave partial. What it costs is one `lstat` and one `fstat` whatever
    # is inside the tree.
    given["source_nomination"] = source_boundary.nominate_source(
        given["nominated_source"])
    given["workspace_capacity"] = _capacity(given["workspace_capacity"])
    given["task_bytes"] = _task_bytes(given["task_document"],
                                      manifest["human_contract"])
    if type(given["credential_slots"]) is not list:
        _refuse("the configuration's credential_slots is one list")
    if type(given["credential_profile"]) is not dict:
        _refuse("the configuration's credential_profile is one object")
    given["credential_resolution"] = credentials.resolved_delivery(
        given["credential_slots"], profile=given["credential_profile"])
    # W81857: THE PRODUCTION LAUNCH IS `/2`, and the preflight authors the
    # exact version this deployment will write. Proving `/1` and then writing
    # `/2` would be proving a document nothing composes.
    launch.launch_document(session="single-worker-preflight",
                           contract=given["launch_contract"],
                           role=given["launch_role"],
                           transport=exchange.EXCHANGE_TRANSPORT)
    # W71917 RETIRED THE MEASUREMENT THAT STOOD HERE, and its absence is the
    # Work rather than a dropped check.
    #
    # `/3` called `workspaces.directory_manifest(input_source)` and compared it
    # with the manifest's declared `contentManifest`. That is a full no-follow
    # walk of the nominated tree -- every file opened, read whole and digested
    # -- performed by a manager that is ruled not to walk, copy, snapshot,
    # enumerate or hash the source at all. It also could not have kept its
    # promise: the tree it measured was measured before the container started,
    # and nothing bound the bytes the engine later mounted to the bytes this
    # walk read.
    #
    # WHAT REPLACES IT IS NOT A WEAKER VERSION OF IT. The declared
    # `contentManifest` for a nominated destination describes the empty
    # MOUNTPOINT this manager stages, which is a statement this manager can
    # keep; `_source_manifest` below holds the configuration to exactly that,
    # so a manifest still claiming to have measured somebody else's tree is
    # refused. Which revision the material actually is, is the worker's
    # question, answered against the base its own profile declares -- and it is
    # answered inside the container, over the tree that is really mounted.
    _source_manifest(manifest["sources"][0])
    if contextual:
        selected = _document(given["provider_context"], "required provider context", ("mode", "storage", "profile_digest"))
        if selected["mode"] != "required" or given["launch_role"] != "implementation" or given["retention_disposition"] != "retain":
            _refuse("required provider context is retained implementation only", category="policy", code="denied")
        given["provider_context"] = {"mode": "required", "storage": _path(selected["storage"], "context storage"), "profile_digest": _digest(selected["profile_digest"], "context profile")}
        _context_declaration(manifest["outputs"])
    elif any(one["name"] == "provider-context-receipt" for one in manifest["outputs"]):
        _context_declaration(manifest["outputs"])
        if given["launch_role"] == "implementation":
            _refuse("reserved context receipt requires context implementation deployment")
    return given


# The `contentManifest` of an empty tree, which is what this deployment stages
# at a nominated destination. Written as the four members rather than measured,
# because measuring an empty directory this deployment created to compare
# against a constant would be a walk performed to learn something already
# known.
EMPTY_TREE_DIGEST = digest([])


def _source_manifest(source):
    """Hold a nominated source descriptor to the empty tree it really stages.

    W71917. A nominated source is MOUNTED, so what this deployment puts in the
    input root at that destination is an empty mountpoint -- and the frozen
    manifest's `contentManifest` for it must describe exactly that. A manifest
    declaring 353 entries and eleven megabytes at a destination this manager
    stages nothing into is not a smaller mistake than a wrong digest: it is
    the whole staged-versus-nominated confusion, written into the document a
    result is later measured against.

    THIS IS NOT A MEASUREMENT OF THE NOMINATED TREE and cannot become one. It
    reads four numbers out of the configuration and compares them with
    constants; nothing under the nominated path is opened, and the check costs
    the same whatever is behind the mount.
    """
    content = source["content_manifest"]
    expected = {"entries": [], "entry_count": 0, "total_bytes": 0,
                "tree_digest": EMPTY_TREE_DIGEST}
    if content != expected:
        _refuse("the bootstrap input manifest declares content at a NOMINATED "
                "source destination; this deployment mounts that directory "
                "read-only and stages an empty mountpoint, so the declared "
                "contentManifest is the empty tree's or it describes material "
                "nobody staged", code="digest")
    return content


def _capacity(capacity):
    """The deployment's declared workspace capacity, owned then composed.

    ONE MEMBER AND NO MORE, read here so the refusal names the configuration
    member a deployment can fix, and then handed to the manager's own
    `workspace_capacity` -- which is what holds it to the floor above bounded
    scratch and to this build's ceiling. One rule, at its owner.

    THE ENTRY COUNT IS GONE RATHER THAN CARRIED, because W71917 rules that this
    document may not declare what nothing applies. `max_entries` was validated
    here, passed down, and then reached no mount, no runtime and no sweep; a
    deployment that set it was answering a question this delivery never asked.
    A closed member set makes the removal a refusal rather than a silent
    ignore, which is the point of removing it from the set rather than merely
    from the docstring.
    """
    given = _document(capacity, "the configuration's workspace_capacity",
                      ("max_bytes",))
    return source_boundary.workspace_capacity(given["max_bytes"])


def _task_bytes(place, contract):
    """The frozen workload document, READ ONCE and held as exact bytes.

    W81115. `single_worker` composed an input root carrying the two protocol
    manifests and the staged source and nothing else, while the certified
    worker opens `/input/task.json` before it does any provider work. The Job
    projection therefore reached `running` over a root the worker refuses, and
    no later operation could make the document appear.

    READ HERE, WHICH IS BEFORE ANYTHING EXISTS TO UNDO. This runs inside static
    configuration validation -- before the Authority is opened, before an offer
    is made, before an attempt or a workspace exists -- so every refusal below
    happens with no attempt root to leave partial and nothing to settle.

    HELD AS BYTES, AND THE PATH IS NEVER REOPENED. What this deployment
    delivers is decided once, here; a change to the configured path afterwards
    cannot change what a later composition publishes. That is also why the
    bytes rather than the path are what the constructed deployment carries.

    NO-FOLLOW, ORDINARY, BOUNDED, in that order and for three different
    reasons. A final symlink is a path this deployment did not choose;
    a directory, FIFO or device is not a document; and one byte past the
    worker's own ceiling is material the receiving end will never see whole.
    `O_NONBLOCK` so that opening a FIFO nobody has opened for writing answers
    rather than hanging the whole deployment before it starts.

    AND IT IS THE MANIFEST'S HUMAN CONTRACT, which is the approved decision
    this rests on. For THIS production profile the task document IS the input
    manifest's `human_contract` artifact, so the frozen manifest already
    carries its media type, its width and its digest -- and holding the bytes
    to them is what makes the delivery digest-bound rather than
    path-trusting. The locator stays provenance and is never read as a host
    path.

    WHAT IS DELIBERATELY NOT DONE HERE. The document's provider-specific
    schema is not parsed. `claude_agent` owns that vocabulary at the receiving
    end, and a host-side copy of it would be a second reader of one contract --
    which is exactly what the retired dogfood helpers were, and why they could
    not be reused: they follow the final symlink, parse on the host, and
    reserialize the object instead of delivering the bytes.
    """
    if type(contract) is not dict:
        _refuse("the bootstrap input manifest carries no human contract")
    if contract["media_type"] != "application/json":
        _refuse(f"this profile's task document is the input manifest's "
                f"human contract and that artifact is "
                f"{contract['media_type']!r} rather than 'application/json'",
                category="refused", code="precondition")
    if type(contract["bytes"]) is not int or type(contract["bytes"]) is bool \
            or contract["bytes"] > MAX_TASK_BYTES:
        _refuse(f"this profile's human-contract artifact is wider than the "
                f"{MAX_TASK_BYTES}-byte ceiling the workload reads",
                code="limit")
    try:
        handle = os.open(place, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC
                         | os.O_NONBLOCK)
    except OSError as failure:
        _refuse(f"the configured task document could not be opened "
                f"({type(failure).__name__})", code="path")
    try:
        found = os.fstat(handle)
        if not stat.S_ISREG(found.st_mode):
            _refuse("the configured task document is one ordinary file",
                    code="path")
        pieces = []
        remaining = MAX_TASK_BYTES + 1
        while remaining:
            part = os.read(handle, remaining)
            if not part:
                break
            pieces.append(part)
            remaining -= len(part)
    finally:
        os.close(handle)
    raw = b"".join(pieces)
    if len(raw) > MAX_TASK_BYTES:
        _refuse(f"the configured task document is wider than "
                f"{MAX_TASK_BYTES} bytes", code="limit")
    if len(raw) != contract["bytes"]:
        _refuse(f"the configured task document is {len(raw)} bytes and this "
                f"profile's human-contract artifact declares "
                f"{contract['bytes']}", code="digest")
    if digest_of_bytes(raw) != contract["content_digest"]:
        _refuse("the configured task document is not the content this "
                "profile's human-contract artifact names", code="digest")
    return raw


def _sayable(message, instead):
    """Own another component's diagnostic before it becomes a refusal's.

    Re-review 2026-09-03T18:49:20Z [P1]. `ContractRefusal` refuses to be
    CONSTRUCTED around a live bearer, so quoting a credential source's own
    text raised `integrity/secret-leak` out of this deployment's handler --
    which left the stage with no ending and the provider called again on every
    tick. The secret never reached a durable surface and the accepted ending
    was lost, which is its own defect.

    The shipped §13 rule decides, rather than a second copy of it here, and
    what replaces an unsayable diagnostic says why it was replaced.
    """
    try:
        check_no_durable_secret(message,
                                what="a credential source's own diagnostic")
    except ContractRefusal:
        return instead
    return message


def _now():
    moment = datetime.now(timezone.utc)
    return (moment.strftime("%Y-%m-%dT%H:%M:%S.")
            + f"{moment.microsecond // 1000:03d}Z")


def _bearer():
    import secrets
    return secrets.token_urlsafe(32)


def _engine_run(argv, *, seconds=None):
    finished = subprocess.run(argv, capture_output=True,
                              timeout=600 if seconds is None else seconds)
    return {"status": finished.returncode,
            "stdout": finished.stdout.decode("utf-8", "replace"),
            "stderr": finished.stderr.decode("utf-8", "replace")}


def _assignment(row):
    return {"work_ref": {"authority_uuid": row["authority_uuid"],
                         "work_id": row["work_id"]},
            "participant": row["participant"],
            "generation": row["claim_generation"]}


def _claim_facts(row):
    assignment = _assignment(row)
    decision = {"endpoint": row["participant"],
                "principal": row["claim_principal"],
                "effective_scope": row["claim_scope"],
                "role": row["claim_role"], "grant": row["claim_grant"],
                "policy_generation": row["claim_policy_generation"]}
    return {"assignment": assignment, "claim_event": row["claim_event_seq"],
            "decision": decision}


def _assignment_manifest(given, row, attempt_id, offer_id):
    manifest = given["input_manifest"]
    document = {
        "version": {"major": 1, "minor": 0},
        "manifest_id": "assignment-" + digest(attempt_id)[7:31],
        "created_at": row["accepted_at"], "extensions": {},
        "schema": "baton.worker-manifest/assignment",
        "assignment_ref": _assignment(row),
        "assignment_contract": manifest["assignment_contract"],
        "offer_id": offer_id, "runtime_attempt_id": attempt_id,
        "input_manifest_digest": manifest["manifest_digest"],
        "policy_digest": manifest["policy_digest"],
        "runtime_profile_digest": manifest["runtime_profile_digest"],
        "claim_receipt_digest": digest(_claim_facts(row)),
        "claim_event_seq": row["claim_event_seq"],
        "activated_at": row["decided_at"]}
    document["manifest_digest"] = digest(document)
    return check_manifest_structure(
        document, "assignmentManifest",
        what="the bootstrap assignment manifest")


class _AuthoritySession:
    """The exact Authority surface this implementation deployment carries.

    The core Session owns the lifecycle operations and gate discharge this worker needs.
    ``AuthorityPort`` also names conversational publication; this bootstrap
    does not run inquiry sessions, so that capability is an explicit
    typed refusal rather than a successful-looking no-op.
    """

    __slots__ = ("_session",)

    def __init__(self, session):
        self._session = session

    @property
    def participant(self):
        return self._session.participant

    def project_work(self, *arguments):
        return self._session.project_work(*arguments)

    def slot_holder(self, *arguments):
        return self._session.slot_holder(*arguments)

    def assignment_of(self, *arguments):
        return self._session.assignment_of(*arguments)

    def cancel(self, *arguments):
        return self._session.cancel(*arguments)

    def claim(self, *arguments):
        return self._session.claim(*arguments)

    def settle_operation(self, *arguments):
        return self._session.settle_operation(*arguments)

    def satisfy_gate(self, operands):
        return self._session.satisfy_gate(operands)

    def route_fenced(self, operands):
        """W125189's act, forwarded like the pass and for the same reason.

        W122060. It is the DEPLOYMENT's transition rather than the Worker
        Manager's: `AuthorityPort` names the operations that manager performs
        and this is not one of them -- it moves a Work to the route its next
        role is served on, while the original runtime gate still holds. The
        manager has no business in that, and the port deliberately keeps the
        concrete Authority outside its import boundary.

        FORWARDED AND NOT COMPOSED. Every operand is the caller's, derived from
        committed records it owns: the original assignment, the cancellation
        this ending's own checkpoint fenced under, and the two routes. This
        carries them.
        """
        return self._session.route_fenced(operands)

    def publish_answer(self, *arguments):
        del arguments
        _refuse("the bootstrap implementation deployment carries no inquiry "
                "publication capability", category="refused",
                code="capability")

    def pass_work(self, *arguments):
        """W81857: the ONE lifecycle transition this deployment's ending makes.

        ADDED HERE RATHER THAN REACHED THROUGH THE PORT. `AuthorityPort` is the
        narrow capability the Worker Manager holds, and every operation on it
        is one that manager performs; a pass is the DEPLOYMENT's act -- it ends
        the assignment and moves the Work's Route in one authority
        transaction -- and widening the manager's port to carry it would give
        the manager an authority it has no operation for.

        The wrapper stays a wrapper: it forwards one exact operand document to
        the real session, exactly as the other lifecycle operations above do,
        and the answer is held to its shape at the one caller that reads it.
        """
        return self._session.pass_work(*arguments)


def _more_than_the_mountpoint(inputs, boundary):
    """Whether an uncomposed input root holds anything this deployment did not
    just establish.

    W71917 MADE "EMPTY" THE WRONG QUESTION. Before this Work, a root with no
    protocol pair and any entry at all was partial, and the test was one
    `os.listdir`. The boundary is now composed BEFORE the root is frozen --
    it has to be, because freezing closes the directory the mountpoint lives
    in -- so the ordinary pre-composition state is a root holding exactly one
    entry: the empty mountpoint. A rule that called that partial would refuse
    every first composition.

    SO THE QUESTION IS "ANYTHING ELSE", and the mountpoint is excluded by the
    name the composed boundary answers rather than by a constant, so a root
    holding a directory called `source` that this composition did not
    establish is not quietly forgiven.

    AND THE MOUNTPOINT ITSELF IS PROVED WITHOUT ENUMERATING IT. A directory on
    another filesystem than its parent is a live bind, and reading it would be
    reading the nominated source -- the one thing this deployment does not do.
    That case is refused on the DEVICE, before anything is listed. Only once
    it is provably this manager's own directory is it peeked at, and then for
    one entry rather than a walk: leftovers from the retired copied bootstrap
    are material whose provenance this composition cannot prove, and adopting
    them is exactly what the partial-root rule exists to stop.
    """
    for name in os.listdir(inputs):
        if name != os.path.basename(boundary.mountpoint):
            return True
    place = boundary.mountpoint
    if not os.path.isdir(place):
        return True
    if os.lstat(place).st_dev != os.lstat(inputs).st_dev:
        # A LIVE BIND, and this is where it is refused rather than read. It is
        # not an ordinary state -- the engine binds inside the container's own
        # mount namespace -- so a host-side one is somebody else's mount over
        # this manager's mountpoint.
        return True
    with os.scandir(place) as reading:
        for _entry in reading:
            return True
    return False


# W125032: WHAT AN AUTHORITY REFUSAL OF A CLAIM MEANS TO THIS MANAGER.
#
# `work/records/2026/09/finding-v12-composed-ending-consumer/findings/
# finding-concrete-claim-adapter/`, implementing the approved
# `finding-authority-refusal-containment/ALLOCATION-PROPOSAL-2026-09-09.md`.
#
# CLOSED, AND DERIVED FROM NOTHING THE SOURCE WROTE IN PROSE. `Refusal` carries
# an optional unstructured code and a durability flag, and the claim-raising
# sites set no code at all -- so reading the MESSAGE to decide whether this was
# a policy, a stale identity or a collision would be inventing a vocabulary the
# source does not have and cannot keep stable. These two shapes are the ones
# the source actually produces, and each maps onto a pair this manager already
# owns.
_CLAIM_REFUSED = ("refused", "precondition")
_CLAIM_AMBIGUOUS = ("ambiguous", "operation")
_CLAIM_UNKNOWN = ("integrity", "schema")

# AND THE DIAGNOSTIC FOR THE SHAPE THIS BUILD DOES NOT RECOGNISE IS STATIC.
# Copying an unknown source code into a closed manager vocabulary would put a
# value nobody owns where a reader expects one that is owned, and a malformed
# durability flag is not evidence of durability -- so neither is carried.
_UNKNOWN_CLAIM_SHAPE = ("the authority refused this claim with a code or "
                        "durability this build does not recognise; a source "
                        "shape it cannot read is not one it may classify")
_UNREADABLE_CLAIM_DIAGNOSTIC = ("the authority refused this claim and its own "
                                "diagnostic could not be carried safely")


def _claim_refusal(refusal):
    """One concrete Authority claim refusal, as this manager's own.

    THE MAPPING IS THE WHOLE OF IT and it reads three inert facts: whether the
    source named a code, whether it said the refusal was durable, and what it
    said. Nothing else is consulted and nothing is retried, disposed, retired
    or released here -- a mapping decides what a refusal MEANS, and what to do
    about it belongs to the scheduler that already reads the manager's own
    canonical receipt.

    `durable=False` ON EVERY ANSWER, including the ambiguous one. Durability is
    a statement about a MANAGER receipt, and a remotely durable failure is
    exactly the case where this manager has none -- so recording one would be
    this deployment asserting a local outcome it never wrote. `ambiguous` is
    the honest pair for that: leave the settlement to the existing public
    operation recovery.

    THE SOURCE'S OWN WORDS ARE BOUNDED BEFORE THEY ARE CARRIED, through the
    same `label_of` every other caller-supplied diagnostic in this
    distribution goes through, and a diagnostic that cannot be composed at all
    falls back to a static one rather than chaining a raw exception out of a
    refusal path.
    """
    code = getattr(refusal, "code", _UNKNOWN_CLAIM_SHAPE)
    durable = getattr(refusal, "durable", _UNKNOWN_CLAIM_SHAPE)
    # `is True` / `is False` AND NOT TRUTHINESS. `1 == True`, and a flag of
    # any other shape is a source this build was not written against rather
    # than a quiet yes.
    if code is None and durable is False:
        category, why, detail = _CLAIM_REFUSED + (_claim_detail(refusal),)
    elif code is None and durable is True:
        category, why, detail = _CLAIM_AMBIGUOUS + (_claim_detail(refusal),)
    else:
        category, why, detail = _CLAIM_UNKNOWN + (_UNKNOWN_CLAIM_SHAPE,)
    try:
        return ContractRefusal(category, why, detail)
    except AssertionError:
        # ONLY THE DIAGNOSTIC REJECTION, and review 2026-09-09T04-50-13Z is
        # right that the first cut said otherwise. `except BaseException` here
        # turned an injected `KeyboardInterrupt`, `MemoryError` or
        # `RuntimeError` at this constructor into an ordinary
        # `refused/precondition` result -- which is the broad catch this
        # boundary was written to avoid, one line away from the mapping that
        # avoids it.
        #
        # `AssertionError` IS THE WHOLE OF THE INTENDED REJECTION, and it is
        # the owner's own choice of type rather than this module's guess:
        # `ContractRefusal` classifies a message that is not text, not
        # encodable or too long as a defect at the RAISING SITE and says so
        # with an assertion. The pair is one of three constants here, so the
        # message is the only operand that can be rejected -- and the refusal
        # keeps its meaning while losing only the words it could not carry.
        return ContractRefusal(category, why, _UNREADABLE_CLAIM_DIAGNOSTIC)


def _claim_detail(refusal):
    """The source's own account of the refusal, bounded and encodable."""
    return (f"the authority refused this claim: "
            f"{label_of(getattr(refusal, 'message', None))}")


class _ManagerClaimSession(_AuthoritySession):
    """The session the MANAGER's port is given, and the only thing it changes.

    W125032. WHY THIS EXISTS AT ALL. One refused claim used to abort a whole
    serving sweep: `authority.errors.Refusal` is not a `ContractRefusal`, so
    the scheduler's per-stage handler did not contain it, and an ordinary
    wrong-route claim on one Job stopped every other Job in the same tick.

    WHY IT IS HERE AND NOT AT THE PORT OR THE SCHEDULER. `AuthorityPort` keeps
    the concrete Authority module graph outside its import boundary on purpose,
    and teaching the generic scheduler about one deployment's exception type
    would make every injected operation depend on it. This deployment already
    imports that Authority -- it opens the handle -- so the translation belongs
    exactly here, at the one seam that already knows both vocabularies.

    IT OVERRIDES ONE METHOD. Every other forwarder is inherited unchanged, so
    each keeps its own result and refusal identity, `satisfy_gate` included;
    a successful claim is returned exactly as the session answered it; and an
    exception that is not an Authority `Refusal` -- a programming error, a
    transport failure, an existing `ContractRefusal` -- travels out untouched,
    because a boundary that swallowed those would be hiding defects rather than
    containing refusals.

    `_AuthoritySession` IS STILL WHAT THE DEPLOYMENT HOLDS. The two wrap the
    SAME already-minted participant session, so nothing new is minted and no
    second capability exists; what differs is only which of them the manager's
    port was handed.
    """

    __slots__ = ()

    def claim(self, *arguments):
        try:
            return self._session.claim(*arguments)
        except Refusal as refusal:
            # `from None` DELIBERATELY. A chained cause would carry the source
            # exception -- and the diagnostic this boundary just decided not to
            # carry -- out through every reader of the refusal.
            raise _claim_refusal(refusal) from None


class _RecordedRuntime:
    """The runtime adapter a HISTORICAL ending is typed against.

    W122060. THE DRIVER TYPES ITS WHOLE ADAPTER SURFACE BEFORE IT DECIDES
    which ending it is performing, and it is right to: "a composite that finds
    out halfway through that it cannot finish has already stopped somebody's
    container". But a resumed ending is reached only once the runtime is
    destroyed and its two roots are gone, so there is nothing left to compose a
    real adapter over -- and composing one anyway would mean allocating
    directories this ending has already positively let go.

    SO THIS IS THE SHAPE AND EXPLICITLY NOT THE CAPABILITY. It answers the one
    identity the custody receipts bind -- the custodian image this deployment
    is configured with, which is a configured fact and not a claim about a
    container -- and every verb refuses. `_resumed_implementation` says it
    "grants no writer, mounts nothing, starts nothing, stops nothing, seals
    nothing, collects nothing, destroys nothing, asks no engine and asks no
    worker: the adapter is not touched", and this is that sentence made
    unfalsifiable from the deployment's side: a historical ending that reached
    any of these would refuse in this object's words rather than quietly
    performing an act over evidence somebody has already been given.
    """

    __slots__ = ("custodian_image_digest",)

    # THE UNION OF WHAT THE ACCEPTED ENDINGS TYPE, mirrored deliberately.
    # `review_driver.RUNTIME_ADAPTER` is the driver's own tuple and this is the
    # deployment's account of the same surface; a member added there and not
    # here refuses at `_typed` with the verb named, which is the failure this
    # composition wants rather than a silent absence.
    VERBS = ("stop", "list", "observe", "seal", "collect", "retain", "destroy",
             "normalize_directory", "prove_line_consumable",
             # W285465, review 2026-09-28T06-52-46Z: the ending's writer listing joins the
             # surface, as the REFUSING shape like every other verb here. A historical
             # resume performs no runtime act, so an inert adapter that ANSWERED this --
             # with an empty list, say -- would be fabricating the very observation the
             # ordinary ending exists to establish. It refuses in this object's words
             # instead, and the typing succeeds because the shape is present.
             "surviving_helpers")

    def __init__(self, image_digest):
        self.custodian_image_digest = image_digest

    @staticmethod
    def _refused(verb):
        def act(*arguments, **operands):
            del arguments, operands
            _refuse(f"a historical composed ending performs no runtime act "
                    f"and this one reached {verb!r}; the attempt's runtime was "
                    f"destroyed and its roots let go, so there is nothing for "
                    f"this to be about", category="refused", code="capability")
        return act

    def __getattr__(self, name):
        if name in _RecordedRuntime.VERBS:
            return _RecordedRuntime._refused(name)
        raise AttributeError(name)


# W61599: THE ACTIVITY INGESTION HELPER, AND THE ONE SLOT THAT ADMITS IT.
#
# WHY A MODULE-LEVEL REGISTRY RATHER THAN A FIELD ON A COMPOSITION. Two
# DISTINCT compositions can be built over the same control store in one
# process, and exclusion that lived on either of them would not see the other.
# Keying admission on the store a deployment actually HOLDS is what makes the
# rule stable across both factories and across recomposition.
#
# AND THE KEY CARRIES NO ATTEMPT. An earlier revision keyed it per
# `(store, attempt)` and did not exclude anything: a composition holding a
# blocked helper for attempt A left `(store, B)` free, so a replacement started
# a SECOND helper against the same store while the first was still unresolved.
# One slot per store identity is what actually forbids that.
_ACTIVITY_LOCK = threading.Lock()
_ACTIVITY_HELPERS = {}

# HOW MANY STORE IDENTITIES THIS PROCESS WILL ADMIT AT ONCE. Bounded for the
# reason every other limit in this path is: exceeding it means NO new helper,
# which fails toward no diagnostic rather than toward unbounded growth. It is
# deliberately distinct from the worker's own file bound.
MAX_ACTIVITY_ADMISSIONS = 64

# THE FINITE STOP, matching the worker's own publisher bound so neither side
# waits on the other.
ACTIVITY_STOP_SECONDS = 2


def _store_identity(control_store):
    """The FILE this deployment's held control store actually has open.

    ASKED OF THE HANDLE, NOT OF A CONFIGURATION. Neither factory is given a
    control-store path -- the caller opens the store and hands the handle over
    -- and the identity that matters is the one two compositions would actually
    collide on, which is the database file rather than the string somebody
    passed in. `ControlStore._path_of` asks SQLite the same question for the
    same reason.

    ANSWERS `None` FOR A STORE WITH NO FILE. An in-memory store names none, and
    an identity this module cannot establish is one it will not admit a helper
    under -- no diagnostic is the safe direction.
    """
    connection = getattr(control_store, "_connection", None)
    if connection is None:
        return None
    try:
        for row in connection.execute("PRAGMA database_list"):
            if row[1] == "main" and row[2]:
                return os.path.realpath(row[2])
    except Exception:                                      # noqa: BLE001
        return None
    return None


class _ActivityIngestion:
    """One off-loop reader of the optional activity document.

    W61599. WHAT THIS EXISTS TO KEEP OFF THE SERVING LOOP is a file read and a
    store write. The sweep is serial: a slow store on that thread delays every
    pass, stage and cleanup behind it, and a diagnostic that could do that
    would cost more than the count it publishes is worth.

    ITS STORE HANDLE IS ITS OWN AND IS OPENED ON ITS OWN THREAD, because a
    `sqlite3` connection belongs to the thread that opened it. It never shares
    the serving handle, and no other thread ever touches it.

    THE ENQUEUE IS A SLOT ASSIGNMENT. One request, newest wins, and it cannot
    block -- which is what makes calling it from the serving loop safe.
    """

    __slots__ = ("_identity", "_place", "_incarnation", "_clock", "_lock",
                 "_wake", "_stop", "_slot", "_thread", "_token")

    def __init__(self, identity, token, *, incarnation, clock):
        self._identity = identity
        self._token = token
        self._place = identity
        self._incarnation = incarnation
        self._clock = clock
        self._lock = threading.Lock()
        self._wake = threading.Event()
        self._stop = False
        self._slot = None
        self._thread = None

    def start(self):
        self._thread = threading.Thread(target=self._serve, daemon=True)
        self._thread.start()
        return self

    def enqueue(self, request):
        """Newest request wins. NEVER blocks and never raises at the caller."""
        with self._lock:
            self._slot = request
        self._wake.set()

    def stop(self, seconds=ACTIVITY_STOP_SECONDS):
        """Ask it to finish and WAIT A FINITE BOUND. Answers whether it did.

        A FALSE ANSWER IS NOT A FAILURE TO REPORT LATER AND FORGET. The slot
        stays occupied, the handle stays open, and the composition that called
        this reports the unresolved helper. Leaking a handle is the lesser
        fault; closing one under a live writer is a use-after-close, and this
        object is the only thing that may close its own.
        """
        with self._lock:
            self._stop = True
        self._wake.set()
        thread = self._thread
        if thread is None:
            return True
        thread.join(seconds)
        return not thread.is_alive()

    def _serve(self):
        store = None
        try:
            while True:
                self._wake.wait()
                with self._lock:
                    self._wake.clear()
                    request, self._slot = self._slot, None
                    stopping = self._stop
                if request is not None:
                    # THE HANDLE IS OPENED ON FIRST USE, ON THIS THREAD. A
                    # deployment that never serves an attempt never opens a
                    # second connection to its own control store, and one that
                    # does opens it exactly once -- on the thread that will
                    # close it, which is what `sqlite3` requires.
                    if store is None:
                        store = ControlStore.open(
                            self._place, incarnation=self._incarnation,
                            clock=self._clock)
                    self._ingest(store, request)
                if stopping:
                    return
        except BaseException:                              # noqa: BLE001
            # A HELPER THAT CANNOT OPEN ITS OWN HANDLE SIMPLY DOES NOT INGEST.
            # It is a diagnostic; nothing in this deployment branches on the
            # count, so the exit path below is the whole of the consequence.
            return
        finally:
            # THE OWNING THREAD CLOSES ITS OWN HANDLE DURING ITS OWN
            # FINALIZATION, and this is the only place that ever happens. A
            # timed-out `stop` never reaches here, which is exactly why it
            # leaves the handle open and the slot held.
            if store is not None:
                try:
                    store.close()
                except BaseException:                      # noqa: BLE001
                    pass
            self._release()

    def _release(self):
        with _ACTIVITY_LOCK:
            if _ACTIVITY_HELPERS.get(self._identity) is self._token:
                del _ACTIVITY_HELPERS[self._identity]

    @staticmethod
    def _ingest(store, request):
        """One activity document, read and recorded. NOTHING ELSE.

        EVERY IDENTITY IS THIS MANAGER'S. The event root is a LOCAL CAPABILITY
        composed by the deployment that made the delivery -- it is never read
        from the document and never supplied over the wire -- and the six
        compared fields are the manager's own: the attempt and the session
        travel in the request, the sequence, operation and operation id are
        derived by rule, and the command digest is read back from the command
        THIS MANAGER published into a namespace the container holds read-only.

        NO ADOPTION RUNS HERE. `launch.adopt` proves a delivery by authoring
        and comparing its canonical bytes, which is a write-path proof this
        diagnostic has no business performing.

        A REFUSAL INGESTS NOTHING. Absent, foreign, mis-bound, hostile or
        oversized material leaves the projection exactly as it was -- unknown,
        or at its last observed value -- because that is already what absence
        means here and a diagnostic must not be able to say more than it saw.
        """
        delivery = exchange.ExchangeDelivery(attempt_id=request["attempt_id"],
                                             root=os.path.realpath(request["root"]))
        try:
            expected = exchange.activity_identities(
                delivery, session=request["session"])
            if expected is None:
                return
            total = exchange.observed_activity(delivery, expected)
        except ContractRefusal:
            return
        except OSError:
            return
        if total is None or total <= 0:
            # ONLY A POSITIVE TOTAL IS RECORDED. A zero would read as
            # "observed, and empty", which is a different answer from "nothing
            # observed yet" and is not one this manager has evidence for.
            return
        try:
            attempts.observe_activity(store,
                                      attempt_id=request["attempt_id"],
                                      bytes_observed=total)
        except ContractRefusal:
            # THE OWNER'S OWN RULES DECIDE. A repeat is a no-op there and a
            # regression is refused there; neither is this reader's to
            # second-guess, and neither may reach the serving loop.
            return


def activity_ingestion(control_store, *, clock=None):
    """Admit ONE ingestion helper for the store this deployment holds, or none.

    W61599. THE SLOT IS ACQUIRED ATOMICALLY, WITHOUT WAITING, AND BEFORE THE
    HELPER STARTS. A composition that found it occupied starts NO helper and
    ingests nothing: the deployment composes and runs exactly as it would
    otherwise, and only the optional diagnostic is absent -- which is what
    "optional" has meant throughout this design.

    THE SLOT IS HELD UNTIL POSITIVE TERMINATION. An abandoned or timed-out stop
    leaves it occupied indefinitely, and that is the point rather than a leak:
    no successor may start while a predecessor may still be writing to the same
    store.

    CONSTRUCTION FAILURE RELEASES IT ONLY IF NO HELPER STARTED. Once the thread
    is running, the slot belongs to that thread and its own exit is what frees
    it.

    BOTH FACTORIES CALL THIS ONE FUNCTION. Neither has a copy, which is the
    whole reason the exclusion holds across distinct compositions.
    """
    identity = _store_identity(control_store)
    if identity is None:
        return None
    incarnation = getattr(control_store, "incarnation", None)
    if type(incarnation) is not str or not incarnation:
        return None
    token = object()
    with _ACTIVITY_LOCK:
        if identity in _ACTIVITY_HELPERS:
            return None
        if len(_ACTIVITY_HELPERS) >= MAX_ACTIVITY_ADMISSIONS:
            return None
        _ACTIVITY_HELPERS[identity] = token
    helper = _ActivityIngestion(identity, token, incarnation=incarnation,
                                clock=clock or getattr(control_store, "_now",
                                                       None) or _now)
    try:
        return helper.start()
    except BaseException:
        with _ACTIVITY_LOCK:
            if _ACTIVITY_HELPERS.get(identity) is token:
                del _ACTIVITY_HELPERS[identity]
        raise


def activity_release(helper, *, seconds=ACTIVITY_STOP_SECONDS):
    """Stop one helper and REFUSE if it did not resolve.

    Both factories unwind through this, so the staged path's collected refusal
    and the bootstrap path's `dispose` report the same fact in the same words.
    """
    if helper is None:
        return
    if not helper.stop(seconds):
        _refuse(f"this deployment's activity ingestion helper did not stop "
                f"within {seconds}s; its control store handle and its "
                f"admission are deliberately left held, because closing a "
                f"handle under a live writer is a use-after-close and no "
                f"successor may start while this one may still be writing",
                category="unavailable", code="transport")


class _UncooperativeAgent:
    """What this deployment has instead of a cooperative cancellation channel.

    W236087. `attempts.request_cancellation` asks the AGENT to wind down before
    it asks the runtime to stop, because a cooperative shutdown is the thing a
    kill does not give. This deployment's worker speaks through a durable FILE
    EXCHANGE and has no such channel: nothing here can reach a provider turn
    that is already in flight.

    SO IT SAYS SO, and the settlement travels back un-summarized -- which is
    exactly what `_order_quiescence` does with it. Two alternatives were both
    worse. Raising would have been accurate and then unhelpful: a throwing
    agent still lets the stop happen and is then RE-RAISED, so every ordinary
    cancellation would end in an exception whose meaning was "as expected".
    Returning a bare success would have been a deployment telling the manager
    that a worker had cooperated with an order it never received.
    """

    __slots__ = ("_given",)

    def __init__(self, given):
        self._given = given

    def cancel(self, command):
        held = boundaries.document(
            command, "a cancellation command",
            required=("attempt_id", "assignment", "runtime_id",
                      "operation_id"))
        return {"cooperative": False,
                "participant": self._given["participant"],
                "attempt_id": held["attempt_id"],
                "operation_id": held["operation_id"],
                "why": "this deployment's worker is driven through a durable "
                       "file exchange and carries no cooperative cancellation "
                       "channel; the runtime stop below is the whole of the "
                       "order this attempt receives"}


class _SingleWorker:
    """The launch capability; it receives no Authority bootstrap or path."""

    def __init__(self, given, control, port, *, credential_provider,
                 engine_run, session=None, clock=None, checkpoint=None,
                 stage=None, judgment_document=None,
                 execution_context=None, activity=None):
        self.given = given
        # W285464: THE PREPARATION OWNERSHIPS THIS COMPOSITION HOLDS, per attempt.
        # The capability lives for as long as this manager composition does, which is
        # what lets the act that opened a window continue it across ticks while a
        # second call -- one that cannot present the object -- is refused.
        self._preparations = {}
        # W61599: WHERE AN ACTIVITY REQUEST GOES, or `None` for a composition
        # that admitted no ingestion helper -- which is every composition whose
        # store already had one, and every focused verification that composed
        # none. A worker with no helper simply enqueues nothing; the optional
        # count is then absent, which is what an unobserved attempt has always
        # projected.
        self.activity = activity
        # W156162: THE ONE THING THIS WORKER LEARNS ABOUT A JOB, and it is a
        # CALLABLE rather than a store.
        #
        # A Job may configure the seconds one provider turn and one verification
        # command may take, and the launch delivery is what carries them into a
        # container -- so this composition has to be able to ask. Handing it the
        # Job store would make every launch composition a Job-store reader,
        # which is the separation the factory keeps; the pinned decision of
        # 2026-09-13T01:58:25Z is a narrow injected reader instead. It answers
        # one question over the factory's already-open owner and exposes no
        # write, no migration, no Authority session, no engine and no
        # credentials.
        #
        # `None` is a composition with no Job behind it -- the bootstrap
        # deployment and focused verification -- and those keep the legacy
        # launch shapes they already had.
        self.execution_context = execution_context
        # W103083: THE TWO PLACES A STAGE DIFFERS, AND THERE ARE ONLY TWO.
        # What a worker MOUNTS and how its attempt ENDS are the whole of the
        # difference between an implementation, a review and an integration
        # stage; the offer, the claim, the attempt record, the assignment
        # activation, the input root, the retained manifest, the launch
        # document, the credential delivery, the boundary re-proof and the
        # runtime start are identical for all three. So those two are seams
        # and the rest is called unchanged -- which is the assembly boundary's
        # own rule that three deployment opinions over one security boundary
        # is what a second copy of this module would be.
        #
        # `None` IS THE BOOTSTRAP COMPOSITION, unchanged in every respect: it
        # composes its own roots and boundary and ends through the v11 pass
        # below.
        self.stage = stage
        self.judgment_document = judgment_document
        self.control = control
        self.port = port
        # W81857: THE SESSION, FOR THE ONE ACT THE PORT DOES NOT CARRY. It is
        # optional only so focused verification can compose a worker that
        # never reaches an ending; `_passed` refuses without it rather than
        # skipping the handoff, because an attempt whose result is frozen,
        # collected and retained and whose Work never moves is a stage that
        # looks finished and has not been handed to anybody.
        self.session = session
        self.group = configured_workspace_group(control)
        self.credential_home = credentials.CredentialHome(
            given["credential_home"])
        self.credential_provider = credential_provider
        self.engine = EnginePort(engine_run)
        self.clock = clock or _now
        self.checkpoint = checkpoint or (lambda _name: None)
        self.expected_offer = None

    def admit(self, perform, stage, job):
        """Bind the one admissible intent before its bearer can be minted."""
        self._matches(stage, job)
        if self.expected_offer is not None:
            _refuse("one single-worker offer delivery is already in progress",
                    category="refused", code="precondition")
        self.expected_offer = {
            "offer_id": stage["offer_id"],
            "runtime_attempt_id": stage["attempt_id"],
            "work_id": stage["work_id"],
            "participant": self.given["participant"]}
        try:
            return perform(stage, job)
        finally:
            self.expected_offer = None

    def delivered(self, issued):
        given = self.given
        manifest = given["input_manifest"]
        expected = self.expected_offer
        if expected is None:
            _refuse("an offer bearer arrived outside its one admission call",
                    category="refused", code="capability")
        for member, value in expected.items():
            if issued.get(member) != value:
                _refuse(f"the issued offer's {member} does not match this "
                        "single-worker deployment",
                        category="refused", code="precondition")
        accept_offer(
            self.control, self.port, offer_id=issued["offer_id"],
            decision="accept", bearer=issued["bearer"], now=self.clock(),
            runtime_attempt_id=issued["runtime_attempt_id"],
            work_ref=dict(manifest["work_ref"]))

    def _matches(self, stage, job):
        given = self.given
        manifest = given["input_manifest"]
        # W103083: THE KIND IS THE CONFIGURED ROLE. It read `implementation`
        # as a literal, which is the same value `_held` proves `launch_role`
        # to be for a bootstrap deployment -- so the bootstrap comparison is
        # unchanged and a composed reviewer is held to `review` by the one
        # member its own preflight already owns.
        expected = {"kind": given["launch_role"],
                    "work_id": manifest["work_ref"]["work_id"],
                    "profile_name": given["profile_name"],
                    "profile_digest": given["profile_digest"]}
        for member, value in expected.items():
            if stage.get(member) != value:
                _refuse(f"stage {stage.get('stage_id')!r} names {member} "
                        f"{stage.get(member)!r}; this single worker accepts "
                        f"only {value!r}", category="refused",
                        code="precondition")
        # W202663: THE JOB'S INPUT IDENTITY, NOT THIS WORKER'S RUNTIME ONE.
        #
        # This compared `manifest_digest` -- the digest of the WHOLE manifest,
        # including the worker's own image -- against the ONE `input_digest` a
        # Job carries. Every worker serving a Job was therefore forced onto one
        # manifest, one image and, because a runtime runs its image's own
        # ENTRYPOINT, one PROGRAM. The supported recipes are three programs, so
        # an ordinary implementation/review/integration pool could not be
        # expressed: the refusal read "the Job names another bootstrap input"
        # and the composition it was refusing was correct.
        #
        # `launch.py`'s Job execution context had already ruled on this, and
        # carried `job_input_digest` and `runtime_input_digest` as two members
        # precisely because "requiring them equal would refuse the ordinary
        # case". This comparison had not been told. Owner ruling
        # 2026-09-18T22:01:51Z (W202663) classifies it as a gap in realizing the
        # provider-diverse architecture rather than a property of it.
        #
        # SO THE JOB-SCOPED PROJECTION IS WHAT IS COMPARED, and the check is
        # not weakened by one member: `job_input_identity` re-owns this
        # manifest and digests everything in it EXCEPT the worker-runtime axis,
        # so a worker that moved the Work, the sources, the outputs, the record
        # binding, the human contract or any shared policy is refused exactly
        # as before. What it may now differ in is its own image, toolchain,
        # runtime profile and credential policy -- which is the whole of what
        # the ruling makes separate.
        #
        # THE WORKER'S OWN IMAGE IS STILL BOUND, one rule up: `_held` refuses
        # unless `image_digest` equals this manifest's `worker_image_digest`.
        # That is what keeps "each worker selects its own image" from becoming
        # "any worker may run any image".
        identity = job_input_identity(
            manifest, what="this single worker's configured input")
        if job.get("input_digest") != identity:
            # W202663 REVIEW 206898 [R3]: A LEGACY JOB IS SAID OUT LOUD.
            #
            # This IS a semantic change and not a widening: the projection
            # differs from the whole digest even for one unchanged homogeneous
            # manifest, so every Job submitted before this correction refuses
            # here. Fail-closed is right -- a manager that quietly accepted the
            # old identity would be admitting a Job under a rule nobody chose,
            # and rewriting the retained submission would destroy provenance.
            # But refusing a migratable Job with the same four words as a Job
            # about someone else's input sends its operator looking for the
            # wrong fault, so the two are distinguished and neither is repaired
            # here.
            if job.get("input_digest") == manifest["manifest_digest"]:
                _refuse(f"this Job names the whole runtime manifest digest "
                        f"{manifest['manifest_digest']!r}, which identified a "
                        f"Job's input before its workers could select their "
                        f"own images; a Job now names that manifest's "
                        f"Job-scoped projection {identity!r}. Resubmit the Job "
                        f"against the projection -- the retained submission is "
                        f"evidence and is not rewritten for it",
                        category="refused", code="precondition")
            _refuse("the Job names another bootstrap input",
                    category="refused", code="precondition")
        if job.get("policy_digest") != given["policy_digest"]:
            _refuse("the Job names another bootstrap policy",
                    category="refused", code="precondition")

    def _claim(self, stage):
        found = claimed_offers_for(self.control, stage["attempt_id"])
        if len(found) != 1:
            _refuse(f"attempt {stage['attempt_id']!r} has {len(found)} "
                    "claimed offers; one launch requires exactly one",
                    category="refused", code="precondition")
        row = found[0]
        # W202663: THE OFFER CARRIES THE JOB'S INTENT, SO IT IS COMPARED AS ONE.
        #
        # `delegation.admit` mints this offer from "the Job's immutable input
        # and policy identities" -- its own words -- and this comparison read
        # that member as though it were the worker's runtime manifest digest.
        # It is the third site of the one conflation `_matches` above describes,
        # and it is the site that actually stops a heterogeneous pool: an offer
        # is minted per stage, so every stage's worker was required to hold the
        # single manifest the Job was submitted with.
        #
        # The projection is what is compared, exactly as at admission, and
        # nothing else about the offer moves: the offer id, the Authority, the
        # Work, the participant, the profile and the policy are still matched
        # whole.
        expected = {"offer_id": stage["offer_id"],
                    "authority_uuid": self.given["authority_uuid"],
                    "work_id": stage["work_id"],
                    "participant": self.given["participant"],
                    "profile_digest": self.given["profile_digest"],
                    "input_digest": job_input_identity(
                        self.given["input_manifest"],
                        what="this single worker's configured input"),
                    "policy_digest": self.given["policy_digest"]}
        for member, value in expected.items():
            if row.get(member) != value:
                _refuse(f"the claimed offer's {member} does not match this "
                        "stage", category="refused",
                        code="operation-collision")
        return row

    def _input(self, roots, assignment, boundary):
        given = self.given
        manifest = given["input_manifest"]
        try:
            held_input, held_assignment = workspaces.read_input_root(
                roots["inputs"])
        except ContractRefusal:
            if _more_than_the_mountpoint(roots["inputs"], boundary):
                # Review 2026-09-03T17:23:00Z [P1]: this raised
                # `refused/path`, which is not one of §9's closed pairs -- so
                # the one branch that finds incomplete material rejected its
                # own raising site with an `AssertionError` instead of the
                # typed refusal it meant.  `integrity/path` is the pair this
                # is: a root whose bytes this manager cannot account for.
                _refuse("the bootstrap input root is partial; restart refuses "
                        "rather than completing material whose provenance it "
                        "cannot prove", code="path")
            # W81115: THE WORKLOAD DOCUMENT FIRST, and the order is the
            # content. `compose_input_root` FREEZES the root when it finishes
            # -- 0555 on the directory -- so nothing can be added afterwards,
            # and the source copy walks a tree this deployment does not want
            # deciding whether the task name is still free. Publishing here
            # means the whole root is composed before the protocol pair
            # completes it, which is also W76207's rule: a death anywhere in
            # between leaves a partial root the next process refuses above
            # rather than repairs.
            self._published_task(roots["inputs"])
            if self.judgment_document is not None:
                self._published_task(roots["inputs"], name="judgment.json",
                                     content=self.judgment_document)
            # W71917: THE MOUNTPOINT, NOT A COPY. What stood here walked the
            # nominated tree a second time and wrote every file into the input
            # root -- the ordinary copied bootstrap this Work retires. The
            # boundary was already composed before this method was reached, so
            # the empty directory the engine binds over exists; nothing is read
            # from the nominated source and nothing is written into the root
            # except the two protocol documents and the task.
            #
            # THE DESTINATION IS STILL PINNED, by the same rule the preflight
            # pins it with: the certified workload reads exactly one relative
            # path, and a manifest naming another would compose a root the
            # worker cannot use.
            if manifest["sources"][0]["destination"] \
                    != os.path.basename(boundary.mountpoint):
                _refuse("the bootstrap input manifest stages its source "
                        "somewhere other than the mountpoint this deployment "
                        "established")
            workspaces.compose_input_root(
                roots["inputs"], manifest, assignment,
                assignment=dict(assignment["assignment_ref"]),
                runtime_attempt_id=assignment["runtime_attempt_id"])
            return manifest
        if held_input != manifest or held_assignment != assignment:
            _refuse("the existing bootstrap input root is another delivery",
                    category="refused", code="precondition")
        # W81115: AND THE WORKLOAD DOCUMENT IS PROVED TOO, on every restart.
        #
        # `read_input_root` deliberately reads exactly the two PROTOCOL
        # documents -- that is the generic component's whole contract -- so a
        # matching manifest pair says nothing at all about the workload
        # material beside it. Inferring the task from `input.json` would be
        # this deployment concluding something the reader it called never
        # looked at.
        self._proved_task(roots["inputs"])
        if self.judgment_document is not None:
            self._proved_task(roots["inputs"], name="judgment.json",
                              content=self.judgment_document)
        return held_input

    def _published_task(self, inputs, *, name=TASK_DOCUMENT, content=None):
        """Install the held task bytes as the read-only workload document.

        NEVER FROM THE CONFIGURED PATH. The bytes were read once, at
        construction, and are what this publishes; reopening the path here
        would let material change between the proof and the delivery, which is
        the whole reason `_task_bytes` holds them.

        REFUSED RATHER THAN REPLACED when the name is taken, AND THE
        EXCLUSIVE CREATION IS BOTH DECISIONS AT ONCE. An input root carrying a
        task this composition did not write is material whose provenance it
        cannot prove, and W76207's rule for exactly that is to refuse and
        record one preparation ending rather than repair in place.

        THERE IS NO SECOND PATHNAME, and two reviews are why. The first cut
        checked the final name and finished with `os.replace`, which CLOBBERS,
        so a creator that won the interval between the check and the rename had
        its document silently replaced (review 2026-09-04T00:56:36Z [P1]). The
        second made that transition a no-clobber `os.link` -- and left the
        STAGING NAME as a mutable pathname between the proof and the
        publication, so a creator that unlinked it and put a symlink there had
        that symlink hard-linked at the final name, published, and reported as
        success (review 2026-09-04T01:06:30Z [P1]).

        Both defects are one defect: a name proved at one moment and used at
        another. Defending the interval a third time would be the same bet
        again, so the interval is GONE. The document is created directly at its
        final name with `O_CREAT | O_EXCL | O_NOFOLLOW`, which IS the
        no-clobber decision -- an existing file, directory or symlink at that
        name fails `EEXIST` and nothing is written -- and every act after it is
        on THE DESCRIPTOR THAT CREATION RETURNED. The bytes, the readback and
        the mode all reach the same inode, and there is no other pathname for
        anything to substitute.

        UNREADABLE UNTIL PROVED. Mode 0 at creation, and `fchmod` on that same
        descriptor only after the bytes have been read back and compared -- so
        the document becomes readable exactly when it becomes both complete and
        proved. What an interrupted composition leaves is an unreadable file
        inside a root with no protocol pair, which the partial-root rule
        refuses above and `_proved_task` would refuse for its mode.

        NOT `workspaces._write_read_only`, which is the same shape one
        component over. That one is the private owner of the two protocol
        documents, and publishing this through it would mean making a generic
        Worker Manager operation public to carry workload material -- the
        vocabulary boundary this Work is explicitly held to. It also stages,
        for a reason that is real where it lives: those documents are composed
        into a root a container may already be mounting. This one is written
        before the root is frozen and before any runtime exists, so nothing can
        observe the incomplete name, and removing the second pathname is worth
        more here than atomic appearance is.
        """
        held = self.given["task_bytes"] if content is None else content
        place = os.path.join(inputs, name)
        try:
            handle = os.open(place, os.O_RDWR | os.O_CREAT | os.O_EXCL
                             | os.O_NOFOLLOW | os.O_CLOEXEC, 0o000)
        except FileExistsError:
            _refuse(f"the bootstrap input root already carries "
                    f"{TASK_DOCUMENT!r}; a workload document this composition "
                    f"did not write is material whose provenance it cannot "
                    f"prove", code="path")
        except OSError as failure:
            _refuse(f"the bootstrap task document could not be created "
                    f"({type(failure).__name__})", code="path")
        try:
            written = 0
            while written < len(held):
                moved = os.write(handle, held[written:])
                if moved <= 0:
                    _refuse("the bootstrap task document could not be written "
                            "whole", code="limit")
                written += moved
            os.fsync(handle)
            os.lseek(handle, 0, os.SEEK_SET)
            if os.read(handle, len(held) + 1) != held:
                _refuse("the published bootstrap task document is not the "
                        "content this deployment holds", code="digest")
            os.fchmod(handle, 0o444)
        except BaseException:
            # THE NAME THIS OPERATION EXCLUSIVELY CREATED IS ITS OWN TO REMOVE,
            # and it is removed by name rather than proved first because the
            # exclusive creation is what established that the name was free:
            # nothing else has published under it in between without this
            # having already failed.
            os.close(handle)
            os.unlink(place)
            raise
        os.close(handle)
        return place

    def _proved_task(self, inputs, *, name=TASK_DOCUMENT, content=None):
        """The installed workload document, re-proved against the held bytes.

        The same three questions the configuration asked, asked again of what
        is actually on disk: a no-follow ordinary file, the exact bytes this
        deployment holds, and the read-only mode that says on disk what the
        delivery says in prose. A root whose protocol pair matches while its
        task has moved is a root the worker would read something else out of.
        """
        held = self.given["task_bytes"] if content is None else content
        place = os.path.join(inputs, name)
        try:
            handle = os.open(place, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC
                             | os.O_NONBLOCK)
        except OSError as failure:
            _refuse(f"the existing bootstrap input root carries no readable "
                    f"{TASK_DOCUMENT!r} ({type(failure).__name__})",
                    code="path")
        try:
            found = os.fstat(handle)
            if not stat.S_ISREG(found.st_mode):
                _refuse(f"the existing {TASK_DOCUMENT!r} is one ordinary file",
                        code="path")
            if stat.S_IMODE(found.st_mode) != 0o444:
                _refuse(f"the existing {TASK_DOCUMENT!r} is not the read-only "
                        f"document this deployment published", code="path")
            raw = os.read(handle, len(held) + 1)
        finally:
            os.close(handle)
        if raw != held:
            _refuse("the existing bootstrap input root carries another task "
                    "document", category="refused", code="precondition")
        return place

    def _attempt_scratch(self, attempt_id):
        """The attempt's own disk-backed scratch directory, allocated here.

        W202663, owner 2026-09-21T05:53:07Z ("I approve spare mount"). One
        directory per attempt in the assignment's own home on the workspace
        storage disk -- real storage, outside every checkout, seen by exactly
        this attempt at `oci.SCRATCH_TARGET`. The deployment-setup tests a
        verifier runs refuse a fixture root that is inside the checkout or on
        a memory filesystem, and Job2 measured that without this delivery the
        container holds no compliant place at all.

        ADOPTED, NEVER CREATED HERE. `workspaces.HOME_ENTRIES` provisions the
        entry with the home, because `compose_input_root` closes the home the
        moment composition ends and nothing can be created in it afterwards
        -- exactly the measured refusal a post-hoc mkdir met. A link or a
        non-directory standing at the name refuses. Nothing here deletes:
        retention follows the assignment home's own disposition.
        """
        place = os.path.join(self.given["workspace_storage"], attempt_id,
                             "scratch")
        try:
            held = os.lstat(place)
        except OSError as failure:
            _refuse(f"the attempt scratch at {place} cannot be adopted "
                    f"({type(failure).__name__}); the home provisions it and "
                    f"a home without it is not this manager's",
                    code="path")
        if stat.S_ISLNK(held.st_mode) or not stat.S_ISDIR(held.st_mode):
            _refuse(f"the attempt scratch at {place} is not an ordinary "
                    f"directory; links and special files are refused",
                    code="path")
        return place

    def _adapter(self, roots, delivery, orphan, launched, boundary=None,
                 scratch=None):
        given = self.given
        manifest = given["input_manifest"]
        return OciAdapter(
            given["engine"], self.engine,
            identity={"image_digest": given["image_digest"],
                      "profile_digest": given["profile_digest"],
                      "policy_digest": given["policy_digest"],
                      "adapter_digest": given["adapter_digest"]},
            assignment_roots=roots, posture="execution",
            # THE TWO ROOTS THIS MANAGER CREATED, unchanged by W71917. The
            # input root is still read-only at `/input` and the workspace
            # still writable at `/output`; what the nominated source adds is a
            # THIRD bind, composed by `oci` out of the typed boundary below
            # rather than named here, because a source this deployment could
            # name as a path would be the caller-selected locator the proof
            # exists to remove.
            mounts=[{"source": roots["inputs"], "target": "/input",
                     "writable": False},
                    {"source": roots["workspace"], "target": "/output",
                     "writable": True}],
            # W71917: `None` FOR THE ADAPTERS THAT ONLY IDENTIFY OR RECOVER.
            # `_naming` and `_recovered` build an adapter to ask the engine
            # what is already there; neither starts anything, so neither needs
            # -- or should hold -- a delivery over somebody else's tree.
            source_delivery=boundary,
            outputs=[dict(one) for one in manifest["outputs"]],
            input_manifest_digest=manifest["manifest_digest"],
            credential_delivery=delivery,
            credential_home=self.credential_home,
            credential_orphan=orphan,
            launch_delivery=launched, workspace_group=self.group,
            context_delivery=_context_mount(self.control, self.given, launched.attempt_id) if launched is not None else None,
            scratch_delivery=scratch,
            context_execution=self._context_grant(launched),
            network=given["network"], interactive=True)

    def _context_grant(self, launched):
        """The launch boundary's grant, for the vocabularies that earn one.

        W177936: a deterministic profile answers None -- the adapter's
        refusal stands exactly as before, and composed fixtures substitute
        the boundary explicitly. Candidate and production admissions mint
        the grant by re-asking the store, which is the second half of the
        gate the admission already journaled.
        """
        from baton_v12.worker_manager import provider_context

        given = self.given
        if launched is None or given.get("provider_context") is None:
            return None
        profile = provider_context.context_profile_of(
            self.control, given["provider_context"]["profile_digest"])
        if profile["qualification"] == "deterministic":
            return None
        return provider_context.prove_context_execution(
            self.control, launched.attempt_id)

    def _credential(self, attempt_id, state, roots, launched=None, *,
                    seconds=None):
        given = self.given
        if not given["credential_resolution"]:
            return None, None
        if state["execution_runtime"] == "not-started":
            root = self.credential_home.volatile_root(attempt_id)
            if self.credential_home.read_state(attempt_id) is not None \
                    or os.path.lexists(root):
                self.credential_home.discard_orphan(attempt_id)
            return (self.credential_home.materialize(
                given["credential_resolution"], attempt_id=attempt_id,
                workspace_group=self.group,
                credential_provider=self.credential_provider), None)
        recovered = self._recovered(attempt_id, state, roots, launched,
                                    seconds=seconds)
        if recovered is not None:
            return recovered, None
        # THE START OPERATION MAY HAVE COMMITTED BEFORE ITS ENGINE CALL. The
        # materializing process and its Delivery capability are then gone,
        # and no runtime id exists yet with which `adopt` could rebuild one.
        # The public orphan capability carries exactly that durable
        # uncertainty into reconciliation without opening bearer bytes or
        # pretending the delivery never existed.
        return None, credentials.OrphanTeardown(
            attempt_id, homes=[self.credential_home])

    def _recovered(self, attempt_id, state, roots, launched=None, *,
                   seconds=None):
        """Adopt a published delivery only through the public LIVE proof.

        Review 2026-09-03T17:23:00Z [P1]: this read the lifecycle record and
        called `CredentialHome.adopt` with the runtime id taken OUT OF THAT
        SAME RECORD, so the one comparison it made was the record against
        itself. Bearer bytes were re-registered before anything proved the
        live container was the one the record names or that it holds the
        mount the record describes -- which is the exact boundary the
        credential recovery contract says must fail closed.

        `OciAdapter.recover_credentials` IS THAT BOUNDARY and it is composed
        rather than paraphrased: it derives this attempt's whole label set,
        identifies exactly one live runtime, compares the record's runtime id
        with the engine's answer, inspects what that runtime actually has
        mounted, and only then calls `adopt` itself. Ordinary
        `reconcile_runtime` performs none of those checks, which is why
        reaching it first was not the same thing.

        THE ADAPTER THAT ASKS CARRIES NO DELIVERY, because it has none yet --
        the delivery is what this returns. A disagreement raises, and the
        recovery operation's own bounded stop and cleanup ride out with the
        refusal untouched: nothing here re-registers a bearer, accepts output
        or repairs what disagreed.

        ABSENCE IS THE CALLER'S OTHER BRANCH rather than an ending here. The
        lifecycle record is written only once there is a runtime to name, so
        an attempt interrupted between the start journal and that publication
        has none, and the orphan teardown is what stands in for a delivery
        this process cannot hold.
        """
        if self.credential_home.read_state(attempt_id) is None:
            return None
        adapter = self._adapter(roots, None, None, launched)
        recovery = {
            "attempt_id": attempt_id,
            # THE ASSIGNMENT ACTIVATION FIXED, out of the same atomic read the
            # branch above turns on -- not the claim row, which is where this
            # attempt came from rather than what its runtime labels were
            # composed out of.
            "assignment": state["assignment"],
            "context": label_context(self.control, attempt_id)}
        # W247941: THE ALLOWANCE REACHES THE PRE-CORE RECOVERY TOO. An
        # unbounded call passes no operand, byte for byte as before.
        answered = (adapter.recover_credentials(recovery) if seconds is None
                    else adapter.recover_credentials(recovery,
                                                     seconds=seconds))
        return answered.get("delivery")

    def start(self, stage, job):
        """Drive one claimed stage to a live runtime, or to ONE recorded end.

        THE ATTEMPT AND ITS ACTIVATION COME FIRST AND STAND ALONE. They are
        what makes an ending recordable at all -- the record is held against
        the assignment activation fixed -- so a refusal from either is the one
        preparation refusal this composition cannot settle, and it travels out
        as itself rather than being dressed as an ending nobody wrote.

        EVERY BOUNDARY AFTER THEM SETTLES THE SAME WAY, and re-review [P1] is
        why "the same way" now means every one of them. The first correction
        settled only from `not-started` and re-raised from `start-requested`,
        so a credential recovery that failed closed in the restart window left
        the stage claimed and was asked again on every tick -- an ordinary
        refusal is neither an ending nor a safe wait state, and the recovery's
        bounded stop had already changed the host by the time the next tick
        repeated it. `refuse_runtime_preparation` records from both live axes,
        and the refusal it raises carries the recovery's whole account.
        """
        self._matches(stage, job)
        row = self._claim(stage)
        given = self.given
        attempt_id = stage["attempt_id"]
        self.checkpoint("claimed")
        record_attempt(
            self.control, attempt_id=attempt_id,
            adapter_name=given["adapter_name"],
            adapter_digest=given["adapter_digest"],
            profile_digest=given["profile_digest"],
            input_digest=given["input_manifest"]["manifest_digest"],
            policy_digest=given["policy_digest"],
            image_digest=given["image_digest"],
            toolchain_digest=given["input_manifest"]["toolchain_digest"])
        self.checkpoint("attempt")
        activate_assignment(self.control, self.port, attempt_id=attempt_id,
                            expect=_assignment(row))
        self.checkpoint("activation")
        # W285464 review 2026-09-27T17-26-12Z: THE WINDOW IS RELEASED WHEN THIS
        # WRITER RETURNS, success or refusal. An unfinished preparation window is held
        # because somebody may still be writing, and the one party that can say
        # otherwise is the writer itself: reaching this `finally` IS the cessation of
        # an in-process writer, not a deadline and not a label. A manager that DIES
        # mid-write runs no `finally`, so its window keeps standing and
        # `admit_preparation` reports it UNKNOWN -- which is the honest remainder.
        self._releasing = None
        try:
          try:
            return self._prepared(stage, row, attempt_id)
          finally:
            self._released()
        except SourceRefusal as failure:
            refusal = ContractRefusal("policy", "denied", _sayable(
                str(failure),
                "the configured credential source refused, and its own "
                "diagnostic quoted a value the secret registry holds live, "
                "so it is not carried"))
        except ContractRefusal as failure:
            refusal = failure
        # A START THAT ALREADY FAILED HAS ITS OWN ACCOUNT.
        # `request_runtime_start` journals the failed start, settles the axis
        # and re-raises -- so sending that refusal on to the preparation writer
        # got `already-terminal` back, and the sweep report then carried this
        # deployment's note about why it could not write a record instead of
        # the engine's reason for refusing. The owner's record already exists;
        # the original refusal is what an operator reads.
        if attempt_start_failure_of(self.control, attempt_id) is not None \
                or attempt_preparation_failure_of(self.control,
                                                  attempt_id) is not None:
            raise refusal
        # ONE OWNER-RECORDED ENDING, and the raise is the report. The Worker
        # Manager identifies the runtime, journals the failed preparation and
        # re-raises this refusal with its own account appended, so the next
        # projection reads that record and the stage is exceptional rather than
        # claimed and polled.
        #
        # THE IDENTIFICATION RIDES THE SAME CALL, and re-review [P1] is why.
        # Doing it after the record had no second chance: the record makes the
        # stage exceptional and the control plane stops asking, so a crash or a
        # naming refusal in between orphaned the runtime permanently. Asking
        # the owner to reconcile before it records makes a crash leave the
        # stage CLAIMED, which the next tick drives through the same path
        # again -- and it covers every boundary that refuses after a start was
        # requested rather than only the one branch that noticed.
        refuse_runtime_preparation(self.control, attempt_id=attempt_id,
                                   refusal=refusal,
                                   adapter=self._naming(attempt_id))

    def _naming(self, attempt_id):
        """An adapter that can only IDENTIFY, for an attempt that may have one.

        A runtime can exist only where a start was requested, so nothing is
        asked of the engine for an attempt that never reached one. The adapter
        carries no credential delivery and no launch delivery -- what the owner
        does with it is `list` and `observe` -- so no bearer is reread and no
        launch bytes are needed to build it.

        WHY THE ROOTS ARE COMPOSED RATHER THAN ALLOCATED. This runs while a
        failure is already on its way out, and `assignment_workspace` is one of
        the boundaries that may have been what refused. The reconciliation
        needs an adapter, not a workspace; the paths are the deployment's own
        derivation, exactly as the preflight adapter's are.

        ANSWERS `None` RATHER THAN RAISING, for the same reason: an ending
        nobody could write because an adapter could not be built is the retry
        loop this whole path exists to stop.
        """
        try:
            if attempt_runtime_of(self.control,
                                  attempt_id)["execution_runtime"] \
                    == "not-started":
                return None
            home = os.path.join(self.given["workspace_storage"], attempt_id)
            return self._adapter({"inputs": os.path.join(home, "inputs"),
                                  "workspace": os.path.join(home, "workspace")},
                                 None, None, None)
        except ContractRefusal:
            return None

    def _mounted(self, stage, attempt_id, *, checkpoint=True, writer=True):
        """This attempt's two roots and the mount custody composed over them.

        W103083. THE ALLOCATION HAPPENS FIRST FOR EVERY ROLE, and that is not
        an ordering convenience. A private line's writable root is the LINE,
        not a fresh directory, and a reviewer's read-only root is somebody
        else's frozen checkpoint -- but both of the accepted boundaries that
        compose those mounts ADOPT an attempt's roots rather than creating
        them, because creating is an allocation performed by something that
        only means to read. So this allocates the ordinary pair the way it
        always did, and the stage composition is then free to answer a
        different pair over it.

        WHAT A STAGE COMPOSITION MAY AND MAY NOT DO HERE. It answers `roots`
        and `boundary`, and everything downstream -- the durable pin, the
        input root, the retained manifest, the launch document, the credential
        delivery, the pre-start re-proof and the start -- runs over its answer
        unchanged. It cannot skip any of them, which is the point: a composer
        that wanted a line mounted writable had to be able to get one without
        also getting a second opinion about how a container is started.
        """
        given = self.given
        # W270664 F2: the store this worker acts through is the journal that says
        # whether a cleanup or removal owns these roots, so it is named here.
        # W285464 review 2026-09-27T16-13-26Z: OWNERSHIP FIRST, AND IT SPANS EVERY
        # WRITER. The allocation's own window closes when creation ends, so the
        # source mountpoint, the task publication, the protocol pair and the freeze
        # all used to run with nothing excluding a competing admission -- the
        # reviewer's probe admitted a real removal in the middle of
        # `compose_input_root`. This window opens before the first governed writer
        # and is closed by the completion record, so "admitted with no completion"
        # is exactly "a writer may still be finishing here".
        # THE EXECUTION IS THE ATTEMPT'S OWN RUNTIME IDENTITY, so a re-entry of THIS
        # execution continues its own window and another execution does not take it
        # over: review 2026-09-27T16-41-41Z is right that an ordinal anybody receives
        # is not authority to write, and that HOST-8 excludes a duplicate manager
        # rather than a second execution inside one.
        # THE OWNERSHIP IS A CAPABILITY THIS ACT HOLDS, not a name it repeats.
        # Review 2026-09-27T17-01-18Z: passing the attempt identity as an execution
        # made every re-entry for that attempt compare equal, so a second call was
        # admitted while the first writer could still finish. What continues a window
        # now is presenting the object the opening admission answered -- and this
        # composition holds it for exactly as long as it is preparing.
        held = self._preparations.get(attempt_id)
        # W236087, owner 2026-09-30T09:50:56Z: NO PREPARATION WINDOW OVER
        # PRESERVED, OFFERED MATERIAL.
        #
        # A preparation window says a writer may be running inside these roots,
        # and `admit_preparation` refuses to open one once the output is sealed
        # and the cleanup has not completed -- because the worker's material
        # stands offered for inspection and a preparation is a WRITER inside it.
        # THAT REFUSAL IS RIGHT. What was wrong is that an ending RE-ENTRY asked
        # for the window at all: its seal, collect and intake are already
        # journalled, and what it has left -- the retention decisions, the
        # Authority pass and the cleanup authorization -- writes nothing in
        # those roots. Measured: a review provider timed out, intake sealed its
        # output, the cleanup axis ended `pending`, and the manager was refused
        # every tick for 104 seconds and 58 sweeps until an operator
        # interrupted it.
        #
        # SO THE ROOTS ARE REVALIDATED INSTEAD. `assignment_workspace` takes the
        # same revalidation path it already takes for a live task: it PROVES the
        # pair and refuses missing or replaced material rather than repairing
        # it, and it writes nothing. `mount` still composes a boundary and a
        # LAUNCH still admits its window, because a container really is a writer.
        # AND THE CALLER'S INTENT DECIDES, NOT THE STATE ALONE. Review
        # 2026-09-30T11:24:20Z: my first cut skipped the window whenever the
        # material was offered, for EVERY caller of this shared helper -- so a
        # launch, a task publication or a credential writer reaching this state
        # would have lost the protection instead of being refused by it. Only a
        # RE-ENTRY THAT WRITES NOTHING passes `writer=False`, and the skip
        # needs both that and the offered state. Every other caller keeps the
        # admission and keeps the refusal.
        offered = not writer and workspaces.material_is_offered(
            self.control, attempt_id)
        preparing = None if offered else workspaces.admit_preparation(
            self.control, attempt_id,
            f"preparing attempt {attempt_id}'s roots", attempt_id,
            holding=held)
        if preparing is not None:
            self._preparations[attempt_id] = preparing
        # AND THE WINDOW IS RELEASED WHEN THIS WRITER RETURNS. W285464 review
        # 2026-09-27T17-26-12Z: an unfinished window is held because somebody may
        # still be writing, and the one party that can say otherwise is the writer
        # itself -- so the composition that opened it closes it on its way out unless
        # the completion already did. A process that DIES mid-write runs no `finally`,
        # which is why that case stays held and is reported UNKNOWN.
        # NOTHING TO RELEASE WHEN NOTHING WAS ADMITTED. `_released` reads this
        # to close a window whose writer returned without completing; a
        # revalidated ending opened no window, so there is no window to close.
        self._releasing = None if preparing is None else (attempt_id, preparing)
        roots = workspaces.assignment_workspace(
            self.group, given["workspace_storage"], attempt_id,
            control=self.control,
            preparing=None if preparing is None else preparing.ordinal)
        if checkpoint:
            self.checkpoint("workspace")
        if self.stage is not None:
            # W285465: THE ACTING PREPARATION'S OWN CAPABILITY GOES TO THE STAGE OWNER,
            # which is the producer hop the consumer's fresh positive reaches. This
            # composition holds `preparing` because it just admitted the window; the stage
            # forwards it and the adoption entry decides.
            composed = self.stage.mount(self, stage, roots, preparing=preparing)
            return composed["roots"], composed["boundary"]
        return roots, source_boundary.compose_source_boundary(
            given["source_nomination"], roots, given["workspace_capacity"])

    def _prepared(self, stage, row, attempt_id):
        """Compose the assignment's material and start or reconcile its runtime.

        Every refusal here has one recorded ending at the caller, so nothing in
        it repairs, completes or works around material it cannot account for.

        THE LAUNCH DELIVERY IS PROVED BEFORE ANY BEARER IS TOUCHED. Credential
        recovery rereads and REGISTERS bearer bytes; a launch document that
        refused afterwards left those registrations live with nothing holding
        the delivery, and the next tick registered them again. Proving the
        launch first means the only thing a launch refusal can unwind is a
        launch.

        AND THE UNWIND COVERS THE START ITSELF. Re-review 2026-09-03T19:24:19Z
        [P1]: the cleanup `try` used to end before `request_runtime_start`, and
        the provider's answer is UNTRUSTED -- one equal to this attempt's own
        durable identity is registered live and then makes every §13 walk over
        a row containing that identity refuse. The manager could no longer read
        its own attempt, so nothing could be settled, recorded or reported, and
        the delivery stayed on the host. The delivery's owner stays live across
        every pre-start boundary that follows materialization, so the colliding
        value is released -- after its bytes are proved gone -- before any
        durable state is read again.
        """
        given = self.given
        roots, boundary = self._mounted(stage, attempt_id)
        # W71917: THE BOUNDARY IS COMPOSED BEFORE THE INPUT ROOT IS FROZEN,
        # and the order is the content. `compose_source_boundary` establishes
        # the empty mountpoint inside `inputs`, and `compose_input_root` closes
        # that directory read-only when it finishes -- so a boundary composed
        # afterwards would have nowhere to put the mountpoint, and a deployment
        # that created it later would be writing into evidence a claim was
        # already made against.
        #
        # IT ALSO PROVES THE WORKSPACE HERE, which is before anything exists to
        # undo: a workspace on a memory filesystem, or one whose storage cannot
        # currently meet the declared capacity, is a preparation refusal with
        # no container started rather than a worker discovering it halfway
        # through a turn.
        #
        # W103083 MOVED THAT COMPOSITION INTO `_mounted` ABOVE and changed
        # nothing about it: the bootstrap branch is the same call with the
        # same operands, and the ordering rule this comment states is kept by
        # allocating and composing before the two lines below rather than by
        # where the call is spelled.
        # W71917: AND THE OBJECT IT PROVED IS PINNED DURABLY, immediately.
        #
        # The composition above pins the source's (device, inode) IN MEMORY,
        # which is enough for this incarnation and nothing at all for the next
        # one: a restarted manager recomposes the boundary from configuration,
        # so the pre-start comparison would compare a fresh reading with
        # itself. Run7 review [P1] is exactly that hole -- a directory replaced
        # while the manager was down is re-nominated and accepted.
        #
        # WRITE-ONCE, AND AN EXACT REPEAT IS NOT A WRITE, so every later
        # incarnation reaching this line for the same attempt either re-observes
        # the same object or is refused here rather than silently re-pinning
        # the replacement over the evidence that would have caught it.
        pin_boundary_identity(
            self.control, attempt_id=attempt_id,
            source=(boundary.device, boundary.inode),
            # W71917 THIRD REVIEW [P1]: BOTH ROOTS. The source was pinned and
            # the workspace was not, so a real directory created at the
            # workspace's pathname was adopted with nothing to compare it
            # against -- and the workspace is the half this assignment's answer
            # is collected out of.
            workspace=(boundary.workspace_device, boundary.workspace_inode))
        self.checkpoint("boundary")
        assignment = _assignment_manifest(given, row, attempt_id,
                                          stage["offer_id"])
        manifest = self._input(roots, assignment, boundary)
        self.checkpoint("input")
        retain_manifest(self.control, manifest, "inputManifest")
        self.checkpoint("manifest")
        # W285464, amended TOK-7: THE HOST DURABLY RECORDS THAT ITS PREPARATION
        # FINISHED, after the last governed writer on this path and before the task
        # is admitted. `_input` is that last writer -- it publishes the task and the
        # protocol pair and freezes the root -- so the account is written here, with
        # the objects a task is about to be started over named by `device:inode`.
        #
        # A RESTART REACHES THIS LINE THROUGH THE SAME PATH and writes the same
        # operands at the same identity, so it replays rather than recording a
        # second preparation.
        workspaces.record_preparation(
            self.control, attempt_id, roots,
            (TASK_DOCUMENT,) + (("judgment.json",)
                                if self.judgment_document is not None else ()))
        self.checkpoint("prepared")
        state = attempt_runtime_of(self.control, attempt_id)
        fresh = state["execution_runtime"] == "not-started"
        if given.get("provider_context") is not None:
            if self.stage is None:
                _refuse("required provider context lacks its stage owner")
            self.stage.prepare_context(self, stage)
        launched = self._launch_document(stage, state)
        self.checkpoint("launch")
        delivery = None
        adapter = None
        try:
            delivery, orphan = self._credential(attempt_id, state, roots, launched)
            self.checkpoint("credential")
            # W71917: RE-PROVED IMMEDIATELY BEFORE THE START, and this is the
            # gate the ruling asks for. Everything between composition and here
            # -- the input root, the retained manifest, the launch document,
            # the credential delivery -- takes time a host is free to change
            # things in, and the two paths this delivery rests on are the two
            # a change would be worst at. A source re-pointed at another tree
            # resolves to the same characters and a different inode; a
            # workspace replaced with a link or moved aside is no longer the
            # one this manager holds custody of. Both refuse here, with no
            # runtime started.
            #
            # A RESTART REACHES THIS LINE THROUGH THE SAME PATH, which is why
            # there is one gate rather than two: `assignment_workspace`
            # answered the adopted roots, the boundary was composed over them
            # again, and this proves the topology a second incarnation is about
            # to start over is the one it just proved.
            boundary = source_boundary.adopt_source_boundary(
                boundary, roots,
                # READ UNCONDITIONALLY. A caller that has a pinned identity and
                # does not pass it gets the weaker in-memory gate, which after a
                # restart compares a fresh reading with another fresh reading.
                pinned=boundary_identity_of(self.control, attempt_id))
            self.checkpoint("adopted-boundary")
            # W202663: the per-attempt disk-backed scratch travels with the
            # START path only -- identification and recovery adapters compose
            # exactly what they composed before.
            adapter = self._adapter(roots, delivery, orphan, launched,
                                    boundary,
                                    scratch=self._attempt_scratch(attempt_id))
            if fresh:
                # W285464, amended TOK-7: NO LAUNCH WHILE A HOST WRITER COULD STILL
                # FINISH, AND NOT OVER A REPLACED RESOURCE. The gate asks the
                # journal three things -- is any preparation writer still able to
                # complete, did the preparation finish at all, and are the inputs
                # and workspace the very objects it completed over -- and refuses
                # before any container is created. A deadline is not cessation, so
                # nothing here infers an ending from elapsed time.
                workspaces.require_prepared(
                    self.control, attempt_id, roots,
                    f"starting attempt {attempt_id}'s runtime")
                if given.get("provider_context") is not None:
                    self.stage.revalidate_context(self, stage)
                # W275774: THE GOVERNED START. The workspace object this
                # assignment mounts is the resource its start contends for, so
                # the start is reserved against it, the container is bound before
                # any effect, and the activation is admitted at the last moment.
                # W275774 review 18:33:48Z [P1]: THE ARGUED IDENTITY AT THE START.
                #
                # Overlap exclusion is decided at ACQUISITION -- the only moment it
                # matters, because that is when one resource is or is not already held.
                # So the start passes the control store and gets the identity carrying
                # the containment argument, which also proves it EQUALS the pinned
                # object. The endings below deliberately keep the pinned form: by then
                # the workspace may legitimately be gone, and an identity that refused
                # for a missing path would silently skip an attempt whose token is still
                # held. Equal at acquisition, stable afterwards.
                # W275774, MEASURED DEFECT OF MY OWN, 2026-09-26 claim 279322: THE
                # CONTROL-BOUND FORM IS WRONG FOR THIS DEPLOYMENT.
                #
                # `governed_workspace_identity` re-derives the writable root as
                # `<configured storage>/<attempt>/workspace` and requires it to equal the
                # PINNED object. That holds for the plain layout and NOT for a private
                # line: `workspaces.adopted_persistent_line` composes roots whose
                # `workspace` IS THE LINE HOME, so the pin records that object and the
                # re-derived path names a different directory. The equality check then
                # refused every implementation start with
                # "the resource a start reserved is not the resource this act would name".
                #
                # Measured, not reasoned: `test_oci`'s context-mount cases and
                # `test_stage_execution` failed with exactly that refusal, and I had
                # previously reported those as pre-existing WIP -- which review 21:33:35Z
                # was right to refuse as an unattributed claim.
                #
                # AND THE REPAIR IS THE ROOT, NOT A DOWNGRADE. Review 22:07:51Z refused
                # my first correction -- pins-only governance here -- because it dropped
                # the acquisition overlap argument for ORDINARY starts as well, to fix a
                # layout mismatch that only a private line has. What this passes instead
                # is the root it is about to mount: the containment owner proves that root
                # sits in one of the two sibling arrangements this build supports, the
                # equality against the PINNED object is unchanged, and the domain is still
                # the durable one every ending here resolves through.
                # W285464 review 2026-09-27T17-37-14Z: THE CONDITION TRAVELS INTO
                # THE ACQUISITION. `require_prepared` above is the early refusal and
                # reads the OBJECTS, which needs a filesystem and therefore cannot
                # happen under a lock; this governance re-asks the journal-only half
                # inside `tokens.acquire`'s own `BEGIN IMMEDIATE`, so a conflict that
                # arrives between the two is refused by the acquisition rather than
                # slipping through the gap. Same domain, same journal, same G1
                # endings -- only the eligibility is added.
                answer = request_runtime_start(
                    self.control, adapter, attempt_id=attempt_id,
                    inputs=roots["inputs"],
                    govern=workspaces.prepared_workspace_governance(
                        self.control, attempt_id,
                        mounted=roots["workspace"]))
            else:
                answer = reconcile_runtime(self.control, adapter,
                                           attempt_id=attempt_id)
        except (SourceRefusal, ContractRefusal):
            self._unwound(adapter, delivery, launched, fresh)
            raise
        self.checkpoint("runtime")
        return answer

    def _released(self):
        """Close this composition's preparation window if it opened one.

        Called from the caller's own `finally`, so the writer has returned by the time
        this runs. If the preparation COMPLETED, its completion already closed the
        window and this records nothing; otherwise the release says the writer ended
        without finishing, which is a different fact from either.
        """
        naming = getattr(self, "_releasing", None)
        if naming is None:
            return
        attempt_id, holding = naming
        self._releasing = None
        self._preparations.pop(attempt_id, None)
        if workspaces.preparation_completed(self.control, attempt_id) is not None:
            return
        workspaces.release_preparation(
            self.control, holding,
            f"the composition preparing attempt {attempt_id} returned without "
            f"recording a completion, so its writer has ended")

    def _unwound(self, adapter, delivery, launched, fresh):
        """End what THIS attempt's pre-start composition still holds.

        BEFORE A START IS THE WHOLE CONDITION, and re-review [P1] corrected
        what it used to be. Ownership was read as "did this invocation author
        it", which left a launch document published by a process that crashed
        before its credential, adopted by the next one and then stranded by an
        ordinary provider refusal -- present forever, with no runtime that
        could ever have mounted it. What decides is the state the manager
        already proved: `not-started` says no runtime received either
        delivery, so both are this composition's to end. After a start was
        requested neither is: a container may hold the mount, and removing a
        mount source out from under one is the act the credential contract
        calls worse than leaving it.

        AN OWNER THAT ALREADY DECIDED IS NOT SECOND-GUESSED, and re-review
        2026-09-03T22:20:58Z [P1] is why this comes first. `fresh` is the axis
        as it stood BEFORE the start was requested, so a start that reached the
        engine, CREATED a container and then reported failure arrived here
        still called fresh -- and this removed the very mounts that container
        holds. `OciAdapter._undelivered` had already asked the engine, seen the
        live runtime and left both roots `unresolved` on purpose; it said so
        only in refusal prose, so nothing here could tell. It keeps that answer
        now, and an adapter carrying one has settled both mounts by whatever
        rule its own evidence supports. There is nothing left here to end.

        TWO CONDITIONS THIS IS NOT, because both were tried and each broke a
        rule pinned above. The execution AXIS skips the settled-`uncertain`
        path, where nothing was established and a colliding bearer must still
        be released. The attached runtime IDENTITY cannot even be read on that
        same path, because the attempt row carries the very value §13 is
        refusing over -- the read that would decide is blocked by the condition
        this teardown exists to clear. Neither is a fact about who decided;
        the settlement is.

        `None` IS THE ORDINARY CASE and keeps `fresh` as the whole rule: a
        refusal raised before the adapter existed, or before `start` reached
        the settlement, is one where no runtime owner decided anything and the
        deliveries are this composition's as before.

        THE CREDENTIAL FIRST, because its teardown is what proves the bytes
        gone and only then releases the registered value -- which is what lets
        the caller read durable state again when the provider's answer
        collided with it.
        """
        if adapter is not None and adapter.settlement is not None:
            return
        if not fresh:
            return
        if delivery is not None:
            self.credential_home.tear_down(delivery)
        if launched is not None:
            launch.discard(launched.root)

    # -- W81857: the durable file exchange -----------------------------------
    #
    # THREE ENTRY POINTS AND ONE RECONSTRUCTION. Every pass rebuilds this
    # attempt's launch and exchange delivery from durable state -- nothing is
    # carried in a field, and the process that started the container has no
    # standing the next one lacks. That is the whole point of the transport:
    # the manager's lifetime is not the container's, so a restarted manager
    # reaches exactly the same delivery by rereading exactly the same files.

    def observed_exchange(self, stage):
        """This attempt's exchange, as an observation that never raises.

        THE PROJECTION READS THIS FOR EVERY STAGE ON EVERY TICK, which is why
        a refusal here is caught and reported rather than propagated. The
        acceptance requires a faulted stage to leave every other stage
        observable; an adoption refusal that escaped would make one damaged
        launch root stop the sweep from observing anything at all.

        WHAT COMES BACK IS SAFE. The category and the code and nothing else --
        a refusal's prose is composed from values this deployment read,
        including values a worker wrote, and the exchange's durable-evidence
        rule does not stop applying because the value is on its way to a
        status document.
        """
        try:
            launched = self._adopted(stage)
            if launched is None or launched.exchange is None:
                return None
            return exchange.observation(launched.exchange)
        except ContractRefusal as refusal:
            return {"transport": exchange.EXCHANGE_TRANSPORT,
                    "sequence_id": None, "command": None, "receipt": None,
                    "states": [], "terminal": None, "foreign": [],
                    "state": "unreadable",
                    "unreadable": {"category": refusal.category,
                                   "code": refusal.code}}

    def refresh_runtime(self, stage):
        """Ask the ENGINE what this attempt's attached runtime is now.

        W85500. THE SERVING LOOP'S ONE RUNTIME READ, and until this existed
        there was none after the start. `request_runtime_start` attaches a
        runtime and records it; `_prepared` reconciles only while a stage
        still projects `claimed`; and `ending` reconciles only after an
        `answered` terminal -- which an exceptional stage never reaches,
        correctly, because it owes no act. So a worker that wrote a faulted
        terminal and exited was projected `running` for as long as anybody
        looked, while the engine independently reported the exact runtime
        exited.

        WHAT IT MAY NOT DO is the whole boundary. `reconcile_runtime` lists by
        the complete immutable assignment labels, observes the exact attached
        identity even when the listing is empty, and records the answer. It
        starts nothing. This composition gives it a NAMING-ONLY adapter: no
        credential is read, resolved or registered, no launch document is
        authored or adopted, no command is published, no provider is invoked,
        and no workspace material is written.

        NOTHING TO REFRESH IS AN ANSWER, not a refusal. An attempt that never
        requested a runtime has nothing for an engine to be asked about.
        A failed preparation with a start already requested is different: a
        lost reply can leave a real runtime unidentified, so that failure still
        owes read-only identification. `None` reports genuinely unasked cases.

        AND IT NEVER MANUFACTURES QUIESCENCE. What comes back is whatever the
        reconciliation recorded. A stopped container is `quiescent` on the
        RUNTIME axis and says nothing whatever about the worker's answer; the
        ending stays gated on a correlated `answered` terminal.
        """
        attempt_id = stage["attempt_id"]
        state = attempt_runtime_of(self.control, attempt_id)
        if state is None:
            return None
        unidentified_failure = (state["runtime_id"] is None
                                and state["execution_runtime"] == "start-requested"
                                and attempt_preparation_failure_of(self.control, attempt_id) is not None)
        if state["runtime_id"] is None and not unidentified_failure:
            return None
        # A RUNTIME ALREADY AT THE END OF ITS AXIS IS NOT ASKED ABOUT AGAIN.
        # The transition table names nothing after `destroyed`, so an engine
        # answer could only be refused by the recorder -- and every sweep after
        # a cleanup would become a refusal this pass then has to contain.
        if state["execution_runtime"] == "destroyed":
            return None
        # W61599: THE ENQUEUE, AND IT IS A SLOT ASSIGNMENT. This hook is the
        # serving loop's one runtime read: it already runs per tick, it is
        # serving-only, and an attempt with a live runtime is exactly the
        # attempt whose container may be publishing a count. What happens here
        # is an assignment into a single slot -- no file is read, no store is
        # written, no launch is adopted, and nothing below can block.
        self._enqueue_activity(attempt_id)
        if unidentified_failure:
            # A lost launch reply plus failed identification still owes observation.
            # The exceptional stage will not launch again; name its exact runtime
            # without reopening host preparation or clearing the recorded failure.
            adapter = self._naming(attempt_id)
            if adapter is None:
                return None
        else:
            roots = workspaces.assignment_workspace(
                self.group, self.given["workspace_storage"], attempt_id,
                control=self.control)
            # Observation carries no credential or launch delivery.
            adapter = self._adapter(roots, None, None, None)
        # THE ENGINE'S OWN FAILURES, NAMED BY THE DEPLOYMENT THAT OWNS THEM.
        # Review 2026-09-04T19:08:40Z [P1]: the manager caught `OSError` and
        # then caught `Exception`, so it was deciding what an engine failure
        # is on behalf of every deployment -- and turning everything else into
        # report data `serve` discards on the next tick.
        #
        # THESE TWO ARE ONE OPERATIONAL FACT AND TWO PYTHON TYPES. The runner
        # is `subprocess.run`: an invocation that could not be made at all --
        # a missing engine binary -- arrives as `OSError`, and one that hit
        # its deadline arrives as `TimeoutExpired`, which is not an `OSError`
        # and used to reach the blanket branch. Both mean the question could
        # not be put, and neither says anything about whether the container is
        # still there.
        #
        # A DEAD DAEMON IS NOT ONE OF THEM, and review 2026-09-04T21:52:30Z
        # measured that through this exact composition. The CLI runs perfectly
        # well and answers NON-ZERO, so `OciAdapter.list` refuses it `policy /
        # denied` and the manager reports that category and code. It is
        # contained per stage like any other refusal and it records nothing on
        # the runtime axis, so the accepted boundary holds -- but it is not
        # `uncertain / engine-unreachable`, and this comment used to say it
        # was. Telling an unreachable daemon apart from an ordinary policy or
        # integrity refusal needs a typed adapter failure that does not exist
        # yet; wrapping every OCI `ContractRefusal` instead would report a
        # mislabelled runtime or a hand-edited listing as an unreachable
        # engine, which is a different fact entirely.
        #
        # NOTHING WIDER. A defect in this composition is not an unreachable
        # engine and must not be dressed as one; it escapes, and the manager
        # lets it.
        try:
            reconcile_runtime(self.control, adapter, attempt_id=attempt_id)
        except (OSError, subprocess.TimeoutExpired) as unreachable:
            raise RefreshUnavailable(unreachable) from unreachable
        # THE RECORDED AXIS, READ BACK, and not the reconciliation's own
        # answer document. That document reports what this call OBSERVED, in
        # one of several shapes depending on which branch it took; what the
        # sweep reports is the durable runtime axis, which is the same fact
        # every other reader sees and the one a restart reaches too. Reading
        # it back also means this answer cannot disagree with the projection
        # taken a moment later in the same tick.
        return {"execution_runtime":
                attempt_runtime_of(self.control,
                                   attempt_id)["execution_runtime"]}

    def _enqueue_activity(self, attempt_id):
        """Hand one attempt to the ingestion helper. NEVER raises at the sweep.

        W61599. WHAT TRAVELS is the attempt, this manager's own session for it,
        and the LOCAL event root -- a capability composed by this deployment
        rather than read from any document. The remaining identities the helper
        compares are derived by rule or read from the command this manager
        itself published, off this thread.

        THE ROOT IS COMPOSED, NOT ADOPTED, and `_naming` records the same rule
        for the same reason: `launch.adopt` authors and compares canonical
        bytes, which is a proof this diagnostic has no business performing and
        which the design explicitly forbids on this path. `launch.materialize`
        puts one attempt's delivery at `<launch_home>/<attempt_id>` and
        `ExchangeDelivery` derives both namespaces from it; a root that names
        nothing simply yields no document to read.

        A HELPER THAT IS ABSENT IS NOT A FAILURE. It is a deployment whose
        store already admitted one, and the optional count is then absent.
        """
        if self.activity is None:
            return
        try:
            root = os.path.join(self.given["launch_home"], attempt_id)
            self.activity({"attempt_id": attempt_id, "root": root,
                           "session": self._session_of(attempt_id)})
        except BaseException:                              # noqa: BLE001
            # A DIAGNOSTIC MAY NOT STOP THE SWEEP. This hook exists to observe
            # the serving loop, and an observation that could end a pass would
            # be the defect it was added to remove.
            return

    def command(self, stage, job):
        """Publish THE ONE command sequence into this attempt's exchange.

        THIS IS THE ACT THE WHOLE WORK EXISTS FOR. Before it the container is
        up and has been asked for nothing -- which is the state W81857
        reproduced and which every health and elapsed-time signal reports as
        indistinguishable from useful execution. After it the command is a
        durable file, and neither this process nor the manager that restarts
        after it is needed for the container to act on it.

        IT IS SAFE TO CALL TWICE AND THAT IS NOT AN ACCIDENT. The document is
        authored from the attempt alone, so two managers compose identical
        bytes under an identical derived name; the publisher adopts an
        identical existing command and refuses a different one rather than
        replacing a command the worker may already have receipted.
        """
        self._matches(stage, job)
        attempt_id = stage["attempt_id"]
        launched = self._adopted(stage)
        if launched is None or launched.exchange is None:
            _refuse(f"attempt {attempt_id!r} has no exchange delivery to "
                    f"publish a command into; a command nothing mounts is a "
                    f"file no container will ever read",
                    category="refused", code="precondition")
        published = exchange.publish_command(
            launched.exchange,
            exchange.command_document(session=self._session_of(attempt_id),
                                      attempt_id=attempt_id))
        # THE HOST PATH STAYS HERE. What the control plane reports is whether
        # this call published the sequence and which command it is; where this
        # deployment keeps its launch home is a fact about the machine and not
        # about the stage, and a sweep report is read by whoever is watching
        # the service rather than by whoever provisioned it.
        return {"published": published["published"],
                "command_digest": published["command_digest"]}

    def cancel_attempt(self, *, attempt_id, reason):
        """Stop an attempt that is STILL EXECUTING, through the accepted path.

        W236087, review 2026-09-22T07:03:13Z R2a. A bounded owner supervisor
        that reaches its deadline with a provider turn still running has
        nothing to drive: closing its admission gate stops the NEXT runtime and
        the ordinary ending path has nothing to finish while this one waits. So
        the runtime kept going and the run reported `held` with a container
        alive. Stopping it is the DEPLOYMENT's act, because the port, the agent
        and the adapter are this composition's -- an orchestrator that rebuilt
        them from this module's private state would be a second controller over
        one security boundary.

        `attempts.request_cancellation` IS the act, unchanged: it fences the
        exact participant and generation at the Authority FIRST and only then
        orders quiescence, because a runtime stopped before the fence is a
        worker torn out from under an assignment the authority still believes
        is executing. Nothing here re-implements any part of it.

        THE ADAPTER IS THE IDENTIFY/OBSERVE ONE. `reconcile` already builds it
        exactly this way for an attempt it did not start in this process, and
        `OciAdapter.stop` reads only the runtime id and the operation id out of
        its request -- no credential delivery, no launch document and no orphan
        belong to a stop, and composing them here would be inventing operands
        for an act that has none.

        ITS RETURN IS NOT ABSENCE, and the caller is owed that plainly: this
        answers what was ORDERED. Positive exclusion arrives through the
        ordinary ending and `intake.cleanup_of`, which is where the supervisor
        keeps looking.
        """
        boundaries.identity(attempt_id, "a runtime attempt id")
        roots = workspaces.assignment_workspace(
            self.group, self.given["workspace_storage"], attempt_id,
            control=self.control)
        return attempts.request_cancellation(
            self.control, self.port, _UncooperativeAgent(self.given),
            self._adapter(roots, None, None, None),
            attempt_id=attempt_id, reason=reason)

    def abandon_attempt(self, *, attempt_id, reason, stage, seconds=None,
                        reclaim=None):
        """W247941: the manager's FOURTH ending, reachable by its owner.

        THE COMPOSITION OWNS THIS AND AN ORCHESTRATOR CANNOT.
        `intake.abandon_attempt` needs the Authority port, a per-attempt
        adapter carrying the deliveries the START created, and the custody
        capability -- all three this composition's. A supervisor that rebuilt
        them from this module's private state would be a second controller over
        one security boundary, which is the rule `cancel_attempt` records.

        AND IT IS A DECLARATION, NOT AN OBSERVATION. `reason` is the caller's
        own account of why the attempt is over; nothing here reads a clock,
        counts a retry or measures silence. Calling the operation IS the
        declaration, so a caller that has not decided must not call this.

        REPLAY IS THE CORE'S. `intake.abandon_attempt` commits or replays its
        own intent before any external call and owns every eligibility check.
        This composes operands and nothing else -- it does not read a discharge
        or a cleanup to decide what to do, and it never synthesises an
        operation result.
        """
        boundaries.identity(attempt_id, "a runtime attempt id")
        reason = boundaries.text(reason, "an abandonment reason")
        # THE TYPE ANSWERS FIRST, AND THE REFUSAL TOUCHES NOTHING. A refusal
        # that formats with `(stage or {}).get(...)` raises `AttributeError`
        # on a string, a list or an int -- a refusal that crashes is not one.
        if type(stage) is not dict:
            # `integrity`/`schema` is the closed pair for a malformed
            # document; `refused`/`schema` is not one, and this build asserts
            # on an unclosed pairing rather than raising the refusal.
            _refuse(f"an abandonment takes the attempt's own stage document; "
                    f"this is a {type(stage).__name__}",
                    category="integrity", code="schema")
        if stage.get("attempt_id") != attempt_id:
            _refuse(f"an abandonment names the stage of attempt "
                    f"{attempt_id!r} and this one names "
                    f"{stage.get('attempt_id')!r}; the durable context is "
                    f"recovered from the attempt's own stage or this refuses "
                    f"before any effect",
                    category="refused", code="precondition")
        state = attempt_runtime_of(self.control, attempt_id)
        if state["runtime_id"] is None:
            _refuse(f"attempt {attempt_id!r} has no attached runtime; "
                    f"abandonment ends an attempt whose runtime STARTED and "
                    f"whose worker then never answered, and there is nothing "
                    f"here to end", category="refused", code="precondition")
        # ADOPTION DECIDES WHICH ROOT RECOVERY IS EVEN LEGAL, so it happens
        # first. `launch.adopt` answers None ONLY when the launch root does not
        # exist -- every other condition refuses -- so None means there is no
        # launch material, and a stage composition has nothing to answer about.
        launched = self._adopted(stage)
        if launched is not None and self.stage is not None:
            # THE STAGE'S OWN MOUNTS, recovered the way `ending` recovers them
            # for an attempt this process did not start: a private line is the
            # writable root for an implementation attempt, and a teardown over
            # the ordinary pair would remove the wrong tree.
            roots = self._mounted(stage, attempt_id, checkpoint=False)[0]
        else:
            # PROVED, NEVER ALLOCATED. Allocating a root in order to remove it
            # would be this call creating what it came to destroy, and a
            # refusal here is the core's own precondition failing early rather
            # than a state this call may work around.
            roots = workspaces.adopted_assignment_workspace(
                self.given["workspace_storage"], attempt_id,
                control=self.control)
        # A RETRY AFTER AN INTERRUPTED SETTLEMENT FINDS THE RUNTIME GONE, and
        # `_credential`'s live recovery cannot serve it: `recover_credentials`
        # adopts exactly ONE identified container and refuses every other
        # count, so a removal that journalled nothing left a retry that this
        # composition refused before the core was ever entered -- the one the
        # core explicitly supports, because "force-removal of an already
        # absent exact identity answers absent".
        #
        # SO THE ENGINE IS ASKED, AND ONLY A POSITIVE ABSENCE BRANCHES.
        # `observe` answers `absent` only when the engine says THIS EXACT
        # identity does not exist; anything it cannot read is `uncertain`, and
        # uncertainty takes the ordinary path. Nothing here catches a refusal
        # to decide this -- that was the fabrication this Work removed.
        #
        # AND THE ORPHAN IS `_credential`'S OWN ANSWER for a delivery this
        # process cannot hold, not a substitute invented here: the credential
        # lifecycle is then settled by cleanup discarding the orphaned root,
        # which is what the recovery refusal itself describes.
        if self._adapter(roots, None, None, launched).observe(
                state["runtime_id"], seconds=seconds)["state"] == "absent":
            delivery = None
            orphan = (credentials.OrphanTeardown(
                attempt_id, homes=[self.credential_home])
                if self.given["credential_resolution"] else None)
        else:
            delivery, orphan = self._credential(attempt_id, state, roots,
                                                launched, seconds=seconds)
        adapter = self._adapter(roots, delivery, orphan, launched)
        answered = intake.abandon_attempt(
            self.control, self.port, adapter, attempt_id=attempt_id,
            reason=reason,
            retention_policy_digest=self.given["retention_policy_digest"],
            # W275774 review 16:29:48Z [P1]: THE ABANDONED ENDING GOVERNS TOO, and
            # leaving it out was the exact defect I had warned about in the abstract
            # one claim earlier -- a governed start acquires a token that an
            # ungoverned ending cannot return. Abandonment is the case a resource
            # token exists for, a runtime whose worker never answered, so this is the
            # ending where a permanent hold would hurt most.
            govern=tokens.workspace_governance(),
            # ONE ALLOWANCE, READ AT EACH BOUNDARY. `seconds` may be a
            # callable answering what is left, so the observation above, the
            # removal, both custody acts and the discharge below all spend
            # from the same budget rather than each starting a fresh one.
            seconds=seconds,
            # AND THE RECLAMATION SPENDS THE TOTAL. The work allowance is net
            # of the caller's reserve; the margin exists for the reclamation a
            # timed-out act may still owe, so that is what may spend it.
            reclaim=reclaim)
        # AND THE GATE THIS ACT INSTALLED IS CARRIED, because nothing else
        # will. The fence and the authority's `runtime-quiescence:<generation>`
        # commit in one transaction, and an abandonment has no ordinary ending
        # anywhere in its future to discharge it -- so an operator declaration
        # would leave the Work gated forever. A REFUSAL HERE PROPAGATES: the
        # cleanup is committed and durable, and a retry replays it and then
        # discharges, which is better than an answer that hides an obligation
        # nobody holds a receipt for.
        self._discharged_abandonment(attempt_id, answered)
        return answered

    def _discharged_abandonment(self, attempt_id, answered):
        """W247941: the abandoned gate's discharge, on the accepted shape.

        `StageExecution._discharged` is the pattern and this is deliberately
        the same three steps in the same order: REPLAY a committed discharge
        before anything mutable is read, decide owedness from what THIS act
        FENCED rather than from today's projection -- a lost receipt leaves
        the gate already cleared, so the projection would say nothing is owed
        -- and only then perform the act.

        AND THE COMMITTED CLEANUP IS THE PRECONDITION, read from the durable
        record rather than inferred from the answer in hand. An interrupted
        settlement journals nothing, and this gate "is discharged on the
        abandonment this manager committed and never on the absence of one";
        asking the reader is how this composition knows which it is holding.
        """
        held = intake.abandoned_gate_discharge_of(self.control, attempt_id)
        if held is not None:
            return held
        if not (answered.get("fenced") or {}).get("gate"):
            return None
        digest = self.given["retention_policy_digest"]
        if intake.abandonment_cleanup_of(
                self.control, attempt_id=attempt_id,
                retention_policy_digest=digest) is None:
            return None
        return intake.discharge_abandoned_quiescence_gate(
            self.control, self.port, attempt_id=attempt_id,
            retention_policy_digest=digest)

    def ending(self, stage, job):
        """Drive ONE answered attempt through the already-ruled ending.

        THE ORDER IS THE RULING'S AND IS NOT AN IMPLEMENTATION CHOICE:

          1. positively quiesce and reconcile the exact runtime;
          2. record the worker's returned disposition;
          3. freeze the declared output for that disposition;
          4. collect it and record the intake receipt;
          5. decide every artifact's retention under the configured policy;
          6. end the exact Authority assignment by passing it to the
             configured review Route; and only then
          7. authorize runtime cleanup.

        `authorize_cleanup` REFUSES WHILE THE ASSIGNMENT IS LIVE, so cleaning
        up before the pass is not an implementation option. Conversely, ending
        the assignment before intake can quarantine the result if the
        collection races that ending. The pass therefore follows intake and
        retention and precedes cleanup, which is where W44657 put it.

        AND IT IS ASKED AGAIN UNTIL IT IS FINISHED. Review
        2026-09-04T03-43-45Z [P1]: the projection used to call a stage
        `completed` the moment its output was frozen, which is the THIRD of
        those seven steps -- so a process death after `request_freeze` left
        intake, retention, the Authority pass and cleanup owed forever while
        the board reported the Work done and its assignment stayed live. The
        stage now stays `answering` until the manager's own cleanup axis is
        terminal, and every step above replays: `stop` re-observes an already
        quiescent runtime, `observe` of the same disposition is a no-op, the
        freeze replays its immutable record, intake and retention replay their
        journalled operations, and the pass is effectively-once by identity. So
        this whole function is safe to re-enter at any boundary a crash can
        land on.

        THE WORKER'S TERMINAL IS A CLAIM AND NOT A SETTLEMENT. What it decides
        here is only that the ending is owed and which disposition to ask the
        freeze about; the freeze validates `/output/output.json` itself, the
        quiescence is a positive observation of the exact runtime, and intake
        measures the bytes rather than believing them. A container that
        published `answered` over an empty output root reaches a refusal from
        those owners, not a completed stage. Its `manifest_digest` is compared
        with the digest the freeze produced, below, so a terminal naming
        another envelope cannot ride a separately valid one.

        NO ABANDONMENT AND NO RETRY. A faulted, lost or incomplete exchange is
        REPORTED -- the projection reads it as `exceptional` -- and this
        composition does not end it. W44716's abandonment is the owner for a
        started attempt policy decides to end, and deciding that is not this
        vertical slice's.
        """
        self._matches(stage, job)
        row = self._claim(stage)
        attempt_id = stage["attempt_id"]
        if self.stage is not None:
            historical = self.stage.historical(stage, _assignment(row))
            if historical is not None:
                # W122060: THE ENDING AFTER THE CUSTODY IT EARNED, ENTERED
                # WITHOUT ANY OF THE LIVE EVIDENCE BELOW.
                #
                # Everything from here to the composed call is about an
                # attempt that still exists: the exchange delivery is adopted
                # and its terminal read, the roots the container was started
                # over are re-mounted, and this attempt's credential is
                # materialized. After the cleanup committed, none of those is
                # evidence -- the runtime is destroyed, the writer that made
                # the mount is revoked, and a credential is a secret
                # materialized for a container that is gone. What is still
                # owed is the gate discharge and the routing, and neither
                # needs a single one of them.
                #
                # AND THERE ARE NO ROOTS LEFT TO COMPOSE ONE OVER, which is
                # a measured fact rather than a caution: after the cleanup
                # this attempt's home holds `credential-state`, `credentials`
                # and `custody` at mode 0555, and `inputs` and `workspace` are
                # gone. `assignment_workspace` would try to create them and
                # refuse with a `PermissionError`; `adopted_assignment_
                # workspace` proves roots that no longer exist. An adapter
                # composed here could only be one composed over directories
                # this ending has already positively let go.
                #
                # SO THE DRIVER IS TYPED AGAINST AN ADAPTER THAT CANNOT ACT.
                # It is required to be SHAPED -- `_typed` runs before the
                # branch that decides which ending this is -- and the resumed
                # path then touches none of it. `_RecordedRuntime` makes that
                # a property of the object rather than a promise about the
                # code path: every verb refuses, so a historical ending that
                # somehow reached the engine, the seal, the collection or the
                # destroy would say so loudly instead of quietly acting.
                return self.stage.end(self, stage, job, dict(
                    historical,
                    adapter=_RecordedRuntime(self.given["image_digest"]),
                    roots=None))
        launched = self._adopted(stage)
        if launched is None or launched.exchange is None:
            _refuse(f"attempt {attempt_id!r} has no exchange delivery to end",
                    category="refused", code="precondition")
        view = exchange.observation(launched.exchange)
        terminal = view["terminal"]
        if terminal is None or terminal["ending"] != "answered":
            _refuse(f"attempt {attempt_id!r}'s exchange reports "
                    f"{view['state']!r}; only a correlated answered terminal "
                    f"authorizes the successful ending",
                    category="refused", code="precondition")
        disposition = terminal["disposition"]
        if disposition not in DISPOSITIONS:
            _refuse(f"attempt {attempt_id!r}'s worker answered disposition "
                    f"{disposition!r} and this manager knows "
                    f"{', '.join(DISPOSITIONS)}; a disposition nobody can name "
                    f"is not one to freeze an output under",
                    category="refused", code="precondition")
        state = attempt_runtime_of(self.control, attempt_id)
        runtime_id = state["runtime_id"]
        if runtime_id is None:
            _refuse(f"attempt {attempt_id!r} answered its command and this "
                    f"manager holds no runtime identity for it; a freeze takes "
                    f"a positively quiescent runtime and there is nothing here "
                    f"to observe", category="refused", code="precondition")
        # W103083: THE SAME ROOTS THE LAUNCH MOUNTED, derived the same way.
        # An ending seals, collects and retains the tree the container wrote,
        # and for a private line that tree is the LINE rather than a fresh
        # workspace -- so an ending that recomposed the ordinary pair here
        # would be taking custody of an empty directory beside the work.
        # `writer=False`: THIS RE-ENTRY WRITES NOTHING IN THOSE ROOTS. Its
        # seal, collect and intake are already journalled, and the retention
        # decisions, the Authority pass and the cleanup authorization touch the
        # journal rather than the tree. See `_mounted`.
        roots = self._mounted(stage, attempt_id, checkpoint=False,
                              writer=False)[0]
        delivery, orphan = self._credential(attempt_id, state, roots, launched)
        adapter = self._adapter(roots, delivery, orphan, launched)
        if self.stage is not None:
            # W103083: AND THE ENDING ITSELF IS THE STAGE'S. Everything above
            # is the part that is the same for all three roles -- the terminal
            # is correlated, the disposition is proved against this manager's
            # own vocabulary, the runtime identity is read and the adapter is
            # composed with this attempt's credential delivery. What differs is
            # what the ending DOES with them, and that belongs to the accepted
            # driver rather than to a second copy of it here.
            #
            # NOTHING BELOW RUNS FOR A COMPOSED STAGE. The v11 pass, in
            # particular, is the bootstrap deployment's own handoff; a composed
            # implementation ending publishes a proposal and freezes a
            # checkpoint instead, and doing both would end one assignment
            # twice.
            return self.stage.end(self, stage, job, {
                "attempt_id": attempt_id, "adapter": adapter, "roots": roots,
                "disposition": disposition, "terminal": terminal,
                "assignment": _assignment(row)})
        # QUIESCENCE IS ORDERED, NOT WAITED FOR. The container is started
        # INTERACTIVE so its idle PID 1 outlives the provider it ran, and
        # `reconcile_runtime` observes rather than stops.
        #
        # ONLY `quiescent`, AND `absent` IS NOT THE SAME PROOF: a runtime that
        # is merely GONE was never observed to have finished writing, so
        # freezing its output would seal bytes nobody watched the end of.
        stopped = adapter.stop({"runtime_id": runtime_id,
                               "operation_id": f"quiesce:{attempt_id}"})
        if stopped.get("state") != "quiescent":
            _refuse(f"attempt {attempt_id!r}'s runtime was ordered to stop and "
                    f"observed {stopped.get('state')!r}; a freeze takes a "
                    f"positively quiescent runtime, and an absent one is not "
                    f"the same proof because its writer was never seen to "
                    f"finish", category="refused", code="precondition")
        reconcile_runtime(self.control, adapter, attempt_id=attempt_id)
        observe(self.control, attempt_id=attempt_id, axis="worker_disposition",
                value=disposition)
        frozen = request_freeze(self.control, self.port, adapter,
                                attempt_id=attempt_id,
                                disposition=disposition)
        # W81857 review 2026-09-04T03-43-45Z [P1]: THE TERMINAL'S DIGEST IS
        # COMPARED, AND THIS IS THE VALUE TO COMPARE IT WITH.
        #
        # `manifest_digest` was carried and never enforced, so an answered
        # terminal naming another envelope drove the whole success ending
        # whenever a separately valid `/output/output.json` happened to exist --
        # which defeats the correlation the member was added to provide.
        #
        # IT IS THE SEALED RESULT'S `completion_manifest_digest`, NOT THE
        # FROZEN RESULT'S OWN `manifest_digest`. Those are two documents:
        # `manifest_digest` names the MANAGER's result manifest, and the
        # worker's terminal names the WORKER's completion envelope. Comparing
        # the terminal against the result manifest would refuse every honest
        # attempt, which the real-composition regression caught. `sealing`
        # opens `/output/output.json` itself, validates its shape against the
        # declarations and recomputes its digest over the bytes it read, and
        # records that digest in the sealed result -- so this compares the
        # worker's claim with this manager's own independent answer about the
        # same file.
        #
        # THE COMPARISON CANNOT HAPPEN EARLIER, because that answer does not
        # exist until the freeze commits.
        #
        # A MISMATCH REFUSES AND SETTLES NOTHING FURTHER. The freeze is durable
        # and replays; intake, retention, the Authority pass and cleanup do not
        # happen, so no result reaches review and no runtime is removed on the
        # strength of a correlation that failed. The stage stays `answering`
        # and the sweep reports the refusal every tick, which is an operator's
        # problem to look at rather than a silence.
        sealed = load_manifest(self.control, frozen["manifest_digest"],
                               "resultManifest")
        validated = (sealed or {}).get("completion_manifest_digest")
        if terminal["manifest_digest"] != validated:
            _refuse(f"attempt {attempt_id!r}'s worker answered completion "
                    f"manifest {terminal['manifest_digest']!r} and this "
                    f"manager validated {validated!r}; a terminal that names "
                    f"another envelope is not evidence about the output this "
                    f"manager froze",
                    category="refused", code="operation-collision")
        receipt = request_intake(self.control, self.port, adapter,
                                 attempt_id=attempt_id)
        held = list(receipt["artifacts"])
        decided = decide_retention(
            self.control, self.port, adapter, attempt_id=attempt_id,
            artifact_ids=[one["artifact_id"] for one in held],
            disposition=self.given["retention_disposition"],
            retention_policy_digest=self.given["retention_policy_digest"])
        passed = self._passed(attempt_id, _assignment(row))
        # AND THE ENDING RETURNS WHAT THE START RESERVED. A governed start with an
        # ungoverned ending is worse than no governance: the workspace would stay
        # held for the life of the store.
        authorize_cleanup(
            self.control, self.port, adapter, attempt_id=attempt_id,
            retention_policy_digest=self.given["retention_policy_digest"],
            govern=tokens.workspace_governance())
        return {"disposition": disposition,
                "manifest_digest": frozen["manifest_digest"],
                "result_id": frozen["result_id"],
                "receipt_digest": receipt["receipt_digest"],
                "artifacts": sorted(one["artifact_id"] for one in held),
                "retention": decided["disposition"],
                "review_route": passed["route"]}

    def handoff(self, *, expect, attempt_id, fence_operation_id, from_route,
                to_route=None):
        """Move this attempt's Work to the route its next role is served on.

        W122060, consuming W125189's accepted act. THE GATE IS STILL HOLDING
        WHEN THIS RUNS, and that is the whole point: `route_fenced` changes
        only the route, leaving the phase, the gate and the generation exactly
        as this ending's own fence left them, so the handoff commits while
        nothing can yet write. Discharging first would return the Work to
        `queued` on the route the FINISHED role is served on, and the
        participant that just ended could reclaim it before the next role was
        offered anything.

        IT IS NOT A PASS. `pass_work` ends a live assignment and is the
        bootstrap deployment's own handoff; this attempt's assignment was
        already ended by its checkpoint fence, and a pass would refuse. The two
        are different acts for different states, and this deployment now has
        both.

        THE OPERANDS COME FROM COMMITTED RECORDS AND THE ANSWER IS OWNED. The
        operation identity is derived from the assignment and the two routes,
        so a lost answer replays the Authority's own committed receipt rather
        than moving a route twice; a different generation carries a different
        signature and collides.
        """
        if self.session is None:
            _refuse("this deployment holds no Authority routing capability, "
                    "so a fenced attempt's Work cannot reach its next Route",
                    category="refused", code="capability")
        # THE TARGET IS THE CALLER'S WHEN IT HAS ONE. A correction sends the
        # Work back to the producer's own route rather than forward to this
        # worker's configured next one, and which of those applies is the
        # composition's decision about an answer -- not this worker's.
        route = self.given["review_route"] if to_route is None else to_route
        _text(route, "the next route")
        _text(from_route, "the original claim route")
        answered = self.session.route_fenced({
            "expect": dict(expect),
            "operation_id": f"route-fenced:{attempt_id}:{route}",
            "fence_operation_id": fence_operation_id,
            "from_route": from_route, "to_route": route})
        if type(answered) is not dict:
            _refuse(f"the authority answered the fenced handoff with "
                    f"{type(answered).__name__} and this deployment reads a "
                    f"document", category="refused", code="precondition")
        missing = sorted(one for one in HANDOFF_MEMBERS if one not in answered)
        if missing:
            _refuse(f"the fenced handoff answered without "
                    f"{', '.join(missing)}; a document missing the assignment "
                    f"it moved or the routes it moved between is not evidence "
                    f"this Work was handed on", category="refused",
                    code="precondition")
        if answered["assignment"] != expect:
            _refuse(f"the fenced handoff moved {answered['assignment']!r} and "
                    f"this attempt holds {expect!r}; an answer about another "
                    f"assignment is not evidence that this one moved",
                    category="refused", code="operation-collision")
        if answered["from_route"] != from_route \
                or answered["to_route"] != route:
            _refuse(f"the fenced handoff moved {answered['from_route']!r} to "
                    f"{answered['to_route']!r} and this deployment asked for "
                    f"{from_route!r} to {route!r}", category="refused",
                    code="operation-collision")
        # AND THE GATE IS STILL THERE, which is the property this ordering
        # exists to keep. An answer reporting a discharged Work would mean the
        # handoff had let somebody claim before the runtime was proved gone.
        if answered["phase"] != "block" or not answered["gate"]:
            _refuse(f"the fenced handoff left the Work {answered['phase']!r} "
                    f"with gate {answered['gate']!r}; a handoff moves the "
                    f"route and leaves the runtime gate exactly as the fence "
                    f"set it", category="refused", code="precondition")
        return {"route": route, "answer": answered}

    def _passed(self, attempt_id, expect):
        """The authority's own answer to this deployment's pass, held to shape.

        WHAT IS KEPT IS WHAT THE AUTHORITY SAID, not what this deployment asked
        for. A route echo is not the proof and taking one as proof was a
        measured defect in the supervised composition: an answer ABOUT ANOTHER
        GENERATION that happened to echo the route was accepted as this
        attempt's pass, and cleanup then ran on the strength of a transition
        that ended somebody else's assignment. The ASSIGNMENT the authority
        says it ended is what is compared, and the route is checked beside it
        rather than instead of it.

        EFFECTIVELY ONCE BY IDENTITY. The operation id is derived from this
        attempt, so an exact replay replays the authority's own committed
        answer instead of passing a second time; a different generation carries
        a different signature and collides rather than silently reusing this
        one's pass.
        """
        if self.session is None:
            _refuse("this deployment holds no Authority pass capability, so "
                    "an ended attempt's Work cannot reach its review Route",
                    category="refused", code="capability")
        route = self.given["review_route"]
        answered = self.session.pass_work({
            "expect": dict(expect), "operation_id": f"pass:{attempt_id}",
            "to_route": route, "comment": PASS_COMMENT})
        if type(answered) is not dict:
            _refuse(f"the authority answered the review pass with "
                    f"{type(answered).__name__} and this deployment reads a "
                    f"document", category="refused", code="precondition")
        missing = sorted(one for one in PASS_MEMBERS if one not in answered)
        if missing:
            _refuse(f"the review pass answered without {', '.join(missing)}; "
                    f"a document missing either the ended assignment or the "
                    f"route it moved the Work to is not evidence this "
                    f"assignment ended", category="refused",
                    code="precondition")
        if answered["assignment"] != expect:
            _refuse(f"the review pass ended {answered['assignment']!r} and "
                    f"this attempt holds {expect!r}; an answer about another "
                    f"assignment is not evidence that this one ended",
                    category="refused", code="operation-collision")
        if answered["route"] != route:
            _refuse(f"the assignment was passed to {answered['route']!r} and "
                    f"this deployment asked for {route!r}",
                    category="refused", code="precondition")
        if answered["cause"] != "pass" or answered["fenced"]:
            _refuse(f"the assignment ended {answered['cause']!r} with fenced "
                    f"{answered['fenced']!r}; the approved transition is an "
                    f"unfenced pass and nothing else is one",
                    category="refused", code="precondition")
        if answered["phase"] != "queued" or answered["gate"] is not None:
            _refuse(f"the assignment was passed into phase "
                    f"{answered['phase']!r} behind gate {answered['gate']!r}; "
                    f"the approved handoff leaves the Work queued and ungated "
                    f"for its review route to claim",
                    category="refused", code="precondition")
        return {"route": answered["route"], "cause": answered["cause"],
                "phase": answered["phase"], "gate": answered["gate"]}

    def _session_of(self, attempt_id):
        """The one container session identity this attempt's launch carries.

        DERIVED FROM THE ATTEMPT, so the process that publishes the command and
        the process that authored the launch document reach the same value
        without either remembering anything.
        """
        return "session-" + digest(attempt_id)[7:31]

    def _job_execution(self, stage):
        """This stage's Job execution context, or `None` when there is no Job.

        W156162. The Job half is RE-RESOLVED through its own owner every time,
        never read back out of the launch being checked -- adoption compares
        canonical bytes, and a Job half taken from disk would make the document
        prove itself.

        THE RUNTIME HALF IS THIS DEPLOYMENT'S OWN. The Job's submitted input and
        policy identities are the Job owner's; what this runtime was actually
        given is the configured manifest and policy this worker mounts and that
        `_claim` compares the claimed offer against. They are two facts and both
        are stated.
        """
        if self.execution_context is None or stage is None:
            return None
        # W156162: AND A COMPOSITION THAT RESOLVES JOBS WILL NOT COMPOSE A
        # LAUNCH FOR AN EXECUTION THAT NAMES NONE. An ordinary stage row always
        # carries its Job; a derived judgment's intent carries the Job its own
        # OWNING RESULT names. Answering `None` here would hand a Job-bound
        # deployment the image defaults under an execution that has an owner,
        # which is the legacy-delivery confusion this Work refuses everywhere
        # else.
        job_id = stage.get("job_id")
        if not job_id:
            _refuse("this execution names no Job and this deployment resolves "
                    "a Job's configured ceilings; a launch composed now would "
                    "state defaults nothing chose",
                    category="refused", code="precondition")
        given = self.given
        return self.execution_context(
            job_id=job_id, attempt_id=stage["attempt_id"],
            runtime_input_digest=given["input_manifest"]["manifest_digest"],
            runtime_policy_digest=given["policy_digest"])

    def _adopted(self, stage):
        """This attempt's launch and exchange delivery, from durable state.

        ADOPTION AND NOT MATERIALIZATION. A delivery that is absent here is one
        no container ever mounted, and authoring a replacement under a running
        container would turn lost durable evidence into state that looks valid
        -- which is the correction `_launch_document` records for the launch
        document and which applies with more force to a namespace the worker
        writes.
        """
        attempt_id = stage["attempt_id"]
        return launch.adopt(
            self.given["launch_home"], attempt_id=attempt_id,
            session=self._session_of(attempt_id),
            contract=self.given["launch_contract"],
            role=self.given["launch_role"],
            transport=exchange.EXCHANGE_TRANSPORT,
            job_execution=self._job_execution(stage),
            provider_context=_context_descriptor(self.control, self.given, attempt_id),
            workspace_group=self.group)

    def _launch_document(self, stage, state):
        """Adopt this attempt's exact launch delivery; author one ONLY before
        a start.

        Review 2026-09-03T18:16:57Z [P1]: this materialized whenever `adopt`
        answered absence, including after the start operation had committed.
        The launch owner says absence is ordinary only until a caller knows a
        runtime started, and that caller must then refuse -- and the pinned
        finding says contradictory or partial material refuses rather than
        being repaired. Authoring a fresh document under a container that may
        already hold the mount turns lost durable evidence into state that
        looks valid.

        AND EVERY REFUSAL FROM HERE IS SETTLED THE SAME WAY. Re-review
        2026-09-03T19:24:19Z [P1]: only the ABSENCE branch used to reach the
        identification, so contradictory or partial launch material -- which
        `adopt` refuses rather than answering `None` for -- ended the stage
        with the runtime still unnamed. Nothing is settled here at all now:
        the caller's one handler identifies the runtime and records the
        ending for every boundary alike.
        """
        given = self.given
        attempt_id = stage["attempt_id"]
        launched = self._adopted(stage)
        if launched is not None:
            return launched
        if state["execution_runtime"] != "not-started":
            _refuse("this attempt's start was already requested and its launch "
                    "delivery is absent; a replacement authored now would be "
                    "mounted by nothing that exists and would claim evidence "
                    "this deployment does not have",
                    category="refused", code="precondition")
        # W81857: THE PRODUCTION LAUNCH SELECTS THE FILE EXCHANGE, and its two
        # namespaces are created here -- before the start, inside the same
        # attempt-private root, under a parent this manager closes read-only
        # once every entry exists. A namespace created after the start is one
        # nothing mounts, and there is no second chance at a mount table.
        return launch.materialize(
            given["launch_home"], attempt_id=attempt_id,
            session=self._session_of(attempt_id),
            contract=given["launch_contract"], role=given["launch_role"],
            transport=exchange.EXCHANGE_TRANSPORT,
            job_execution=self._job_execution(stage),
            provider_context=_context_descriptor(self.control, self.given, attempt_id),
            workspace_group=self.group)

# What this deployment says when it hands an implementation result on. The
# authority records it beside the transition, so it is written once here rather
# than composed at the call site.
PASS_COMMENT = ("the implementation worker answered, its declared output is "
                "frozen, collected and retained, and the candidate is ready "
                "for independent review")

# THE CLOSED RESULT A PASS ANSWERS WITH. `AuthorityCore.pass_work` returns the
# ended assignment beside the new Route, and every member of it is read at
# `_passed` -- holding a document to the members it must carry is what makes
# that a comparison rather than a `get` that shrugs at an absence.
PASS_MEMBERS = ("assignment", "route", "cause", "phase", "gate", "fenced")

# W122060: AND THE CLOSED RESULT A FENCED HANDOFF ANSWERS WITH. W125189's act
# changes only the route and says so: it echoes the assignment it moved, the
# cancellation that authorized the move, both routes, and the phase and gate it
# left exactly as it found them.
HANDOFF_MEMBERS = ("assignment", "fence_operation_id", "from_route",
                   "to_route", "phase", "gate")


class _Operations(ManagerOperations):
    __slots__ = ("_dispose", "_worker")

    def __init__(self, *arguments, worker, dispose, **keywords):
        super().__init__(*arguments, **keywords)
        self._worker = worker
        self._dispose = dispose

    def admit(self, stage, job):
        return self._worker.admit(super().admit, stage, job)

    def cancel_attempt(self, *, attempt_id, reason):
        """W236087: the composed worker's own stop, reachable by its owner."""
        return self._worker.cancel_attempt(attempt_id=attempt_id,
                                           reason=reason)

    def abandon_attempt(self, *, attempt_id, reason, stage, seconds=None,
                        reclaim=None):
        """W247941: the composed worker's own FOURTH ending, likewise."""
        return self._worker.abandon_attempt(attempt_id=attempt_id,
                                            reason=reason, stage=stage,
                                            seconds=seconds, reclaim=reclaim)

    def close(self):
        dispose, self._dispose = self._dispose, None
        if dispose is not None:
            dispose()


def operations_from(document, job_store, control_store, *, engine_run=None,
                    credential_provider=None, clock=None, checkpoint=None):
    """Build the exact manager operations from one already-read document.

    ``job_store`` is accepted because every factory has the same public shape.
    W83781 gave it one thing this deployment must read: the Authority the
    store is bound to, which is compared with the configured Authority before
    any durable side effect.  The two injectable capabilities are for focused
    verification.  The public ``factory`` supplies the real subprocess runner
    and private source reader.
    """
    given = _held(document)
    if given.get("provider_context") is not None:
        _refuse("bootstrap has no private-line context owner", category="policy", code="denied")
    # W83781: THE JOB STORE'S AUTHORITY BINDING IS COMPARED FIRST, before this
    # deployment configures anything.
    #
    # `job_store` used to be deleted here with a note that this deployment
    # needs no private Job-store read. That was true when a Job store knew
    # nothing about which Authority it belonged to; it is not true now. The
    # store's episode identities are derived in its Authority's namespace and
    # the containers those identities name carry that Authority as an
    # immutable label -- so a Job store bound to one Authority driven by a
    # configuration naming another would start runtimes labelled for an
    # Authority its own identities were never derived in.
    #
    # BEFORE ANY DURABLE SIDE EFFECT, and the ordering is the whole
    # correction. Everything below this line writes: the workspace group and
    # storage are configured on the control store, a profile is certified,
    # storage is allocated and an Authority is opened. A mismatch found after
    # any of those would have left this deployment half-configured against a
    # store it must not touch at all.
    held = getattr(job_store, "authority_uuid", None)
    if held != given["authority_uuid"]:
        _refuse(f"this Job store is bound to Authority {held!r} and this "
                f"configuration names {given['authority_uuid']!r}; a store's "
                f"episode identities are derived in its own Authority's "
                f"namespace, so driving it from another one would start "
                f"runtimes labelled for an Authority those identities were "
                f"never derived in", category="refused",
                code="operation-collision")
    provider = worker_preflight(given, control_store,
                                credential_provider=credential_provider,
                                engine_run=engine_run)
    authority = Authority.open(
        given["authority_store"],
        expected_authority_uuid=given["authority_uuid"])
    # W61599: THE BOOTSTRAP DEPLOYMENT'S OWN HELPER. A bootstrap composition
    # never reaches `StageExecution._closers`, so its teardown is the one hook
    # it already has -- `_Operations.close`'s single `dispose` hand-back. The
    # two factories share the ADMISSION and not the unwind: each constructs
    # exactly one helper and releases it through the hook it owns.
    helper = None
    try:
        helper = activity_ingestion(control_store, clock=clock)
        return worker_operations(given, control_store, authority, provider,
                                 engine_run=engine_run, clock=clock,
                                 checkpoint=checkpoint,
                                 dispose=_bootstrap_dispose(authority, helper),
                                 activity=None if helper is None
                                 else helper.enqueue,
                                 execution_context=job_execution_reader(
                                     job_store))
    except BaseException:
        # PARTIAL CONSTRUCTION RELEASES WHAT IT ACQUIRED. A half-built
        # composition must not leave a slot occupied by a helper nobody will
        # ever stop -- and an over-bound stop here still refuses, because the
        # handle is then genuinely still held.
        try:
            activity_release(helper)
        finally:
            authority.dispose()
        raise


def _bootstrap_dispose(authority, helper):
    """The bootstrap deployment's ONE teardown point, with the helper on it.

    THE ORDER IS STOP-THEN-RELEASE, and the helper closes its OWN store handle
    as part of stopping. An over-bound stop is REPORTED rather than swallowed:
    the Authority is still released -- a diagnostic must not strand a lock --
    and the refusal is raised afterwards so `close` carries the fact out.
    """
    def dispose():
        try:
            activity_release(helper)
        finally:
            authority.dispose()

    return dispose


def job_execution_reader(job_store):
    """A NARROW, READ-ONLY reader over an already-open Job owner.

    W156162, pinned 2026-09-13T01:58:25Z. The launch delivery carries a Job's
    configured ceilings, so the composition that authors it has to be able to
    ask which Job it is serving. Handing a worker the Job store would make every
    launch composition -- including the read-only observation the projection
    runs on every tick -- a Job-store reader, which is the separation the
    factory keeps.

    SO WHAT IS HANDED OVER IS THIS ONE QUESTION. The closure holds the store the
    factory already opened and answers `job_execution_context` and nothing else:
    no write, no migration, no Authority session, no engine, no credentials, and
    no way to reach the store itself. A caller can learn what a Job configured;
    it cannot learn anything else and it cannot change anything.

    It is a FUNCTION rather than a cached answer on purpose: a fresh process
    must obtain the same expected context, and a value remembered from admission
    would be a second account of a fact the Job owner holds.
    """
    def reader(*, job_id, attempt_id, runtime_input_digest,
               runtime_policy_digest):
        from baton_v12.job_manager import submission as job_submission

        return job_submission.job_execution_context(
            job_store, job_id, attempt_id=attempt_id,
            runtime_input_digest=runtime_input_digest,
            runtime_policy_digest=runtime_policy_digest)

    return reader


def effective_engine_run(engine_run=None):
    """The engine runner this module would ACTUALLY use, named publicly.

    W103068 review 2026-09-11T02-06-10Z [P1]. `worker_operations` resolves
    `engine_run or _engine_run` privately, so a composer that passed its own
    `engine_run` through to a second consumer passed `None` whenever the caller
    had supplied nothing -- and the production `factory` supplies nothing. The
    integration runtime port then refused for want of an engine capability, on
    the one entry point that is supposed to work by default.

    IT IS THE SAME EXPRESSION AND NOT A SECOND OPINION. Injected overrides and
    ordinary defaults converge here by construction, which is exactly what the
    pinned design requires: one boundary answers what this module runs
    containers with, and `worker_operations` below resolves through it.
    """
    return engine_run or _engine_run


def worker_preflight(given, control_store, *, credential_provider=None,
                     engine_run=None):
    """The half of a worker deployment that needs no Authority.

    W103083 needs three workers over one Authority and one control store, and
    copying this into a second composer would be a second deployment opinion
    over the same security boundary -- which is exactly what the assembly
    boundary forbids. So it is parameterized rather than duplicated, and split
    at the Authority: this half is everything the engine, image, network and
    workspace group can refuse, and the half below is everything that needs an
    open Authority. The bootstrap deployment runs this one first, because it
    has nothing else to ask.

    IT IS NOT READ-ONLY, and W103083's review 2026-09-07T14-12-42Z [P1] is
    what made that worth saying out loud. It CONFIGURES the control store's
    workspace group and storage, certifies a runtime profile and constructs a
    credential home -- so a composer with checks of its own must decide
    whether they belong before this or after it, and the pooled one puts every
    check it can answer without writing anything first. See
    `stage_execution.operations_from`.

    Answers the credential provider, because that is the one thing built here
    that the half below needs.
    """
    _context_preflight(given, control_store)
    provider = credential_provider
    if provider is None:
        if given["credential_sources"] is None:
            _refuse("the production credential provider requires an absolute "
                    "credential_sources registry path", category="refused",
                    code="capability")
        provider = UserCredentialSources(
            given["credential_sources"], max_bearer=credentials.MAX_BEARER)
    # W275774, DESIGN HOST-8 as amended by owner 279031: ONE ACTIVE MANAGER, AND THE
    # REFUSAL HAPPENS BEFORE ANYTHING IS WRITTEN.
    #
    # FIRST, and review 21:26:24Z is why it moved. The guard used to be taken after the
    # two configuring acts below, so a duplicate manager committed configuration into the
    # database the ACTIVE manager owns before being refused. HOST-8 requires the refusal
    # before work is dispatched or a managed resource is mutated, and a configuration
    # written into another manager's store is exactly such a mutation.
    #
    # The root comes from the deployment's own configuration document rather than from the
    # store, which is what makes this possible at all: nothing needs to be recorded before
    # the instance can be named.
    #
    # THE DESCRIPTOR OUTLIVES THIS CALL on purpose: the guard is held by the process for
    # as long as it is a manager, and a second composition inside this same process
    # answers the guard it already holds rather than a second lock.
    workspaces.hold_manager_instance(control_store, given["workspace_storage"])
    configure_workspace_group(control_store, given["workspace_group"])
    workspaces.configure_workspace_storage(control_store,
                                           given["workspace_storage"])
    certify_profile(control_store, "runtime", given["profile_name"],
                    given["profile_digest"])
    group = configured_workspace_group(control_store)
    # W194457, owner decision 2026-09-17: PREFLIGHT STARTS NO CONTAINER, and
    # there is no longer anything for it to activate.
    #
    # An earlier cut of this Work observed the engine's host-side identity
    # here. It HUNG the suite: this function is reached by bootstrap
    # composition, by staged worker composition and by result-judgment
    # composition, and its `engine_run` DEFAULTS to
    # `effective_engine_run(None)` -- `subprocess.run` on the real argv -- so
    # an observation here is a container start acquired silently by three
    # composers that are not launching anything.
    #
    # The owner then superseded the measurement entirely: the supported
    # host/container mapping is TRUSTED deployment configuration, documented at
    # `workspaces.SUPPORTED_IDENTITY_MAPPING`. What preflight does about
    # identity is what it already did -- construct the adapter's static half,
    # which mints the identity from the configured workspace group and refuses
    # a root manager or an unconfigured group before admission. That is a
    # structural configuration check and it reaches no engine.
    credentials.CredentialHome(given["credential_home"])
    # Construct the adapter's static half now.  No runtime or assignment root
    # exists yet, so two distinct absent placeholders are used only to force
    # the engine, identity, network and workspace-group checks before admission.
    OciAdapter(
        given["engine"], EnginePort(effective_engine_run(engine_run)),
        identity={"image_digest": given["image_digest"],
                  "profile_digest": given["profile_digest"],
                  "policy_digest": given["policy_digest"],
                  "adapter_digest": given["adapter_digest"]},
        assignment_roots={"inputs": os.path.join(given["workspace_storage"],
                                                  ".preflight-input"),
                          "workspace": os.path.join(
                              given["workspace_storage"],
                              ".preflight-workspace")},
        posture="execution", workspace_group=group,
        network=given["network"], interactive=True)
    return provider


def worker_operations(given, control_store, authority, provider, *,
                      engine_run=None, clock=None, checkpoint=None,
                      dispose=None, stage=None, judgment_document=None,
                      execution_context=None, activity=None):
    """The half that needs an Authority, over one the CALLER owns.

    `dispose` is what makes this reusable by a pool. A single-worker
    deployment hands its own `authority.dispose`, because it opened that
    handle and nobody else holds it; a pooled composer hands something that
    does NOT dispose, because one shared Authority released by the first
    worker to be torn down would take the other two with it.

    `stage` is what makes it reusable by a STAGE. It is the composition that
    answers what this worker mounts and how its attempt ends; `None` is the
    bootstrap deployment, which mounts its nominated source and ends through
    the configured v11 review Route. See `_SingleWorker.__init__`.
    """
    if given.get("provider_context") is not None and stage is None:
        _refuse("required provider context lacks its staged implementation owner")
    if authority.principal_of(given["participant"]) != given["principal"]:
        _refuse("the configured participant resolves to another principal",
                category="refused", code="capability")
    projected = authority.project_work(
        given["input_manifest"]["work_ref"]["work_id"])
    if projected is None or projected["authority_uuid"] \
            != given["authority_uuid"]:
        _refuse("the configured bootstrap Work is absent from this "
                "Authority", category="refused", code="precondition")
    # ONE MINTED SESSION, TWO NARROW VIEWS OF IT. W125032: the deployment keeps
    # the plain forwarder for its own calls, and the manager's port is handed
    # the one that translates a concrete claim refusal into this manager's
    # closed vocabulary. Nothing new is minted and neither view widens the
    # other; see `_ManagerClaimSession`.
    minted = authority.session(given["participant"])
    session = _AuthoritySession(minted)
    port = AuthorityPort(_ManagerClaimSession(minted), claim_signature)
    # Authority bootstrap and the provider registry are deployment-side
    # capabilities.  The runtime composer gets neither path; it receives
    # only the already-minted restricted port and provider callable.
    runtime = {member: value for member, value in given.items()
               if member not in ("authority_store", "principal",
                                 "credential_sources")}
    worker = _SingleWorker(
        runtime, control_store, port, credential_provider=provider,
        engine_run=effective_engine_run(engine_run), session=session,
        clock=clock,
        checkpoint=checkpoint, stage=stage,
        judgment_document=judgment_document,
        execution_context=execution_context,
        # W61599: THE DEPLOYMENT'S ONE INGESTION HELPER, handed to every worker
        # it composes. The helper is per STORE and not per worker, so what a
        # worker receives is the enqueue and never the helper itself -- a
        # worker that could stop it would be a worker that could take the
        # diagnostic away from the deployment's other workers.
        activity=activity)
    return _Operations(
        control_store, port, mint_bearer=_bearer,
        deliver_bearer=worker.delivered, start_runtime=worker.start,
        # W81857: THE THREE EXCHANGE CAPABILITIES, supplied separately
        # because they are three different authorities. Reading is a pure
        # observation the projection performs on every tick for every
        # stage; publishing the command is the one act that commits this
        # attempt to a provider turn; ending it freezes, takes custody of
        # and hands on somebody's work.
        observe_exchange=worker.observed_exchange,
        dispatch_exchange=worker.command,
        conclude_attempt=worker.ending,
        # W85500: THE FOURTH, AND IT IS SERVING-ONLY. It records, so no
        # status surface gets it; the observation-only composition is
        # built without it for exactly that reason.
        refresh_runtime=worker.refresh_runtime,
        worker=worker,
        dispose=dispose if dispose is not None else authority.dispose)


def _judged_job(subject):
    """The Job that owns the result this judgment is about.

    W156162, review 2026-09-13T03:50:23Z. Read from the OWNER'S OWN SUBJECT --
    `Integration` composes it from the reconciled result account -- and not
    inferred from an ordinary stage allocation this execution does not have, nor
    taken from a carrier, which a judgment is never handed.
    """
    held = subject.get("job_id")
    if type(held) is not str or not held:
        _refuse("a derived judgment names the Job its own judged result "
                "belongs to; this subject names none",
                category="refused", code="precondition")
    return held


class JudgmentExecution:
    """One configured judge, using the ordinary worker lifecycle end to end.

    The intent identifies a separate Authority Work and execution, not a Job
    stage or pool allocation. Only frozen, collected output can answer it.
    """

    def __init__(self, given, control, authority, provider, *, worker_id,
                 subject, source, engine_run=None, clock=None,
                 execution_context=None):
        self.control = control
        self.subject = dict(subject)
        self.given = dict(given, source_nomination=source_boundary.nominate_source(source))
        self.document = json.dumps(subject, sort_keys=True, separators=(",", ":")).encode()
        identity = digest({"subject": subject, "worker_id": worker_id,
                           "participant": given["participant"],
                           "input": given["input_manifest"]["manifest_digest"],
                           "policy": given["policy_digest"],
                           "profile": given["profile_digest"]})[7:]
        self.intent = {"stage_id": "judgment-" + identity,
                       "attempt_id": "judgment-" + identity,
                       "offer_id": "judgment-offer-" + identity,
                       "kind": "review", "work_id": given["input_manifest"]["work_ref"]["work_id"],
                       "profile_name": given["profile_name"],
                       "profile_digest": given["profile_digest"],
                       # W156162: THE JOB THIS JUDGMENT'S OWN SUBJECT NAMES. A
                       # derived judgment has no ordinary stage row and no pool
                       # allocation to read a Job from, and it is handed no
                       # carrier -- the owning Job is the one the RESULT this
                       # judgment is about belongs to, which is what
                       # `Integration`'s own subject states. It rides on the
                       # intent because the intent is what this execution's
                       # launch is composed from.
                       "job_id": _judged_job(subject)}
        # THE RETAINED INTENT, and it is what the launch states as the runtime
        # half: not the Job's submitted identities, but what THIS judge was
        # actually given -- the configured manifest this execution mounts and
        # the policy it runs under, which `_claim` compares its claimed offer
        # against. Two facts, both stated, neither invented.
        #
        # W202663: IT IS ALSO THE OPERAND `_matches` READS AS A JOB, and that
        # is why the projection appears in a document about a runtime. `poll`
        # hands this dictionary to `operations.admit` in the Job's place -- a
        # derived judgment has no stage row and no pool allocation to read a
        # real Job from -- so its `input_digest` is compared by the rule that
        # compares a JOB's. Left as the whole manifest digest it refused every
        # derived judgment against the judge's own configuration, which is the
        # one shape that cannot be a mismatch.
        #
        # THE RUNTIME HALF IS NOT LOST. `_claim` reads the same projection off
        # the offer this judgment mints for itself, and what the LAUNCH states
        # as the runtime input is composed separately, from
        # `given["input_manifest"]["manifest_digest"]`, where it always was.
        self.input = {"input_digest": job_input_identity(
                          given["input_manifest"],
                          what="this derived judgment's configured input"),
                      "policy_digest": given["policy_digest"]}
        self.operations = worker_operations(
            self.given, control, authority, provider, engine_run=engine_run,
            dispose=lambda: None, judgment_document=self.document, clock=clock,
            execution_context=execution_context)

    def poll(self):
        operations, intent = self.operations, self.intent
        for act in ("admit", "claim"):
            if operations.receipt_of(operations.canonical_operation(act, intent["offer_id"])) is None:
                if act == "admit":
                    operations.admit(intent, self.input)
                else:
                    operations.claim(intent)
        view = operations.observe(intent)
        state = view["runtime"]
        if state is not None and state["cleanup"] in ("complete", "retained"):
            return self.result()
        if view["start_failure"] is not None or view["preparation_failure"] is not None:
            _refuse("the derived-result judge failed preparation or start",
                    category="refused", code="precondition")
        if state is None or state["runtime_id"] is None:
            operations.launch(intent, self.input)
        operations.dispatch(intent, self.input)
        operations.refresh_runtime(intent)
        view = operations.observe(intent)
        terminal = (view["exchange"] or {}).get("terminal")
        if terminal is None:
            return None
        if terminal["ending"] != "answered":
            _refuse("the derived-result judge did not answer its command",
                    category="refused", code="precondition")
        operations.conclude(intent, self.input)
        return self.result()

    def result(self):
        from baton_v12.worker_manager import assignment_of, frozen_output_of
        from baton_v12.worker_manager.intake import intake_receipt_of

        attempt_id = self.intent["attempt_id"]
        # Bind even on recovery, when the runtime and writable output are gone.
        row = self.operations._worker._claim(self.intent)
        fixed = assignment_of(self.control, attempt_id)
        frozen = frozen_output_of(self.control, attempt_id)
        receipt = intake_receipt_of(self.control, attempt_id)
        if frozen is None or frozen["disposition"] != "completed" or receipt is None or receipt["custody"] != "accepted":
            _refuse("a judgment needs a completed frozen result in accepted custody",
                    category="refused", code="precondition")
        result = load_manifest(self.control, frozen["manifest_digest"], "resultManifest")
        expected = {"work_ref": self.given["input_manifest"]["work_ref"],
                    "participant": self.given["participant"],
                    "generation": row["claim_generation"]}
        fixed_ref = {"work_ref": {"authority_uuid": fixed["authority_uuid"], "work_id": fixed["work_id"]},
                     "participant": fixed["participant"], "generation": fixed["generation"]}
        if (result is None or result["assignment_ref"] != expected
                or fixed_ref != _assignment(row)
                or result["result_id"] != frozen["result_id"]
                or receipt["assignment"] != fixed_ref
                or receipt["result_id"] != frozen["result_id"]
                or receipt["manifest_digest"] != frozen["manifest_digest"]):
            _refuse("the judgment result, custody and assignment disagree", code="digest")
        outputs = {one["name"]: one for one in result["outputs"]}
        namespace = "baton.checkpoint-review/1"
        for name in ("findings", "logs"):
            if (name not in outputs or outputs[name].get("status") != "present"
                    or outputs[name].get("artifact") is None or outputs[name].get("content_manifest") is None):
                _refuse("the judgment did not freeze both findings and logs")
            output = outputs[name]
            artifacts = [one for one in receipt["artifacts"] if one["artifact_id"] == output["artifact"]["artifact_id"]]
            if len(artifacts) != 1 or artifacts[0]["content_digest"] != output["content_manifest"]["tree_digest"]:
                _refuse("the judgment output and accepted custody disagree", code="digest")
        if any(namespace in (one.get("result_metadata") or {}) for name, one in outputs.items() if name != "findings"):
            _refuse("a judgment carries competing report claims")
        claim = (outputs["findings"].get("result_metadata") or {}).get(namespace)
        if type(claim) is not dict or set(claim) != {"verdict", "base", "head", "tree"}:
            _refuse("the frozen judgment report carries no closed review claim")
        if (claim["base"] != self.subject["source_base"]
                or claim["head"] != self.subject["candidate"]
                or claim["tree"] != self.subject["tree"]):
            _refuse("the frozen judgment describes another candidate", code="digest")
        if claim["verdict"] not in ("accepted", "rejected", "changes-requested"):
            _refuse("the frozen judgment carries an unknown verdict")
        # Read the report from accepted custody, never from the former writer
        # directory. Its bytes must still match the frozen content manifest.
        from urllib.parse import unquote, urlsplit
        artifact_id = outputs["findings"]["artifact"]["artifact_id"]
        artifact = next(one for one in receipt["artifacts"] if one["artifact_id"] == artifact_id)
        locator = urlsplit(artifact["custody_locator"])
        if locator.scheme != "file" or locator.netloc or locator.query or locator.fragment:
            _refuse("this judgment consumer reads local accepted report custody")
        entries = [one for one in outputs["findings"]["content_manifest"]["entries"] if one["path"] == "report.json"]
        if len(entries) != 1 or entries[0]["bytes"] > MAX_CONFIG_BYTES:
            _refuse("the frozen judgment has no bounded report.json")
        try:
            descriptor = os.open(os.path.join(unquote(locator.path), "report.json"), os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
        except OSError:
            _refuse("the accepted judgment report is unavailable", code="path")
        try:
            if not stat.S_ISREG(os.fstat(descriptor).st_mode):
                _refuse("the retained judgment report is not a regular file")
            raw = os.read(descriptor, entries[0]["bytes"] + 1)
        finally:
            os.close(descriptor)
        if len(raw) != entries[0]["bytes"] or digest_of_bytes(raw) != entries[0]["content_digest"]:
            _refuse("the retained judgment report differs from frozen custody", code="digest")
        try:
            report = json.loads(raw)
        except (ValueError, UnicodeError):
            _refuse("the retained judgment report is not JSON")
        if (type(report) is not dict or set(report) != {"schema", "verdict", "findings"}
                or report["schema"] != "baton.review-report/1"
                or report["verdict"] != claim["verdict"] or type(report["findings"]) is not str):
            _refuse("the retained judgment report and its frozen claim disagree")
        return {"subject": self.subject, "attempt_id": attempt_id,
                "assignment": fixed, "verdict": claim["verdict"],
                "result_id": frozen["result_id"],
                "result_digest": frozen["manifest_digest"],
                "receipt_digest": receipt["receipt_digest"]}


class _Observation:
    """W85500: the durable exchange reader, composed from NOTHING ELSE.

    WHAT IT IS FOR. `tools.job_manager status` could never report a worker's
    terminal, because `_ReadOnly` has no exchange read at all -- so the
    run6 faulted terminal sat on disk, correlated and readable, while the one
    command an operator runs printed `exchange: null`. The parser was not the
    problem; nothing had been given a way to look.

    WHAT IT DELIBERATELY IS NOT. `operations_from` configures the workspace
    group and storage on the control store, certifies a profile, constructs a
    credential home, opens an Authority and mints a session -- and hands back
    an object carrying mint, delivery, start, dispatch, ending and pass. This
    class does none of that and carries none of it. It reads immutable
    configuration, it reads the already-open control store, and it adopts
    launch material from disk.

    IT HOLDS NO CONTROL STORE WRITE AND NO ENGINE. There is no runtime refresh
    here on purpose: reconciling RECORDS what it saw, and a status command
    that recorded would be a read that mutates. Runtime freshness belongs to
    the serving loop.
    """

    def __init__(self, document, control_store, *, job_store=None,
                 roles=("implementation",)):
        given = _held(document, roles=roles)
        # THE JOB STORE IS ACCEPTED AND NOT READ, exactly as `operations_from`
        # accepts it: every factory has the same public shape.
        #
        # AN EARLIER DRAFT OF THIS CLASS COMPARED THE STORE'S AUTHORITY
        # BINDING against the configured one, and that check has been removed
        # rather than kept. It was written while W83781's candidate was in
        # this checkout, and it reads `JobStore.authority_uuid` -- an
        # attribute W83781 introduces and which this Work's declared base does
        # not have. On this base `getattr` answers `None`, so the comparison
        # would have refused EVERY observation, including every correct one.
        #
        # THE ORDERING IS THE REASON IT STAYS OUT. W83781 is ordered behind
        # this Work rather than integrated over it, so a candidate here must
        # not depend on it. The binding belongs to that Work's boundary and
        # is its to enforce, in `operations_from` and in the store itself.
        #
        # W83781 IS NOW INTEGRATED OVER W85500, WHICH SUPERSEDES THE ORDERING
        # SENTENCE ABOVE AND NOT THE DECISION. The check still stays out, for
        # a reason that is now measurable rather than provisional:
        # `JobStore.open` REQUIRES the Authority operand and refuses a store
        # bound to another one without touching it, so by the time a store
        # reaches this factory its binding has already been proved against
        # what the operator named. What `operations_from` compares is a second
        # question -- the CONFIGURATION's Authority against the store's -- and
        # it compares it because everything after that line WRITES. This one
        # reads. A configuration naming another Authority reaches another
        # Authority's launch home, where this store's namespaced attempt ids
        # do not exist, so the answer is `exchange: null` rather than a
        # stranger's terminal. Refusing here as well is a design decision that
        # belongs to a pinned ruling and an independent review, not to a
        # rebase.
        # W156162, pinned 2026-09-13T01:58:25Z: THE STORE IS STILL NOT HELD,
        # AND ONE NARROW READ OVER IT NOW IS.
        #
        # The paragraph above is about an EXTRA Authority-mismatch REFUSAL in
        # observation, and it stands unchanged: that decision still belongs to a
        # pinned ruling and an independent review, and this composition still
        # does not make it. What it did not establish is a universal ban on
        # reading Job data -- `StageObservation` already holds the Job store and
        # asks `scheduler.allocation_of` about every observed attempt.
        #
        # WHY THIS ONE IS NEEDED. Adoption proves a launch delivery by
        # re-authoring it and comparing canonical bytes, and a Job-bound
        # delivery carries that Job's configured ceilings. An observation that
        # could not ask which Job it was looking at could not reproduce those
        # bytes, so every launch would be reported unreadable on every status
        # pass. The callable answers that one question over the read-only owner
        # the factory already opened: no write, no migration, no runtime
        # refresh, no serving factory, no Authority session, no engine and no
        # credentials.
        self.execution_context = (job_execution_reader(job_store)
                                  if job_store is not None else None)
        self.given = given
        self.control = control_store
        self.launch_home = given["launch_home"]
        # THE SAME GROUP THE SERVING DEPLOYMENT READS, from the same store.
        # `launch.adopt` validates the delivery against it, so an observation
        # that skipped it would either refuse every real launch or -- worse --
        # accept one belonging to another group's workspace.
        self.group = configured_workspace_group(control_store)

    @staticmethod
    def _session_of(attempt_id):
        """The same derivation `_SingleWorker` uses, for the same reason.

        Derived from the attempt, so a process that authored nothing reaches
        the value the authoring process used without remembering anything.
        """
        return "session-" + digest(attempt_id)[7:31]

    def _job_execution(self, stage):
        """The same Job context the serving deployment composes, read-only.

        Identical inputs produce identical bytes, which is exactly what lets
        this observation adopt a delivery the serving composition materialized
        -- and what would otherwise report every Job-bound launch unreadable on
        every status pass.
        """
        if self.execution_context is None or stage is None:
            return None
        # THE SAME REFUSAL THE SERVING READER MAKES, for the same reason: two
        # compositions that disagreed about whether an unbound execution takes
        # the defaults would disagree about the BYTES, and this one exists to
        # reproduce them exactly.
        job_id = stage.get("job_id")
        if not job_id:
            _refuse("this execution names no Job and this observation "
                    "reproduces a Job-bound launch; there is nothing here to "
                    "resolve", category="refused", code="precondition")
        given = self.given
        return self.execution_context(
            job_id=job_id, attempt_id=stage["attempt_id"],
            runtime_input_digest=given["input_manifest"]["manifest_digest"],
            runtime_policy_digest=given["policy_digest"])

    def observe_exchange(self, stage):
        """The same reconstruction the serving deployment performs.

        NEVER RAISES, for the reason the serving one does not: the projection
        reads this for every stage on every pass, and one damaged launch root
        must not stop a status run from reporting anything at all. What comes
        back on a refusal is the category and the code and nothing else --
        a refusal's prose is composed from values a worker wrote.
        """
        try:
            attempt_id = stage["attempt_id"]
            launched = launch.adopt(
                self.launch_home, attempt_id=attempt_id,
                session=self._session_of(attempt_id),
                contract=self.given["launch_contract"],
                role=self.given["launch_role"],
                transport=exchange.EXCHANGE_TRANSPORT,
                job_execution=self._job_execution(stage),
                provider_context=_context_descriptor(self.control, self.given, attempt_id),
                workspace_group=self.group)
            if launched is None or launched.exchange is None:
                return None
            return exchange.observation(launched.exchange)
        except ContractRefusal as refusal:
            return {"transport": exchange.EXCHANGE_TRANSPORT,
                    "sequence_id": None, "command": None, "receipt": None,
                    "states": [], "terminal": None, "foreign": [],
                    "state": "unreadable",
                    "unreadable": {"category": refusal.category,
                                   "code": refusal.code}}


def observation_from(document, job_store, control_store):
    """Build the observation-only surface from one already-read document."""
    return _Observation(document, control_store, job_store=job_store)


def observing_factory(job_store, control_store):
    """The `status --observe` entry point, named the same way `factory` is."""
    place = os.environ.get(CONFIG_ENV)
    if place is None:
        _refuse(f"{CONFIG_ENV} names the required absolute deployment "
                "configuration path", category="refused", code="capability")
    return observation_from(_read(place), job_store, control_store)


def factory(job_store, control_store):
    place = os.environ.get(CONFIG_ENV)
    if place is None:
        _refuse(f"{CONFIG_ENV} names the required absolute deployment "
                "configuration path", category="refused", code="capability")
    return operations_from(_read(place), job_store, control_store)


def _context_declaration(outputs):
    chosen = [one for one in outputs if one["name"] == "provider-context-receipt"]
    if len(chosen) != 1:
        _refuse("required context receipt declaration is missing")
    one = chosen[0]
    limits = one["constraints"]
    if one["path"] != "provider-context-receipt" or one["required"] is not False or one["type"] != "directory-result" or limits["max_entries"] != 1 or limits["max_bytes"] != 16384 or limits["allowed_media_types"] != ["application/octet-stream"] or limits["link_policy"] != "forbid" or limits["validator_digest"] is not None:
        _refuse("required context receipt declaration disagrees with its bounded contract")


def _context_preflight(given, control):
    selected = given.get("provider_context")
    if selected is None:
        return
    from baton_v12.worker_manager import provider_context, context_delivery
    profile = provider_context.context_profile_of(control, selected["profile_digest"])
    storage = context_delivery.configured_context_storage(control)
    if storage.path != selected["storage"] or any(profile[key] != given[other] for key, other in (("runtime_profile_digest", "profile_digest"), ("adapter_digest", "adapter_digest"), ("image_digest", "image_digest"), ("retention_policy_digest", "retention_policy_digest"))):
        _refuse("required context configuration disagrees with its preconfigured owner")
    if profile["argv_policy_digest"] != digest(provider_context.ARGV_POLICY) or profile["environment_policy_digest"] != digest(provider_context.ENVIRONMENT_POLICY):
        _refuse("required context profile lacks the selected serving policy")
    for key in ("workspace_storage", "launch_home", "credential_home", "nominated_source", "task_document", "credential_sources"):
        other = given.get(key)
        if other and (os.path.commonpath([storage.path, other]) in (storage.path, other)):
            _refuse("context storage overlaps a configured execution root")


def _context_descriptor(control, given, attempt_id):
    from baton_v12.worker_manager import provider_context
    binding = provider_context.context_invocation_of(control, attempt_id)
    if (binding is None) != (given.get("provider_context") is None):
        _refuse("required context binding is missing or deployment was downgraded")
    if binding is not None and binding["profile_digest"] != given["provider_context"]["profile_digest"]:
        _refuse("required context binding changed profile")
    return binding


def _context_mount(control, given, attempt_id):
    if _context_descriptor(control, given, attempt_id) is None:
        return None
    from baton_v12.worker_manager import context_delivery
    storage = context_delivery.configured_context_storage(control)
    if storage.path != given["provider_context"]["storage"]:
        _refuse("required context storage changed")
    return context_delivery.context_mount_of(control, storage, attempt_id=attempt_id)
