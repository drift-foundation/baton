"""The long-lived control loop: recover, derive, delegate, record.

W71875. WHAT MAKES THIS A MANAGER RATHER THAN A SCRIPT is that every tick
starts from persisted state. Nothing is carried in a variable across a
restart, no step is owed because the previous command said so, and an operator
supplies no per-transition instruction: a sweep reads the two stores, derives
which acts are owed, delegates each to its canonical operation, and records
what came back.

THE ORDER INSIDE ONE ACT IS THE RESTART CONTRACT, and it is deliberately not
the obvious one. The delegated operation is performed OUTSIDE this store's
transaction, and the receipt is written afterwards from the manager's own
journal row. That leaves exactly one window -- performed but unrecorded -- and
it is the window the reconciliation read closes: the next sweep finds the
manager's committed operation under the identity this build derives, adopts
it, and does not perform it again. The reverse order would be worse in a way
no read could fix: a receipt written first and a crash before the call would
durably assert an act that never happened.

WHY THE RECEIPT IS TAKEN FROM THE MANAGER'S ROW AND NOT FROM THE CALL'S
ANSWER. The two are the same bytes when the call performed the act and are not
comparable when it replayed one -- and `issue_offer` deliberately answers with
a bearer that must not be stored. Reading the row means a performed act and an
adopted act record the same thing, so a restart audit compares receipts rather
than provenance.
"""

import json

from ..contracts import ContractRefusal
from ..source_profiles.checkout import ProfileRefusal

# THE REFUSAL TYPES THIS LOOP TREATS AS CONDITIONS, named once. `ProfileRefusal`
# is the checkpoint profile's own and is an `Exception`, not a
# `ContractRefusal`; W197661 measured it escaping `serve` entirely. Everything
# NOT in this tuple still escapes, which is the point of writing it down.
_CHECKPOINT_REFUSAL = (ContractRefusal, ProfileRefusal)
from ..contracts.errors import name_value
from ..worker_manager import boundaries
from ..worker_manager import events
from . import (cancellation, delegation, documents, ending, episodes,
               failure_analysis, job_control, projection,
               retained_verification, scheduler, submission)
from .store import job_signature

__all__ = ["TICK_SECONDS", "reconcile", "serve", "sweep"]

# The default distance between ticks of a serving loop, in seconds. It is a
# DEFAULT and not a policy: `serve` takes the interval as an operand, and a
# deployment that wants another cadence supplies one.
TICK_SECONDS = 5

# WHERE THE TWO ENDING VOCABULARIES MEET, so the relationship between them is a
# fact this build cannot start without rather than one a test happens to check.
# `documents.py` asserts the half it can see -- every replaceable ending is an
# ending -- and this is the half that needs both packages in scope: every
# ending this store acts on is a terminal offer state, and the one terminal
# offer state it must NOT act on is the successful one. Review [P1,
# 2026-09-03] is what a build that got this wrong did to a running stage.
assert frozenset(documents.EPISODE_ENDINGS) < frozenset(
    events.TERMINAL_OFFER_STATES)
assert (frozenset(events.TERMINAL_OFFER_STATES)
        - frozenset(documents.EPISODE_ENDINGS)) == {"claimed"}

_RECEIPT_KIND = "stage.receipt"


def receipt_operation_id(stage_id, episode, act):
    """One receipt's durable identity, WITH THE EPISODE IN IT.

    W73629: without the episode a replacement's `admit` would replay the
    abandoned episode's receipt instead of recording its own, so the fresh
    offer would be issued and then reported as an act that had already
    happened -- which is the wedge again, one layer down.
    """
    return f"{_RECEIPT_KIND}:{stage_id}:{episode}:{act}"


def reconcile(store, operations, *, now):
    """Resume: recover, RESYNCHRONIZE, then sweep once.

    The recovery is the MANAGER's, not a second one written here. An offer a
    previous incarnation issued and never delivered a bearer for is abandoned
    by `recover_on_restart`; an accepted one stays recoverable. Re-deciding
    that would be a second opinion about somebody else's durable state, and
    the two opinions would differ exactly when it mattered.

    W73629 ADDED THE MIDDLE STEP, and it is the correction at this level.
    Recovery used to end a stage's offer and tell nobody, so this store went
    on projecting `offered` and owing a `claim` against an offer that had
    ended -- one restart wedged the stage permanently. Now the seam is asked to
    REPUBLISH the current canonical state of every offer this store's live
    episodes name, and the sweep applies what comes back before it derives
    anything.

    THE ASK IS LEVEL-TRIGGERED, so nothing depends on having been listening at
    the right moment. An assertion missed while this process was down, or
    dropped with the transient transport, costs one tick of latency and
    nothing else: resynchronizing is exactly what attaching does, and it
    happens on every resume rather than once at a moment nobody can name.
    """
    recovered = operations.recover(now=now)
    return sweep(store, operations, now=now, recovered=recovered,
                 attach=True)


def sweep(store, operations, *, now, recovered=None, attach=False):
    """One tick: observe, replace, adopt, then derive and delegate.

    THE ADOPTION PASS COMES BEFORE DERIVATION AND COVERS EVERY ACT, not only
    the ones a stage still owes. A crash between a delegated call and its
    receipt leaves the manager holding a committed operation and this store
    holding no record of it -- and for the claim in particular the canonical
    state has already moved on, so the act is no longer owed and a pass that
    only looked at owed acts would leave the receipt missing forever.
    Reconciling by the identity rather than by the eligibility is what makes
    "records the returned identity/receipt" survive a restart.

    W73629 PUT TWO PASSES IN FRONT OF IT, in this order and for this reason:

    1. `_observe` drains whatever canonical state assertions are waiting, so
       an episode whose offer has ended is RECORDED as ended before anything
       reads what the stage owes. Draining afterwards would derive from state
       this same tick already knew was stale.
    2. `_replace` opens a fresh episode for every stage whose last one ended
       in a way that took nothing back. Doing it before adoption is what makes
       the replacement's `admit` an act THIS tick performs rather than one the
       operator waits another tick for.

    Ordinary ticks also attach admitted live offers, so a lost terminal
    assertion is repaired without restarting. Resume attaches every live
    episode, including an admission whose receipt was lost.
    """
    boundaries.instant(now, "the sweep's instant")
    observed = _observe(store, operations, attach=True, admitted_only=not attach)
    scheduler.reconcile_allocations(store)
    replaced = _replace(store, operations)
    # W85500: AND THE ENGINE IS ASKED BEFORE ANYTHING IS PROJECTED.
    #
    # THE THIRD PASS IN FRONT OF DERIVATION, for the same reason the two above
    # it are there: the runtime axis is state this tick can already know is
    # stale. A start attaches a runtime and records it, and nothing asked the
    # engine about that runtime again -- the successful ending is the only
    # other caller of the reconciliation, and an exceptional stage never
    # reaches it because it owes no act. So a worker that faulted and exited
    # was projected `running` for as long as anybody looked.
    #
    # BEFORE `stage_states`, NOT AFTER. What a stage owes and what a status
    # says are both derived from that projection, so refreshing afterwards
    # would report this tick's decisions from last tick's runtime truth.
    # W383217: AND THE CONTROL PASS, BEFORE THE FIRST PROJECTION THIS TICK
    # DERIVES ACTS FROM. A Job whose first deadline the trusted clock has
    # reached is fenced here, so this same tick's admission, launch and
    # cancellation passes read the fence; it is not the only guard -- every
    # write-side owner decides the same question under its own lock -- it
    # is the one that journals the trigger and orders the cessation.
    expired = _control(store, operations, now)
    # Settlement is not admission: fenced offers still need their Authority
    # operation reconciled. Publish the resulting owner state before adoption.
    settle = getattr(operations, "settle_offer", None)
    settled = False
    if settle is not None:
        for entry in projection.stage_states(store, operations).values():
            if entry["attempt"] is None or "admit" not in entry["receipts"]:
                continue
            attempt = entry["attempt"]
            job = submission.job_of(store, attempt["job_id"])
            delegation.check_binding(operations, attempt, job)
            try:
                settled = settle(attempt, now=now) is not None or settled
            except ContractRefusal as refusal:
                _defer(store, dict(stage_id=attempt["stage_id"],
                                   episode=attempt["episode"], act="claim",
                                   attempt_id=attempt["attempt_id"]),
                       {"category": refusal.category, "code": refusal.code,
                        "message": refusal.message},
                       operation_id=operations.canonical_operation("claim", attempt["offer_id"]))
    observed += _observe(store, operations, attach=settled)
    refreshed = _refresh(store, operations)
    held = projection.stage_states(store, operations)
    scheduler.reconcile_allocations(store, held)
    acts = _adopt(store, operations, held)
    if acts:
        # The receipts changed underneath the derivation, so what is owed is
        # decided from the state AFTER adoption rather than before it.
        held = projection.stage_states(store, operations)
    for owed in projection.owed_acts(store, operations, held):
        entry = held[owed["stage_id"]]
        acts.append(_delegate(store, operations, owed, entry["attempt"],
                              submission.job_of(store,
                                                entry["stage"]["job_id"])))
    observed += _observe(store, operations, attach=False)
    # THE LAUNCH PASS IS LAST, AND IT REACQUIRES STATE FIRST. W76207: what a
    # stage is owed here depends on receipts this same tick may have written,
    # so deriving it from the `held` above would be deciding from state the
    # tick has already moved past.
    started = _launch(store, operations, projection.stage_states(store,
                                                                 operations))
    # W81857: AND THE EXCHANGE PASS IS AFTER THE LAUNCH, REACQUIRING AGAIN.
    # A stage this tick just started is a stage that now owes a command, and
    # deriving that from state read before the launch would make every fresh
    # container wait a whole tick for a sequence this tick could already have
    # published. The same reacquisition is what lets one tick command a stage
    # and the next one end it without either being edge-triggered on the other.
    spoken = _converse(store, operations, projection.stage_states(store,
                                                                  operations))
    # W383215: AND THE CANCELLATION PASS, AFTER THE EXCHANGE PASS, REACQUIRING
    # AGAIN. It is level-triggered on the fence and the live axes, so a tick
    # that finds nothing cancelled does nothing, and a target that attached a
    # runtime after an earlier order is ordered again through its owner.
    cancelled = _cancel(store, operations,
                        projection.stage_states(store, operations))
    # W119733: AND THE COMPOSED ENDINGS NO PROJECTION OF A LIVE EPISODE CAN
    # REACH, LAST AND FROM THE JOB JOURNAL RATHER THAN FROM `held`. A
    # correction round ends the episode that owed the ending and opens its
    # successor, so the obligation belongs to a stage that has already moved
    # on; the pass above answers for the current attempt and is the wrong
    # place to ask about a previous one.
    spoken.extend(_recover_endings(store, operations, spoken))
    # W385623 / REC-8: AND THE RETAINED-VERIFICATION-FAILURE RECOVERY PASS,
    # AFTER THE ENDINGS AND BEFORE THE CAPACITY IS SETTLED.
    #
    # AFTER, because what it derives from is a SETTLED ending: the pass above
    # is what finishes an ending no live projection could reach, and a
    # recovery pass in front of it would walk past a failure whose own
    # settlement this same tick was about to write. A terminal ending is
    # "durably attributed" when its settlement is committed, not when a
    # worker's disposition is observed.
    #
    # LEVEL-TRIGGERED LIKE EVERY PASS AROUND IT. It reads the ending journal
    # and the recovery records rather than an edge this process happened to
    # see, which is the whole reason the analysis of a failure survives the
    # restart that interrupted it.
    #
    # AND ABSENT IS AN ANSWER. A deployment that configures no analysis seam
    # reaches none of this and its report carries no `analysed` member, which
    # is what preserves every accepted operations object in this tree.
    analysed = _analyse(store, operations, now)
    # W385625 / REC-8: AND THE RETAINED-VERIFICATION EXECUTION PASS, AFTER
    # THE ANALYSIS PASS AND BEFORE THE CAPACITY IS SETTLED.
    #
    # AFTER, for the reason the analysis pass is after the endings: what this
    # one derives from is an ADMITTED successor, and an approval recorded by
    # the owner command between two ticks is a successor this tick can
    # already materialize. Nothing chains inside it -- one act per successor
    # per tick -- because the fault cuts between materializing, running the
    # approved command and handing the candidate to review are exactly the
    # cuts the contract names and acceptance injects failures at.
    #
    # BEFORE THE CAPACITY SETTLES, because a handoff committed here opens the
    # review stage's recovery gate, and the admission that gate releases is
    # the next tick's: this pass never launches a reviewer itself.
    #
    # AND ABSENT IS AN ANSWER. A deployment that configures no verification
    # seam reaches none of this, which is what preserves every accepted
    # operations object in this tree.
    #
    # NOT ADDED TO THE REPORT, which is this loop's standing rule for an act
    # whose account somebody else already holds -- the same sentence the
    # capacity reconciliation below is governed by. The `sweep` document's
    # member contract is CLOSED and this build does not widen it; what this
    # pass did is visible where a reader looks for it, in the five durable
    # records `retained_verification.successor_execution` answers with, in
    # the owner items `owner_items_of` lists, and in the review stage's own
    # recovery gate. A caller that wants the per-act list drives
    # `advance_verification` and is handed it.
    _verify(store, operations, now)
    # W385695 / REC-9: AND THE PUBLICATION RECOVERY PASS, AFTER THE ENDINGS
    # AND BEFORE THE CAPACITY IS SETTLED, for the verification pass's reasons.
    #
    # AFTER THE ENDINGS, because what it binds is a publication stage's
    # ORDINARY ending -- the freeze and the intake this same tick's exchange
    # pass may just have performed. BEFORE THE CAPACITY SETTLES, because the
    # handoff it commits opens the review stage's gate and the admission that
    # gate releases is the next tick's: this pass never launches a publisher
    # and never offers a reviewer.
    #
    # NOT ADDED TO THE REPORT, by the same standing rule: the `sweep`
    # document's member contract is closed, and what this pass did is visible
    # in `publication_execution.publication_readiness`, in the six durable
    # records it reads, and in the review stage's own gate.
    _publish(store, operations, now)
    # W316918: AND THE CAPACITY IS SETTLED FROM THE STATE THIS TICK LEAVES,
    # not from the state it began with.
    #
    # MEASURED BEFORE IT WAS WRITTEN. `reconcile_allocations` above runs on a
    # `held` projection taken BEFORE the adoptions, the endings and the
    # exchange pass -- so the tick in which a stage's cleanup axis actually
    # becomes terminal is a tick whose reconciliation already looked. The
    # release therefore landed on the NEXT tick, and the last stage of a Job
    # has no next tick: a supervisor that stops when its stages are completed
    # stops in between, and its final allocation stays `reserved` for the life
    # of the store. That is exactly what the completed Job in
    # STATUS-COPY-316831.json shows -- implementation `released`
    # `cleanup-retained`, review `reserved` with `released_at` null six
    # milliseconds later.
    #
    # THIS ADDS NO NEW RULE AND WEAKENS NO HOLD. It is the same
    # reconciliation, asked once more with the projection re-derived after this
    # tick's acts: an allocation is still released only on a release ENDING or
    # a `complete`/`retained` cleanup with no blocker, and a running, unknown
    # or unsettled cleanup is held exactly as before. It is idempotent by
    # construction -- the loop only considers `LIVE_STATES`, so an allocation
    # this tick already released is skipped rather than released twice.
    # NOT ADDED TO THE REPORT: the sweep document's contract is closed, and a
    # release is already visible where a reader looks for it -- the allocation
    # projection's own `allocation_state`, `released_at` and `release_reason`,
    # which is what a status document carries.
    scheduler.reconcile_allocations(
        store, projection.stage_states(store, operations))
    return documents.sweep_report(observed_at=now, recovered=recovered,
                                  observed=observed, replaced=replaced,
                                  acts=acts, started=started, spoken=spoken,
                                  refreshed=refreshed,
                                  **({"analysed": analysed} if analysed
                                     else {}),
                                  **({"cancelled": cancelled} if cancelled
                                     else {}),
                                  **({"expired": expired} if expired
                                     else {}))


def _analyse(store, operations, now):
    """Run the configured retained-failure recovery pass, or nothing.

    W385623. THE ONE PRODUCTION CALLER of `failure_analysis`'s automatic path,
    and it is this loop for the reason every other pass is: what a Job manager
    owns is WHEN to ask, derived from durable state on every tick including
    the first one after a restart.

    THE SEAM IS AN OPTIONAL CAPABILITY, discovered exactly as `settle_offer`
    and `reclaim` are. A deployment that declares an analysis worker supplies
    it; `ManagerOperations` carries `None` by default, the read-only status
    surface holds none, and a fake in a test that names nothing reaches none
    of this.

    A CONTAINED REFUSAL IS A CONDITION. The pass already treats a single
    failure's refusal as one and keeps going; what is caught HERE is a refusal
    of the seam ITSELF -- a declaration a deployment composed wrongly, or a
    capability that cannot be called -- because a misconfigured recovery path
    must not stop a tick that is otherwise serving Jobs correctly. It is
    reported in the same typed shape the pass reports its own with.
    """
    seam = getattr(operations, "recovery_analysis", None)
    if seam is None:
        return []
    try:
        return failure_analysis.advance_recovery(store, seam, now=now)
    except ContractRefusal as refusal:
        return [documents.recovery_analysis(
            failure_key=None, stage_id=None, act="observe", outcome="refused",
            detail={"category": refusal.category, "code": refusal.code})]


def _verify(store, operations, now):
    """Run the configured retained-verification execution pass, or nothing.

    W385625. THE ONE PRODUCTION CALLER of `retained_verification`'s automatic
    path, and it is this loop for the reason every other pass is: what a Job
    manager owns is WHEN to ask, derived from durable state on every tick
    including the first one after a restart.

    THE SEAM IS AN OPTIONAL CAPABILITY, discovered exactly as `settle_offer`,
    `reclaim` and `recovery_analysis` are. A deployment that configures a
    private verification workspace, a declared execution context and a host
    command runner supplies it; `ManagerOperations` carries `None` by default,
    the read-only status surface holds none, and a fake in a test that names
    nothing reaches none of this.

    A CONTAINED REFUSAL IS A CONDITION. The pass already treats one
    successor's refusal as one and keeps going; what is caught HERE is a
    refusal of the seam ITSELF -- a context a deployment composed wrongly, a
    workspace root that is not a directory, a runner that cannot say which
    instance it runs in -- because a misconfigured recovery path must not stop
    a tick that is otherwise serving Jobs correctly.
    """
    seam = getattr(operations, "recovery_verification", None)
    if seam is None:
        return []
    try:
        return retained_verification.advance_verification(store, seam,
                                                          now=now)
    except ContractRefusal as refusal:
        return [documents.recovery_verification(
            failure_key=None, job_id=None, act="materialize",
            outcome="refused", detail={"category": refusal.category,
                                       "code": refusal.code})]


def _publish(store, operations, now):
    """Run the configured publication recovery pass, or nothing.

    W385695 / REC-9. THE ONE PRODUCTION CALLER of
    `publication_execution.advance_publication`, and of the serving
    manager's prior-assignment endings. The seam is an OPTIONAL capability
    discovered exactly as `recovery_verification` is: a deployment that
    installed the deterministic publication worker supplies it, and every
    other operations object answers `None` and reaches none of this.

    TWO THINGS, IN THE ORDER A RECOVERY NEEDS THEM:

      the PRIOR-ASSIGNMENT ENDINGS, when the seam carries the serving
        deployment's own ending port -- which is the one composition holding
        the producer participant's session. A reserved, approved recovery
        whose admission stopped for want of that session is offered its
        ending here, through the Authority's own exact-expect transition;
      then ONE ACT per admitted recovery of the publication execution pass:
        stage, account for the launched adoption, bind custody, hand off.

    IT NEVER LAUNCHES. The confined publication worker is an ordinary stage
    of this same sweep, admitted, claimed, started, commanded and concluded
    by the passes above through its own composed lifecycle.

    A CONTAINED REFUSAL IS A CONDITION, as it is in `_verify`: a misconfigured
    recovery seam must not stop a tick that is otherwise serving Jobs.
    """
    from . import publication_execution, publication_recovery

    seam = getattr(operations, "recovery_publication", None)
    if seam is None:
        return []
    acts = []
    try:
        ending = getattr(seam, "ending", None)
        if ending is not None:
            acts += publication_recovery.advance_endings(
                store, seam.control, ending=ending,
                exclusion=seam.exclusion, now=now)
        acts += publication_execution.advance_publication(
            store, seam, now=now)["acts"]
    except ContractRefusal as refusal:
        acts.append({"decision_id": None, "job_id": None, "act": "stage",
                     "outcome": "refused",
                     "detail": {"category": refusal.category,
                                "code": refusal.code}})
    return acts


def _converse(store, operations, held):
    """Publish the command a started stage owes, and end one that answered.

    LEVEL-TRIGGERED, WHICH IS THE WHOLE POINT, exactly as `_launch` is. Both
    acts are derived from canonical state -- a started runtime with no command,
    and a worker terminal that answered with no frozen output -- so an ordinary
    tick and the first tick after a restart ask the same question and get the
    same answer. Nothing here depends on having been the process that started
    the container, held a pipe, or saw an event.

    NOTHING IS WRITTEN TO THE JOB STORE, and that is the ruling rather than an
    omission. The command is a durable file whose name this build derives, and
    every substep of the ending is journalled by its own owner under an
    identity that owner derives, so replay is those owners' question. A receipt
    here would be a second account of a fact somebody else already holds -- and
    the one this leaf could not keep true, because the crash window it exists
    for is between the act and the receipt.

    A FAILURE IS CONTAINED TO ITS STAGE. A container that answered nonsense, a
    provider that faulted, an ending whose freeze refused: none of those may
    stop this sweep from observing every other stage. What makes a stage stop
    is a fact its own owner recorded, which the next projection reads.

    AN UNEXPECTED FAULT IS NOT CONTAINED. `_launch` contains an adapter fault
    only when the Worker Manager proved it recorded one; there is no equivalent
    proof for a programming error in a deployment's ending composition, and
    turning one into a per-stage outcome would bury it as a transient
    condition.
    """
    spoken = []
    for act, attempt in projection.owed_exchange(held):
        stage_id = attempt["stage_id"]
        job = submission.job_of(store, attempt["job_id"])
        try:
            performed = (operations.dispatch(attempt, job)
                         if act == "dispatch"
                         else operations.conclude(attempt, job))
        except _CHECKPOINT_REFUSAL as refusal:
            # A CHECKPOINT PROFILE'S OWN REFUSAL IS A CONDITION TOO, and it
            # reaches here as its own type. W197661 c200000 measured this:
            # `checkpoint_profiles.freeze` refused a dirty private line, and
            # `source_profiles.checkout.ProfileRefusal` is an `Exception`
            # rather than a `ContractRefusal` -- so it escaped this loop and
            # ENDED `serve`. One unfreezable checkpoint stopped every Job that
            # manager served, and the deferral machinery that exists for
            # exactly this cut point never saw it.
            #
            # NAMED, NOT SWALLOWED. Only this one declared refusal type joins
            # `ContractRefusal` here. A programming error still escapes, for
            # the reason the docstring above gives: there is no record proving
            # it was contained, and burying one as a transient per-stage
            # condition is how it never gets fixed.
            refusal = _as_condition(refusal)
            # EVERY REFUSAL HERE IS A CONDITION AND NOT AN ENDING, DURABLE OR
            # NOT, and the difference from `_launch` is a fact about who owns
            # the record. A durable launch refusal that nobody journalled would
            # leave a stage claimed and retried forever, which is why that pass
            # raises; here the DURABLE endings are the Worker Manager's own
            # failed freeze, refused intake and abandonment records, and the
            # next projection reads them through the observation this leaf
            # already takes. There is no state this pass could leave that the
            # exchange and the canonical readers do not already describe.
            # W197661 review 2026-09-18T02-59-56Z [R1]: AND THE REASON IS
            # DURABLE HERE TOO. I wired `_defer` into `_delegate` only, whose
            # acts are `admit` and `claim` -- and the defect the owner selected
            # this visibility FOR is a deferred `conclude`, which is this path.
            # So the probe still found `answering` with `deferral: null` for
            # the exact attempt whose finalization was blocked.
            #
            # NOTHING ELSE ABOUT THIS PASS CHANGES. The ruling above still
            # holds: no receipt is written here, because the substeps are
            # journalled by their own owners. A deferral is not a receipt --
            # it is why an act this leaf owes has not happened yet.
            reason = {"category": refusal.category, "code": refusal.code,
                      "message": refusal.message}
            spoken.append(documents.stage_exchange(
                stage_id=stage_id, episode=attempt["episode"],
                attempt_id=attempt["attempt_id"], act=act, outcome="deferred",
                detail=dict(reason, **_noted(
                    _defer(store, _owed_of(attempt, act), reason)))))
            continue
        spoken.append(documents.stage_exchange(
            stage_id=stage_id, episode=attempt["episode"],
            attempt_id=attempt["attempt_id"], act=act, outcome="performed",
            detail=_settled(performed,
                            _resolve(store, _owed_of(attempt, act)))))
    return spoken


def _as_condition(refusal):
    """One declared refusal, as the `ContractRefusal` a deferral is written from.

    NAMED, NOT SWALLOWED, and named in ONE place. `_CHECKPOINT_REFUSAL` is the
    closed pair this loop treats as conditions; a `ProfileRefusal` carries no
    category or code of its own, so it is translated into the vocabulary the
    deferral axis is written in, with its own type name kept in the message
    because that is what tells an operator which leaf refused.

    AN ORDINARY `ContractRefusal` IS RETURNED UNTOUCHED: it already says what
    it is, and rewriting its category would lose the reason.

    W197661 review 2026-09-18T05-14-53Z [R2]: this was written inline on the
    live path and simply absent on the recovered one. Two copies of a rule is
    how the second one is forgotten, so there is one.
    """
    if isinstance(refusal, ContractRefusal):
        return refusal
    return ContractRefusal("refused", "precondition",
                           f"{type(refusal).__name__}: {refusal}")


def _owed_of(attempt, act):
    """One owed act, in the shape `_defer` and `_resolve` read.

    The exchange passes an ATTEMPT and the delegated path passes an OWED act;
    both name the same three things, and composing the shape here keeps one
    reader rather than two.
    """
    return {"stage_id": attempt["stage_id"], "episode": attempt["episode"],
            "act": act, "attempt_id": attempt["attempt_id"]}


def _noted(answer):
    """An evidence outcome, carried only when it has something to say.

    A deferral that recorded normally adds nothing to the report: the report
    is about the ACT, and a line saying the note was filed would be noise on
    every tick. A failure to record is the exception, and it travels.
    """
    return {} if answer is None or answer.get("recorded") else {
        "evidence": answer}


def _settled(performed, cleared):
    """A performed act's own detail, plus a failed clear if there was one."""
    detail = performed if type(performed) is dict else None
    if cleared is not None and not cleared.get("cleared"):
        return dict(detail or {}, evidence=cleared)
    return detail


def _recover_endings(store, operations, spoken):
    """Ask again for every registered composed ending that never settled.

    W119733. THE ONE PASS THAT IS NOT DERIVED FROM A LIVE EPISODE, and it
    exists because the obligation outlives the attempt that owed it. A
    composed ending commits its intent before it can reach cleanup and its
    settlement only after the gate discharge and the routing have succeeded;
    `advance_correction` may end that episode and open its successor in
    between. The stage then has a live episode with nothing owed and a
    PREVIOUS one holding an unfinished ending, and every projection this
    manager takes is about the live one.

    THE SAME SERVING ACT AND NO OTHER. What this asks for is `conclude`, with
    the stage-and-episode view the recorded selectors still bind to -- so the
    deployment re-enters the ending it was already performing rather than a
    second one this pass composed. It reopens nothing, restarts nothing and
    starts no runtime: an ended episode's attempt is over, and what is left is
    the acts after the cleanup.

    NOT TWICE IN ONE TICK. `_converse` has already spoken for every live
    episode the projection reported `answering`, which a registered unsettled
    ending is; this pass skips exactly what that one performed or deferred.
    Owner replay makes a second call harmless anyway -- but a report saying a
    tick concluded one stage twice is a report of something that did not
    happen.

    A FAILURE IS CONTAINED TO ITS STAGE, for `_converse`'s reason and with its
    boundary. A refusal here is a condition somebody else's record already
    describes, and the obligation stays registered and unsettled, so the next
    tick asks again. An unexpected fault is not contained.
    """
    done = {(one["stage_id"], one["episode"]) for one in spoken
            if one["act"] == "conclude"}
    resumed = []
    for intent in ending.pending_endings(store):
        key = (intent["stage_id"], intent["episode"])
        if key in done:
            continue
        done.add(key)
        attempt = ending.attempt_of(store, intent)
        job = submission.job_of(store, intent["job_id"])
        try:
            performed = operations.conclude(attempt, job)
        except _CHECKPOINT_REFUSAL as refusal:
            # THE SAME TWO TYPES, because this is the same act. W197661 review
            # 2026-09-18T05-14-53Z [R2]: the live path learned that a
            # checkpoint profile refuses in its OWN type and this one did not,
            # so a `ProfileRefusal` raised by a RESUMED `conclude` escaped the
            # sweep and ended `serve` -- the very failure the live-path fix was
            # for, still reachable by the restart path it is most likely to be
            # met on. A containment boundary that holds for one caller of an
            # act and not the other is not a boundary.
            refusal = _as_condition(refusal)
            # AND HERE, which is the path the review names explicitly: this
            # services an ending registered by a PRIOR episode, so its reason
            # has to be attributable to that episode rather than to the live
            # one. `projection.deferral_of` reads both.
            reason = {"category": refusal.category, "code": refusal.code,
                      "message": refusal.message}
            owed = {"stage_id": intent["stage_id"],
                    "episode": intent["episode"], "act": "conclude",
                    "attempt_id": intent["attempt_id"]}
            resumed.append(documents.stage_exchange(
                stage_id=intent["stage_id"], episode=intent["episode"],
                attempt_id=intent["attempt_id"], act="conclude",
                outcome="deferred",
                detail=dict(reason, **_noted(_defer(store, owed, reason)))))
            continue
        resumed.append(documents.stage_exchange(
            stage_id=intent["stage_id"], episode=intent["episode"],
            attempt_id=intent["attempt_id"], act="conclude",
            outcome="performed",
            detail=_settled(performed, _resolve(
                store, {"stage_id": intent["stage_id"],
                        "episode": intent["episode"], "act": "conclude",
                        "attempt_id": intent["attempt_id"]}))))
    return resumed


def _launch(store, operations, held):
    """Ask the deployment to drive every CLAIMED stage into a live worker.

    LEVEL-TRIGGERED, WHICH IS THE WHOLE POINT. The eligibility is a fact about
    canonical state -- claimed, with no runtime and no recorded start failure --
    so an ordinary tick and the first tick after a restart ask exactly the same
    question and get the same answer. Folding this into `claim()` would have
    made it edge-triggered on an act a resumed manager deliberately does not
    repeat: a crash after the Authority commits the claim leaves the next
    incarnation adopting the canonical settlement without calling `claim`, and
    a launch hidden in there would be skipped once, permanently, on the one
    path nobody is watching.

    A FAILURE IS CONTAINED TO ITS STAGE. Unlike a delegated act, this pass does
    not raise: the acceptance says a failed start must contain that stage and
    still leave every other stage observable, so each launch is reported as its
    own outcome and the loop continues. A DURABLE refusal is the Worker
    Manager's recorded start failure, which the next projection reads as
    `exceptional` through `attempt_start_failure_of` or its preparation
    sibling; an ordinary one is a condition this tick could not satisfy and
    the next tick asks again.

    Nothing is written to the Job store here. `admit` and `claim` remain the
    only receipt acts this leaf owns; the runtime start is journalled by its
    owner under an identity that owner derives, so replay is that manager's
    question rather than a second account kept here.
    """
    started = []
    for stage_id in sorted(held):
        entry = held[stage_id]
        # `claimed` is exactly "the claim is taken and no runtime is attached".
        # `running` already has one, and a recorded start failure has already
        # made the stage `exceptional`, so neither is asked again.
        if entry["state"] != "claimed":
            continue
        attempt = entry["attempt"]
        # W383215: THE FENCE IS RE-READ IMMEDIATELY BEFORE THE START. A
        # launch is the Worker Manager's act and cannot run under this
        # store's lock; a cancelled Job's claimed stage is reported deferred
        # and the cancellation pass fences its assignment instead.
        # W383217: AND THE DEADLINE AND THE TRUSTED CLOCK, by the same
        # question every write-side owner asks -- a stage claimed before the
        # deadline starts no runtime after it, and an uncertain clock starts
        # nothing new.
        closed = job_control.closed_of(store, attempt["job_id"],
                                       stage_id=stage_id)
        if closed is not None:
            started.append(documents.stage_launch(
                stage_id=stage_id, episode=attempt["episode"],
                attempt_id=attempt["attempt_id"], outcome="deferred",
                detail={"category": "refused", "code": "precondition",
                        "message": job_control.closed_message(
                            closed, "a runtime start")}))
            continue
        job = submission.job_of(store, attempt["job_id"])
        try:
            answer = operations.launch(attempt, job)
        except ContractRefusal as refusal:
            detail = {"category": refusal.category, "code": refusal.code,
                      "message": refusal.message}
            if _recorded_failure(operations, attempt, job):
                # THE CANONICAL ENDING EXISTS, so this stage is over and the
                # next projection reads it as `exceptional`. Containing it here
                # is what keeps one failed stage from ending the sweep.
                started.append(documents.stage_launch(
                    stage_id=stage_id, episode=attempt["episode"],
                    attempt_id=attempt["attempt_id"], outcome="refused",
                    detail=detail))
                continue
            if refusal.durable:
                # A DURABLE ENDING NOBODY RECORDED IS NOT A STAGE OUTCOME.
                # Review [P1]: reporting it as `refused` left the stage
                # `claimed` with no canonical failure, so the next tick asked
                # again and the one after that, forever. The deployment's
                # composition owns recording its own durable endings through
                # the Worker Manager; one that refuses durably and journals
                # nothing has left this control plane no fact to project and
                # no reason to stop, and saying so loudly is the only answer
                # that is not a silent retry loop.
                raise ContractRefusal(
                    "integrity", "schema",
                    f"the launch of stage {name_value(stage_id)} refused "
                    f"durably as {name_value(refusal.code)} and the Worker "
                    f"Manager holds no failed-start record for attempt "
                    f"{name_value(attempt['attempt_id'])}; a durable ending "
                    f"this control plane cannot observe would leave the stage "
                    f"claimed and retried on every tick") from refusal
            # AN ORDINARY REFUSAL IS A CONDITION, not an ending: the workspace
            # is not ready, the worker has not accepted. The next tick asks
            # again, which is what level-triggered means.
            started.append(documents.stage_launch(
                stage_id=stage_id, episode=attempt["episode"],
                attempt_id=attempt["attempt_id"], outcome="deferred",
                detail=detail))
            continue
        except Exception as fault:
            # THE ADAPTER FAULT PATH, and review [P1] is why it is here.
            # `request_runtime_start` journals the failed start and then
            # RE-RAISES the adapter's own typed fault, so a real engine error
            # is not a `ContractRefusal` at all -- it escaped this loop,
            # skipped every stage sorted after it, and ended `serve` even
            # though the canonical failure record now existed.
            #
            # ONLY A FAULT THE MANAGER PROVED IT RECORDED IS CONTAINED. A
            # programming error has no such record, and turning one into a
            # per-stage outcome would bury it as a transient condition.
            if not _recorded_failure(operations, attempt, job):
                raise
            started.append(documents.stage_launch(
                stage_id=stage_id, episode=attempt["episode"],
                attempt_id=attempt["attempt_id"], outcome="refused",
                detail={"category": "runtime-observation", "code": "fault",
                        "message": f"{type(fault).__name__}: {fault}"}))
            continue
        # THE RUNTIME IDENTITY IS THE MANAGER'S ANSWER, not a row this leaf
        # went looking for. An answer that names none is not a failure -- an
        # uncertain reconciliation carries no identity -- so it is reported as
        # what it is and the next tick observes rather than starting again.
        runtime_id = (answer.get("runtime_id") if type(answer) is dict
                      else None)
        started.append(documents.stage_launch(
            stage_id=stage_id, episode=attempt["episode"],
            attempt_id=attempt["attempt_id"], outcome="started",
            runtime_id=runtime_id))
    return started


def _observe(store, operations, *, attach, admitted_only=False):
    """Apply every canonical state assertion waiting for this store.

    NOTHING IS READ OUT OF THE WORKER MANAGER HERE. This asks its seam to
    republish what that manager already holds, then drains the transport; the
    assertions arrive as documents and `apply_offer_state` is the one thing in
    this package that ends an episode.

    ATTACHING NAMES WHAT IS RELEVANT. A control store may carry other Job
    stores' offers, so what this store asks about is the offers its own LIVE
    episodes name: an ended episode needs no further assertion, and asking
    about somebody else's offer would be taking an interest in a row that is
    not this store's business.

    Answers how many assertions were applied, so a tick that resynchronized
    can say so rather than leaving it to be inferred from what followed.
    """
    if attach:
        live = _live_episodes(store)
        if admitted_only:
            live = [episode for episode in live
                    if "admit" in projection.receipts_of(store, episode["stage_id"], episode["episode"])]
        if live or not admitted_only:
            operations.attach([episode["offer_id"] for episode in live])
    return operations.drain(
        {events.OFFER_STATE_KIND: lambda event: apply_offer_state(store,
                                                                  event)},
        quiescent=(lambda: store._connection.in_transaction,))


def _refresh(store, operations):
    """Ask the engine about every live attempt, one stage at a time.

    ONE STAGE'S FAILURE IS ONE STAGE'S. The acceptance says plainly that a
    faulted stage must not stop another from being observed or progressed, so
    a typed refusal is contained here and reported against the stage that
    raised it. An escaping refusal would make one damaged attempt stop the
    whole sweep from projecting anything -- which is the shape of the defect
    this Work exists to correct, arriving by a different road.

    TWO CONDITIONS AND NO MORE, which is re-review 2026-09-04T19:08:40Z [P1].
    Containment is for MALFORMED EVIDENCE a deployment answered with, and for
    the operational failure a deployment itself names as "the engine could not
    be reached". A defect in somebody's code is neither, and it must not be
    converted into report data: `serve` keeps only the last tick's report, so
    a defect contained on an earlier tick is raised nowhere, recorded nowhere,
    and gone as soon as one tick succeeds. It escapes to whoever is running
    the loop instead, where it can be seen and fixed.

    ONLY A LIVE EPISODE. A stage whose episode is over has identities that
    belong to a finished attempt; asking the engine about them would refresh
    somebody else's runtime into this stage's row.

    NOTHING IS WRITTEN HERE. The reconciliation the deployment performs writes
    its own answer under its own identity, exactly as `launch` and `dispatch`
    do, so a second Job-store receipt would be a second account of a fact its
    owner already holds.
    """
    refreshed = []
    for stage in submission.stage_rows(store):
        live = episodes.live_of(store, stage["stage_id"])
        if live is None:
            continue
        attempt = episodes.attempting(stage, live)
        members = {"stage_id": stage["stage_id"], "episode": live["episode"],
                   "attempt_id": live["attempt_id"]}
        try:
            answer = operations.refresh_runtime(attempt)
        except ContractRefusal as refusal:
            # THE CATEGORY AND THE CODE AND NOTHING ELSE. A refusal's prose is
            # composed from values this deployment read, and some of those come
            # from a worker; a sweep report is read by whoever watches the
            # service and is not a place to publish them.
            refreshed.append(documents.stage_refresh(
                **members, state=None,
                detail={"category": refusal.category, "code": refusal.code}))
            continue
        except delegation.RefreshUnavailable as unreachable:
            # AN ENGINE THAT COULD NOT BE ASKED IS NOT A RUNTIME THAT IS GONE.
            # Review 2026-09-04T14-27-54Z [P1]: only typed refusals were
            # contained, so a socket, a pipe or a missing binary aborted the
            # whole sweep before the first projection -- suppressing an
            # exchange terminal that was readable on disk the whole time.
            #
            # THE DEPLOYMENT DECIDES WHAT COUNTS, which is re-review
            # 2026-09-04T19:08:40Z [P1]. This used to catch `OSError` here and
            # then catch `Exception` after it, so every unexpected defect
            # became report data that `serve` overwrote on the next tick. Only
            # the deployment knows which of ITS failures mean the engine could
            # not be reached -- a missing binary and a runner that timed out
            # are the same operational fact and are not the same Python type --
            # so it names them, and this pass contains exactly what it named.
            #
            # NOTHING IS RECORDED FROM THIS. The runtime axis keeps whatever it
            # last knew; what this reports is that the question could not be
            # put, which is the honest difference between "gone" and "unasked".
            refreshed.append(documents.stage_refresh(
                **members, state=None,
                detail={"category": "uncertain", "code": "engine-unreachable",
                        "error": unreachable.engine_error}))
            continue
        refreshed.append(documents.stage_refresh(
            **members,
            state=("not-asked" if answer is None
                   else answer["execution_runtime"])))
    return refreshed


def _live_episodes(store):
    return [live for stage in submission.stage_rows(store)
            for live in [episodes.live_of(store, stage["stage_id"])]
            if live is not None]


def _replace(store, operations):
    """Open a fresh episode for every stage whose last one ended recoverably.

    THE ENDING IS WHAT AUTHORIZES THIS, and only an ending in the closed
    replaceable set. An abandoned offer decided nothing about the stage -- the
    manager ended it because it could not account for a bearer, not because
    anybody looked at the work -- so re-admitting it takes nothing back. An
    episode that ended any other way is a stage that stopped, and this pass
    leaves it stopped for the projection to report.

    ONE REPLACEMENT PER ENDING, decided by the store rather than by this loop.
    The successor's operation identity is derived from the ended episode's
    number, so two managers reconciling one abandonment open the same episode
    and the second replays the first's committed result; the partial unique
    index refuses a second live episode however else the race arrives.
    """
    opened = []
    held = projection.stage_states(store, operations)
    for stage_id in sorted(held):
        entry = held[stage_id]
        if not projection.replaceable(entry):
            continue
        # W383215: A CANCELLED JOB'S STAGE IS NOT REPLACED. `open_next`
        # refuses this under its own lock too; skipping here keeps the
        # ordinary tick from asking a question whose answer is the fence.
        if entry.get("cancellation") is not None:
            continue
        # W383217: NOR A JOB PAST ITS DEADLINE OR UNDER UNCERTAIN TIMING.
        if projection.control_closed(entry.get("control"), stage_id):
            continue
        opened.append(episodes.open_next(store, stage_id,
                                         entry["history"][-1]))
    return opened


def _control(store, operations, now):
    """Journal the FIRST reached deadline of every controlled Job as its fence.

    W383217 / LIM-5. Level-triggered on durable rows: the origins, the
    profile and the trusted clock (the later of `now` and the persisted
    watermark) decide; the record is signed over the derived deadline, so a
    restart or a concurrent sweep replays it. A Job already expired is left
    to the cancellation pass; so is one an operator cancelled AT OR BEFORE
    its first reached deadline. An operator request LATER than a reached
    deadline does not hide the deadline (review 2026-11-19T00-20-37Z P2):
    the expiry is journalled beside it and, being the earlier trigger, is
    the fence the bound runs from. A Job whose every stage is OVER by the
    owners' evidence (`cancellation.over`) is NOT fenced: a deadline that
    passes after useful work finished closes nothing and manufactures no
    cancellation of it; a terminal label over an unceased or uncertain
    runtime is not over (P1). Uncertain timing holds admission (the
    projection and the guards do that) and is reported here; it undoes no
    reached deadline.
    """
    acted = []
    controls = job_control.controls_of(store)
    if not controls:
        return acted
    job_control.observe(store, now)
    held = projection.stage_states(store, operations)
    over = {}
    for entry in held.values():
        over.setdefault(entry["stage"]["job_id"], {})[
            entry["stage"]["stage_id"]] = cancellation.over(entry)
    for job_id in sorted(controls):
        fence = cancellation.fence_of(store, job_id)
        if fence is not None and fence.get("trigger", "operator") != "operator":
            continue
        evaluation = job_control.evaluate(store._connection, job_id, now)
        # A STAGE THAT IS ALREADY OVER NEVER REACHES ITS DEADLINE; the Job
        # deadline counts while anything of the Job is not.
        stages = over.get(job_id, {})
        first = job_control.closing(
            evaluation, any_stage=True,
            finished=[stage_id for stage_id, done in stages.items() if done])
        if first is None:
            if fence is None and evaluation["timing"] == "uncertain":
                acted.append(documents.job_control_notice(
                    job_id=job_id, outcome="held",
                    detail={"category": "uncertain", "code": "timing",
                            "watermark": evaluation["watermark"],
                            "observed_at": now}))
            continue
        if fence is not None and fence["requested_at"] <= first["deadline_at"]:
            continue
        if stages and all(stages.values()):
            continue
        try:
            record = job_control.expire(
                store, job_id=job_id, trigger=first["trigger"],
                stage_id=first["stage_id"], deadline_at=first["deadline_at"],
                observed_at=now)
        except ContractRefusal as refusal:
            acted.append(documents.job_control_notice(
                job_id=job_id, outcome="refused", trigger=first["trigger"],
                stage_id=first["stage_id"], deadline_at=first["deadline_at"],
                detail={"category": refusal.category, "code": refusal.code,
                        "message": refusal.message}))
            continue
        acted.append(documents.job_control_notice(
            job_id=job_id,
            outcome=("fenced" if record["observed_at"] == now
                     else "replayed"),
            trigger=record["trigger"], stage_id=record["stage_id"],
            deadline_at=record["deadline_at"]))
    return acted


def _cancel(store, operations, held):
    """Carry every committed cancellation out through the EXISTING owners.

    W383215 / LIM-5. ONE EFFECT PER TARGET PER TICK, decided from the live
    axes (`cancellation.effect_for`): a claimed attempt whose runtime never
    started is fenced at the Authority through the composition that would
    have launched it; an attached runtime is ordered to cease through
    `request_cancellation`, which fences the exact generation first. Neither
    answer is cessation, and nothing here says it is: the order is recorded
    as this store's account of having asked, and the next tick asks the axes
    again.

    A REFUSAL IS CONTAINED TO ITS TARGET and reported, never swallowed: a
    deployment that composes no cancellation capability, or an owner that
    refuses, leaves the target `pending` in the Job's cancellation report
    with the refusal beside it, which is the honest unknown.
    """
    acted = []
    cancel = getattr(operations, "cancel_attempt", None)
    fence = getattr(operations, "fence_unstarted_attempt", None)
    reasons = {}
    for stage_id in sorted(held):
        entry = held[stage_id]
        record = entry.get("cancellation")
        if record is None or entry["episode"] is None:
            continue
        attempt = entry["attempt"]
        effect = cancellation.effect_for(entry["state"], entry["observed"],
                                         entry.get("cancellation_targets", ()))
        if effect is None:
            continue
        act = fence if effect == cancellation.FENCE_UNSTARTED else cancel
        detail = None
        if act is None:
            outcome = "refused"
            detail = {"category": "refused", "code": "capability",
                      "message": f"this deployment composes no {effect} "
                                 f"capability"}
        else:
            # THE WORDING THE OWNERS WERE FIRST GIVEN FOR THIS JOB, journalled
            # once and replayed: the fence may since have become an earlier
            # deadline (review 2026-11-19T00-20-37Z P2), and the owner's stop
            # operation is signed over its reason.
            job_id = attempt["job_id"]
            if job_id not in reasons:
                reasons[job_id] = cancellation.order_reason(store, job_id,
                                                            record)
            try:
                if effect == cancellation.FENCE_UNSTARTED:
                    answer = act(attempt, reason=reasons[job_id])
                else:
                    answer = act(attempt_id=attempt["attempt_id"],
                                 reason=reasons[job_id])
            except ContractRefusal as refusal:
                outcome = "refused" if refusal.durable else "deferred"
                detail = {"category": refusal.category,
                          "code": refusal.code, "message": refusal.message}
            else:
                # RECORDED ONLY WHEN THE OWNER SAYS IT ORDERED. A returned
                # answer whose quiescence says `ordered: false` (fenced, but
                # nothing resolved to stop) is reported as such and left for
                # the next tick; the Authority fence is the owner's and
                # replays.
                if effect == cancellation.ORDER_CESSATION and not (
                        type(answer) is dict
                        and type(answer.get("quiescence")) is dict
                        and answer["quiescence"].get("ordered") is True):
                    outcome = "not-ordered"
                    detail = {"category": "runtime-observation",
                              "code": "quiescence-unknown",
                              "message": "the owner fenced the assignment "
                                         "and ordered no stop; nothing "
                                         "resolved to a runtime"}
                else:
                    outcome = "ordered"
                    cancellation.record_target(
                        store, job_id=attempt["job_id"], stage_id=stage_id,
                        episode=attempt["episode"],
                        attempt_id=attempt["attempt_id"], effect=effect,
                        evidence=_order_evidence(answer))
        acted.append(documents.stage_cancellation(
            stage_id=stage_id, episode=attempt["episode"],
            attempt_id=attempt["attempt_id"], effect=effect, outcome=outcome,
            **({} if detail is None else {"detail": detail})))
    return acted


def _order_evidence(answer):
    """The owner's returned identities, and nothing a journal may not hold."""
    if type(answer) is not dict:
        return {}
    held = {}
    intent = answer.get("intent")
    if type(intent) is dict:
        for member in ("authority_operation_id", "assignment", "reason"):
            if member in intent:
                held[member] = intent[member]
    fenced = answer.get("fenced")
    if type(fenced) is dict:
        held["fenced"] = {member: fenced[member]
                          for member in ("cause", "phase", "gate", "fenced")
                          if member in fenced}
    return held


def _recorded_failure(operations, attempt, job):
    """Did the Worker Manager durably record that THIS attempt will not run?

    The one question that decides whether a launch failure is this stage's
    ending or this control plane's problem. It is asked through the same bound
    observation everything else here goes through, so a foreign attempt under
    a derived id cannot answer it -- and it is asked AFTER the failure, because
    the record is written by the act that just failed.

    A refusal while asking is not an answer and is not swallowed: an
    unreadable or colliding failure record is an integrity problem in its own
    right, and `observation_of` raises it rather than letting this pass
    conclude that nothing was recorded.
    """
    observed = delegation.observation_of(operations, attempt, job)
    return (observed["start_failure"] is not None
            or observed["preparation_failure"] is not None)


def apply_offer_state(store, event):
    """Record what one canonical `offer.state` assertion means for this store.

    THE ONLY EFFECT AN ASSERTION CAN HAVE IS ENDING AN EPISODE, and it is
    worth being exact about why that is enough. A live offer -- `issued` or
    `accepted` -- tells this store nothing it does not already derive from its
    own receipts and the canonical observation it takes at projection time. An
    offer that will never produce a claim is the one fact it cannot derive,
    because the thing it would have derived it from is the offer that is now
    over.

    A TERMINAL OFFER IS NOT A TERMINAL STAGE. `claimed` is terminal for the
    offer and is the ending that means the stage is RUNNING, so it ends no
    episode here: the attempt that offer froze is the one the projection goes
    on observing. Review [P1, 2026-09-03] measured what treating the offer's
    whole terminal set as episode endings did -- a claimed stage came back
    `exceptional` with its identities cleared at the next restart. The set that
    ends an execution is `documents.EPISODE_ENDINGS`, and it is not
    `events.TERMINAL_OFFER_STATES`.

    IDEMPOTENT THREE TIMES OVER, because at-least-once delivery means the same
    assertion arrives again after a restart, after a reconnect, and on any
    republication. An assertion about an offer this store never asked for is
    silence; an assertion that the offer is still live has no effect; and an
    episode that has already recorded an ending keeps the one it recorded. The
    journalled `episode.end` identity is the fourth: two callers applying one
    assertion concurrently commit one row and replay it.

    A STALE ASSERTION CANNOT REGRESS ANYTHING. Revisions are monotone over the
    canonical lifecycle, so an older one is by construction either about a live
    state -- no effect -- or not greater than the ending already recorded, and
    an already-ended episode is never re-ended. The replacement episode is a
    different row with a different offer id, so no assertion about the ended
    offer can reach it at all.

    Answers the episode it ended, or `None` when the assertion changed nothing.
    """
    taken = boundaries.document(event, "an offer state assertion",
                                required=events.OFFER_STATE_MEMBERS)
    offer_id = boundaries.identity(taken["offer_id"], "an offer id")
    state = boundaries.text(taken["state"], "a canonical offer state")
    revision = events.offer_state_revision(state)
    if taken["revision"] != revision:
        raise ContractRefusal(
            "integrity", "schema",
            f"the assertion about {name_value(offer_id)} carries revision "
            f"{name_value(taken['revision'])} and this build ranks "
            f"{name_value(state)} at {revision}; a revision that does not "
            f"follow from the state it travels with cannot order anything")
    episode = episodes.episode_by_offer(store, offer_id)
    if episode is None:
        return None
    if episode["attempt_id"] != taken["attempt_id"]:
        raise ContractRefusal(
            "refused", "operation-collision",
            f"the assertion about {name_value(offer_id)} names attempt "
            f"{name_value(taken['attempt_id'])} and episode "
            f"{episode['episode']} of stage "
            f"{name_value(episode['stage_id'])} asked for "
            f"{name_value(episode['attempt_id'])}; one offer froze one "
            f"attempt, and applying this would record an ending for an "
            f"execution this store never asked for")
    if state not in documents.EPISODE_ENDINGS:
        return None
    if episode["ended_state"] is not None:
        # THE SAME ENDING AGAIN IS THE ORDINARY CASE and answers "nothing
        # changed". A DIFFERENT one is not ignorable: one offer reaches one
        # ending, so two would mean this store and the publisher disagree
        # about which offer this episode asked for, and quietly keeping the
        # first would be deciding that disagreement by arrival order.
        if episode["ended_state"] != state:
            raise ContractRefusal(
                "refused", "operation-collision",
                f"episode {episode['episode']} of stage "
                f"{name_value(episode['stage_id'])} recorded "
                f"{name_value(episode['ended_state'])} and this assertion "
                f"about {name_value(offer_id)} says {name_value(state)}; one "
                f"offer reaches one ending, so keeping the first by arrival "
                f"order would be deciding a disagreement rather than "
                f"reporting it")
        return None
    return episodes.end_episode(store, episode, state, revision)


def _adopt(store, operations, held):
    """Record a receipt for every canonical act this store never wrote one for.

    Nothing is performed here. The manager's journal is the authority on what
    happened, so an operation committed under the identity this build derives
    is adopted exactly as it stands -- and an act with no such row is left
    alone, because absence of a receipt is not evidence that an act ran.

    THAT THE ROW IS THIS STAGE'S ACT IS PROVED AT THE READ, and no longer
    inherited from the `stage_states` pass that built `held` immediately above.
    Review [P1, 2026-09-03]: a proof that has to stay true between two reads is
    not a proof of what the second one returned. A stage whose offer was absent
    when that pass looked is answered `None` there -- absence is the ordinary
    state of an unstarted stage -- so a foreign offer committing in between
    would be adopted here on the strength of a check that ran before it
    existed, and reported to an operator as this Job's `adopted` act.
    """
    adopted = []
    for stage_id in sorted(held):
        entry = held[stage_id]
        attempt = entry["attempt"]
        # A stage between an ending and its replacement has no identities to
        # reconcile against. Its ended episode's acts were adopted while it
        # was live, and asking the journal about them again would be adopting
        # a finished attempt's receipts onto a stage that has moved on.
        if attempt is None:
            continue
        job = submission.job_of(store, attempt["job_id"])
        for act in documents.ACTS:
            if act in entry["receipts"]:
                continue
            operation_id = operations.canonical_operation(
                act, attempt["offer_id"])
            record = _proved(operations, operation_id, attempt, job)
            if record is None:
                continue
            state = "refused" if _refused_act(act, record) else "adopted"
            _record(store, {"stage_id": stage_id, "act": act,
                            "episode": attempt["episode"]}, record, state)
            adopted.append(documents.reconciliation(
                stage_id=stage_id, episode=attempt["episode"], act=act,
                outcome=state, operation_id=operation_id))
    return adopted


def serve(store, operations, *, clock, sleep, should_continue,
          interval=TICK_SECONDS, reclaim=None):
    """The long-lived process, with its waiting and its stopping INJECTED.

    A loop that reached for `time.sleep` and a module-level flag would be a
    loop no test can drive and no deployment can stop politely. So the caller
    supplies the instant source, the wait and the predicate that ends the run,
    and this function owns only the order: recover once, then sweep until the
    predicate says to stop.

    Answers the LAST report rather than every one of them. A process that ran
    for a week would otherwise answer with a week of reports, and the useful
    fact at the end of a run is what was true at the end of it.
    """
    boundaries.capability(clock, "the Job manager's instant source")
    boundaries.capability(sleep, "the loop's wait")
    boundaries.capability(should_continue, "the loop's stop condition")
    if type(interval) is not int or interval <= 0:
        raise ContractRefusal(
            "integrity", "schema",
            f"a serving loop ticks a positive whole number of seconds apart; "
            f"this is {name_value(interval)}")
    # W275774 review 17:17:15Z: TYPED BEFORE THE FIRST EFFECTFUL ACT.
    #
    # The check ran after `reconcile`, which recovers and can adopt runtimes -- so a
    # deployment that passed something uncallable did real work first and only then
    # learned its expiry pass was unusable. A run that cannot reclaim must not begin.
    if reclaim is not None:
        boundaries.capability(reclaim, "a resource reclaim pass")
    report = reconcile(store, operations, now=clock())
    while should_continue():
        sleep(interval)
        report = sweep(store, operations, now=clock())
        # W275774: THE OVERDUE-RESOURCE PASS, INJECTED for the same reason the clock
        # and the wait are.
        #
        # Reclaiming an expired resource needs a runtime adapter, and composing one
        # is the deployment's act rather than this module's: the tool that knows how
        # to build an adapter for an attempt passes a pass that uses it. So this owns
        # only WHEN the sweep happens -- once per tick, after the ordinary sweep, so
        # a reclaim never races the launch pass in the same tick.
        #
        # ITS REFUSALS ARE NOT SWALLOWED. A reclaim that cannot proceed says so and
        # ends the run, because a long-lived loop that silently skipped expiry would
        # leave resources held forever with nothing in the record to say why. A
        # deployment that wants a tick to survive one bad attempt wraps that policy
        # into the pass it supplies, where the choice is visible.
        if reclaim is not None:
            # W275774 review 17:27:42Z: THE PASS'S OWN ANSWER IS KEPT, not discarded.
            # A held-or-refused outcome is the actionable part of an expiry tick --
            # which resources are still held and why -- and dropping it left an
            # operator with a sweep report that said nothing about expiry at all.
            reclaimed = reclaim(now=clock())
            if reclaimed is not None:
                report = dict(report, reclaimed=reclaimed)
    return report


def _proved(operations, canonical_id, stage, job):
    """One canonical row under a derived identity, or absence -- never a row
    this stage has not been shown to own.

    OBTAINING AND PROVING ARE ONE ACT HERE, and that is the whole of review
    [P1, 2026-09-03]. They used to be two steps a caller could take the first
    of: `_delegate` proved the row its FIRST read returned and then read the
    journal again after the delegated call, and `_adopt` rested on a check the
    projection pass had run a moment earlier. Both of those reads can return a
    row that did not exist when the proof ran -- a second Job store commits the
    same derived `offer.issue` identity, this store's call refuses the
    collision, and the foreign row is picked up as the answer. Routing every
    read through one function leaves no read that can skip the proof.

    Absence is answered as absence: an unissued offer is the ordinary state of
    a stage nothing has admitted, and there is nothing there to prove.
    """
    record = operations.receipt_of(canonical_id)
    if record is not None:
        delegation.check_binding(operations, stage, job)
    return record


def _delegate(store, operations, owed, stage, job):
    """Perform one owed act at most once, and record its canonical receipt.

    ONE ACQUISITION AFTER THE CALL, WHICHEVER WAY THE CALL ANSWERED. A returned
    call and a durable refusal are two answers about the same journal, and
    reading it at two sites was what let one of them go unproved. So the
    delegated call decides only whether a missing row is `deferred` or a
    derived-identity fault, and the row itself is obtained and proved once.
    """
    canonical_id = owed["operation_id"]
    record = _proved(operations, canonical_id, stage, job)
    performed = False
    if record is None:
        try:
            _perform(operations, owed["act"], stage, job)
        except ContractRefusal as refusal:
            # AN ORDINARY REFUSAL IS AN ANSWER, NOT A FAILURE. `submit_claim`
            # refuses an offer the worker has not accepted yet, and that is
            # the honest state of the world rather than something to record.
            # A DURABLE one did commit a journal row, so the act is settled
            # and the row below is what settles it here too.
            deferred = {"category": refusal.category, "code": refusal.code,
                        "message": refusal.message}
        else:
            deferred = None
        record = _proved(operations, canonical_id, stage, job)
        if record is None:
            if deferred is not None:
                # W197661: AND THE REASON IS NOW DURABLE. This branch used to
                # return the reason and persist nothing -- `_record` below
                # writes only when the Worker Manager journalled a row -- so a
                # stage that had owed one act for an hour looked exactly like a
                # stage that had just been offered, and the only account of why
                # was a reconcile report nobody kept. A real deployment sat at
                # `answering` through a whole incident that way.
                #
                # IT IS NOT A RECEIPT AND IT IS NOT TERMINAL. `deferrals` is its
                # own relation for exactly that reason; see the table's own
                # comment, and `projection._deferral`, which carries it beside
                # the stage state without being allowed to decide one.
                deferred = dict(deferred,
                                **_noted(_defer(store, owed, deferred, operation_id=canonical_id)))
                return documents.reconciliation(
                    stage_id=owed["stage_id"], episode=owed["episode"],
                    act=owed["act"], outcome="deferred",
                    operation_id=canonical_id, detail=deferred)
            # THE DERIVED IDENTITY IS WRONG, and this is where that shows.
            # The operation happened and the journal holds nothing under
            # the name this build asked for, so every later reconciliation
            # would repeat it. Refusing here is the only answer that does
            # not silently start re-issuing offers.
            raise ContractRefusal(
                "integrity", "schema",
                f"the {owed['act']} of stage "
                f"{name_value(owed['stage_id'])} was performed and the "
                f"Worker Manager journalled no operation "
                f"{name_value(canonical_id)}; this build derives that "
                f"identity to decide what a restart already did, and one "
                f"that names nothing would make every sweep repeat the "
                f"act")
        performed = True
    state = ("refused" if _refused_act(owed["act"], record)
             else ("performed" if performed else "adopted"))
    # AND A SETTLED ACT HAS NO OUTSTANDING REASON. A deferral left behind after
    # its act succeeded would be worse than none: an operator would be reading
    # a live explanation of something that is over.
    cleared = _resolve(store, owed)
    _record(store, owed, record, state)
    return documents.reconciliation(
        stage_id=owed["stage_id"], episode=owed["episode"], act=owed["act"],
        outcome=state, operation_id=canonical_id,
        # A FAILED CLEAR TRAVELS WITH THE ACT THAT SETTLED. Silence here would
        # leave an operator reading a live explanation of something that is
        # over, which is the same class of falsehood as an unrecorded reason.
        **({} if cleared.get("cleared") else {"detail": {"evidence": cleared}}))


def _refused_act(act, record):
    # offer.settle commits both successful claims and terminal non-claims.
    return (record["state"] == "refused"
            or (act == "claim" and json.loads(record["result"]).get("state") in documents.EPISODE_ENDINGS))


def _perform(operations, act, stage, job):
    if act == "admit":
        return operations.admit(stage, job)
    return operations.claim(stage)



def _defer(store, owed, reason, *, operation_id=None):
    """Record why one owed act did not happen, ONCE, and keep it current.

    W197661. UPSERT rather than insert: a deferral repeats on every tick, and a
    row per occurrence would be an unbounded durable write driven by a condition
    that is not changing. `first_seen_at` is when this started; `last_seen_at`
    is how an operator tells "still" from "stale".

    BEST EFFORT, DELIBERATELY. This is an observation ABOUT a failure to act,
    and a manager that failed its whole tick because it could not write one
    would have made the diagnostic more dangerous than the silence it replaces.
    A tick whose store is unwritable has larger problems and reports them
    elsewhere.
    """
    now = store._now()
    try:
        store._connection.execute(
            "INSERT INTO deferrals (stage_id, episode, act, attempt_id, "
            "operation_id, category, code, message, first_seen_at, "
            "last_seen_at, incarnation) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, "
            "?) ON CONFLICT (stage_id, episode, act) DO UPDATE SET "
            "attempt_id = excluded.attempt_id, "
            "operation_id = excluded.operation_id, "
            "category = excluded.category, code = excluded.code, "
            "message = excluded.message, last_seen_at = excluded.last_seen_at, "
            "incarnation = excluded.incarnation",
            (owed["stage_id"], owed["episode"], owed["act"],
             owed["attempt_id"], operation_id,
             str(reason.get("category")),
             str(reason.get("code")), str(reason.get("message"))[:_MAX_REASON],
             now, now, store.incarnation))
    except Exception as failure:                             # noqa: BLE001
        # W197661 review 2026-09-18T02-59-56Z [R2]: A SWALLOWED FAILURE IS NOT
        # A SUCCESS. This returned `None` either way, so a deferral that was
        # never written was indistinguishable from one that was -- an evidence
        # surface that silently has no evidence, which is the class of defect
        # this whole Work exists to remove.
        #
        # IT STILL DOES NOT RAISE, and that is deliberate: this is an
        # observation ABOUT a failure to act, and a manager whose tick died
        # because it could not write a diagnostic would have made the
        # diagnostic more dangerous than the silence. What it does instead is
        # ANSWER, so the caller puts the evidence failure in its own report --
        # beside the stage's execution state and never inside it.
        return {"recorded": False,
                "why": f"this deferral could not be recorded "
                       f"({type(failure).__name__})"}
    return {"recorded": True}


def _resolve(store, owed):
    """This act is settled, so its outstanding reason is not a reason.

    AND A FAILED CLEAR IS SAID OUT LOUD. A reason left behind because the
    DELETE failed would present a settled act as outstanding, which is the
    opposite of what this table is for -- so the caller is told, rather than
    an operator being left to read a live explanation of something that is
    over.
    """
    try:
        store._connection.execute(
            "DELETE FROM deferrals WHERE stage_id = ? AND episode = ? "
            "AND act = ?",
            (owed["stage_id"], owed["episode"], owed["act"]))
    except Exception as failure:                             # noqa: BLE001
        return {"cleared": False,
                "why": f"this act settled and its earlier reason could not be "
                       f"cleared ({type(failure).__name__}); it may still be "
                       f"reported as outstanding"}
    return {"cleared": True}


# A deferral's prose is an operand from another layer's refusal, so it is
# bounded here the way every other durable diagnostic in this campaign is.
_MAX_REASON = 2000

def _record(store, owed, record, state):
    """Write the receipt for one settled canonical act.

    THE SIGNATURE NAMES THE FACT AND NOT HOW WE LEARNED IT. `performed` and
    `adopted` are the same act observed by two paths -- one incarnation that
    called it and one that found it committed -- so putting the path in the
    durable identity would make two sweeps of one act collide instead of
    replaying.
    """
    stage_id = owed["stage_id"]
    act = owed["act"]
    episode = owed["episode"]
    operation_id = record["operation_id"]
    signature = job_signature(_RECEIPT_KIND,
                              {"stage_id": stage_id, "episode": episode,
                               "act": act, "operation_id": operation_id})
    detail = {"canonical_state": record["state"],
              "settled_at": record["settled_at"],
              "result": json.loads(record["result"])
              if record["result"] is not None else None,
              "refusal": json.loads(record["refusal"])
              if record["refusal"] is not None else None}

    def perform(connection):
        recorded_at = store._now()
        connection.execute(
            "INSERT INTO receipts (stage_id, episode, act, operation_id, "
            "state, detail, recorded_at, incarnation) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            (stage_id, episode, act, operation_id, state,
             json.dumps(detail, sort_keys=True, ensure_ascii=False),
             recorded_at, store.incarnation))
        return documents.receipt(
            stage_id=stage_id, episode=episode, act=act,
            operation_id=operation_id, state=state, recorded_at=recorded_at,
            detail=detail)

    return store.transact(receipt_operation_id(stage_id, episode, act),
                          _RECEIPT_KIND, signature, perform)
