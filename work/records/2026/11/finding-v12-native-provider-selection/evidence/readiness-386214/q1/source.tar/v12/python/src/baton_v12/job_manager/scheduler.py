"""Durable pooled worker selection for Job stage episodes.

W71877.  A logical worker is scheduler capacity, not a process or provider
session.  This module records the immutable pool generation and reserves that
capacity before the Worker Manager is asked to issue an offer.  Runtime,
offer, claim, output and cleanup state remain owned by the Worker Manager.
"""

import json

from ..contracts import ContractRefusal, canonical_text, digest
from ..contracts.errors import name_value
from ..worker_manager import boundaries
from .store import job_signature
from . import cancellation, documents, job_control

__all__ = ["ALLOCATION_STATES", "INTEGRATION_COMPLETED", "LANES", "POOL_SCHEMA",
           "ORDINARY_POOL_SCHEMA", "POOL_SCHEMAS", "ORDINARY_LANES",
           "PUBLICATION_LANE", "STAGE_LANES", "lane_of",
           "SEPARATION_CLASSES", "PooledManagerOperations", "activate_pool",
           "active_generation", "allocation_of", "allocation_refusal_of", "allocation_rows",
           "own_pool", "pool_workers", "reconcile_allocations", "release",
           "require_recovery", "reserve"]

# W385695 / DESIGN REC-9 moved this to /2, and the version is in the name for
# the reason every other revision in this build carries one: /2 declares a
# DEDICATED DETERMINISTIC PUBLICATION WORKER in a lane of its own, and an
# older binary that read it as /1 would see a worker whose lane it does not
# know and -- worse -- would be asked to serve a publication stage from the
# implementation lane. Refusing an unrecognised pool generation is the refusal
# such a build already has.
#
# /1 IS STILL OWNED, AND THAT IS THE POINT. A deployment that configures the
# two ordinary lanes configures exactly what it always did; `own_pool` reads
# both generations and only /2 may name the publication lane.
ORDINARY_POOL_SCHEMA = "baton.v12.worker-pool/1"
POOL_SCHEMA = "baton.v12.worker-pool/2"
POOL_SCHEMAS = (ORDINARY_POOL_SCHEMA, POOL_SCHEMA)
PUBLICATION_LANE = "publication"
# EVERY LANE THIS SCHEDULER ALLOCATES IN. `ORDINARY_LANES` is the pair a /1
# pool may name, and the publication lane is reserved capacity with its own
# principal that the ordinary implementation lane cannot serve.
ORDINARY_LANES = ("implementation", "review")
LANES = ("implementation", PUBLICATION_LANE, "review")
# WHICH LANE SERVES WHICH STAGE KIND, AS A TABLE AND NEVER AS A FALLTHROUGH.
# This used to be `"review" if kind == "review" else "implementation"`, which
# is exactly the defect REC-9's contract names twice: a publication stage
# submitted into that expression is OFFERED TO IMPLEMENTATION WORKERS. A
# missing entry is now a refusal rather than a default, so a kind added to the
# vocabulary without a lane is a loud failure at the one place that routes it
# instead of a silent misroute.
STAGE_LANES = {"implementation": "implementation",
               PUBLICATION_LANE: PUBLICATION_LANE,
               "review": "review",
               "integration": "implementation"}
SEPARATION_CLASSES = ("provider-diverse", "same-provider/different-model",
                      "same-provider/same-model-fresh-context")
ALLOCATION_STATES = ("reserved", "recovery-required", "released")
POOL_MEMBERS = ("schema", "variant", "separation_class", "workers")
WORKER_MEMBERS = ("worker_id", "lane", "participant", "profile_name",
                  "profile_digest", "eligible_kinds")
SELECTION_OUTCOMES = ("initial", "preferred", "fallback")
LIVE_STATES = ("reserved", "recovery-required")
RELEASE_ENDINGS = frozenset({"abandoned-after-restart", "declined", "expired",
                             "claim-refused", "settlement-expired"})


def _refuse(message, *, durable=False):
    raise ContractRefusal("integrity", "schema", message, durable=durable)


def _unique(values, what):
    if len(set(values)) != len(values):
        _refuse(f"a worker pool names one {what} per worker; duplicate "
                f"{what} values are not distinct capacity")


def own_pool(document):
    """Own one closed pool document; principals arrive from deployment."""
    taken = boundaries.document(document, "a worker pool",
                                required=POOL_MEMBERS)
    if taken["schema"] not in POOL_SCHEMAS:
        _refuse(f"a worker pool is one of "
                f"{', '.join(name_value(one) for one in POOL_SCHEMAS)}; this "
                f"is {name_value(taken['schema'])}")
    generation = taken["schema"]
    # WHICH LANES THIS GENERATION MAY NAME. A /1 document is exactly what it
    # always was; the publication lane is /2's own addition and a /1 pool
    # naming it is refused as the generation mismatch it is rather than
    # quietly admitted because this build happens to know the word.
    admitted_lanes = (LANES if generation == POOL_SCHEMA else ORDINARY_LANES)
    admitted_kinds = (documents.STAGE_KINDS if generation == POOL_SCHEMA
                      else documents.ORDINARY_STAGE_KINDS)
    variant = boundaries.text(taken["variant"], "a pool variant")
    separation = taken["separation_class"]
    if separation not in SEPARATION_CLASSES:
        _refuse(f"a pool separation class is one of "
                f"{', '.join(SEPARATION_CLASSES)}; this is "
                f"{name_value(separation)}")
    workers = taken["workers"]
    if type(workers) is not list or not workers:
        _refuse("a worker pool carries a non-empty workers list")
    owned = []
    for entry in workers:
        worker = boundaries.document(entry, "a configured worker",
                                     required=WORKER_MEMBERS)
        worker_id = boundaries.identity(worker["worker_id"], "a worker id")
        lane = worker["lane"]
        if lane not in admitted_lanes:
            _refuse(f"worker {name_value(worker_id)} names lane "
                    f"{name_value(lane)} and {name_value(generation)} "
                    f"configures {', '.join(admitted_lanes)}"
                    + (f"; the {PUBLICATION_LANE} lane is "
                       f"{POOL_SCHEMA}'s own and an older pool generation "
                       f"does not reserve its capacity"
                       if lane in LANES else ""))
        participant = boundaries.text(worker["participant"],
                                      "a worker participant")
        profile_name = boundaries.text(worker["profile_name"],
                                       "a worker profile name")
        profile_digest = boundaries.text(worker["profile_digest"],
                                         "a worker profile digest")
        kinds = worker["eligible_kinds"]
        if type(kinds) is not list or not kinds:
            _refuse(f"worker {name_value(worker_id)} needs at least one "
                    f"eligible stage kind")
        allowed = []
        for kind in kinds:
            if kind not in admitted_kinds:
                _refuse(f"worker {name_value(worker_id)} names unknown stage "
                        f"kind {name_value(kind)}; {name_value(generation)} "
                        f"serves {', '.join(admitted_kinds)}")
            expected_lane = lane_of(kind)
            if lane != expected_lane:
                _refuse(f"worker {name_value(worker_id)} is in {lane} lane but "
                        f"names {kind} eligibility; lanes are immutable")
            if kind in allowed:
                _refuse(f"worker {name_value(worker_id)} repeats eligible kind "
                        f"{name_value(kind)}")
            allowed.append(kind)
        owned.append({"worker_id": worker_id, "lane": lane,
                      "participant": participant,
                      "profile_name": profile_name,
                      "profile_digest": profile_digest,
                      "eligible_kinds": sorted(allowed)})
    _unique([one["worker_id"] for one in owned], "worker id")
    _unique([one["participant"] for one in owned], "participant")
    # THE DOCUMENT KEEPS ITS OWN GENERATION, for `documents.owned_submission`'s
    # reason: the normalized text is the durable identity an activation is
    # compared against, so rewriting a /1 deployment's pool as /2 would give
    # one configuration two identities and make an already-journalled
    # activation unreplayable the day this build shipped.
    return {"schema": generation, "variant": variant,
            "separation_class": separation,
            "workers": sorted(owned, key=lambda one: one["worker_id"])}


def _principals(principals, workers):
    if type(principals) is not dict:
        _refuse("pool activation needs deployment-resolved principals keyed "
                "by configured participant")
    wanted = {one["participant"] for one in workers}
    if set(principals) != wanted:
        _refuse("pool activation's resolved-principal keys must exactly match "
                "the configured participants")
    return {participant: boundaries.text(principals[participant],
                                          "a canonical principal")
            for participant in sorted(wanted)}


def active_generation(store):
    row = store._connection.execute(
        "SELECT * FROM pool_generations ORDER BY generation DESC LIMIT 1"
    ).fetchone()
    return dict(row) if row is not None else None


def pool_workers(store, generation=None):
    if generation is None:
        active = active_generation(store)
        if active is None:
            return []
        generation = active["generation"]
    return [dict(row) for row in store._connection.execute(
        "SELECT * FROM pool_workers WHERE generation = ? ORDER BY worker_id",
        (generation,))]


def _required_workers(store):
    active = active_generation(store)
    if active is None:
        return []
    rows = {(row["generation"], row["worker_id"]): row
            for row in pool_workers(store, active["generation"])}
    for allocation in store._connection.execute(
            "SELECT DISTINCT generation, worker_id FROM stage_allocations "
            "WHERE allocation_state IN ('reserved', 'recovery-required')"):
        key = (allocation["generation"], allocation["worker_id"])
        if key not in rows:
            row = store._connection.execute(
                "SELECT * FROM pool_workers WHERE generation = ? "
                "AND worker_id = ?", key).fetchone()
            if row is None:
                _refuse(f"live allocation names missing pool worker "
                        f"{name_value(key[1])} in generation {key[0]}")
            rows[key] = dict(row)
    return [rows[key] for key in sorted(rows)]


def activate_pool(store, document, resolved_principals):
    """Activate or reattach one immutable generation.

    Repeating the ACTIVE document revalidates every Authority-resolved
    principal and returns the same generation.  A different document creates
    the next generation; live allocations remain bound to their old rows.

    RETURNING DELIBERATELY TO A HISTORICAL VARIANT CREATES A NEW GENERATION,
    and W71877's review [P2] is why.  The digest identifies the immutable
    CONFIGURATION; it is not the identity of the act of activating it.  While
    it was also the operation identity, activating the primary document again
    after a fallback answered generation 1 and left generation 2 active --
    which reads as "the primary is back" while every new reservation still
    goes to the fallback.

    The two questions are separated here.  The operation identity counts how
    many generations already carry this digest, minus the live one when the
    live one IS this document.  An exact retry of the activation that is
    currently active therefore replays, and a deliberate return to a
    configuration that is not active is a new act with a new identity and a
    new generation.
    """
    pool = own_pool(document)
    principals = _principals(resolved_principals, pool["workers"])
    pool_digest = digest(pool)
    active = active_generation(store)
    live_is_this = active is not None and active["digest"] == pool_digest
    carried = store._connection.execute(
        "SELECT COUNT(*) FROM pool_generations WHERE digest = ?",
        (pool_digest,)).fetchone()[0]
    operation_id = ("pool.activate:" + pool_digest[7:] + ":"
                    + str(carried - (1 if live_is_this else 0)))
    signature = job_signature(
        "pool.activate", {"pool": pool, "resolved_principals": principals})
    if live_is_this:
        rows = list(store._connection.execute(
            "SELECT participant, canonical_principal FROM pool_workers "
            "WHERE generation = ? ORDER BY participant",
            (active["generation"],)))
        held = {row["participant"]: row["canonical_principal"] for row in rows}
        if held != principals:
            _refuse("the persisted pool generation resolves a participant to "
                    "another canonical principal; attachment refuses rather "
                    "than rewriting capacity identity")

    def perform(connection):
        # RE-READ UNDER THE LOCK, because the selection above is a pre-lock
        # observation: another manager may have activated something between
        # that read and this transaction, and the ACTIVE generation is what
        # decides whether this call is a revalidation or a new act.
        found = connection.execute(
            "SELECT * FROM pool_generations ORDER BY generation DESC LIMIT 1"
        ).fetchone()
        if found is not None and found["digest"] == pool_digest:
            generation = found["generation"]
            rows = list(connection.execute(
                "SELECT participant, canonical_principal FROM pool_workers "
                "WHERE generation = ? ORDER BY participant", (generation,)))
            held = {row["participant"]: row["canonical_principal"]
                    for row in rows}
            if held != principals:
                _refuse("the persisted pool generation resolves a participant "
                        "to another canonical principal; attachment refuses "
                        "rather than rewriting capacity identity")
            return _generation_document(found)
        generation = connection.execute(
            "SELECT COALESCE(MAX(generation), 0) + 1 FROM pool_generations"
        ).fetchone()[0]
        activated_at = store._now()
        connection.execute(
            "INSERT INTO pool_generations (generation, variant, "
            "separation_class, document, digest, activated_at) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (generation, pool["variant"], pool["separation_class"],
             canonical_text(pool), pool_digest, activated_at))
        for worker in pool["workers"]:
            connection.execute(
                "INSERT INTO pool_workers (generation, worker_id, lane, "
                "participant, canonical_principal, profile_name, "
                "profile_digest, eligible_kinds) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                (generation, worker["worker_id"], worker["lane"],
                 worker["participant"], principals[worker["participant"]],
                 worker["profile_name"], worker["profile_digest"],
                 canonical_text(worker["eligible_kinds"])))
        return {"generation": generation, "variant": pool["variant"],
                "separation_class": pool["separation_class"],
                "digest": pool_digest, "activated_at": activated_at}

    return store.transact(operation_id, "pool.activate", signature, perform)


def _generation_document(row):
    return {member: row[member] for member in
            ("generation", "variant", "separation_class", "digest",
             "activated_at")}


def allocation_rows(store, stage_id=None):
    sql = ("SELECT allocation.*, generation.variant, "
           "generation.separation_class, generation.digest AS generation_digest, "
           "worker.profile_name AS worker_profile_name, "
           "worker.profile_digest AS worker_profile_digest "
           "FROM stage_allocations allocation "
           "JOIN pool_generations generation USING (generation) "
           "JOIN pool_workers worker ON worker.generation = allocation.generation "
           "AND worker.worker_id = allocation.worker_id")
    operands = ()
    if stage_id is not None:
        sql += " WHERE allocation.stage_id = ?"
        operands = (stage_id,)
    sql += " ORDER BY allocation.reserved_at, allocation.assignment_id"
    return [dict(row) for row in store._connection.execute(sql, operands)]


def allocation_of(store, assignment_id):
    row = store._connection.execute(
        "SELECT allocation.*, generation.variant, "
        "generation.separation_class, generation.digest AS generation_digest, "
        "worker.profile_name AS worker_profile_name, "
        "worker.profile_digest AS worker_profile_digest "
        "FROM stage_allocations allocation "
        "JOIN pool_generations generation USING (generation) "
        "JOIN pool_workers worker ON worker.generation = allocation.generation "
        "AND worker.worker_id = allocation.worker_id "
        "WHERE allocation.assignment_id = ?",
        (assignment_id,)).fetchone()
    return dict(row) if row is not None else None


def allocation_refusal_of(store, assignment_id):
    row = store._connection.execute(
        "SELECT state, refusal FROM operations WHERE operation_id = ?",
        ("allocation.reserve:" + assignment_id,)).fetchone()
    return (None if row is None or row["state"] != "refused"
            else json.loads(row["refusal"]))


def lane_of(kind):
    """THE LANE THAT SERVES ONE STAGE KIND, from the table and nowhere else.

    A KIND WITH NO ENTRY IS A REFUSAL. The old expression answered
    `implementation` for everything that was not a review, so the day a
    publication stage became submittable it would have been routed to the
    workers that run implementations -- which is "never map publication to
    implementation by default", and it would have happened without one line
    of this module changing. A table refuses instead, here, where the routing
    decision is made.
    """
    lane = STAGE_LANES.get(kind)
    if lane is None:
        raise ContractRefusal(
            "integrity", "schema",
            f"this scheduler allocates {', '.join(LANES)} capacity and holds "
            f"no lane for a {name_value(kind)} stage; a stage kind with no "
            f"lane is not routed to whichever lane happens to be the default")
    return lane


def _lane(kind):
    return lane_of(kind)


def _exclusions(connection, stage, excluded):
    excluded = excluded or {}
    worker_ids = set(excluded.get("worker_ids", ()))
    participants = set(excluded.get("participants", ()))
    principals = set(excluded.get("principals", ()))
    if stage["kind"] == "review":
        # W385695 / DESIGN REC-9: EVERY PRODUCER OF THE CANDIDATE THIS REVIEW
        # IS ABOUT, and for a publication recovery that is TWO Jobs' worth.
        #
        # The reviewer must be independent of the original implementation
        # principal AND of the publication principal -- REC-9's own
        # requirement, and the contract's sentence that "a new Job must not
        # erase the original producer exclusion". The original implementation
        # ran under the FAILED Job, which is not this stage's Job at all, so
        # an exclusion scoped to `stage["job_id"]` alone would hand a recovery
        # review to the very worker whose output it is judging.
        producing = [stage["job_id"]]
        prior = _prior_producer_job(connection, stage["job_id"])
        if prior is not None:
            producing.append(prior)
        names = ", ".join("?" * len(producing))
        for row in connection.execute(
                f"SELECT allocation.* FROM stage_allocations allocation "
                f"JOIN stages producer ON producer.stage_id = allocation.stage_id "
                f"WHERE producer.job_id IN ({names}) AND producer.kind IN "
                f"('implementation', '{PUBLICATION_LANE}')",
                tuple(producing)):
            worker_ids.add(row["worker_id"])
            participants.add(row["participant"])
            principals.add(row["canonical_principal"])
    return worker_ids, participants, principals


def _prior_producer_job(connection, job_id):
    """The FAILED Job whose output a recovery Job publishes, or None.

    READ FROM THE DURABLE ADMISSION RECORD and never from a name pattern: the
    recovery Job's identity is derived from an owner decision id, and deriving
    the prior Job back out of a string would be this module inventing a
    lineage the admission already wrote down. An ordinary Job has no such
    record and answers None, which is the ordinary case.
    """
    from .publication_recovery import prior_job_in

    return prior_job_in(connection, job_id)


def reserve(store, stage, *, excluded=None):
    """Reserve one eligible worker before the offer side effect."""
    assignment_id = boundaries.identity(stage["attempt_id"],
                                        "a stage assignment id")
    existing = allocation_of(store, assignment_id)
    if existing is not None:
        if existing["allocation_state"] == "released":
            _refuse(f"stage assignment {name_value(assignment_id)} already "
                    "has a released allocation and cannot be reserved again",
                    durable=True)
        return existing
    operation_id = "allocation.reserve:" + assignment_id
    signature = job_signature(
        "allocation.reserve", {"assignment_id": assignment_id,
                               "stage_id": stage["stage_id"],
                               "episode": stage["episode"]})

    def perform(connection):
        # W383215: THE WRITE-SIDE ADMISSION FENCE. The reservation is the
        # reserve-before-offer write, so a cancelled Job refused here issues
        # no offer whatever a projection taken a moment earlier owed.
        # W383217: AND THE CONTROL GUARD, under the same lock -- a reached
        # deadline or uncertain timing admits no reservation either.
        job_control.refuse_closed(connection, stage["job_id"],
                                  f"reserving a worker for stage "
                                  f"{name_value(stage['stage_id'])}",
                                  now=store._now(),
                                  stage_id=stage["stage_id"])
        generation = connection.execute(
            "SELECT generation FROM pool_generations ORDER BY generation DESC "
            "LIMIT 1").fetchone()
        if generation is None:
            raise ContractRefusal("refused", "precondition",
                                  "no worker pool generation is active")
        generation = generation["generation"]
        lane = _lane(stage["kind"])
        workers = [dict(row) for row in connection.execute(
            "SELECT * FROM pool_workers WHERE generation = ? AND lane = ? "
            "AND profile_name = ? AND profile_digest = ? ORDER BY worker_id",
            (generation, lane, stage["profile_name"], stage["profile_digest"]))
            if stage["kind"] in json.loads(row["eligible_kinds"])]
        excluded_workers, excluded_participants, excluded_principals = \
            _exclusions(connection, stage, excluded)
        eligible = [worker for worker in workers
                    if worker["worker_id"] not in excluded_workers
                    and worker["participant"] not in excluded_participants
                    and worker["canonical_principal"] not in excluded_principals]
        if not eligible:
            raise ContractRefusal(
                "policy", "profile-uncertified",
                f"stage {name_value(stage['stage_id'])} has no eligible "
                f"{lane} worker for profile "
                f"{name_value(stage['profile_name'])}/"
                f"{name_value(stage['profile_digest'])} after hard "
                f"independence exclusions", durable=True)
        live = list(connection.execute(
            "SELECT worker_id, canonical_principal FROM stage_allocations "
            "WHERE allocation_state IN ('reserved', 'recovery-required')"))
        occupied_workers = {row["worker_id"] for row in live}
        occupied_principals = {row["canonical_principal"] for row in live}
        available = [worker for worker in eligible
                     if worker["worker_id"] not in occupied_workers
                     and worker["canonical_principal"] not in occupied_principals]
        if not available:
            raise ContractRefusal(
                "refused", "precondition",
                f"stage {name_value(stage['stage_id'])} has eligible {lane} "
                f"workers but every effective worker/principal capacity is "
                f"reserved or recovery-required")
        affinity = connection.execute(
            "SELECT worker_id FROM worker_affinity WHERE development_line = ? "
            "AND lane = ?", (stage["work_id"], lane)).fetchone()
        preferred = affinity["worker_id"] if affinity is not None else None
        selected = next((worker for worker in available
                         if worker["worker_id"] == preferred), available[0])
        outcome = ("initial" if preferred is None else
                   ("preferred" if selected["worker_id"] == preferred
                    else "fallback"))
        reserved_at = store._now()
        connection.execute(
            "INSERT INTO stage_allocations (assignment_id, stage_id, episode, "
            "generation, worker_id, lane, participant, canonical_principal, "
            "preferred_worker_id, selection_outcome, allocation_state, "
            "reserved_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'reserved', ?)",
            (assignment_id, stage["stage_id"], stage["episode"], generation,
             selected["worker_id"], lane, selected["participant"],
             selected["canonical_principal"], preferred, outcome, reserved_at))
        if affinity is None:
            connection.execute(
                "INSERT INTO worker_affinity (development_line, lane, worker_id, "
                "recorded_at) VALUES (?, ?, ?, ?)",
                (stage["work_id"], lane, selected["worker_id"], reserved_at))
        return allocation_of(store, assignment_id)

    return store.transact(operation_id, "allocation.reserve", signature,
                          perform)


def _move(store, assignment_id, state, reason):
    """One settlement act, always through the journal.

    W71877 review [P2]: this returned early whenever the allocation was
    already in the requested state or already released, BEFORE it built the
    operation signature -- so releasing twice with two different reasons
    answered the first row instead of refusing the changed operand, even
    though `reason` is part of the signature by construction.  A settled
    allocation is exactly where a replay has to be told from a second,
    different act; short-circuiting in front of the journal removed the only
    place that could tell them apart.

    Absence is still absence: there is nothing to move and nothing to record
    when no allocation exists.  Everything else goes to `JobStore.transact`,
    which replays an exact repeat and refuses a changed one.
    """
    allocation = allocation_of(store, assignment_id)
    if allocation is None:
        return None
    operation_id = f"allocation.{state}:{assignment_id}"
    signature = job_signature(
        f"allocation.{state}", {"assignment_id": assignment_id,
                                "reason": reason})

    def perform(connection):
        current = connection.execute(
            "SELECT allocation_state FROM stage_allocations "
            "WHERE assignment_id = ?", (assignment_id,)).fetchone()
        if current is None:
            return allocation_of(store, assignment_id)
        if current["allocation_state"] == "released":
            if state == "released":
                # The same terminal state this act asks for. Reaching here
                # means the journal did not hold this operation, so another
                # act released it: answer the settled row rather than
                # recording a second release of one allocation.
                return allocation_of(store, assignment_id)
            _refuse(f"allocation {name_value(assignment_id)} is released; a "
                    f"released allocation is not quarantined again, and its "
                    f"capacity is already back in circulation")
        if current["allocation_state"] == state:
            return allocation_of(store, assignment_id)
        now = store._now()
        if state == "released":
            # W161230 slice1: A REGISTERED ROOT IS NOT RELEASED UNDER ITS OWN
            # EXECUTIONS, checked INSIDE this transaction rather than in a
            # preflight somebody could race.
            #
            # THE RELEASED TRANSITION ONLY. `require_recovery` comes through
            # here too, and a root that could not be quarantined because a
            # member is still open would be worse than the defect: uncertainty
            # is exactly when capacity must stay held AND visible.
            #
            # EVERY BRANCH IS COVERED because they all funnel here -- the
            # episode ending, the cleanup shortcuts, the validated integration
            # completion and the pre-runtime failure. A validated completion of
            # the parent stage says nothing about a preparation execution still
            # admitted under its reservation. An allocation nobody registered
            # keeps its existing behaviour.
            from . import integration_capacity
            withheld = integration_capacity.releasable(connection,
                                                       assignment_id)
            if withheld is not None:
                _refuse(withheld)
            integration_capacity.mark_root_ended(connection, assignment_id)
            connection.execute(
                "UPDATE stage_allocations SET allocation_state = 'released', "
                "released_at = ?, release_reason = ? WHERE assignment_id = ?",
                (now, reason, assignment_id))
        else:
            connection.execute(
                "UPDATE stage_allocations SET allocation_state = "
                "'recovery-required', recovery_required_at = ? "
                "WHERE assignment_id = ?", (now, assignment_id))
        return allocation_of(store, assignment_id)

    return store.transact(operation_id, f"allocation.{state}", signature,
                          perform)


def release(store, assignment_id, reason):
    return _move(store, assignment_id, "released",
                 boundaries.text(reason, "an allocation release reason"))


def require_recovery(store, assignment_id):
    return _move(store, assignment_id, "recovery-required", None)


# W131187: THE RELEASE REASON A COMPLETED INTEGRATION RETURNS ITS CAPACITY
# UNDER, and it is its own word rather than one of the cleanup ones. What this
# settles is LOGICAL worker and principal capacity; it claims nothing about the
# container, the credential or the workspace, whose cleanup axis is still
# whatever it is. A reader that found `cleanup-complete` here would be told the
# resources were destroyed, and they were not.
INTEGRATION_COMPLETED = "integration-completed"


def _completed_integration(allocation, entry):
    """THIS allocation's own validated completed integration, or absence.

    W131187. `reconcile_allocations` returns capacity on an episode that ended
    in one of the release endings, or on a runtime whose cleanup axis is
    terminal. An integration attempt reaches NEITHER: an integrator's runtime
    produces no frozen worker result, so no intake receipt, so no
    `authorize_cleanup`, so its cleanup stays `pending` forever -- and the one
    configured integration worker was therefore held by the first Job that used
    it for the whole life of the deployment.

    THE EVIDENCE IS THE PROJECTION'S OWN AND NOTHING IS READ HERE. The
    integration and Authority stores are not this module's to open;
    `delegation.observation_of` has already bound this document to the stage,
    the episode, the attempt, the claimed offer and the runtime's own fixed
    assignment, and the consumer proved its references through accepted public
    readers. This adds the one binding that layer cannot make: that the
    completed account belongs to the allocation being settled.

    WHICH IS FOUR COMPARISONS AND NOT A SHAPE CHECK:

      the stage and its KIND, because only an integration stage may carry one;
      the EPISODE and the ATTEMPT, so a new episode's completion never releases
        an older allocation that happens to share its stage id;
      the PARTICIPANT this capacity was reserved under; and
      the RUNTIME IDENTITY the completion account reports it excluded, against
        the runtime this attempt actually holds.

    THE POOL GENERATION IS DELIBERATELY NOT COMPARED against the assignment's.
    They are two different numbers -- one is this store's worker pool
    generation and the other is the Authority's assignment generation -- and
    comparing them would refuse every ordinary completion for looking wrong.
    """
    stage = entry.get("stage") or {}
    if stage.get("kind") != "integration":
        return None
    # THE VALIDATED PROJECTED STATE, not the document alone. Projection puts
    # durable refusal, preparation and start failure ahead of a completed
    # integration, so a stage this pass sees as `completed` is one none of
    # those preceded.
    if entry.get("state") != "completed":
        return None
    document = (entry.get("observed") or {}).get("integration")
    if document is None or document.get("state") != "completed":
        return None
    completion = document.get("completion")
    if completion is None:
        return None
    if (document["stage_id"], document["episode"], document["attempt_id"]) != (
            allocation["stage_id"], allocation["episode"],
            allocation["assignment_id"]):
        return None
    if document["assignment"]["participant"] != allocation["participant"]:
        return None
    runtime = (entry.get("observed") or {}).get("runtime") or {}
    if runtime.get("runtime_id") != completion["runtime_id"]:
        return None
    return completion


def reconcile_allocations(store, held=None):
    """Settle scheduler capacity only from canonical episode/runtime facts."""
    from .integration_capacity import release_blocker

    moved = []
    held = held or {}
    for allocation in allocation_rows(store):
        if allocation["allocation_state"] not in LIVE_STATES:
            continue
        episode = store._connection.execute(
            "SELECT ended_state FROM episodes WHERE stage_id = ? AND episode = ?",
            (allocation["stage_id"], allocation["episode"])).fetchone()
        if episode is not None and episode["ended_state"] in RELEASE_ENDINGS:
            if release_blocker(store, allocation["assignment_id"]) is None:
                moved.append(release(store, allocation["assignment_id"],
                                    episode["ended_state"]))
                continue
        entry = held.get(allocation["stage_id"])
        if entry is None or entry.get("attempt") is None:
            continue
        observed = entry["observed"]
        runtime = observed.get("runtime") or {}
        cleanup = runtime.get("cleanup")
        pending = release_blocker(store, allocation["assignment_id"]) is not None
        if cleanup in ("complete", "retained") and not pending:
            moved.append(release(store, allocation["assignment_id"],
                                f"cleanup-{cleanup}"))
        elif _completed_integration(allocation, entry) is not None and not pending:
            # W131187: AND IT IS DECIDED BEFORE THE QUARANTINE BELOW, because
            # a validated completion is HISTORICAL COMMITTED EVIDENCE. The
            # accepted observation contract is explicit that a later
            # runtime-axis uncertainty does not revoke a completion that was
            # already proved, and this act ends an assignment that is already
            # over: quarantining its capacity afterwards would hold a worker
            # against an attempt nothing can still be running.
            #
            # ORDINARY WORKER COMPLETION IS NOT THIS. `completed` is not added
            # to `RELEASE_ENDINGS` and no other kind reaches here: an
            # implementation or review attempt still owes its intake and its
            # cleanup, and that debt is exactly what the branch above settles.
            moved.append(release(store, allocation["assignment_id"],
                                INTEGRATION_COMPLETED))
        elif cleanup == "failed" or runtime.get("execution_runtime") == "uncertain":
            moved.append(require_recovery(store, allocation["assignment_id"]))
        elif not pending and (observed.get("start_failure") is not None or \
                observed.get("preparation_failure") is not None):
            moved.append(release(store, allocation["assignment_id"],
                                "launch-failed-before-runtime"))
    return moved


class PooledManagerOperations:
    """The existing manager surface, selecting one participant per allocation."""

    canonical = True

    def __init__(self, store, workers, *, resolved_principals,
                 independence=None):
        """Attach to every worker this store still needs, and prove each one.

        `resolved_principals` IS REQUIRED AND COVERS LIVE PRIOR GENERATIONS,
        which is W71877's review [P1].  `activate_pool` revalidates the ONE
        generation whose document it is handed, and `_required_workers` then
        adds workers from older generations that still hold live allocations.
        Nothing revalidated those.  A claimed allocation from an old
        generation could therefore be launched, dispatched, concluded or
        observed after its endpoint had come to mean another principal, and
        the claim-answer comparison cannot help: that claim was taken before
        the restart.

        So attachment is where every required worker is proved, active or
        not, against the principal the deployment resolves NOW -- and it
        refuses before any stage operation rather than at the first one that
        happens to compare.
        """
        self.store = store
        if type(workers) is not dict:
            _refuse("pooled operations need worker operations keyed by "
                    "(generation, worker id)")
        # AN EMPTY MAPPING IS AN ANSWER, AND THE STORE STILL DECIDES.
        # W183883, OWNER-FRESH-INSTALL-20260916.md: an installation starts with
        # zero Jobs and no configured execution capacity, and it must serve for
        # real rather than report a fabricated success. Nothing is relaxed to
        # allow that: `_required_workers` below answers `[]` only when this
        # store has no active generation AND no live allocation, and the
        # comparison against it is what makes an empty attachment fail closed
        # the moment either exists.
        self.workers = dict(workers)
        self._independence = independence
        rows = _required_workers(store)
        configured = {(row["generation"], row["worker_id"]) for row in rows}
        if set(self.workers) != configured:
            _refuse("pooled operations must provide exactly the active "
                    "generation and live prior generations' configured "
                    "(generation, worker id) pairs")
        resolved = _principals(
            resolved_principals,
            [{"participant": row["participant"]} for row in rows])
        for row in rows:
            key = (row["generation"], row["worker_id"])
            operation = self.workers[key]
            participant = getattr(getattr(operation, "port", None),
                                  "participant", None)
            if participant != row["participant"]:
                _refuse(f"worker {name_value(row['worker_id'])} is configured "
                        f"for {name_value(row['participant'])} but its "
                        f"participant-bound operations act for "
                        f"{name_value(participant)}")
            if resolved[row["participant"]] != row["canonical_principal"]:
                _refuse(f"worker {name_value(row['worker_id'])} in generation "
                        f"{row['generation']} was reserved under canonical "
                        f"principal {name_value(row['canonical_principal'])} "
                        f"and {name_value(row['participant'])} now resolves to "
                        f"{name_value(resolved[row['participant']])}; "
                        f"attachment refuses before any stage operation "
                        f"rather than acting for another principal")

    def _any(self):
        """Any attached worker, for an answer that is not stage-specific.

        `canonical_operation` derives an operation IDENTITY from an act and an
        offer id, and `receipt_of` asks every attached store.  Neither routes
        work, so neither needs an allocation -- which is exactly the thing
        `_worker` below must not do.
        """
        if not self.workers:
            _refuse("this deployment attached no worker, so there is no "
                    "operation to answer with; an instance with no configured "
                    "execution capacity serves no stage")
        return self.workers[sorted(self.workers)[0]]

    def _offer_exists(self, stage):
        """Whether the canonical offer for this stage was already issued.

        The same question `binding_intent` already asks, at the same owner:
        the admit receipt is recorded by the Worker Manager when the offer
        commits, so its presence is canonical evidence rather than an
        inference from how a refusal was shaped.
        """
        return self.receipt_of(
            self.canonical_operation("admit", stage["offer_id"])) is not None

    def _allocation(self, stage, *, create=False):
        allocation = allocation_of(self.store, stage["attempt_id"])
        if allocation is None and create:
            excluded = (None if self._independence is None else
                        self._independence(stage))
            allocation = reserve(self.store, stage, excluded=excluded)
        return allocation

    def _reader(self, stage):
        """The worker that can ANSWER ABOUT this stage, or a refusal.

        `observe` and `refresh_runtime` are read-only and one tick asks them
        about every live stage -- including a stage that has not been admitted
        yet, which is how the manager learns that it owes an `admit` at all.
        A stage with no offer has no runtime for any worker to hold, so every
        attached store answers the same not-started document and choosing one
        decides nothing.

        THE MOMENT AN OFFER EXISTS WITHOUT AN ALLOCATION THAT STOPS BEING
        TRUE, and that is exactly the migrated in-flight stage W71877's
        review [P1] names: real work is running somewhere and answering about
        it from an arbitrary store would report another worker's silence as
        this stage's state. That refuses here, with the same words the acting
        operations use.

        A SETTLED ALLOCATION FROM A RETIRED GENERATION READS LIKE HISTORY,
        NOT LIKE A ROUTE. W202663 D7, measured on an installed instance whose
        pool had advanced: attachment deliberately requires only the active
        generation and live prior generations (`_required_workers` counts
        `reserved` and `recovery-required`), so a `released` allocation from
        generation 1 has no attached key once generation 2 is active -- and
        the unconditional lookup here raised a raw KeyError that unwound the
        whole serve loop on the first tick after restart.

        WHO ANSWERS FOR HISTORY IS THE SAME WORKER, IN ITS NEWEST ATTACHED
        GENERATION, when the pool still names it. Review209188 [R1]: observe
        and refresh are not interchangeable across workers -- the exchange
        and runtime callbacks adopt each worker's OWN launch home, role and
        manifest context -- so an arbitrary fallback could misread history
        that the same-named worker's context still reads exactly. Only when
        the worker was removed from every attached generation does this fall
        back to `_any()`, whose store-backed answer covers the runtime axis
        and nothing worker-scoped. Neither path launches, dispatches or
        concludes anything: `observe` reads, and `refresh_runtime` asks the
        engine and RECORDS what it observed -- non-launching, though not a
        pure read.

        A LIVE allocation whose key is absent is different -- attachment
        proves those pairs exist before any stage operation, so reaching one
        here is a broken invariant (or a post-attachment state move) and
        refuses by name rather than crashing.
        """
        allocation = allocation_of(self.store, stage["attempt_id"])
        if allocation is not None:
            held = self.workers.get((allocation["generation"],
                                     allocation["worker_id"]))
            if held is not None:
                return held
            if allocation["allocation_state"] in ("reserved",
                                                  "recovery-required"):
                _refuse(f"stage {name_value(stage['stage_id'])} holds a live "
                        f"allocation on worker "
                        f"{name_value(allocation['worker_id'])} in generation "
                        f"{allocation['generation']}, which this attachment "
                        f"does not hold; attachment proves exactly the active "
                        f"and live prior generations' workers, so this "
                        f"deployment cannot answer for that stage")
            same = [key for key in self.workers
                    if key[1] == allocation["worker_id"]]
            if same:
                return self.workers[max(same)]
            return self._any()
        if self._offer_exists(stage):
            _refuse(self._unallocated(stage))
        return self._any()

    def _unallocated(self, stage):
        return (f"stage {name_value(stage['stage_id'])} has no scheduler "
                f"allocation, so no pooled worker owns it. A stage admitted "
                f"before the scheduler relations existed is recovered or "
                f"stopped through the participant-bound operations that hold "
                f"its offer; this boundary will not choose an endpoint for it")

    def _worker(self, stage):
        """The one worker this stage is reserved on, or a refusal.

        W71877 review [P1]: this fell back to whichever worker sorted first
        when no allocation existed, and `launch`, `dispatch`, `conclude`,
        `observe` and `refresh_runtime` all used it.  That erased
        reserve-before-offer and the participant/generation binding at the
        one seam where they decide which endpoint acts -- and the reviewer's
        reproduction launched an unallocated attempt through that worker.

        IT IS NOT AN ACADEMIC CALLER ERROR.  The 3 -> 4 migration deliberately
        creates EMPTY scheduler relations, so a store carrying an already
        admitted or claimed schema-3 stage arrives here with no allocation at
        all.  The refusal names that case and what to do with it, because a
        migrated in-flight stage has to be stopped or recovered through the
        Worker Manager operations that own its offer -- never run through
        whichever worker this dictionary happens to sort first.
        """
        allocation = allocation_of(self.store, stage["attempt_id"])
        if allocation is None:
            _refuse(self._unallocated(stage))
        worker = self.workers.get((allocation["generation"], allocation["worker_id"]))
        if worker is None:
            _refuse(f"stage {name_value(stage['stage_id'])} names worker "
                    f"{name_value(allocation['worker_id'])} in generation "
                    f"{allocation['generation']}, which this attachment does not hold")
        return worker

    def canonical_operation(self, act, offer_id):
        return self._any().canonical_operation(act, offer_id)

    def receipt_of(self, operation_id):
        answers = [worker.receipt_of(operation_id)
                   for worker in self.workers.values()]
        answers = [answer for answer in answers if answer is not None]
        if not answers:
            return None
        first = answers[0]
        if any(answer != first for answer in answers[1:]):
            _refuse(f"worker control stores disagree about operation "
                    f"{name_value(operation_id)}")
        return first

    def recover(self, *, now):
        reports = [worker.recover(now=now)
                   for _, worker in sorted(self.workers.items())]
        abandoned = sorted({offer_id for report in reports
                            for offer_id in report["abandoned"]})
        recoverable = {}
        for report in reports:
            for offer in report["recoverable"]:
                recoverable[offer["offer_id"]] = offer
        return {"abandoned": abandoned,
                "recoverable": [recoverable[offer_id]
                                for offer_id in sorted(recoverable)]}

    def attach(self, offer_ids):
        attached = []
        for worker in self.workers.values():
            attached.extend(worker.attach(offer_ids))
        return attached

    def drain(self, handlers, *, quiescent=()):
        return sum(worker.drain(handlers, quiescent=quiescent)
                   for worker in self.workers.values())

    def binding_intent(self, stage, job):
        from . import publication_recovery
        from .delegation import stage_intent
        # W385695: A RECOVERY'S PUBLICATION STAGE IS OFFERED UNDER ITS OWN
        # INPUT IDENTITY (`publication_recovery.stage_job`), so that is the
        # intent its canonical offer is held to. Every other stage is held to
        # its Job's, exactly as before.
        intent = stage_intent(
            stage, publication_recovery.stage_job(self.store, stage, job))
        allocation = self._allocation(stage)
        if allocation is None:
            operation_id = self.canonical_operation("admit", stage["offer_id"])
            if self.receipt_of(operation_id) is not None:
                raise ContractRefusal(
                    "refused", "operation-collision",
                    f"stage {name_value(stage['stage_id'])} has a canonical "
                    "offer but no scheduler allocation; adopting it would "
                    "erase the reserve-before-offer and participant binding",
                    durable=True)
            return intent
        intent["participant"] = allocation["participant"]
        return intent

    def admit(self, stage, job):
        # W385625: A RECOVERY STAGE IS ADMITTED ONLY THROUGH ITS OWN OPEN
        # GATE. The gate exists for every Job admitted under the retained-
        # recovery profile, and what decides is whether it is OPEN -- the
        # committed candidate handoff, which re-measured the materialized
        # candidate against the bound digest and bound the reused passed
        # verification. Refusing on the gate's EXISTENCE would have made the
        # handoff unreachable once it was built; refusing on anything weaker
        # than the handoff would release a review with no proved delivery of
        # the candidate it is about. The reason travels with the refusal so an
        # operator is told which of the two it is.
        from .retained_recovery import execution_gate
        gate = execution_gate(self.store, stage["job_id"])
        if gate is not None and not gate["open"]:
            raise ContractRefusal(
                "refused", "precondition",
                f"retained recovery requires a validated candidate execution "
                f"handoff; stage {name_value(stage['stage_id'])} is held at "
                f"{name_value(gate['reason'])}")
        allocation = self._allocation(stage, create=True)
        worker = self.workers[(allocation["generation"],
                               allocation["worker_id"])]
        try:
            return worker.admit(stage, job)
        except ContractRefusal as refusal:
            if refusal.durable and not self._offer_exists(stage):
                # DURABLE IS NOT "NO OFFER EXISTS", which is W71877's review
                # [P1].  Durability says the refusal is a recorded outcome;
                # `ManagerOperations.admit` commits `issue_offer` BEFORE it
                # invokes the injected bearer delivery, so a durable delivery
                # refusal can arrive with the canonical offer already there.
                # Releasing then lets unrelated work reserve the same logical
                # worker and principal while that offer may still be accepted.
                #
                # The settlement table permits release only on evidence that
                # no assignment exists.  The canonical admit receipt is that
                # evidence read at its owner: absent, no offer was issued and
                # the reservation is safe to return; present, this is the
                # uncertain case below.
                release(self.store, stage["attempt_id"],
                        "offer-durably-refused-before-any-offer")
            elif refusal.durable:
                require_recovery(self.store, stage["attempt_id"])
            raise
        except BaseException:
            # A fault after reserve but before a canonical offer is uncertain,
            # not absence.  Keep it out of circulation until positive recovery
            # evidence decides whether another stage may use this capacity.
            require_recovery(self.store, stage["attempt_id"])
            raise

    def claim(self, stage):
        # W383215: RE-READ THE FENCE BEFORE THE CLAIM IS TAKEN. A claim is the
        # Authority's act and cannot run under this store's lock, so the
        # fence is read here, immediately before it; an admission that still
        # wins the race is found by the next tick's cancellation pass.
        job_control.refuse_closed(self.store._connection, stage["job_id"],
                                  f"claiming stage "
                                  f"{name_value(stage['stage_id'])}",
                                  now=self.store._now(),
                                  stage_id=stage["stage_id"])
        allocation = self._allocation(stage)
        if allocation is None:
            _refuse(f"stage {name_value(stage['stage_id'])} has an offer but "
                    "no scheduler allocation")
        answer = self.workers[(allocation["generation"],
                               allocation["worker_id"])].claim(stage)
        return self._claim_answer(stage, allocation, answer)

    def _claim_answer(self, stage, allocation, answer):
        if (answer or {}).get("state") in RELEASE_ENDINGS:
            return answer
        principal = ((answer or {}).get("decision") or {}).get("principal")
        if principal != allocation["canonical_principal"]:
            require_recovery(self.store, stage["attempt_id"])
            raise ContractRefusal(
                "runtime-observation", "identity-mismatch",
                f"stage {name_value(stage['stage_id'])} reserved principal "
                f"{name_value(allocation['canonical_principal'])} but the "
                f"claim returned {name_value(principal)}; the allocation "
                f"requires explicit recovery", durable=True)
        return answer

    def settle_offer(self, stage, *, now):
        # Released capacity is settled history, even when its episode remains
        # visible. Never act through a successor worker to reconcile that past.
        allocation = self._allocation(stage)
        if allocation is not None and allocation["allocation_state"] == "released":
            return None
        worker = self._worker(stage)
        settle = getattr(worker, "settle_offer", None)
        if settle is not None:
            answer = settle(stage, now=now)
            if (answer or {}).get("state") == "claimed":
                return self._claim_answer(stage, self._allocation(stage), answer)
            return answer

    def launch(self, stage, job):
        return self._worker(stage).launch(stage, job)

    def dispatch(self, stage, job):
        return self._worker(stage).dispatch(stage, job)

    def conclude(self, stage, job):
        return self._worker(stage).conclude(stage, job)

    def observe(self, stage):
        return self._reader(stage).observe(stage)

    def refresh_runtime(self, stage):
        return self._reader(stage).refresh_runtime(stage)

    def close(self):
        closed = set()
        for worker in self.workers.values():
            if id(worker) in closed:
                continue
            closed.add(id(worker))
            close = getattr(worker, "close", None)
            if close is not None:
                close()
