"""W333486 -- the read-only diagnostic report, and what it refuses to do.

A PURE PROJECTION over one status document: no store, no clock, no engine, no
provider, no subprocess. These cases drive the real module and prove the
allowlist, the per-fact provenance, the bounded unknown reasons, the
incomplete-final-result verdict, the safe-locator emission, and that
`tools/stack_command.COMMANDS` both SERVES and DISPATCHES the subcommand in
source -- with the rebuilt-bundle obligation stated rather than assumed away.

BOUNDED SLICE, stated: the locator ROUND TRIP against a real retained
delivery is not driven here. What is proved is that the report emits the
supported invocation shape, names the one operand only an operator can
supply, and resolves no delivery root itself.
"""

import io
import json
import unittest

from tools import attempt_diagnostics, stack_command

SECRET = "canary-" + "z" * 32


def document(**stage):
    held = {"stage_id": "stage-1", "job_id": "job-1", "kind": "implementation",
            "state": "running", "attempt_id": "attempt-1"}
    diagnostic = stage.get("attempt_diagnostics")
    if isinstance(diagnostic, dict):
        diagnostic = dict(diagnostic, schema=attempt_diagnostics.SOURCE_DIAGNOSTIC_SCHEMA, attempt_id="attempt-1")
        for axis in ("cause", "workspace_object", "worker_declaration"):
            if isinstance(diagnostic.get(axis), dict):
                diagnostic[axis] = {key: {"known": True, "value": value, "source": "fixture"} for key, value in diagnostic[axis].items()}
        stage["attempt_diagnostics"] = diagnostic
    held.update(stage)
    return {"schema": "baton.v12.job-status/9",
            "jobs": [{"job_id": "job-1", "stages": [held]}]}


class TheReportIsAPureProjection(unittest.TestCase):

    def test_preparation_reason_survives_the_report_allowlist(self):
        diagnostic = {"preparation_failure_message": {
            "known": True, "value": "the input root is partial",
            "source": "attempts.attempt_preparation_failure_of.failure.message"}}
        row = attempt_diagnostics.report(json.dumps(document(
            attempt_diagnostics=diagnostic)).encode())["rows"][0]
        self.assertEqual(row["axes"]["preparation_failure_message"]["value"],
                         "the input root is partial")
        self.assertFalse(row["completeness"]["proves_cessation"])

    def test_it_reads_one_document_and_opens_NOTHING(self):
        held = attempt_diagnostics.report(json.dumps(document()).encode())
        self.assertEqual(held["schema"], attempt_diagnostics.SCHEMA)
        self.assertIs(held["opens_no_store"], True)
        self.assertEqual(len(held["rows"]), 1)

    def test_it_states_NO_FRESHNESS_VERDICT_because_none_was_selected(self):
        held = attempt_diagnostics.report(json.dumps(document()).encode())
        self.assertIsNone(held["freshness_verdict"])
        self.assertIn("no freshness policy", held["freshness_why"])

    def test_a_DIAGNOSTIC_CAUSE_IS_NOT_AN_ACCEPTANCE(self):
        held = attempt_diagnostics.report(json.dumps(document(
            attempt_diagnostics={"cause": {
                "component": "expiry-reclaim", "operation_id": "op-1",
                "correlation_id": "c-1", "outcome": "ceased-absent",
                "cessation": "absent", "runtime_id": "container-1",
                "category": None, "code": None}})).encode())
        row = held["rows"][0]
        self.assertIs(held["is_acceptance"], False)
        self.assertIs(row["completeness"]["is_acceptance"], False)
        self.assertIs(row["completeness"]["proves_cessation"], False)
        self.assertEqual(row["completeness"]["state"], "incomplete")
        self.assertEqual(row["cause"]["cessation"]["value"], "absent")

    def test_an_ABSENT_diagnostic_means_NOBODY_LOOKED(self):
        row = attempt_diagnostics.report(
            json.dumps(document()).encode())["rows"][0]
        self.assertIsNone(row["cause"])
        self.assertEqual(row["completeness"]["state"], "absent")
        self.assertIn("nobody looked", row["completeness"]["why"])

    def test_an_INCOMPLETE_final_result_is_INCOMPLETE_and_nothing_more(self):
        # The facts are partial the way a deadline-bounded publication
        # failure leaves them. That is neither a cessation nor an acceptance,
        # and WHY it is partial is unknown.
        row = attempt_diagnostics.report(json.dumps(document(
            attempt_diagnostics={"cause": {"component": "cancellation",
                                           "operation_id": "op-1"}}
        )).encode())["rows"][0]
        self.assertEqual(row["completeness"]["state"], "incomplete")
        self.assertIn("outcome", row["completeness"]["missing"])
        self.assertIs(row["completeness"]["proves_cessation"], False)
        self.assertIn("unknown", row["completeness"]["why"])

    def test_EVERY_member_is_known_with_a_source_or_unknown_with_a_reason(self):
        row = attempt_diagnostics.report(
            json.dumps(document()).encode())["rows"][0]
        for member in row["stage"].values():
            if member["known"]:
                self.assertTrue(member["source"])
            else:
                self.assertTrue(member["why"])
                self.assertIsNone(member["value"])

    def test_the_ALLOWLIST_IS_POSITIVE_and_an_unknown_member_is_NAMED_only(self):
        row = attempt_diagnostics.report(json.dumps(document(
            attempt_diagnostics={"cause": {
                "component": "expiry-reclaim", "operation_id": "op-1",
                "correlation_id": "c-1", "outcome": "ceased-absent",
                "cessation": "absent", "runtime_id": "container-1",
                "category": None, "code": None,
                "private_transcript": SECRET}})).encode())
        self.assertEqual(row["rows"][0]["unrecognised"], ("undeclared members omitted",))
        self.assertNotIn(SECRET, json.dumps(row, default=list))

    def test_a_NESTED_OBJECT_is_NOT_forwarded_wholesale(self):
        row = attempt_diagnostics.report(json.dumps(document(
            attempt_diagnostics={"cause": {
                "component": {"leaked": SECRET}, "operation_id": "op-1",
                "correlation_id": "c-1", "outcome": "ceased-absent",
                "cessation": "absent", "runtime_id": None,
                "category": None, "code": None}})).encode())
        self.assertNotIn(SECRET, json.dumps(row, default=list))
        self.assertFalse(row["rows"][0]["cause"]["component"]["known"])

    def test_DEVICE_AND_INODE_travel_labelled_and_are_NOT_a_locator(self):
        row = attempt_diagnostics.report(json.dumps(document(
            attempt_diagnostics={"workspace_object": {"device": 7,
                                                      "inode": 9}}
        )).encode())["rows"][0]
        workspace = row["locators"]["workspace_object"]
        self.assertEqual(workspace["device"]["value"], 7)
        self.assertIs(workspace["is_a_path"], False)
        self.assertIs(workspace["is_a_locator"], False)

    def test_the_SUPPORTED_READ_names_the_one_operand_it_cannot_supply(self):
        row = attempt_diagnostics.report(
            json.dumps(document()).encode())["rows"][0]
        supported = row["locators"]["supported_read"]
        self.assertIn("baton-v12-stack logs", supported["command"])
        self.assertEqual(supported["operator_must_supply"], "<launch-home>")
        self.assertIn("deployment fact", supported["why"])

    def test_it_carries_the_MANAGERS_OWN_recorded_artifacts_by_name(self):
        row = attempt_diagnostics.report(json.dumps(document(
            artifacts=[{"name": "result/answer.txt"}])).encode())["rows"][0]
        self.assertEqual(tuple(row["locators"]["recorded_artifacts"]["value"]),
                         ("result/answer.txt",))


class TheCommandTableServesAndDispatchesIt(unittest.TestCase):

    def test_COMMANDS_carries_the_subcommand_in_SOURCE(self):
        self.assertIn("attempt-diagnostics", stack_command.COMMANDS)

    def test_the_entry_DISPATCHES_to_this_module(self):
        called = []
        original = attempt_diagnostics.main
        attempt_diagnostics.main = lambda operands: called.append(operands) or 0
        try:
            answer = stack_command.COMMANDS["attempt-diagnostics"](["a.json"])
        finally:
            attempt_diagnostics.main = original
        self.assertEqual(answer, 0)
        self.assertEqual(called, [["a.json"]])

    def test_the_REBUILT_BUNDLE_obligation_is_stated_in_the_artifact(self):
        held = attempt_diagnostics.report(json.dumps(document()).encode())
        self.assertIn("rebuilt", held["deployment_obligation"])
        self.assertIn("stack_command.COMMANDS",
                      held["deployment_obligation"])
        self.assertIn("rebuilt bundle",
                      (attempt_diagnostics.__doc__ or "").lower())

    def test_the_COMMAND_refuses_an_operand_set_it_does_not_serve(self):
        stream = io.StringIO()
        import contextlib
        stack = contextlib.redirect_stderr(io.StringIO())
        stack.__enter__()
        self.addCleanup(stack.__exit__, None, None, None)
        self.assertEqual(attempt_diagnostics.main([], stream=stream), 2)
        self.assertEqual(attempt_diagnostics.main(["a", "b"], stream=stream), 2)


from unittest.mock import patch
from baton_v12.contracts import ContractRefusal
from baton_v12.job_manager import status, submit
from baton_v12.job_manager import delegation, documents, execution_limits
from baton_v12.worker_manager import accept_offer, record_attempt, failure_cause
from tests.job_manager.fixtures import (JobManagerCase, NOW, UUID, WORK_A, PROFILE,
                                        FakeOperations, job, submission)


class RealStatusReportSeam(JobManagerCase):
    def setUp(self):
        super().setUp()
        self.jobs = self.store()
        self.control_store = self.control()
        submit(self.jobs, submission(jobs=[job("job-a")]))
        self.stage = self.attempting(self.jobs)
        self.acts = self.operations(control=self.control_store)
        self.job = {"input_digest": "sha256:" + "1" * 64, "policy_digest": "sha256:" + "2" * 64}
        self.acts.admit(self.stage, self.job)
        accept_offer(self.control_store, self.acts.port, offer_id=self.stage["offer_id"],
                     decision="accept", bearer=self.delivered[-1]["bearer"], now=NOW,
                     runtime_attempt_id=self.stage["attempt_id"],
                     work_ref={"authority_uuid": UUID, "work_id": WORK_A})
        self.acts.claim(self.stage)
        record_attempt(self.control_store, attempt_id=self.stage["attempt_id"],
                       adapter_name="acp", adapter_digest="sha256:" + "a" * 64,
                       profile_digest=PROFILE, policy_digest="sha256:" + "2" * 64)

    def snapshot(self, operations=None):
        return status(self.jobs, operations or self.acts, observed_at=NOW)

    def row(self, snapshot=None):
        return attempt_diagnostics.report(json.dumps(snapshot or self.snapshot()).encode())["rows"][0]

    def outcome(self, outcome="ceased-absent", **extra):
        return failure_cause.record_and_raise_cessation_outcome(
            self.control_store, self.stage["attempt_id"], component="expiry-reclaim",
            generation=None, runtime_id="container-1", correlation_id="resource.reclaim:abc",
            effects=("revoke", "stop", "remove"), outcome=outcome, **extra)

    def test_real_durable_expiry_reaches_status_and_report_unchanged(self):
        self.outcome()
        before = (self.jobs._connection.total_changes, self.control_store._connection.total_changes,
                  list(self.session.calls))
        snapshot = self.snapshot()
        row = self.row(snapshot)
        cause = snapshot["jobs"][0]["stages"][0]["attempt_diagnostics"]["cause"]
        for name in ("component", "operation_id", "correlation_id", "runtime_id", "outcome", "cessation", "effects"):
            self.assertEqual(row["cause"][name]["value"], failure_cause.decode(cause[name])[1])
            self.assertTrue(row["cause"][name]["known"])
        self.assertEqual(row["stage"]["episode"]["value"], 1)
        self.assertEqual(row["axes"]["renewal_limit"]["value"], failure_cause.tokens.RENEWAL_LIMIT)
        self.assertEqual(before, (self.jobs._connection.total_changes, self.control_store._connection.total_changes,
                                  list(self.session.calls)))
        self.assertFalse(row["completeness"]["is_acceptance"])

    def test_typed_engine_failure_is_known_while_cessation_remains_unknown(self):
        self.outcome("engine-timeout", category="runtime-observation", code="engine-timeout")
        row = self.row()
        self.assertEqual(row["cause"]["outcome"]["value"], "engine-timeout")
        self.assertEqual(row["cause"]["cessation"]["value"], "unknown")
        self.assertEqual(row["cause"]["code"]["value"], "engine-timeout")

    def test_historical_unknown_is_not_an_empty_success(self):
        row = self.row()
        self.assertIsNone(row["cause"])
        self.assertIn("no durable cause", row["unknown_why"])
        self.assertIn("attempt.cessation-*:expiry-reclaim", row["absent_records"])
        self.assertEqual(row["completeness"]["state"], "incomplete")

    def test_unreadable_diagnostic_does_not_erase_independent_status(self):
        expected = self.snapshot()["jobs"][0]["stages"][0]["state"]
        for error in (PermissionError(SECRET), ValueError(SECRET), ContractRefusal("integrity", "schema", SECRET)):
            with self.subTest(error=type(error).__name__), patch.object(delegation, "attempt_failure_cause_of", side_effect=error):
                snapshot = self.snapshot()
                self.assertEqual(snapshot["jobs"][0]["stages"][0]["state"], expected)
                row = self.row(snapshot)
                self.assertEqual(row["completeness"]["state"], "unavailable")
                self.assertNotIn(SECRET, json.dumps(snapshot))
                self.assertNotIn(SECRET, json.dumps(row))

    def test_other_episode_and_runtime_evidence_cannot_be_reported_as_current(self):
        self.outcome()
        snapshot = self.snapshot()
        stage = snapshot["jobs"][0]["stages"][0]
        diagnostic = stage["attempt_diagnostics"]
        diagnostic["attempt_id"] = "other-episode-attempt"
        self.assertEqual(self.row(snapshot)["completeness"]["state"], "unavailable")
        diagnostic["attempt_id"] = stage["attempt_id"]
        diagnostic["execution"]["runtime_id"] = {"known": True, "value": "other-runtime", "source": "attempts"}
        self.assertEqual(self.row(snapshot)["completeness"]["state"], "unavailable")

    def test_stale_snapshot_preserves_recorded_time_without_inventing_freshness(self):
        snapshot = self.snapshot()
        diagnostic = snapshot["jobs"][0]["stages"][0]["attempt_diagnostics"]
        diagnostic["execution"]["observed_at"] = {"known": True, "value": NOW, "source": "attempts"}
        result = attempt_diagnostics.report(json.dumps(snapshot).encode())
        self.assertEqual(result["rows"][0]["execution"]["observed_at"]["value"], NOW)
        self.assertIsNone(result["freshness_verdict"])

    def test_returned_and_exception_carriers_are_reported_without_private_text(self):
        for raises in (False, True):
            with self.subTest(raises=raises):
                original = ContractRefusal("runtime-observation", "identity-mismatch", SECRET)
                setattr(original, failure_cause.DEGRADATION_MEMBER, SECRET)
                def call(stage, job):
                    if raises:
                        raise original
                    return {failure_cause.DEGRADATION_MEMBER: SECRET}
                acts = self.operations(control=self.control_store, conclude_attempt=call)
                if raises:
                    with self.assertRaises(ContractRefusal) as caught:
                        acts.conclude(self.stage, self.job)
                    self.assertIs(caught.exception, original)
                else:
                    acts.conclude(self.stage, self.job)
                snapshot = self.snapshot(acts)
                row = self.row(snapshot)
                self.assertEqual(row["diagnostic_degradation"]["value"], True)
                self.assertIn("process-local", row["diagnostic_degradation"]["source"])
                self.assertNotIn(SECRET, json.dumps(snapshot))
                self.assertNotIn(SECRET, json.dumps(row))
                # A cold reader has no carrier evidence; it cannot assert success.
                self.assertFalse(self.row()["diagnostic_degradation"]["known"])

    def test_private_keys_provenance_and_unknown_reasons_are_not_forwarded(self):
        self.outcome()
        snapshot = self.snapshot()
        diagnostic = snapshot["jobs"][0]["stages"][0]["attempt_diagnostics"]
        diagnostic["cause"][SECRET] = SECRET
        diagnostic["cause"]["category"] = {"known": False, "value": None, "why": SECRET}
        diagnostic["cause"]["component"]["source"] = SECRET
        diagnostic["unknown"] = {"why": SECRET}
        diagnostic["absent_records"] = [SECRET]
        self.assertNotIn(SECRET, json.dumps(self.row(snapshot)))

    def test_EVERY_absent_record_the_PRODUCER_composes_reaches_the_report(self):
        """W333486 claim353758: the report's names held against the producer's.

        THE DEFECT THIS CATCHES, measured through this very seam: the reader
        allowlisted `attempt.start-failed`, `attempt.preparation-failed` and a
        bare `resource.revoked`, while `failure_cause` emits
        `runtime.start-failed`, `runtime.preparation-failed` and
        `resource-token.revoked` (bare OR suffixed with its domain and
        generation). THREE OF THE FIVE names a real composed expiry carried
        were dropped SILENTLY, which is the failure mode
        `failure_cause._compose` warns about in terms: a reader that discards a
        record quietly hides that the producer moved.

        The expectation is not a list typed here. It is `absent_of` over the
        SAME document the report read, so a producer rename fails this case
        instead of emptying the report.
        """
        self.outcome()
        snapshot = self.snapshot()
        diagnostic = snapshot["jobs"][0]["stages"][0]["attempt_diagnostics"]
        produced = failure_cause.absent_of(diagnostic)
        self.assertTrue(produced, "this composition must name absent records")
        row = self.row(snapshot)
        self.assertEqual(tuple(row["absent_records"] or ()), tuple(produced))

    def test_an_absent_record_the_report_does_NOT_own_is_still_dropped(self):
        """The allowlist stays POSITIVE: recognition widened, not removed."""
        snapshot = self.snapshot()
        self.outcome()
        snapshot = self.snapshot()
        diagnostic = snapshot["jobs"][0]["stages"][0]["attempt_diagnostics"]
        diagnostic["absent_records"] = list(diagnostic["absent_records"]) + [
            SECRET, "resource-token.revokedNOTASEPARATOR", "attempt.start-failed"]
        row = self.row(snapshot)
        reported = tuple(row["absent_records"] or ())
        self.assertNotIn(SECRET, json.dumps(row))
        self.assertNotIn("resource-token.revokedNOTASEPARATOR", reported)
        # The producer's OLD spelling is not owned by this build either.
        self.assertNotIn("attempt.start-failed", reported)

    def test_the_REAL_composition_carries_the_declaration_axis_end_to_end(self):
        """W385424: producer -> ordinary status -> report, with no fixture.

        This attempt froze nothing, so every declared member is honestly
        unknown -- which is the point: the axis reaches the report through
        the real seam, and an absence travels as an absence rather than as
        nothing at all.
        """
        before = (self.jobs._connection.total_changes,
                  self.control_store._connection.total_changes)
        snapshot = self.snapshot()
        published = snapshot["jobs"][0]["stages"][0]["attempt_diagnostics"]
        declared = published["worker_declaration"]
        self.assertEqual(sorted(declared),
                         sorted(failure_cause.WORKER_DECLARATION_MEMBERS))
        row = self.row(snapshot)
        for name, _kinds in attempt_diagnostics.WORKER_DECLARATION_MEMBERS:
            self.assertFalse(row["worker_declaration"][name]["known"], name)
            self.assertTrue(row["worker_declaration"][name]["why"], name)
        # AND NOTHING WAS WRITTEN TO EITHER STORE BY LOOKING.
        self.assertEqual(before, (self.jobs._connection.total_changes,
                                  self.control_store._connection.total_changes))

    def test_owned_source_schema_does_not_drift(self):
        self.assertEqual(attempt_diagnostics.SOURCE_DIAGNOSTIC_SCHEMA, failure_cause.DIAGNOSTIC_SCHEMA)

    def test_cli_missing_denied_and_malformed_input_never_creates_a_store(self):
        import contextlib
        from pathlib import Path
        missing = Path(self.root) / "never-created.sqlite3"
        with contextlib.redirect_stderr(io.StringIO()):
            self.assertEqual(attempt_diagnostics.main([str(missing)], stream=io.StringIO()), 2)
            self.assertFalse(missing.exists())
            with patch("builtins.open", side_effect=PermissionError(SECRET)):
                self.assertEqual(attempt_diagnostics.main([str(missing)], stream=io.StringIO()), 2)
            missing.write_text(SECRET)
            before = missing.read_bytes()
            self.assertEqual(attempt_diagnostics.main([str(missing)], stream=io.StringIO()), 2)
            self.assertEqual(missing.read_bytes(), before)


if __name__ == "__main__":
    unittest.main()


class JobFactsAndObservationTimeReachTheReport(JobManagerCase):
    """W333486 review-2026-10-22T18-18-00Z.md: the report's own completeness.

    `rows_of` used to discard the Job when it built a row, so a report about a
    failed attempt could not say which provider or verification ceiling that
    attempt ran under; `report` discarded `observed_at`, so it could not say
    how old the snapshot was. The token axis is a DIFFERENT MECHANISM and was
    never a substitute. These cases drive the real production composer, so the
    limits are the ones a Job actually carries rather than a shape typed here.
    """

    def setUp(self):
        super().setUp()
        self.jobs = self.store()

    def composed(self, *, selected=None, other=None):
        """TWO REAL JOBS with DIFFERENT limits, through the real submission."""
        first = job("job-a")
        if selected is not None:
            first["execution_limits"] = dict(selected)
        second = job("job-b")
        if other is not None:
            second["execution_limits"] = dict(other)
        submit(self.jobs, {"schema": documents.SUBMISSION_SCHEMA,
                           "submission_id": "sub-limits",
                           "jobs": [first, second]})
        return status(self.jobs, FakeOperations(), observed_at=NOW)

    def rows(self, document):
        held = attempt_diagnostics.report(json.dumps(document).encode())
        return {one["stage"]["stage_id"]["value"]: one for one in held["rows"]}, held

    def test_each_row_carries_ITS_OWN_JOBS_limits_and_never_a_SIBLINGS(self):
        """The defect this closes: one Job selected, the other defaulted."""
        document = self.composed(selected={"provider_turn_seconds": 120,
                                           "verification_command_seconds": 45})
        rows, _held = self.rows(document)
        mine = rows["job-a/implementation"]["execution_limits"]
        theirs = rows["job-b/implementation"]["execution_limits"]

        # JOB A ASKED, so `requested` is KNOWN and the effective value is it.
        self.assertEqual(mine["requested"]["provider_turn_seconds"]["value"], 120)
        self.assertEqual(mine["requested"]["verification_command_seconds"]["value"], 45)
        self.assertEqual(mine["boundaries"]["provider_turn"]["seconds"]["value"], 120)
        self.assertEqual(mine["boundaries"]["ordinary_verification"]["seconds"]["value"], 45)
        self.assertEqual(mine["boundaries"]["provider_turn"]["origin"]["value"],
                         execution_limits.JOB)

        # JOB B ASKED NOTHING, so `requested` is an HONEST UNKNOWN and the
        # effective value is the runner default with a compatibility origin.
        self.assertFalse(theirs["requested"]["provider_turn_seconds"]["known"])
        self.assertEqual(theirs["boundaries"]["provider_turn"]["seconds"]["value"],
                         execution_limits.boundary_default("provider_turn"))
        self.assertEqual(theirs["boundaries"]["provider_turn"]["origin"]["value"],
                         execution_limits.COMPATIBILITY)

        # AND THE TWO ARE NOT THE SAME, which is the sibling-association bug.
        self.assertNotEqual(mine["boundaries"]["provider_turn"]["seconds"]["value"],
                            theirs["boundaries"]["provider_turn"]["seconds"]["value"])

        # A DEFAULT IS NOT A REQUEST. Job A asked for 120 and its default is
        # still the runner's, reported beside it rather than overwritten.
        self.assertEqual(mine["boundaries"]["provider_turn"]["default_seconds"]["value"],
                         execution_limits.boundary_default("provider_turn"))

    def test_the_units_the_scope_and_the_generation_travel(self):
        document = self.composed(selected={"provider_turn_seconds": 120})
        rows, _held = self.rows(document)
        envelope = rows["job-a/implementation"]["execution_limits"]["envelope"]
        self.assertEqual(envelope["units"]["value"], execution_limits.UNITS)
        self.assertEqual(envelope["scope"]["value"], execution_limits.SCOPE)
        self.assertEqual(envelope["compatibility_generation"]["value"],
                         execution_limits.CURRENT_GENERATION)

    def test_EVERY_owned_boundary_is_reported_for_every_row(self):
        document = self.composed()
        rows, _held = self.rows(document)
        for stage_id, row in rows.items():
            with self.subTest(stage=stage_id):
                self.assertEqual(sorted(row["execution_limits"]["boundaries"]),
                                 sorted(execution_limits.BOUNDARIES))
                for name, member in row["execution_limits"]["boundaries"].items():
                    self.assertEqual(
                        member["setting"]["value"],
                        execution_limits.BOUNDARIES[name])

    def test_the_SNAPSHOT_time_is_reported_and_is_NOT_the_other_two_instants(self):
        document = self.composed()
        _rows, held = self.rows(document)
        self.assertEqual(held["source_observed_at"]["observed_at"]["value"], NOW)
        # AND NOTHING IS CONCLUDED FROM IT.
        self.assertIsNone(held["freshness_verdict"])
        self.assertIn("NO instant of its own", held["source_time_why"])
        self.assertNotIn("a cause's `at`", held["source_time_why"])

    def test_an_OLD_snapshot_reports_its_own_time_UNJUDGED(self):
        document = self.composed()
        document["observed_at"] = "2019-01-01T00:00:00.000Z"
        _rows, held = self.rows(document)
        self.assertEqual(held["source_observed_at"]["observed_at"]["value"],
                         "2019-01-01T00:00:00.000Z")
        self.assertIsNone(held["freshness_verdict"])

    def test_an_ABSENT_or_MALFORMED_time_stays_HONEST(self):
        for value, why in ((None, "does not carry"), ({"a": 1}, "is a dict"),
                           ([1], "is a list")):
            with self.subTest(value=value):
                document = self.composed()
                if value is None:
                    document.pop("observed_at", None)
                else:
                    document["observed_at"] = value
                _rows, held = self.rows(document)
                fact = held["source_observed_at"]["observed_at"]
                self.assertFalse(fact["known"])
                self.assertIsNone(fact["value"])
                self.assertIn(why, fact["why"])

    def test_ABSENT_or_MALFORMED_limits_stay_HONEST_and_invent_no_default(self):
        for mutate, why in (
                (lambda one: one.pop("execution_limits", None), "carries no execution limits"),
                (lambda one: one.update(execution_limits="not-an-object"), "carries no execution limits"),
                (lambda one: one.update(execution_limits={"boundaries": "nope"}), None)):
            with self.subTest(why=why):
                document = self.composed()
                mutate(document["jobs"][0])
                rows, _held = self.rows(document)
                held = rows["job-a/implementation"]["execution_limits"]
                fact = held["boundaries"]["provider_turn"]["seconds"]
                self.assertFalse(fact["known"], held)
                self.assertIsNone(fact["value"], held)
                if why is not None:
                    self.assertIn(why, held["why"])

    def test_a_MALFORMED_boundary_member_is_unknown_and_not_coerced(self):
        document = self.composed()
        document["jobs"][0]["execution_limits"]["boundaries"]["provider_turn"]["seconds"] = "3600"
        rows, _held = self.rows(document)
        fact = rows["job-a/implementation"]["execution_limits"]["boundaries"]["provider_turn"]["seconds"]
        self.assertFalse(fact["known"])
        self.assertIn("is a str", fact["why"])

    def test_an_UNOWNED_boundary_or_member_is_NAMED_and_never_forwarded(self):
        document = self.composed()
        limits = document["jobs"][0]["execution_limits"]
        limits["boundaries"][SECRET] = {"seconds": 1, "origin": SECRET}
        limits[SECRET] = SECRET
        rows, held = self.rows(document)
        row = rows["job-a/implementation"]["execution_limits"]
        self.assertTrue(row["unrecognised"])
        self.assertNotIn(SECRET, json.dumps(held))

    def test_a_SECRET_nested_anywhere_in_the_limits_does_not_travel(self):
        """NOT ONE CANARY, ANYWHERE -- including in an owned field's VALUE.

        W333486 review-2026-10-22T18-28-00Z.md: an earlier revision of THIS
        CASE asserted the canary travelled exactly once and called that the
        positive allowlist working, because `origin` is an owned string
        member. That was wrong and the reviewer caught it: an owned field NAME
        does not make every string in it an owned VALUE, and a test that
        blesses one leak is worse than the leak. `origin`, `setting`, `units`,
        `scope` and the generation are CLOSED vocabularies now, so a value
        their owner never writes is a bounded unknown that does not echo.
        """
        document = self.composed(selected={"provider_turn_seconds": 120})
        limits = document["jobs"][0]["execution_limits"]
        limits["boundaries"]["provider_turn"]["origin"] = SECRET
        limits["boundaries"]["provider_turn"]["setting"] = SECRET
        limits["boundaries"]["provider_turn"]["nested"] = {"deep": SECRET}
        limits["requested"][SECRET] = SECRET
        limits["units"] = SECRET
        limits["scope"] = SECRET
        limits["compatibility_generation"] = 99
        _rows, held = self.rows(document)
        self.assertNotIn("deep", json.dumps(held))
        self.assertNotIn(SECRET, json.dumps(held))

    def test_an_UNOWNED_closed_value_is_UNKNOWN_and_is_never_echoed(self):
        """Every newly projected closed member, one at a time."""
        cases = (("units", SECRET, lambda one: one["envelope"]["units"]),
                 ("scope", SECRET, lambda one: one["envelope"]["scope"]),
                 ("compatibility_generation", 99,
                  lambda one: one["envelope"]["compatibility_generation"]),
                 ("origin", SECRET,
                  lambda one: one["boundaries"]["provider_turn"]["origin"]),
                 ("setting", SECRET,
                  lambda one: one["boundaries"]["provider_turn"]["setting"]))
        for name, value, pick in cases:
            with self.subTest(member=name):
                document = self.composed()
                limits = document["jobs"][0]["execution_limits"]
                if name in ("origin", "setting"):
                    limits["boundaries"]["provider_turn"][name] = value
                else:
                    limits[name] = value
                rows, held = self.rows(document)
                fact = pick(rows["job-a/implementation"]["execution_limits"])
                self.assertFalse(fact["known"], fact)
                self.assertIsNone(fact["value"], fact)
                self.assertIn("does not own", fact["why"])
                self.assertNotIn(str(value), fact["why"])
                self.assertNotIn(str(value), json.dumps(held))

    def test_BOTH_owned_origins_are_reported_as_known_provenance(self):
        """`job` and `compatibility` are the two the producer writes."""
        document = self.composed(selected={"provider_turn_seconds": 120})
        rows, _held = self.rows(document)
        mine = rows["job-a/implementation"]["execution_limits"]
        theirs = rows["job-b/implementation"]["execution_limits"]
        self.assertEqual(mine["boundaries"]["provider_turn"]["origin"]["value"],
                         execution_limits.JOB)
        self.assertEqual(theirs["boundaries"]["provider_turn"]["origin"]["value"],
                         execution_limits.COMPATIBILITY)
        for row in (mine, theirs):
            for name, member in row["boundaries"].items():
                with self.subTest(boundary=name):
                    self.assertTrue(member["origin"]["known"])
                    self.assertIn(member["origin"]["value"],
                                  attempt_diagnostics.SOURCE_LIMIT_ORIGINS)

    def test_an_UNOWNED_value_does_not_cost_the_VALID_facts_beside_it(self):
        """A bad origin must not take the numbers or the sibling Job with it."""
        document = self.composed(selected={"provider_turn_seconds": 120})
        document["jobs"][0]["execution_limits"]["boundaries"]["provider_turn"]["origin"] = SECRET
        rows, held = self.rows(document)
        mine = rows["job-a/implementation"]["execution_limits"]
        self.assertEqual(mine["boundaries"]["provider_turn"]["seconds"]["value"], 120)
        self.assertEqual(mine["requested"]["provider_turn_seconds"]["value"], 120)
        self.assertEqual(mine["envelope"]["units"]["value"],
                         execution_limits.UNITS)
        theirs = rows["job-b/implementation"]["execution_limits"]
        self.assertTrue(theirs["boundaries"]["provider_turn"]["origin"]["known"])
        self.assertEqual(held["source_observed_at"]["observed_at"]["value"], NOW)

    def test_the_report_still_OPENS_NOTHING_and_accepts_nothing(self):
        document = self.composed()
        before = self.jobs._connection.total_changes
        _rows, held = self.rows(document)
        self.assertIs(held["opens_no_store"], True)
        self.assertIs(held["is_acceptance"], False)
        self.assertEqual(self.jobs._connection.total_changes, before)

    def test_owned_execution_limit_vocabulary_does_not_drift(self):
        self.assertEqual(sorted(attempt_diagnostics.SOURCE_LIMIT_BOUNDARIES),
                         sorted(execution_limits.BOUNDARIES))
        self.assertEqual(sorted(attempt_diagnostics.SOURCE_LIMIT_SETTINGS),
                         sorted(execution_limits.LIMIT_MEMBERS))
        self.assertEqual(attempt_diagnostics.SOURCE_LIMIT_UNITS,
                         execution_limits.UNITS)
        self.assertEqual(attempt_diagnostics.SOURCE_LIMIT_SCOPE,
                         execution_limits.SCOPE)
        # AND THE CLOSED VALUES, not only the closed names.
        self.assertEqual(sorted(attempt_diagnostics.SOURCE_LIMIT_ORIGINS),
                         sorted((execution_limits.JOB,
                                 execution_limits.COMPATIBILITY)))
        self.assertEqual(sorted(attempt_diagnostics.SOURCE_LIMIT_GENERATIONS),
                         sorted(execution_limits.GENERATIONS))


class TheWorkerDeclaredEndingIsItsOwnAxis(unittest.TestCase):
    """W385424 -- what the worker said, reported BESIDE the cause.

    The defect these cases are about is a reporting one: the manager held a
    sealed `unable` result naming a provider timeout and a verification that
    was never attempted, and this report could not say any of it. What is
    added is an axis, not a cause -- so every case below also holds the line
    the axis must not cross.
    """

    TIMEOUT = {"disposition": "unable", "result_id": "result-1",
               "frozen_at": "2026-11-20T16:23:27.149Z",
               "declared_ending": "provider-failed",
               "failure_reason": "timeout", "seconds_bound": 3600,
               "seconds_bound_source": "job-default",
               "verification_attempted": False}

    def row(self, declaration):
        return attempt_diagnostics.report(json.dumps(document(
            attempt_diagnostics={"worker_declaration": declaration}
        )).encode())["rows"][0]

    def test_a_PROVIDER_TIMEOUT_reaches_the_report_with_its_bound(self):
        held = self.row(self.TIMEOUT)["worker_declaration"]
        self.assertEqual(held["disposition"]["value"], "unable")
        self.assertEqual(held["declared_ending"]["value"], "provider-failed")
        self.assertEqual(held["failure_reason"]["value"], "timeout")
        self.assertEqual(held["seconds_bound"]["value"], 3600)
        self.assertEqual(held["seconds_bound_source"]["value"], "job-default")
        self.assertIs(held["verification_attempted"]["value"], False)
        # NOT ATTEMPTED IS AN ANSWER AND THE STATUS BESIDE IT IS NOT A ZERO.
        self.assertFalse(held["verification_status"]["known"])
        for name, _kinds in attempt_diagnostics.WORKER_DECLARATION_MEMBERS:
            if held[name]["known"]:
                self.assertTrue(held[name]["source"], name)

    def test_a_FAILED_VERIFICATION_is_a_DIFFERENT_report(self):
        held = self.row(dict(self.TIMEOUT,
                             declared_ending="verification-failed",
                             verification_attempted=True,
                             verification_status=1))["worker_declaration"]
        self.assertEqual(held["declared_ending"]["value"],
                         "verification-failed")
        self.assertIs(held["verification_attempted"]["value"], True)
        self.assertEqual(held["verification_status"]["value"], 1)

    def test_a_DECLARATION_IS_NOT_AN_ACCEPTANCE_AND_NOT_A_CESSATION(self):
        """A passing worker-run verification is still not acceptance, and a
        declaration still does not complete a cause."""
        report = attempt_diagnostics.report(json.dumps(document(
            attempt_diagnostics={"worker_declaration": dict(
                self.TIMEOUT, declared_ending="candidate",
                verification_attempted=True, verification_status=0)}
        )).encode())
        row = report["rows"][0]
        self.assertIs(report["is_acceptance"], False)
        self.assertIs(row["completeness"]["is_acceptance"], False)
        self.assertIs(row["completeness"]["proves_cessation"], False)
        # THE CAUSE AXIS IS UNTOUCHED: no component recorded a cessation, so
        # the report still says exactly that.
        self.assertIsNone(row["cause"])
        self.assertEqual(row["completeness"]["state"], "incomplete")
        self.assertIn("cause", row["completeness"]["missing"])

    def test_an_ABSENT_declaration_axis_is_ABSENT_and_costs_nothing(self):
        """An older producer composed no declaration. That is `None` -- not a
        claim that the worker declared nothing -- and the rest of the row is
        unaffected."""
        row = attempt_diagnostics.report(json.dumps(document(
            attempt_diagnostics={"cause": {
                "component": "expiry-reclaim", "operation_id": "op-1",
                "correlation_id": "c-1", "outcome": "ceased-absent",
                "cessation": "absent", "runtime_id": "container-1",
                "category": None, "code": None}})).encode())["rows"][0]
        self.assertIsNone(row["worker_declaration"])
        self.assertEqual(row["cause"]["cessation"]["value"], "absent")

    def test_an_UNOWNED_CLOSED_VALUE_is_UNKNOWN_and_is_never_ECHOED(self):
        held = self.row(dict(self.TIMEOUT, disposition=SECRET,
                             declared_ending=SECRET, failure_reason=SECRET,
                             seconds_bound_source=SECRET))
        declaration = held["worker_declaration"]
        for name in ("disposition", "declared_ending", "failure_reason",
                     "seconds_bound_source"):
            self.assertFalse(declaration[name]["known"], name)
            self.assertIsNone(declaration[name]["value"], name)
            self.assertIn("does not own", declaration[name]["why"], name)
        self.assertNotIn(SECRET, json.dumps(held, default=list))
        # AND AN UNOWNED VALUE DOES NOT COST THE VALID FACTS BESIDE IT.
        self.assertEqual(declaration["seconds_bound"]["value"], 3600)

    def test_a_NESTED_OBJECT_in_the_declaration_is_NOT_forwarded(self):
        held = self.row(dict(self.TIMEOUT, seconds_bound={"leaked": SECRET}))
        self.assertNotIn(SECRET, json.dumps(held, default=list))
        self.assertFalse(held["worker_declaration"]["seconds_bound"]["known"])

    def test_an_UNDECLARED_member_is_reported_by_NAME_ONLY(self):
        held = self.row(dict(self.TIMEOUT, private_transcript=SECRET))
        self.assertIn("undeclared members omitted", held["unrecognised"])
        self.assertNotIn(SECRET, json.dumps(held, default=list))
        # AND THE NOTICE IS NOT DUPLICATED when the cause carries one too.
        self.assertEqual(len(held["unrecognised"]),
                         len(set(held["unrecognised"])))

    def test_the_OWNED_DECLARATION_VOCABULARY_does_not_drift(self):
        from baton_v12.worker_manager import failure_cause as owner
        from baton_v12.worker_manager import schema as manager_schema

        self.assertEqual(
            [name for name, _kinds
             in attempt_diagnostics.WORKER_DECLARATION_MEMBERS],
            list(owner.WORKER_DECLARATION_MEMBERS))
        self.assertEqual(sorted(attempt_diagnostics.SOURCE_DISPOSITIONS),
                         sorted(manager_schema.DISPOSITIONS))
        self.assertEqual(sorted(attempt_diagnostics.SOURCE_DECLARED_ENDINGS),
                         sorted(owner.DECLARED_ENDINGS))
        self.assertEqual(
            sorted(attempt_diagnostics.SOURCE_DECLARED_FAILURE_REASONS),
            sorted(owner.DECLARED_FAILURE_REASONS))
        self.assertEqual(
            sorted(attempt_diagnostics.SOURCE_DECLARED_BOUND_SOURCES),
            sorted(owner.DECLARED_BOUND_SOURCES))
