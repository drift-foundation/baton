"""W9707 — the parallel test runner, proved over disposable fake suites.

`work/records/2026/08/finding-v12-parallel-test-runner/`.

A test harness that decides which tests run is the one piece of tooling whose
own failure is invisible: a runner that silently drops a shard reports green
for tests nobody executed. So the properties proved here are the ones that
would hide a mistake rather than show one — that collection loses and invents
nothing, that a module belonging to no registry STOPS the run, that
presentation is byte-identical whatever order shards finish in, that a failure
propagates, that the serial registry never overlaps anything, and that an
interrupt leaves no descendant process and no temporary directory behind.

THE SUITES ARE FAKE AND THE RUNNER IS REAL. Every case below drives
`tools/parallel_test.py` itself over a `Suite` pointed at a temporary tree it
built. Nothing re-implements the scheduler in order to assert about it, because
an assertion about a re-implementation is an assertion about the wrong program.

This module is registered PARALLEL, and it is safe there: each case owns its
own `TemporaryDirectory`, every nested run is given an explicit small `--jobs`
so a shard of this module cannot fan out across the host a second time, and the
one timing claim it makes is a 0.6-second sleep against a 0-second one rather
than a race it hopes to win.
"""

import ast
import io
import json
import os
import pathlib
import signal
import subprocess
import sys
import tempfile
import time
import unittest
from unittest import mock

from tools.parallel_test import (CONSUMED_INPUTS, GROUP_MODULES, GROUP_PACKAGES, GROUPS, METHOD_SPLIT,
                                 OPTIONAL_SKIPS, PARALLEL_MODULES, ROOT, Run, RunnerRefusal,
                                 SERIAL_MODULES, STATUS_EVIDENCE_MODULE, STATUS_EVIDENCE_VARIABLE,
                                 SUPERVISED_MODULES, Suite, account, base_id, consumed_inputs, group_of, main,
                                 module_of, partition, present_accounting, resolve_jobs)

RUNNER = pathlib.Path(__file__).resolve().parents[2] / "tools" / "parallel_test.py"
# W384870: a fake tree carves no group; its packages map to one group each.
FAKE_PACKAGES = {"tests": "authority", "tests.tools": "tools-pure"}

PRELUDE = """import json
import os
import pathlib
import subprocess
import sys
import time
import unittest

MARKS = pathlib.Path(%r)


def mark(name, started, ended):
    MARKS.joinpath(name + "-" + str(os.getpid())).write_text(
        json.dumps([name, started, ended]), encoding="utf-8")
"""


def case_source(marks, cls, methods, sleep=0.0, failing=(), spawn=False):
    """One fake test module: sleeps, records its interval, maybe misbehaves."""
    lines = [PRELUDE % str(marks), "", "", "class %s(unittest.TestCase):" % cls]
    for method in methods:
        lines.append("    def %s(self):" % method)
        if spawn:
            # A grandchild that outlives its test unless somebody reaps the
            # whole process group. This is the thing an interrupt has to kill.
            lines.append("        child = subprocess.Popen([sys.executable, '-c',"
                         " 'import time; time.sleep(300)'])")
            lines.append("        MARKS.joinpath('grandchild').write_text(str(child.pid),"
                         " encoding='utf-8')")
        lines.append("        started = time.time()")
        lines.append("        time.sleep(%r)" % sleep)
        lines.append("        mark(%r, started, time.time())" % ("%s.%s" % (cls, method)))
        if method in failing:
            lines.append("        self.fail('the fake suite failing on purpose')")
        else:
            lines.append("        self.assertTrue(True)")
        lines.append("")
    return "\n".join(lines)


def worker_line(output):
    """The one stdout line that reports the worker count rather than a result."""
    return [line for line in output.splitlines() if line.startswith("[parallel] jobs=")]


def without_worker_line(output):
    return [line for line in output.splitlines() if not line.startswith("[parallel] jobs=")]


def write_tree(root, modules):
    tests = root / "tests"
    tests.mkdir(parents=True, exist_ok=True)
    (tests / "__init__.py").write_text("", encoding="utf-8")
    for name, source in modules.items():
        (tests / (name + ".py")).write_text(source, encoding="utf-8")
    return tests


class FakeTreeCase(unittest.TestCase):
    """A private tree, a private marks directory, and nothing shared."""

    def setUp(self):
        self.home = tempfile.TemporaryDirectory(prefix="v12-runner-test-")
        self.addCleanup(self.home.cleanup)
        self.root = pathlib.Path(self.home.name) / "tree"
        self.marks = pathlib.Path(self.home.name) / "marks"
        self.marks.mkdir(parents=True)

    def suite(self, parallel, serial=(), method_split=(), supervised=()):
        # W384870: a fake tree carves no group; its one package maps to one
        # group so the partition check holds over it as it does over the real tree.
        return Suite(self.root, parallel, serial, method_split=method_split, pythonpath=None,
                     supervised=supervised, groups={}, packages=FAKE_PACKAGES)

    def run_suite(self, suite, argv):
        """One in-process run, returning its exit code and its exact stdout."""
        out = io.StringIO()
        code = main(argv, suite=suite, out=out, progress=None)
        return code, out.getvalue()

    def intervals(self):
        found = []
        for path in sorted(self.marks.iterdir()):
            if path.name == "grandchild":
                continue
            name, started, ended = json.loads(path.read_text(encoding="utf-8"))
            found.append((name, started, ended))
        return found


# -- the decisions the parent makes, with no processes at all -----------------


class TheJobsBoundIsLowerOnly(unittest.TestCase):
    """`--jobs` may only ever REDUCE the host's available CPU count."""

    def test_the_default_is_every_available_cpu_capped_by_ready_shards(self):
        self.assertEqual(resolve_jobs(None, 32, 200), 32)
        self.assertEqual(resolve_jobs(None, 32, 5), 5)
        self.assertEqual(resolve_jobs(None, 32, 0), 1)

    def test_an_override_lowers_and_is_still_capped_by_ready_shards(self):
        self.assertEqual(resolve_jobs("8", 32, 200), 8)
        self.assertEqual(resolve_jobs("8", 32, 3), 3)
        self.assertEqual(resolve_jobs("1", 32, 200), 1)

    def test_raising_the_count_above_the_host_is_refused(self):
        with self.assertRaises(RunnerRefusal) as refused:
            resolve_jobs("33", 32, 200)
        self.assertIn("1..32", str(refused.exception))

    def test_the_refusal_is_against_the_host_and_never_the_shard_count(self):
        # The shard count varies with the selection; the operator's bound must
        # not, or `--jobs 8` would mean different things on different days.
        self.assertEqual(resolve_jobs("8", 32, 2), 2)
        with self.assertRaises(RunnerRefusal):
            resolve_jobs("33", 32, 2)

    def test_anything_that_is_not_a_whole_number_is_refused(self):
        for bad in ("0", "-1", "8.5", "x", "", "  ", "+8", "8_0", "0x8"):
            with self.subTest(jobs=bad):
                with self.assertRaises(RunnerRefusal):
                    resolve_jobs(bad, 32, 200)


class PartitioningLosesAndInventsNothing(unittest.TestCase):

    IDS = ("pkg.mod.Alpha.test_a", "pkg.mod.Alpha.test_b",
           "pkg.mod.Beta.test_a", "pkg.other.Gamma.test_a")

    def test_the_ordinary_shard_is_one_concrete_class(self):
        shards = partition(self.IDS, method_split=())
        self.assertEqual([shard["label"] for shard in shards],
                         ["pkg.mod.Alpha", "pkg.mod.Beta", "pkg.other.Gamma"])
        self.assertEqual(shards[0]["ids"], ["pkg.mod.Alpha.test_a", "pkg.mod.Alpha.test_b"])

    def test_a_named_class_is_split_one_test_method_per_shard(self):
        shards = partition(self.IDS, method_split=("pkg.mod.Alpha",))
        self.assertEqual([shard["label"] for shard in shards],
                         ["pkg.mod.Alpha.test_a", "pkg.mod.Alpha.test_b",
                          "pkg.mod.Beta", "pkg.other.Gamma"])
        self.assertTrue(all(len(shard["ids"]) == 1 for shard in shards[:2]))

    def test_every_collected_id_lands_in_exactly_one_shard(self):
        for split in ((), ("pkg.mod.Alpha",), ("pkg.mod.Alpha", "pkg.mod.Beta")):
            with self.subTest(split=split):
                shards = partition(self.IDS, method_split=split)
                covered = [one for shard in shards for one in shard["ids"]]
                self.assertEqual(sorted(covered), sorted(self.IDS))
                self.assertEqual(len(covered), len(set(covered)))

    def test_a_duplicate_collected_id_is_refused_rather_than_run_twice(self):
        with self.assertRaises(RunnerRefusal) as refused:
            partition(list(self.IDS) + ["pkg.mod.Alpha.test_a"])
        self.assertIn("duplicate", str(refused.exception))

    def test_the_order_does_not_depend_on_the_order_ids_arrived_in(self):
        forward = partition(self.IDS, method_split=("pkg.mod.Alpha",))
        backward = partition(list(reversed(self.IDS)), method_split=("pkg.mod.Alpha",))
        self.assertEqual(forward, backward)


# -- the registry, which is the whole safety argument -------------------------


class TheRegistryFailsClosed(FakeTreeCase):

    def test_a_module_in_neither_registry_stops_the_run(self):
        write_tree(self.root, {"test_known": case_source(self.marks, "Known", ["test_a"]),
                               "test_stranger": case_source(self.marks, "Stranger", ["test_a"])})
        code, output = self.run_suite(self.suite(("tests.test_known",)), ["--jobs", "1"])
        self.assertEqual(code, 2)
        self.assertIn("belong to no registry", output)
        self.assertIn("tests.test_stranger", output)

    def test_a_registered_module_that_is_not_in_the_tree_stops_the_run(self):
        write_tree(self.root, {"test_known": case_source(self.marks, "Known", ["test_a"])})
        code, output = self.run_suite(self.suite(("tests.test_known", "tests.test_ghost")),
                                      ["--jobs", "1"])
        self.assertEqual(code, 2)
        self.assertIn("not in the tree", output)
        self.assertIn("tests.test_ghost", output)

    def test_a_module_in_both_registries_stops_the_run(self):
        write_tree(self.root, {"test_known": case_source(self.marks, "Known", ["test_a"])})
        code, output = self.run_suite(
            self.suite(("tests.test_known",), serial=("tests.test_known",)), ["--jobs", "1"])
        self.assertEqual(code, 2)
        self.assertIn("registered more than once", output)

    def test_discovery_uses_unittests_own_pattern_and_not_a_narrower_one(self):
        # `unittest discover`'s default is `test*.py`. A registry check that
        # looked for `test_*.py` would let this file into the canonical gate
        # while reporting the registry complete.
        write_tree(self.root, {"test_known": case_source(self.marks, "Known", ["test_a"]),
                               "testnounderscore": case_source(self.marks, "Sneaky", ["test_a"])})
        code, output = self.run_suite(self.suite(("tests.test_known",)), ["--jobs", "1"])
        self.assertEqual(code, 2)
        self.assertIn("tests.testnounderscore", output)


class SupervisedSelectionFailsClosed(FakeTreeCase):
    """W168703: real collector/scheduler, disposable tests, no engine capability."""

    def setUp(self):
        super().setUp()
        self.entry = {"module": "tests.test_gated", "work": "W32577",
                      "supervisor": "baton:work/records/2026/09/finding-example/engine-gate.py",
                      "reason": "Requires separately selected supervision"}
        self.imported = self.marks / "gated-imported"
        write_tree(self.root, {
            "test_known": case_source(self.marks, "Known", ["test_a"]),
            "test_gated": f"from pathlib import Path\nPath({str(self.imported)!r}).touch()\nraise AssertionError('direct gated import')\n",
        })

    def selected(self, **kwargs):
        return self.suite(("tests.test_known",), supervised=(self.entry,), **kwargs)

    def assert_precollection_refusal(self, suite, argv, diagnostic):
        with mock.patch.object(Run, "open_result_root") as opened, mock.patch.object(Suite, "spawn") as spawned:
            code, output = self.run_suite(suite, argv)
        self.assertEqual(code, 2, output)
        self.assertIn(diagnostic, output)
        self.assertNotIn("-> OK", output)
        opened.assert_not_called()
        spawned.assert_not_called()
        self.assertEqual(list(self.marks.iterdir()), [])

    def test_default_and_all_refuse_even_with_supervisor_environment(self):
        with mock.patch.dict(os.environ, {"BATON_W32577_GATE_DIR": str(self.marks), "BATON_W32577_IMAGE_DIGEST": "sha256:" + "0" * 64}):
            for argv in ([], ["--phase", "all"]):
                with self.subTest(argv=argv):
                    self.assert_precollection_refusal(self.selected(), argv, "all-source acceptance is uncomposed")

    def test_scoped_parallel_runs_ordinary_tests_and_names_the_unselected_gate(self):
        code, output = self.run_suite(self.selected(), ["--phase", "parallel", "--jobs", "1"])
        self.assertEqual(code, 0, output)
        self.assertIn("[scope] parallel only; supervised not selected: tests.test_gated (W32577;", output)
        self.assertIn(self.entry["supervisor"], output)
        self.assertIn("Known (1 tests)", output)
        self.assertFalse(self.imported.exists())
        self.assertEqual(len(self.intervals()), 1)

    def test_scoped_serial_does_not_collect_parallel_or_supervised_modules(self):
        suite = self.suite((), serial=("tests.test_known",), supervised=(self.entry,))
        code, output = self.run_suite(suite, ["--phase", "serial", "--jobs", "1"])
        self.assertEqual(code, 0, output)
        self.assertIn("[scope] serial only; supervised not selected:", output)
        self.assertIn("tests.test_known (1 tests)", output)
        self.assertFalse(self.imported.exists())

    def test_print_ids_requires_explicit_parallel_and_runs_no_test(self):
        for argv in (["--print-ids"], ["--print-ids", "--phase", "all"], ["--print-ids", "--phase", "serial"]):
            with self.subTest(argv=argv):
                self.assert_precollection_refusal(self.selected(), argv, "--print-ids requires explicit --phase parallel")
        code, output = self.run_suite(self.selected(), ["--print-ids", "--phase", "parallel", "--jobs", "1"])
        self.assertEqual(code, 0, output)
        self.assertIn("tests.test_known.Known.test_a", output)
        self.assertIn("supervised not selected", output)
        self.assertEqual(list(self.marks.iterdir()), [])

    def test_supervised_metadata_is_closed_and_validated_before_side_effects(self):
        malformed = [None, {}, dict(self.entry, command="python gate.py"),
                     dict(self.entry, module="tests/test_gated"), dict(self.entry, work="W0"),
                     dict(self.entry, reason=""), dict(self.entry, reason="bad\ntext"),
                     dict(self.entry, reason=17), dict(self.entry, supervisor="/tmp/gate.py"),
                     dict(self.entry, supervisor="baton:work/records/2026/09/../gate.py"),
                     dict(self.entry, supervisor="baton:work/open/finding-example/gate.py")]
        for entry in malformed:
            with self.subTest(entry=entry):
                suite = self.suite(("tests.test_known",), supervised=(entry,))
                self.assert_precollection_refusal(suite, ["--phase", "parallel"], "supervised metadata")

    def test_duplicates_in_every_category_and_stale_supervised_entries_refuse(self):
        for parallel, serial, entries in (
                (("tests.test_known", "tests.test_gated"), (), (self.entry,)),
                (("tests.test_known",), ("tests.test_gated",), (self.entry,)),
                (("tests.test_known",), (), (self.entry, self.entry))):
            with self.subTest(parallel=parallel, serial=serial):
                self.assert_precollection_refusal(self.suite(parallel, serial, supervised=entries), ["--phase", "parallel"], "registered more than once")
        stale = dict(self.entry, module="tests.test_absent")
        suite = self.suite(("tests.test_known",), supervised=(self.entry, stale))
        self.assert_precollection_refusal(suite, ["--phase", "parallel"], "not in the tree")

    def test_supervised_classification_does_not_hide_an_unclassified_module(self):
        (self.root / "tests/testnounderscore.py").write_text("raise AssertionError('must not import')\n")
        self.assert_precollection_refusal(self.selected(), ["--phase", "parallel"], "belong to no registry")

    def test_configured_status_evidence_refuses_before_collection_or_output(self):
        directory = self.root / "tests/tools"
        directory.mkdir()
        (directory / "__init__.py").write_text("")
        (directory / "test_stage_execution_status_hardening.py").write_text("raise AssertionError('must not import')\n")
        suite = self.suite(("tests.test_known", STATUS_EVIDENCE_MODULE), supervised=(self.entry,))
        for value in (str(self.marks / "unowned"), " "):
            with self.subTest(value=value), mock.patch.dict(os.environ, {STATUS_EVIDENCE_VARIABLE: value}):
                self.assert_precollection_refusal(suite, ["--phase", "parallel"], "unset " + STATUS_EVIDENCE_VARIABLE)

    def test_evidence_guard_is_limited_to_the_selected_parallel_leaf(self):
        with mock.patch.dict(os.environ, {STATUS_EVIDENCE_VARIABLE: str(self.marks / "unowned")}):
            code, output = self.run_suite(self.selected(), ["--phase", "parallel", "--jobs", "1"])
        self.assertEqual(code, 0, output)
        self.assertFalse((self.marks / "unowned").exists())

    def test_empty_evidence_destination_allows_the_leaf_and_serial_does_not_import_it(self):
        directory = self.root / "tests/tools"
        directory.mkdir()
        (directory / "__init__.py").write_text("")
        leaf = directory / "test_stage_execution_status_hardening.py"
        leaf.write_text(case_source(self.marks, "Status", ["test_a"]))
        suite = self.suite((STATUS_EVIDENCE_MODULE,), serial=("tests.test_known",), supervised=(self.entry,))
        with mock.patch.dict(os.environ, {STATUS_EVIDENCE_VARIABLE: ""}):
            code, output = self.run_suite(suite, ["--phase", "parallel", "--jobs", "1"])
        self.assertEqual(code, 0, output)
        self.assertEqual([row[0] for row in self.intervals()], ["Status.test_a"])
        leaf.write_text("raise AssertionError('serial must not collect parallel evidence leaf')\n")
        with mock.patch.dict(os.environ, {STATUS_EVIDENCE_VARIABLE: str(self.marks / "unowned")}):
            code, output = self.run_suite(suite, ["--phase", "serial", "--jobs", "1"])
        self.assertEqual(code, 0, output)
        self.assertFalse((self.marks / "unowned").exists())

    def fixture_loader(self, leak):
        (self.root / "tests/test_gated.py").write_text(
            "from pathlib import Path\nimport unittest\n"
            f"Path({str(self.imported)!r}).touch()\n"
            "class Gated(unittest.TestCase):\n"
            "    @classmethod\n    def setUpClass(cls):\n"
            f"        Path({str(self.marks / 'forbidden-setup')!r}).touch()\n"
            "    def test_engine(self):\n"
            f"        Path({str(self.marks / 'forbidden-test')!r}).touch()\n")
        source = case_source(self.marks, "Known", ["test_a"])
        source += "\nfrom tests.test_gated import Gated\n"
        source += "def load_tests(loader, tests, pattern):\n"
        source += "    selected = loader.loadTestsFromTestCase(Known)\n"
        if leak:
            source += "    selected.addTests(loader.loadTestsFromTestCase(Gated))\n"
        source += "    return selected\n"
        (self.root / "tests/test_known.py").write_text(source)

    def test_custom_loader_can_import_safe_supervised_definitions(self):
        self.fixture_loader(leak=False)
        code, output = self.run_suite(self.selected(), ["--phase", "parallel", "--jobs", "1"])
        self.assertEqual(code, 0, output)
        self.assertTrue(self.imported.exists())
        self.assertIn("Known (1 tests)", output)
        self.assertFalse((self.marks / "forbidden-setup").exists())
        self.assertFalse((self.marks / "forbidden-test").exists())

    def test_leaked_supervised_ids_refuse_the_whole_collection_before_shards(self):
        self.fixture_loader(leak=True)
        for extra in ([], ["--print-ids"]):
            with self.subTest(extra=extra), mock.patch("tools.parallel_test.shard_work") as shards:
                code, output = self.run_suite(self.selected(), ["--phase", "parallel", "--jobs", "1"] + extra)
            self.assertEqual(code, 2, output)
            # W384870: the collector now refuses the BINDING module first (a
            # bound stranger would run twice); `check_collected_ids` remains
            # the second line. Either way: refused by name, before any shard.
            self.assertIn("binds test classes defined elsewhere", output)
            self.assertIn("tests.test_gated.Gated", output)
            self.assertNotIn("-> OK", output)
            shards.assert_not_called()
            self.assertEqual([p.name for p in self.marks.iterdir()], ["gated-imported"])


class TheRealRegistryDescribesTheRealTree(unittest.TestCase):
    """The one case that fails when somebody adds a v12 test module.

    That failure is the POINT: it says "decide what this module owns" rather
    than letting an unreviewed module inherit the parallel phase by default.
    """

    def test_every_v12_test_module_is_registered_exactly_once(self):
        Suite(ROOT, PARALLEL_MODULES, SERIAL_MODULES, supervised=SUPERVISED_MODULES).check_registry()

    def test_the_deadline_engine_has_only_supervised_metadata(self):
        self.assertEqual([entry["module"] for entry in SUPERVISED_MODULES], ["tests.manager.test_runtime_deadline_engine"])
        self.assertEqual(SUPERVISED_MODULES[0]["work"], "W32577")
        self.assertNotIn(SUPERVISED_MODULES[0]["module"], PARALLEL_MODULES + SERIAL_MODULES)

    def test_the_serial_modules_are_the_ones_that_own_an_engine(self):
        # W6636 added the third: `test_lifecycle_composition` builds this
        # repository's worker image AND drives a real daemon through the
        # manager's ordered lifecycle, including a case that asks the engine
        # how many containers carry one assignment's labels. Both reasons the
        # first two are serial apply to it at once.
        #
        # W26283 added the fourth: `test_output_custody_engine` runs the
        # reference worker for real and seals what it wrote, so it owns
        # containers and the built image for the same two reasons again.
        #
        # W26284 added the fifth: `test_credentials_engine` starts real
        # containers carrying a delivered credential and asks the DAEMON what
        # it recorded about them.
        #
        # W32385 added the seventh: `test_ended_runtime_adoption` restarts a
        # manager over the same store and asks the daemon whether the exact
        # ENDED container is still there, which a concurrent suite removing
        # containers would answer for it.
        #
        # W32382 added the sixth: `test_negative_race_endings` subclasses
        # W6636's composition fixture and drives the same daemon through the
        # endings the positive arc does not reach, counting containers for one
        # assignment's labels exactly as it does.
        #
        # W33935 added the eighth: `test_input_delivery` reuses W6636's engine
        # fixture, builds the same worker image and starts containers over the
        # manager's own composed argv -- and one of its cases asks the daemon
        # how many containers carry an assignment's labels, which a concurrent
        # suite creating or removing them would answer for it.
        #
        # W34998 added the ninth: `test_failed_start_destroy_engine` builds the
        # worker image and creates real containers in order to remove them,
        # so it owns the same two artefacts the eight before it do. It runs
        # straight after the image gate that produces the one it needs.
        self.assertEqual(SERIAL_MODULES,
                         ("tests.manager.test_worker_container",
                          "tests.manager.test_failed_start_destroy_engine",
                          "tests.manager.test_oci_engine",
                          "tests.manager.test_lifecycle_composition",
                          "tests.manager.test_negative_race_endings",
                          "tests.manager.test_ended_runtime_adoption",
                          "tests.manager.test_output_custody_engine",
                          "tests.manager.test_credentials_engine",
                          "tests.manager.test_refused_session_engine",
                          "tests.manager.test_custody_engine",
                          "tests.manager.test_input_delivery",
                          # W39356 added the twelfth:
                          # `test_worker_entry_engine` inherits the same
                          # composition fixture, builds the same image and
                          # drives `docker exec` against containers it started
                          # under one assignment's labels -- and one case
                          # removes a container and then asks the daemon, which
                          # a concurrent suite would answer for it.
                          "tests.manager.test_worker_entry_engine",
                          # W39357 added the thirteenth: the dogfood image
                          # gate builds an image and starts containers from
                          # it, so it owns the same two artefacts every other
                          # engine gate does.
                          "tests.manager.test_dogfood_image",
                          # W44716 added the fourteenth:
                          # `test_abandoned_attempt_engine` starts real
                          # containers and then asks the daemon whether a
                          # RUNNING one was removed, which is a question a
                          # concurrent suite could answer for it.
                          "tests.manager.test_abandoned_attempt_engine",
                          # W39358 added the fifteenth: the whole-arc gate
                          # builds the dogfood image, runs the composed arc
                          # over a real container and asks the daemon whether
                          # the runtime is gone.
                          "tests.tools.test_dogfood_arc_engine",
                          # W39358 added the sixteenth: the public-retry gate
                          # derives an image from the reference worker and
                          # drives the documented commands over real
                          # containers.
                          "tests.tools.test_dogfood_retry_engine",
                          "tests.manager.test_private_line_access_engine",
                          # Conservative serial registrations; parallel safety
                          # of these composed fixtures is not yet certified.
                          "tests.integration.test_driver",
                          "tests.job_manager.test_review_driver"))
        for module in SERIAL_MODULES:
            with self.subTest(module=module):
                self.assertNotIn(module, PARALLEL_MODULES)

    def test_this_module_registered_itself(self):
        self.assertIn("tests.tools.test_parallel_runner", PARALLEL_MODULES)

    def test_every_method_split_target_is_a_real_class_in_a_parallel_module(self):
        for key in METHOD_SPLIT:
            with self.subTest(key=key):
                module = key.rsplit(".", 1)[0]
                self.assertIn(module, PARALLEL_MODULES)
                loaded = list(unittest.TestLoader().loadTestsFromName(key))
                self.assertGreater(len(loaded), 1,
                                   "splitting a class with one test buys nothing")


# -- presentation, which must not depend on when anything finished ------------


class OutputDoesNotDependOnCompletionOrder(FakeTreeCase):

    SLOW, FAST = 0.6, 0.0

    def build(self, alpha_sleep, zulu_sleep):
        write_tree(self.root, {"test_alpha": case_source(self.marks, "Alpha", ["test_a"], alpha_sleep),
                               "test_zulu": case_source(self.marks, "Zulu", ["test_a"], zulu_sleep)})
        return self.suite(("tests.test_alpha", "tests.test_zulu"))

    def test_inverting_which_shard_finishes_first_changes_nothing_in_stdout(self):
        code, slow_first = self.run_suite(self.build(self.SLOW, self.FAST), ["--jobs", "2"])
        self.assertEqual(code, 0)
        ended = {name: end for name, _, end in self.intervals()}
        self.assertGreater(ended["Alpha.test_a"], ended["Zulu.test_a"],
                           "the fake suite did not actually invert completion order")

        self.setUp()
        code, fast_first = self.run_suite(self.build(self.FAST, self.SLOW), ["--jobs", "2"])
        self.assertEqual(code, 0)
        ended = {name: end for name, _, end in self.intervals()}
        self.assertGreater(ended["Zulu.test_a"], ended["Alpha.test_a"])

        self.assertEqual(slow_first, fast_first)
        self.assertLess(slow_first.index("tests.test_alpha.Alpha"),
                        slow_first.index("tests.test_zulu.Zulu"))

    def test_one_worker_and_the_default_agree_on_ids_and_on_outcome(self):
        suite = self.build(0.0, 0.0)
        alone_code, alone = self.run_suite(suite, ["--jobs", "1"])
        self.setUp()
        suite = self.build(0.0, 0.0)
        default_code, default = self.run_suite(suite, [])
        self.assertEqual(alone_code, default_code)
        # ONE line is expected to differ, and it is the input rather than a
        # result: the `[parallel] jobs=N` line is the runner saying how many
        # workers it used, which is the whole variable under test. Normalizing
        # it is named here rather than achieved by loosening the comparison,
        # so a second line drifting apart would still fail this case.
        self.assertNotEqual(worker_line(alone), worker_line(default))
        self.assertEqual(without_worker_line(alone), without_worker_line(default))

    def test_the_collected_ids_are_the_same_at_any_worker_count(self):
        suite = self.build(0.0, 0.0)
        _, alone = self.run_suite(suite, ["--jobs", "1", "--print-ids"])
        _, default = self.run_suite(suite, ["--print-ids"])
        self.assertEqual(alone.split(), ["tests.test_alpha.Alpha.test_a",
                                         "tests.test_zulu.Zulu.test_a"])
        self.assertEqual(alone, default)


class AFailingShardIsReportedAndStopsTheLaterPhases(FakeTreeCase):

    def build(self):
        write_tree(self.root, {
            "test_good": case_source(self.marks, "Good", ["test_a"]),
            "test_bad": case_source(self.marks, "Bad", ["test_a"], failing=["test_a"]),
            "test_serial": case_source(self.marks, "Serial", ["test_a"])})
        return self.suite(("tests.test_good", "tests.test_bad"), serial=("tests.test_serial",))

    def test_the_failure_propagates_to_the_exit_code_and_the_summary(self):
        code, output = self.run_suite(self.build(), ["--jobs", "2"])
        self.assertEqual(code, 1)
        self.assertIn("[FAIL] tests.test_bad.Bad", output)
        self.assertIn("[pass] tests.test_good.Good", output)
        self.assertIn("the fake suite failing on purpose", output)
        self.assertIn("-> FAILED", output)

    def test_a_failed_parallel_phase_never_reaches_the_serial_registry(self):
        code, output = self.run_suite(self.build(), ["--jobs", "2"])
        self.assertEqual(code, 1)
        self.assertIn("the serial registry did not run", output)
        self.assertNotIn("Serial.test_a", [name for name, _, _ in self.intervals()])

    def test_a_failing_sibling_never_abandons_the_other_shards(self):
        # Drain-then-verdict: the good shard's result is present, which it
        # would not be if the runner had bailed out on the first failure.
        self.run_suite(self.build(), ["--jobs", "1"])
        ran = sorted(name for name, _, _ in self.intervals())
        self.assertEqual(ran, ["Bad.test_a", "Good.test_a"])


class TheSerialRegistryOverlapsNothing(FakeTreeCase):

    def test_serial_modules_run_after_the_parallel_phase_and_one_at_a_time(self):
        write_tree(self.root, {
            "test_pure_a": case_source(self.marks, "PureA", ["test_a"], 0.2),
            "test_pure_b": case_source(self.marks, "PureB", ["test_a"], 0.2),
            "test_serial_a": case_source(self.marks, "SerialA", ["test_a"], 0.2),
            "test_serial_b": case_source(self.marks, "SerialB", ["test_a"], 0.2)})
        suite = self.suite(("tests.test_pure_a", "tests.test_pure_b"),
                           serial=("tests.test_serial_a", "tests.test_serial_b"))
        code, output = self.run_suite(suite, ["--jobs", "2"])
        self.assertEqual(code, 0, output)

        found = {name: (start, end) for name, start, end in self.intervals()}
        self.assertEqual(sorted(found), ["PureA.test_a", "PureB.test_a",
                                         "SerialA.test_a", "SerialB.test_a"])
        for serial in ("SerialA.test_a", "SerialB.test_a"):
            for other in found:
                if other == serial:
                    continue
                with self.subTest(serial=serial, other=other):
                    self.assertFalse(found[serial][0] < found[other][1]
                                     and found[other][0] < found[serial][1],
                                     f"{serial} overlapped {other}")
        self.assertIn("[serial] 2 source modules, one at a time", output)

    def test_the_summary_reports_the_two_phases_separately(self):
        write_tree(self.root, {"test_pure": case_source(self.marks, "Pure", ["test_a"]),
                               "test_serial": case_source(self.marks, "Serial", ["test_a"])})
        code, output = self.run_suite(self.suite(("tests.test_pure",), serial=("tests.test_serial",)),
                                      ["--jobs", "1"])
        self.assertEqual(code, 0, output)
        self.assertIn("--- parallel source ---", output)
        self.assertIn("--- serial source ---", output)
        self.assertIn("parallel source: 1 tests", output)
        self.assertIn("serial source: 1 tests", output)


# -- what is left behind, which is the part nobody notices until it matters ----


class DriverCase(FakeTreeCase):
    """Runs the runner as a REAL child, with a private TMPDIR to inspect."""

    def driver(self, parallel, serial=()):
        path = pathlib.Path(self.home.name) / "driver.py"
        path.write_text("import sys\n"
                        "sys.path.insert(0, %r)\n"
                        "from tools.parallel_test import Suite, main\n"
                        "FAKE = {'tests': 'authority', 'tests.tools': 'tools-pure'}\n"
            "suite = Suite(%r, %r, %r, method_split=(), pythonpath=None, groups={}, packages=FAKE)\n"
                        "raise SystemExit(main(sys.argv[1:], suite=suite))\n"
                        % (str(ROOT), str(self.root), tuple(parallel), tuple(serial)),
                        encoding="utf-8")
        return path

    def temp(self):
        place = pathlib.Path(self.home.name) / "tmp"
        place.mkdir(exist_ok=True)
        return place

    def launch(self, driver, argv, temp):
        environment = dict(os.environ, TMPDIR=str(temp))
        environment.pop("PYTHONPATH", None)
        return subprocess.Popen([sys.executable, str(driver)] + argv, env=environment,
                                stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                                start_new_session=True)


def alive(pid):
    """True only for a process that still exists AND is not already a zombie."""
    try:
        state = pathlib.Path(f"/proc/{pid}/stat").read_text(encoding="utf-8")
    except (FileNotFoundError, ProcessLookupError):
        return False
    return state.rsplit(")", 1)[-1].split()[0] != "Z"


def kill_if_alive(pid):
    """Keep a failed cleanup regression from leaking the process it exposed."""
    if not alive(pid):
        return
    try:
        os.kill(pid, signal.SIGKILL)
    except ProcessLookupError:
        pass


class AnInterruptLeavesNothingBehind(DriverCase):

    def test_it_reaps_its_shards_descendants_and_removes_its_result_root(self):
        write_tree(self.root, {"test_spawner": case_source(self.marks, "Spawner", ["test_a"],
                                                           sleep=60, spawn=True)})
        temp = self.temp()
        child = self.launch(self.driver(("tests.test_spawner",)), ["--jobs", "1"], temp)
        self.addCleanup(lambda: child.poll() is None and child.kill())

        grandchild = self.marks / "grandchild"
        deadline = time.monotonic() + 30
        while time.monotonic() < deadline and not grandchild.exists():
            time.sleep(0.05)
        self.assertTrue(grandchild.exists(), "the fake suite never started its grandchild")
        pid = int(grandchild.read_text(encoding="utf-8"))
        self.assertTrue(alive(pid))

        child.send_signal(signal.SIGINT)
        child.communicate(timeout=60)
        self.assertNotEqual(child.returncode, 0, "an interrupted run must not report success")

        deadline = time.monotonic() + 15
        while time.monotonic() < deadline and alive(pid):
            time.sleep(0.05)
        self.assertFalse(alive(pid), f"the shard's descendant {pid} survived the interrupt")
        self.assertEqual(sorted(path.name for path in temp.iterdir()), [],
                         "the runner left its disposable result root behind")

    def test_it_kills_a_term_ignoring_descendant_after_its_shard_leader_exits(self):
        grandchild = self.marks / "grandchild-ignoring-term"
        command = ("import os,pathlib,signal,time; "
                   "signal.signal(signal.SIGTERM, signal.SIG_IGN); "
                   "pathlib.Path(%r).write_text(str(os.getpid()), encoding='utf-8'); "
                   "time.sleep(300)" % str(grandchild))
        source = (PRELUDE % str(self.marks)) + (
            "\n\nclass Spawner(unittest.TestCase):\n"
            "    def test_a(self):\n"
            "        subprocess.Popen([sys.executable, '-c', %r])\n"
            "        time.sleep(60)\n" % command)
        write_tree(self.root, {"test_spawner": source})
        temp = self.temp()
        child = self.launch(self.driver(("tests.test_spawner",)), ["--jobs", "1"], temp)
        self.addCleanup(lambda: child.poll() is None and child.kill())

        deadline = time.monotonic() + 30
        while time.monotonic() < deadline and not grandchild.exists():
            time.sleep(0.05)
        self.assertTrue(grandchild.exists(), "the fake suite never started its grandchild")
        pid = int(grandchild.read_text(encoding="utf-8"))
        self.addCleanup(kill_if_alive, pid)
        self.assertTrue(alive(pid))

        child.send_signal(signal.SIGINT)
        child.communicate(timeout=60)
        self.assertNotEqual(child.returncode, 0, "an interrupted run must not report success")

        deadline = time.monotonic() + 15
        while time.monotonic() < deadline and alive(pid):
            time.sleep(0.05)
        self.assertFalse(alive(pid),
                         f"the TERM-ignoring descendant {pid} survived the interrupt")

    def test_an_interrupt_during_retirement_cannot_cross_a_tracking_gap(self):
        grandchild = self.marks / "retirement-race-grandchild"
        command = ("import os,pathlib,signal,time; "
                   "signal.signal(signal.SIGTERM, signal.SIG_IGN); "
                   "pathlib.Path(%r).write_text(str(os.getpid()), encoding='utf-8'); "
                   "time.sleep(300)" % str(grandchild))
        source = (PRELUDE % str(self.marks)) + (
            "\n\nclass Spawner(unittest.TestCase):\n"
            "    def test_a(self):\n"
            "        subprocess.Popen([sys.executable, '-c', %r])\n"
            "        deadline = time.time() + 30\n"
            "        while time.time() < deadline and not pathlib.Path(%r).exists():\n"
            "            time.sleep(0.05)\n"
            "        self.assertTrue(pathlib.Path(%r).exists())\n"
            % (command, str(grandchild), str(grandchild)))
        write_tree(self.root, {"test_spawner": source})

        driver = pathlib.Path(self.home.name) / "interrupting-driver.py"
        driver.write_text(
            "import os\n"
            "import pathlib\n"
            "import signal\n"
            "import sys\n"
            "sys.path.insert(0, %r)\n"
            "from tools.parallel_test import Run, Suite, main\n"
            "FAKE = {'tests': 'authority', 'tests.tools': 'tools-pure'}\n"
            "suite = Suite(%r, %r, (), method_split=(), pythonpath=None, groups={}, packages=FAKE)\n"
            "original = Run.signal_group\n"
            "armed = True\n"
            "def interrupt_at_signal(self, pgid, which):\n"
            "    global armed\n"
            "    if armed and which == signal.SIGKILL and pathlib.Path(%r).exists():\n"
            "        armed = False\n"
            "        os.kill(os.getpid(), signal.SIGINT)\n"
            "    return original(self, pgid, which)\n"
            "Run.signal_group = interrupt_at_signal\n"
            "raise SystemExit(main(sys.argv[1:], suite=suite))\n"
            % (str(ROOT), str(self.root), ("tests.test_spawner",), str(grandchild)),
            encoding="utf-8")
        temp = self.temp()
        child = self.launch(driver, ["--jobs", "1"], temp)
        output = child.communicate(timeout=120)[0].decode("utf-8", "replace")
        self.assertEqual(child.returncode, 130, output)
        self.assertTrue(grandchild.exists(), "the fake suite never started its grandchild")
        pid = int(grandchild.read_text(encoding="utf-8"))
        self.addCleanup(kill_if_alive, pid)

        deadline = time.monotonic() + 5
        while time.monotonic() < deadline and alive(pid):
            time.sleep(0.05)
        self.assertFalse(alive(pid),
                         f"the descendant {pid} survived an interrupt during retirement")
        self.assertEqual(sorted(path.name for path in temp.iterdir()), [])

    def test_an_interrupt_after_spawn_cannot_cross_the_registration_gap(self):
        grandchild = self.marks / "spawn-race-grandchild"
        leader = self.marks / "spawn-race-leader"
        command = ("import os,pathlib,signal,time; "
                   "signal.signal(signal.SIGTERM, signal.SIG_IGN); "
                   "pathlib.Path(%r).write_text(str(os.getpid()), encoding='utf-8'); "
                   "time.sleep(300)" % str(grandchild))
        source = (PRELUDE % str(self.marks)) + (
            "\n\nclass Spawner(unittest.TestCase):\n"
            "    def test_a(self):\n"
            "        subprocess.Popen([sys.executable, '-c', %r])\n"
            "        deadline = time.time() + 30\n"
            "        while time.time() < deadline and not pathlib.Path(%r).exists():\n"
            "            time.sleep(0.05)\n"
            "        self.assertTrue(pathlib.Path(%r).exists())\n"
            "        time.sleep(60)\n"
            % (command, str(grandchild), str(grandchild)))
        write_tree(self.root, {"test_spawner": source})

        driver = pathlib.Path(self.home.name) / "spawn-interrupting-driver.py"
        driver.write_text(
            "import os\n"
            "import pathlib\n"
            "import signal\n"
            "import sys\n"
            "import time\n"
            "sys.path.insert(0, %r)\n"
            "from tools.parallel_test import Suite, main\n"
            "FAKE = {'tests': 'authority', 'tests.tools': 'tools-pure'}\n"
            "suite = Suite(%r, %r, (), method_split=(), pythonpath=None, groups={}, packages=FAKE)\n"
            "original = Suite.spawn\n"
            "armed = True\n"
            "def interrupt_after_spawn(self, argv, err):\n"
            "    global armed\n"
            "    child = original(self, argv, err)\n"
            "    if armed and argv[0] == 'run-shard':\n"
            "        armed = False\n"
            "        pathlib.Path(%r).write_text(str(child.pid), encoding='utf-8')\n"
            "        deadline = time.monotonic() + 30\n"
            "        while time.monotonic() < deadline and not pathlib.Path(%r).exists():\n"
            "            time.sleep(0.05)\n"
            "        os.kill(os.getpid(), signal.SIGINT)\n"
            "    return child\n"
            "Suite.spawn = interrupt_after_spawn\n"
            "raise SystemExit(main(sys.argv[1:], suite=suite))\n"
            % (str(ROOT), str(self.root), ("tests.test_spawner",),
               str(leader), str(grandchild)), encoding="utf-8")
        temp = self.temp()
        child = self.launch(driver, ["--jobs", "1"], temp)
        output = child.communicate(timeout=120)[0].decode("utf-8", "replace")
        self.assertEqual(child.returncode, 130, output)
        self.assertTrue(leader.exists(), "the injected spawn never published its leader")
        self.assertTrue(grandchild.exists(), "the fake suite never started its grandchild")
        pids = [int(leader.read_text(encoding="utf-8")),
                int(grandchild.read_text(encoding="utf-8"))]
        for pid in pids:
            self.addCleanup(kill_if_alive, pid)

        deadline = time.monotonic() + 5
        while time.monotonic() < deadline and any(alive(pid) for pid in pids):
            time.sleep(0.05)
        survivors = [pid for pid in pids if alive(pid)]
        self.assertEqual(survivors, [],
                         f"the unregistered shard left surviving processes {survivors}")
        self.assertEqual(sorted(path.name for path in temp.iterdir()), [])

    def test_a_signal_during_final_cleanup_is_recorded_until_cleanup_finishes(self):
        write_tree(self.root, {"test_good": case_source(self.marks, "Good", ["test_a"])})
        driver = pathlib.Path(self.home.name) / "cleanup-interrupting-driver.py"
        driver.write_text(
            "import os\n"
            "import signal\n"
            "import sys\n"
            "sys.path.insert(0, %r)\n"
            "from tools.parallel_test import Run, Suite, main\n"
            "FAKE = {'tests': 'authority', 'tests.tools': 'tools-pure'}\n"
            "suite = Suite(%r, %r, (), method_split=(), pythonpath=None, groups={}, packages=FAKE)\n"
            "original = Run.shutdown\n"
            "armed = True\n"
            "def interrupt_during_cleanup(self):\n"
            "    global armed\n"
            "    if armed:\n"
            "        armed = False\n"
            "        os.kill(os.getpid(), signal.SIGINT)\n"
            "    return original(self)\n"
            "Run.shutdown = interrupt_during_cleanup\n"
            "raise SystemExit(main(sys.argv[1:], suite=suite))\n"
            % (str(ROOT), str(self.root), ("tests.test_good",)), encoding="utf-8")
        temp = self.temp()
        child = self.launch(driver, ["--jobs", "1"], temp)
        output = child.communicate(timeout=120)[0].decode("utf-8", "replace")
        self.assertEqual(child.returncode, 130, output)
        self.assertIn("[runner] interrupted by signal 2 during cleanup", output)
        self.assertEqual(sorted(path.name for path in temp.iterdir()), [],
                         "a signal interrupted final result-root cleanup")


class AFailingRunAlsoLeavesNothingBehind(DriverCase):

    def test_the_result_root_is_removed_when_the_suite_fails(self):
        write_tree(self.root, {"test_bad": case_source(self.marks, "Bad", ["test_a"],
                                                       failing=["test_a"])})
        temp = self.temp()
        child = self.launch(self.driver(("tests.test_bad",)), ["--jobs", "1"], temp)
        output = child.communicate(timeout=120)[0].decode("utf-8", "replace")
        self.assertEqual(child.returncode, 1, output)
        self.assertEqual(sorted(path.name for path in temp.iterdir()), [])

    def test_a_refused_run_removes_it_too(self):
        write_tree(self.root, {"test_bad": case_source(self.marks, "Bad", ["test_a"])})
        temp = self.temp()
        child = self.launch(self.driver(("tests.test_bad", "tests.test_ghost")), ["--jobs", "1"], temp)
        output = child.communicate(timeout=120)[0].decode("utf-8", "replace")
        self.assertEqual(child.returncode, 2, output)
        self.assertEqual(sorted(path.name for path in temp.iterdir()), [])

    def test_a_failed_shard_does_not_orphan_a_descendant_when_its_leader_exits(self):
        grandchild = self.marks / "failed-shard-grandchild"
        command = ("import os,pathlib,signal,time; "
                   "signal.signal(signal.SIGTERM, signal.SIG_IGN); "
                   "pathlib.Path(%r).write_text(str(os.getpid()), encoding='utf-8'); "
                   "time.sleep(300)" % str(grandchild))
        source = (PRELUDE % str(self.marks)) + (
            "\n\nclass Bad(unittest.TestCase):\n"
            "    def test_a(self):\n"
            "        subprocess.Popen([sys.executable, '-c', %r])\n"
            "        deadline = time.time() + 30\n"
            "        while time.time() < deadline and not pathlib.Path(%r).exists():\n"
            "            time.sleep(0.05)\n"
            "        self.assertTrue(pathlib.Path(%r).exists())\n"
            "        self.fail('the fake suite failing on purpose')\n"
            % (command, str(grandchild), str(grandchild)))
        write_tree(self.root, {"test_bad": source})
        temp = self.temp()
        child = self.launch(self.driver(("tests.test_bad",)), ["--jobs", "1"], temp)
        output = child.communicate(timeout=120)[0].decode("utf-8", "replace")
        self.assertEqual(child.returncode, 1, output)
        self.assertTrue(grandchild.exists(), "the fake suite never started its grandchild")
        pid = int(grandchild.read_text(encoding="utf-8"))
        self.addCleanup(kill_if_alive, pid)

        deadline = time.monotonic() + 5
        while time.monotonic() < deadline and alive(pid):
            time.sleep(0.05)
        self.assertFalse(alive(pid), f"the failed shard's descendant {pid} survived the run")
        self.assertEqual(sorted(path.name for path in temp.iterdir()), [])


class AShardThatDiesWithoutAReportIsAFailure(FakeTreeCase):
    """The failure mode that would otherwise read as green.

    A shard killed by the kernel — OOM, a segfaulting extension, an external
    `kill` — writes no report. Counting a missing report as "no failures found"
    is how a runner claims success for tests it never ran, so it is a failure
    with the child's own stderr attached.
    """

    def test_a_shard_that_kills_its_own_interpreter_is_reported_as_an_error(self):
        source = (PRELUDE % str(self.marks)) + (
            "\n\nclass Suicide(unittest.TestCase):\n"
            "    def test_a(self):\n"
            "        sys.stderr.write('about to die\\n')\n"
            "        sys.stderr.flush()\n"
            "        os.kill(os.getpid(), 9)\n")
        write_tree(self.root, {"test_suicide": source})
        code, output = self.run_suite(self.suite(("tests.test_suicide",)), ["--jobs", "1"])
        self.assertEqual(code, 1)
        self.assertIn("[FAIL] tests.test_suicide.Suicide", output)
        self.assertIn("about to die", output)


class CollectionRefusesAModuleThatBindsAnotherModulesTests(FakeTreeCase):

    def test_an_imported_test_class_is_named_at_the_module_that_binds_it(self):
        # W384870: `from tests.test_owner import Owner` would make unittest run
        # Owner's cases twice, once under each module. The collector refuses the
        # binding module by name instead of letting the duplicate surface later.
        write_tree(self.root, {"test_owner": case_source(self.marks, "Owner", ["test_a"]),
                               "test_binder": "from tests.test_owner import Owner\n"})
        code, output = self.run_suite(self.suite(("tests.test_owner", "tests.test_binder")), ["--jobs", "1"])
        self.assertEqual(code, 2)
        self.assertIn("tests.test_binder binds test classes defined elsewhere", output)
        self.assertIn("tests.test_owner.Owner", output)


class CollectionRefusesAModuleItCannotLoad(FakeTreeCase):

    def test_an_unimportable_module_stops_the_run_rather_than_becoming_one_failure(self):
        write_tree(self.root, {"test_broken": "import nonexistent_module_w9707\n"})
        code, output = self.run_suite(self.suite(("tests.test_broken",)), ["--jobs", "1"])
        self.assertEqual(code, 2)
        self.assertIn("collecting tests.test_broken failed", output)


if __name__ == "__main__":
    unittest.main()


# -- W384870: the group partition and exact test-identity accounting ---------



class TheGroupsAreAnExactPartitionOfTheRealTree(unittest.TestCase):
    """Every v12 test module in exactly one group, and the carved sets honest."""

    def test_every_registered_module_has_exactly_one_known_group(self):
        suite = Suite(ROOT, PARALLEL_MODULES, SERIAL_MODULES, supervised=SUPERVISED_MODULES)
        suite.check_groups()
        for module in suite.registered():
            with self.subTest(module=module):
                self.assertIn(suite.group_of(module), GROUPS)

    def test_the_carved_groups_are_disjoint_and_registered(self):
        registered = set(PARALLEL_MODULES + SERIAL_MODULES) | {e["module"] for e in SUPERVISED_MODULES}
        seen = {}
        for name, modules in GROUP_MODULES.items():
            self.assertIn(name, GROUPS)
            for module in modules:
                self.assertNotIn(module, seen, f"{module} carved twice: {seen.get(module)} and {name}")
                seen[module] = name
                self.assertIn(module, registered)
        self.assertTrue(set(GROUP_PACKAGES.values()) <= set(GROUPS))

    def test_the_engine_group_is_exactly_the_serial_engine_gates(self):
        serial_engines = tuple(m for m in SERIAL_MODULES if m.startswith(("tests.manager.", "tests.tools.")))
        self.assertEqual(sorted(GROUP_MODULES["manager-engine"]), sorted(serial_engines))
        self.assertEqual(GROUP_MODULES["supervised"], tuple(e["module"] for e in SUPERVISED_MODULES))

    def test_a_module_carved_twice_or_unmapped_is_refused(self):
        with self.assertRaises(RunnerRefusal):
            group_of("tests.x.test_a", {"scans": ("tests.x.test_a",), "supervised": ("tests.x.test_a",)}, {})
        with self.assertRaises(RunnerRefusal):
            group_of("tests.x.test_a", {}, {"tests.y": "authority"})
        self.assertEqual(group_of("tests.y.test_a", {}, {"tests.y": "authority"}), "authority")

    def test_every_optional_skip_names_a_real_test(self):
        for test_id in OPTIONAL_SKIPS:
            with self.subTest(test_id=test_id):
                loaded = list(unittest.TestLoader().loadTestsFromName(test_id))
                self.assertEqual([one.id() for one in loaded], [test_id])

    def test_ids_resolve_to_their_module(self):
        self.assertEqual(module_of("tests.manager.test_x.Klass.test_a"), "tests.manager.test_x")
        self.assertEqual(module_of("setUpClass (tests.manager.test_x.Klass)"), "setUpClass")
        self.assertEqual(base_id("tests.m.test_x.K.test_a (member='x')"), "tests.m.test_x.K.test_a")


class AccountingDerivesPassedFromWhatRan(unittest.TestCase):
    """Pure: collected versus executed, with every outcome subtracted."""

    def report(self, label, executed, **outcomes):
        answer = {"label": label, "executed": executed, "failures": [], "errors": [], "skipped": [],
                  "expected_failures": [], "unexpected_successes": []}
        answer.update(outcomes)
        return answer

    def test_explicit_summary_distinguishes_outcomes_without_changing_ledger(self):
        cases = [
            ('clean', ['a'], [self.report('x', ['a'])], {}, '1 passed, 0 optional skips, 0 failures, 0 errors, 0 unaccounted -> OK', None),
            ('failure', ['a'], [self.report('x', ['a'], failures=[{'id': 'a', 'trace': ''}])], {}, '0 passed, 0 optional skips, 1 failures, 0 errors, 0 unaccounted -> FAILED', None),
            ('error', ['a'], [self.report('x', ['a'], errors=[{'id': 'a', 'trace': ''}])], {}, '0 passed, 0 optional skips, 0 failures, 1 error, 0 unaccounted -> FAILED', None),
            ('missing', ['a'], [], {}, '0 passed, 0 optional skips, 0 failures, 0 errors, 1 unaccounted -> FAILED', '[UNACCOUNTED] a'),
            ('optional', ['a'], [self.report('x', ['a'], skipped=[{'id': 'a', 'reason': 'optional'}])], {'a': 'owner'}, '0 passed, 1 optional skips, 0 failures, 0 errors, 0 unaccounted -> OK', '[optional skip] a'),
            ('required', ['a'], [self.report('x', ['a'], skipped=[{'id': 'a', 'reason': 'required'}])], {}, '0 passed, 0 optional skips, 0 failures, 0 errors, 0 unaccounted -> FAILED', '[REQUIRED SKIP] a'),
            ('duplicate', ['a'], [self.report('x', ['a']), self.report('y', ['a'])], {}, '1 passed, 0 optional skips, 0 failures, 0 errors, 0 unaccounted -> FAILED', '[DUPLICATES] a'),
            ('fixture error', ['a'], [self.report('x', [], errors=[{'id': 'setUpClass (t.K)', 'trace': 'boom'}])], {}, '0 passed, 0 optional skips, 0 failures, 0 errors, 1 unaccounted -> FAILED', '[FIXTURE ERROR] setUpClass (t.K)'),
            ('fixture skip', ['a'], [self.report('x', [], skipped=[{'id': 'setUpClass (t.K)', 'reason': 'no'}])], {}, '0 passed, 0 optional skips, 0 failures, 0 errors, 1 unaccounted -> FAILED', '[FIXTURE SKIP] setUpClass (t.K)'),
        ]
        for name, collected, reports, optional, summary, anomaly in cases:
            with self.subTest(name=name):
                ledger = account(collected, reports, optional=optional)
                before = json.dumps(ledger, sort_keys=True)
                output = io.StringIO()
                present_accounting(ledger, output)
                self.assertIn('[accounting] 1 collected: ' + summary, output.getvalue())
                if anomaly:
                    self.assertIn(anomaly, output.getvalue())
                self.assertEqual(json.dumps(ledger, sort_keys=True), before)

    def test_a_clean_run_is_passed_plus_optional_skips_equals_collected(self):
        ledger = account(["t.a", "t.b", "t.c"], [self.report("x", ["t.a", "t.b"]),
                                                 self.report("y", ["t.c"], skipped=[{"id": "t.c", "reason": "optional"}])],
                         optional={"t.c": "owner said so"})
        self.assertTrue(ledger["ok"])
        self.assertEqual(ledger["passed"], ["t.a", "t.b"])
        self.assertEqual(ledger["optional_skipped"], {"t.c": "optional"})

    def test_a_required_skip_an_unaccounted_id_and_a_duplicate_each_fail(self):
        ledger = account(["t.a", "t.b"], [self.report("x", ["t.a"], skipped=[{"id": "t.a", "reason": "no reason"}])])
        self.assertFalse(ledger["ok"])
        self.assertEqual(ledger["required_skipped"], {"t.a": "no reason"})
        self.assertEqual(ledger["unaccounted"], ["t.b"])
        ledger = account(["t.a"], [self.report("x", ["t.a"]), self.report("y", ["t.a"])])
        self.assertFalse(ledger["ok"])
        self.assertEqual(ledger["duplicates"], ["t.a"])

    def test_a_subtest_failure_fails_its_test_and_a_stray_error_is_visible(self):
        ledger = account(["t.a", "t.b"], [self.report("x", ["t.a", "t.b"],
                                                      failures=[{"id": "t.a (member='p')", "trace": ""}],
                                                      errors=[{"id": "setUpClass (t.K)", "trace": ""}])])
        self.assertFalse(ledger["ok"])
        self.assertEqual(ledger["failed"], ["t.a"])
        self.assertEqual(list(ledger["fixture_errors"]), ["setUpClass (t.K)"])
        self.assertEqual(ledger["stray_errors"], [])
        self.assertEqual(ledger["passed"], ["t.b"])


class AnAccountedRunProvesEveryIdRan(FakeTreeCase):

    def suite(self, parallel, serial=(), optional=None):
        return Suite(self.root, parallel, serial, pythonpath=None, groups={}, packages=FAKE_PACKAGES,
                     optional_skips=optional or {})

    def test_collected_equals_executed_and_the_ledger_is_written(self):
        write_tree(self.root, {"test_one": case_source(self.marks, "One", ["test_a", "test_b"]),
                               "test_two": case_source(self.marks, "Two", ["test_a"])})
        summary = self.root / "ledger.json"
        code, output = self.run_suite(self.suite(("tests.test_one",), serial=("tests.test_two",)),
                                      ["--jobs", "1", "--account", "--summary", str(summary)])
        self.assertEqual(code, 0, output)
        self.assertIn("[accounting] 3 collected: 3 passed, 0 optional skips, 0 failures, 0 errors, 0 unaccounted -> OK", output)
        self.assertIn("[groups] authority=3", output)
        ledger = json.loads(summary.read_text(encoding="utf-8"))
        self.assertEqual(ledger["collected"], ledger["executed"])
        self.assertEqual(ledger["passed"], ["tests.test_one.One.test_a", "tests.test_one.One.test_b",
                                            "tests.test_two.Two.test_a"])

    def test_a_shard_that_dies_leaves_its_ids_unaccounted(self):
        source = case_source(self.marks, "Dies", ["test_a"]).replace(
            "        self.assertTrue(True)", "        os._exit(9)")
        write_tree(self.root, {"test_dies": source, "test_ok": case_source(self.marks, "Ok", ["test_a"])})
        code, output = self.run_suite(self.suite(("tests.test_dies", "tests.test_ok")), ["--jobs", "1", "--account"])
        self.assertEqual(code, 1)
        self.assertIn("[UNACCOUNTED] tests.test_dies.Dies.test_a", output)
        self.assertIn("-> FAILED", output)

    def test_a_skip_is_required_unless_the_registry_says_optional(self):
        source = case_source(self.marks, "Skips", ["test_a"]).replace(
            "        self.assertTrue(True)", "        self.skipTest('needs something')")
        write_tree(self.root, {"test_skips": source})
        code, output = self.run_suite(self.suite(("tests.test_skips",)), ["--jobs", "1", "--account"])
        self.assertEqual(code, 1)
        self.assertIn("[REQUIRED SKIP] tests.test_skips.Skips.test_a: needs something", output)
        optional = {"tests.test_skips.Skips.test_a": "owner classified"}
        code, output = self.run_suite(self.suite(("tests.test_skips",), optional=optional),
                                      ["--jobs", "1", "--account"])
        self.assertEqual(code, 0, output)
        self.assertIn("[optional skip] tests.test_skips.Skips.test_a: needs something", output)
        self.assertIn("1 collected: 0 passed, 1 optional skips, 0 failures, 0 errors, 0 unaccounted -> OK", output)

    def test_keep_going_runs_the_serial_phase_after_a_parallel_failure(self):
        write_tree(self.root, {"test_bad": case_source(self.marks, "Bad", ["test_a"], failing=["test_a"]),
                               "test_serial": case_source(self.marks, "Serial", ["test_a"])})
        code, output = self.run_suite(self.suite(("tests.test_bad",), serial=("tests.test_serial",)),
                                      ["--jobs", "1", "--account", "--keep-going"])
        self.assertEqual(code, 1)
        self.assertNotIn("the serial registry did not run", output)
        self.assertIn("[pass] tests.test_serial", output)
        self.assertIn("Serial.test_a", [name for name, _, _ in self.intervals()])


class AClassFixtureThatNeverStartsItsTestsLeavesThemUnaccounted(FakeTreeCase):
    """B0's first ledger trusted the loaded plan and counted never-started tests
    as passed; and every `setUpClass (...)` skip collapsed into one key."""

    def fixture_module(self, cls, raising):
        return (case_source(self.marks, cls, ["test_a", "test_b"])
                .replace("class %s(unittest.TestCase):" % cls,
                         "class %s(unittest.TestCase):\n    @classmethod\n    def setUpClass(cls):\n"
                         "        raise %s\n" % (cls, raising)))

    def suite(self, parallel, optional=None):
        return Suite(self.root, parallel, (), pythonpath=None, groups={}, packages=FAKE_PACKAGES,
                     optional_skips=optional or {})

    def test_a_class_level_error_leaves_its_tests_unaccounted_and_names_the_fixture(self):
        write_tree(self.root, {"test_broken": self.fixture_module("Broken", "RuntimeError('no fixture')"),
                               "test_ok": case_source(self.marks, "Ok", ["test_a"])})
        code, output = self.run_suite(self.suite(("tests.test_broken", "tests.test_ok")), ["--jobs", "1", "--account"])
        self.assertEqual(code, 1)
        self.assertIn("[FIXTURE ERROR] setUpClass (tests.test_broken.Broken): RuntimeError: no fixture", output)
        self.assertIn("[UNACCOUNTED] tests.test_broken.Broken.test_a", output)
        self.assertIn("[UNACCOUNTED] tests.test_broken.Broken.test_b", output)
        self.assertIn("collected 3, executed 1, passed 1,", output)

    def test_two_class_level_skips_stay_two_events_and_are_required_unless_optional(self):
        write_tree(self.root, {"test_p": self.fixture_module("P", "unittest.SkipTest('the engine is not on PATH')"),
                               "test_q": self.fixture_module("Q", "unittest.SkipTest('the engine is not on PATH')")})
        code, output = self.run_suite(self.suite(("tests.test_p", "tests.test_q")), ["--jobs", "1", "--account"])
        self.assertEqual(code, 1)
        self.assertIn("[FIXTURE SKIP] setUpClass (tests.test_p.P): the engine is not on PATH", output)
        self.assertIn("[FIXTURE SKIP] setUpClass (tests.test_q.Q): the engine is not on PATH", output)
        self.assertIn("fixture skips 2,", output)
        self.assertIn("unaccounted 4", output)
        optional = {"setUpClass (tests.test_p.P)": "owner: engine variant optional",
                    "setUpClass (tests.test_q.Q)": "owner: engine variant optional"}
        code, output = self.run_suite(self.suite(("tests.test_p", "tests.test_q"), optional=optional),
                                      ["--jobs", "1", "--account"])
        self.assertEqual(code, 0, output)
        self.assertIn("[optional skip] tests.test_p.P.test_a: not started: the engine is not on PATH", output)
        self.assertIn("4 collected: 0 passed, 4 optional skips, 0 failures, 0 errors, 0 unaccounted -> OK", output)


class SubtestOutcomesBindToTheirParent(FakeTreeCase):
    """Review R1: `test [message]`, `test (param=…)` and `test [message] (param=…)`
    outcomes are the PARENT's, bound by structure, never by cutting text."""

    def source(self):
        return (PRELUDE % str(self.marks) + "\n\n"
                "class Sub(unittest.TestCase):\n"
                "    def test_message_failure(self):\n"
                "        with self.subTest('named diagnostic'):\n"
                "            self.fail('message-only subtest fails')\n"
                "    def test_parameter_error(self):\n"
                "        with self.subTest(member='x'):\n"
                "            raise RuntimeError('parameters-only subtest errors')\n"
                "    def test_both_skip(self):\n"
                "        with self.subTest('why', member='y'):\n"
                "            self.skipTest('message-plus-parameters subtest skips')\n"
                "    def test_passes(self):\n"
                "        with self.subTest('fine'):\n"
                "            self.assertTrue(True)\n")

    def test_no_synthetic_id_and_no_passed_parent(self):
        write_tree(self.root, {"test_sub": self.source()})
        summary = self.root / "ledger.json"
        code, output = self.run_suite(self.suite(("tests.test_sub",)),
                                      ["--jobs", "1", "--account", "--summary", str(summary)])
        self.assertEqual(code, 1)
        ledger = json.loads(summary.read_text(encoding="utf-8"))
        self.assertEqual(ledger["failed"], ["tests.test_sub.Sub.test_message_failure"])
        self.assertEqual(ledger["errors"], ["tests.test_sub.Sub.test_parameter_error"])
        self.assertEqual(list(ledger["required_skipped"]), ["tests.test_sub.Sub.test_both_skip"])
        self.assertEqual(ledger["passed"], ["tests.test_sub.Sub.test_passes"])
        self.assertEqual(ledger["stray_errors"], [])
        self.assertEqual(ledger["uncollected"], [])
        self.assertEqual(ledger["fixture_errors"], {})
        self.assertEqual(ledger["fixture_skipped"], {})
        # The diagnostics keep the subtest's own identity.
        self.assertIn("=== FAILURE: tests.test_sub.Sub.test_message_failure [named diagnostic] ===", output)
        self.assertIn("message-only subtest fails", output)
        self.assertIn("collected 4, executed 4, passed 1,", output)

    def test_subjects_are_read_from_the_result_objects(self):
        from tools.parallel_test import subject, subject_of
        class K(unittest.TestCase):
            def test_a(self):
                pass
        parent = K("test_a")
        sub = unittest.case._SubTest(parent, "named diagnostic", {"member": "x"})
        self.assertEqual(subject_of(sub), {"id": sub.id(), "parent": parent.id(), "fixture": False})
        self.assertEqual(subject_of(parent), {"id": parent.id(), "parent": parent.id(), "fixture": False})
        holder = unittest.suite._ErrorHolder("setUpClass (tests.x.K)")
        self.assertEqual(subject_of(holder), {"id": "setUpClass (tests.x.K)", "parent": None, "fixture": True})
        # A report entry without structure falls back to the text rule.
        self.assertEqual(subject({"id": "tests.m.K.test_a [msg] (member='x')"}), ("tests.m.K.test_a", False))
        self.assertEqual(subject({"id": "setUpClass (tests.m.K)"}), (None, True))


class AGroupSelectsExactlyItsModules(FakeTreeCase):

    def test_a_group_runs_its_modules_and_an_unknown_group_refuses(self):
        write_tree(self.root, {"test_one": case_source(self.marks, "One", ["test_a"]),
                               "test_two": case_source(self.marks, "Two", ["test_a"])})
        suite = Suite(self.root, ("tests.test_one", "tests.test_two"), (), pythonpath=None,
                      groups={"scans": ("tests.test_two",)}, packages=FAKE_PACKAGES)
        code, output = self.run_suite(suite, ["--jobs", "1", "--group", "scans", "--account"])
        self.assertEqual(code, 0, output)
        self.assertIn("[group] scans: 1 parallel, 0 serial, 0 supervised modules", output)
        self.assertEqual([name for name, _, _ in self.intervals()], ["Two.test_a"])
        code, output = self.run_suite(suite, ["--jobs", "1", "--group", "nope"])
        self.assertEqual(code, 2)
        self.assertIn("unknown group", output)

    def test_the_registry_is_checked_before_the_group_narrows_it(self):
        write_tree(self.root, {"test_one": case_source(self.marks, "One", ["test_a"]),
                               "test_stranger": case_source(self.marks, "Stranger", ["test_a"])})
        suite = Suite(self.root, ("tests.test_one",), (), pythonpath=None, groups={}, packages=FAKE_PACKAGES)
        code, output = self.run_suite(suite, ["--jobs", "1", "--group", "authority"])
        self.assertEqual(code, 2)
        self.assertIn("belong to no registry", output)


# -- W384870 R2: every record path a test reads is declared or synthetic --

def _string_chain(node):
    """The string constants of a `/` chain, left to right; None for a non-constant."""
    if isinstance(node, ast.Constant) and isinstance(node.value, str):
        return [node.value]
    if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Div):
        return _string_chain(node.left) + _string_chain(node.right)
    return [None]


def _record_path(parts):
    """`work/records/...` joined from the first part that names it through the
    last consecutive constant, or None when no part does."""
    for index, part in enumerate(parts):
        if part is None:
            continue
        if "work/records" in part or (part == "work" and parts[index + 1:index + 2] == ["records"]):
            tail = []
            for later in parts[index:]:
                if later is None:
                    break
                tail.append(later)
            text = "/".join(tail)
            return text[text.index("work/records"):]
    return None


def record_paths(source):
    """Every repository record path a module names in code: a string constant,
    a `pathlib` `/` chain or an `os.path.join` call whose constants spell
    `work/records/...`. Docstrings are prose and are skipped; comments never
    reach the AST. A constant inside a chain or join is reported once, joined."""
    tree = ast.parse(source.read_text(encoding="utf-8"), filename=str(source))
    skip = set()
    for node in ast.walk(tree):
        if isinstance(node, (ast.Module, ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)):
            body = node.body
            if body and isinstance(body[0], ast.Expr) and isinstance(body[0].value, ast.Constant):
                skip.add(id(body[0].value))
    found = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Div) and id(node) not in skip:
            for inner in ast.walk(node):
                if inner is not node:
                    skip.add(id(inner))
            joined = _record_path(_string_chain(node))
        elif isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) and node.func.attr == "join":
            for inner in node.args:
                skip.add(id(inner))
            joined = _record_path([one.value if isinstance(one, ast.Constant) and isinstance(one.value, str) else None
                                   for one in node.args])
        else:
            continue
        if joined:
            found.add(joined)
    for node in ast.walk(tree):
        if isinstance(node, ast.Constant) and isinstance(node.value, str) and id(node) not in skip and "work/records" in node.value:
            found.add(node.value[node.value.index("work/records"):])
    # `work/records/YYYY/MM/finding-x` is the shortest path that can name a
    # record; anything shorter is a root or a prefix check, not an input.
    return {one for one in found if one.count("/") >= 4}


# Record paths the test tree names WITHOUT reading them from this checkout:
# forbidden words, synthetic documents, references created inside a case's own
# temporary repository, fake registry entries. Each is exact. A new literal
# lands here only with a reason, or in CONSUMED_INPUTS when the run reads it.
SYNTHETIC_RECORD_PATHS = {
    # test_pool.record_in, test_bootstrap.composed_for and test_connected_creation
    # write FINDING.md/PLAN.md themselves in disposable checkouts, not from this tree.
    "work/records/2026/08/finding-v12-work-tags/findings/finding-v12-work-label-protocol-cli",
    # W385695: the publication-recovery cases (test_bootstrap's publisher fixture and
    # test_publication_recovery_execution's pooled fixture) bind a Work to this record
    # LOCATOR and write its FINDING.md/PLAN.md themselves inside their own disposable
    # checkout; nothing is read from this tree's dossier of the same name.
    "work/records/2026/11/finding-v12-output-publication-recovery",
    # the runner's supervisor-locator grammar, a pattern rather than a path
    r"work/records/[0-9]{4}/(?:0[1-9]|1[0-2])/(?:[A-Za-z0-9_.-]+/)+[A-Za-z0-9_.-]+\.py",
    # a reference each dossier case creates inside its own temporary repository
    "work/records/2026/10/finding-v12-pilot-dossier-binding/FINDING.md",
    # the disposition command cases' temporary repository
    "work/records/2026/10/finding-pilot",
    "work/records/2026/10/finding-pilot/INTEGRATION.json",
    "work/records/2026/10/finding-pilot/INTEGRATION-2.json",
    "work/records/2026/10/finding-pilot/LINKED.json",
    "work/records/2026/10/finding-pilot/OTHER.json",
    # synthetic contract documents of the dogfood operator cases
    "work/records/2026/08/finding-v12-first-useful-dogfood-task",
    "work/records/2026/08/finding-v12-first-useful-dogfood-task/evidence/first-task.md",
    # fake supervised-registry entries of this module's own cases
    "work/records/2026/09/finding-example/engine-gate.py",
    "work/records/2026/09/../gate.py",
}


class TheDeclaredInputsCoverWhatTheTestsRead(unittest.TestCase):
    """CONSUMED_INPUTS is complete against the tree, mechanically.

    The declaration is the identity's boundary (`tools.source_identity
    --declared`), so a record path a test reads but nobody declared would be
    the R2 defect again: a run whose tested bytes can change without its
    identity changing. This sweep names every record path the tests and tools
    spell in code and requires each to be declared or listed as synthetic.
    """

    def declared(self):
        return consumed_inputs()

    def covered(self, path):
        for declared in self.declared():
            if path == declared or path.startswith(declared + "/"):
                return True
            # a dossier directory a test keeps (RECORD / "x.json" later) whose consumed file is declared
            if declared.startswith(path + "/") and path.count("/") >= 4:
                return True
        return False

    def test_every_record_path_in_the_tree_is_declared_or_synthetic(self):
        sources = sorted(list((ROOT / "tests").rglob("*.py")) + list((ROOT / "tools").glob("*.py")))
        self.assertGreater(len(sources), 150)
        undeclared, seen = {}, set()
        for source in sources:
            for path in record_paths(source):
                seen.add(path)
                if not self.covered(path) and path not in SYNTHETIC_RECORD_PATHS:
                    undeclared.setdefault(path, []).append(source.relative_to(ROOT).as_posix())
        self.assertEqual(undeclared, {}, "declare these in CONSUMED_INPUTS, or list them as synthetic with a reason")
        self.assertEqual(sorted(SYNTHETIC_RECORD_PATHS - seen), [], "a synthetic entry nobody spells any more is stale")
        for path in SYNTHETIC_RECORD_PATHS:
            self.assertFalse(self.covered(path), f"{path} is declared AND listed as synthetic; it is one or the other")

    def test_the_sweep_reads_the_three_spellings_and_skips_prose(self):
        # Spelled in two halves so that the sweep over THIS module does not read the probe.
        root = "work/" + "records"
        with tempfile.TemporaryDirectory(prefix="v12-record-sweep-") as home:
            source = pathlib.Path(home, "probe.py")
            source.write_text(
                f'"""{root}/2026/01/finding-doc/PROSE.md is prose."""\n'
                'import os, pathlib\n'
                'REPO = pathlib.Path("/r")\n'
                f'A = "{root}/2026/01/finding-a/a.json"\n'
                'B = REPO / "work" / "records" / "2026" / "01" / "finding-b" / "b.json"\n'
                f'C = os.path.join(str(REPO), "{root}/2026/01", "finding-c", "c.json")\n'
                f'D = "baton:{root}/2026/01/finding-d/d.py"\n'
                'def f():\n'
                f'    """{root}/2026/01/finding-doc/ALSO-PROSE.md"""\n'
                '    return REPO / "work" / "records" / "2026" / "01" / "finding-e"\n', encoding="utf-8")
            self.assertEqual(record_paths(source), {
                f"{root}/2026/01/finding-a/a.json", f"{root}/2026/01/finding-b/b.json",
                f"{root}/2026/01/finding-c/c.json", f"{root}/2026/01/finding-d/d.py",
                f"{root}/2026/01/finding-e"})

    def test_every_declared_input_names_its_consumers_and_is_not_a_whole_dossier(self):
        for entry in CONSUMED_INPUTS:
            self.assertTrue(entry["consumers"], entry["path"])
            self.assertTrue((ROOT.parents[1] / entry["path"]).exists(), entry["path"])
            self.assertFalse(entry["path"].startswith(("/", "v12/")) or ".." in entry["path"].split("/"), entry["path"])
            if not entry["path"].startswith("work/"):
                # W385853 review R1: TESTING.md sections 6 and 9 require every
                # input outside `v12/` to be declared, not only Work records.
                # A repository document is declared as the one exact FILE.
                self.assertTrue((ROOT.parents[1] / entry["path"]).is_file(), f"{entry['path']} is not one exact file")
                continue
            self.assertTrue(entry["path"].startswith("work/records/20"), entry["path"])
            self.assertGreaterEqual(entry["path"].count("/"), 5, f"{entry['path']} is a whole dossier, not the consumed file or import path")
        self.assertEqual(len({entry["path"] for entry in CONSUMED_INPUTS}), len(CONSUMED_INPUTS), "declared twice")
